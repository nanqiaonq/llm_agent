# FF-OpenHermes · 会自我进化的教学版 Agent

一个用来**亲眼观察 AI Agent 自我成长**的最小可运行项目。后端 `FastAPI` + 前端 `Next.js`，本地就能跑起来。

它最值得看的是两件别的对话工具看不到的事：

- **自生成**：Agent 不只是回答问题，它会把对话里有价值的经验**自己沉淀成"技能"**存进技能库——而且分得清哪些是「你教它的」、哪些是「它自己学的」。
- **自进化**：当它自己学的技能攒多了、出现重复，它会**自己合并整理**技能库——但只动它自己学的，绝不碰你手工教它的。

> 想直接看效果：装好后打开技能页，本包内置了两个**案例会话**——「自生成演示」和「自治理演示」，切过去就能看到上面两件事的真实结果。配套讲解见 `操作体验指南-两大核心功能.md` 和 `讲解-自生成与自进化机制.md`。

---

## 一、环境要求

| 组件 | 版本 | 说明 |
|------|------|------|
| Python | 3.10+（推荐 3.11） | 后端，LangChain 1.x 需要 |
| Node.js | 18+（推荐 20） | 前端 |
| 一个 OpenRouter API Key | — | 用来调用大模型，下面第三步讲怎么拿 |

---

## 二、启动后端（`backend/`）

```bash
cd backend

# 1) 创建并激活虚拟环境（venv；如习惯 conda 见文末备选）
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 2) 安装依赖
pip install -r requirements.txt

# 3) 准备配置文件（把模板复制成正式配置）
cp .env.example .env
#    然后编辑 .env，填入你的 API Key（见第三节）

# 4) 启动后端（默认端口 8003）
uvicorn app:app --host 127.0.0.1 --port 8003
```

看到 `FF-OpenHermes backend ready` 就成功了。浏览器访问 <http://127.0.0.1:8003> 应返回 `{"status":"running"}`。

---

## 三、配置 API Key（关键一步）

本项目通过 **OpenRouter**（一个大模型聚合服务）调用模型，默认用性价比很高的 `deepseek/deepseek-chat-v3.1`。

1. 打开 <https://openrouter.ai>，注册并在 **Keys** 页面创建一个 Key（形如 `sk-or-v1-xxxxxxxx`）。
2. 打开 `backend/.env`，把 Key 填进去：

   ```ini
   OPENROUTER_API_KEY=sk-or-v1-你的真实key
   OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
   OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1
   ```

3. （演示建议）想更快看到「自生成」效果，把这一项调小：

   ```ini
   # 每 N 轮对话，后台就自动复盘一次、决定要不要自己存技能。默认 5；演示设 2 更快出效果
   MEMORY_REFLECTION_INTERVAL=2
   ```

> `.env` 是你的私密文件，**不要分享、不要提交到 Git**。本包只附带了不含真实 Key 的 `.env.example` 模板。

---

## 四、启动前端（`frontend/`）

新开一个终端：

```bash
cd frontend

# 1) 安装依赖
npm install

# 2) 准备配置（默认就指向后端 8003，一般无需改动）
cp .env.local.example .env.local

# 3) 启动前端（默认端口 3000）
npm run dev
```

浏览器打开 <http://localhost:3000>。

---

## 五、第一次对话（验证一切正常）

1. 确认后端（8003）和前端（3000）都已启动，且 `backend/.env` 里填了有效的 OpenRouter Key。
2. 在前端页面点「新建」开一个会话，在对话框输入任意问题，比如「你好，帮我写一个 Python 冒泡排序」。
3. 能看到流式回复，就说明前后端 + 模型链路全通了。

---

## 六、体验两大核心功能

详细的图文步骤（含每一步该敲什么提示词、屏幕会变成什么样）在：

- **`操作体验指南-两大核心功能.md`** —— 跟着做，亲手复现「自生成」和「自进化」
- **`讲解-自生成与自进化机制.md`** —— 想搞懂背后原理时读这份

最快的方式：打开左栏「技能」页，用顶部的会话切换器切到内置的两个案例会话——

| 案例会话 | 看点 |
|----------|------|
| **自生成演示** | 技能库里同时有 🟦「你教的」`conda-deploy` 和 🟩「它自学的」`pg-query-degradation` |
| **自治理演示** | 三个相似技能被自动合并成一个 🟩`write-structured-content`，而 🟦`my-precious` 原封不动 |

---

## 七、配置项说明（`backend/.env`）

| 配置项 | 默认值 | 作用 |
|--------|--------|------|
| `OPENROUTER_API_KEY` | 空（必填） | OpenRouter 的 API Key |
| `OPENROUTER_BASE_URL` | `https://openrouter.ai/api/v1` | OpenRouter 接口地址 |
| `OPENROUTER_MODEL` | `deepseek/deepseek-chat-v3.1` | 用哪个模型 |
| `MEMORY_REFLECTION_INTERVAL` | `5` | 每几轮对话后台自动复盘一次（自生成触发频率），演示可设 `2` |
| `HOST` / `PORT` | `127.0.0.1` / `8003` | 后端监听地址 |
| `CORS_ORIGINS` | `http://localhost:3000` | 允许的前端来源，前端换端口时要同步改 |
| `TAVILY_API_KEY` | 空（可选） | 联网搜索工具，不填则不影响主流程 |

---

## 八、常见问题

- **对话报错 / 没有回复**：99% 是 `backend/.env` 的 `OPENROUTER_API_KEY` 没填或无效。确认 Key 正确、账户有额度。
- **某些模型返回 403**：OpenRouter 上部分 anthropic/openai/google 模型对某些地区/IP 有限制；保持默认的 `deepseek/...` 模型即可，最稳。
- **前端连不上后端 / 跨域报错**：确认后端在 8003、前端在 3000；若改了端口，需同步改 `backend/.env` 的 `CORS_ORIGINS` 和 `frontend/.env.local` 的 `NEXT_PUBLIC_API_BASE`。
- **端口被占用**：换端口启动（如 `--port 8004`），并同步上一条提到的两个配置。

---

## 九、项目结构

```
FF-OpenHermes-dist/
├── README.md                          ← 本文件
├── 操作体验指南-两大核心功能.md         ← 图文操作步骤（含截图）
├── 讲解-自生成与自进化机制.md           ← 原理讲解
├── 演示截图/                           ← 配套截图
├── backend/                           ← FastAPI 后端
│   ├── app.py                         ← 启动入口（uvicorn app:app）
│   ├── config.py / requirements.txt
│   ├── .env.example                   ← 配置模板（复制成 .env 再填 Key）
│   ├── agent/  api/  skill_engine/  tools/   ← 核心代码
│   ├── skills_global/                 ← 出厂预置技能
│   ├── sessions/                      ← 内置两个案例会话（自生成/自治理演示）
│   └── tests/                         ← 测试
└── frontend/                          ← Next.js 前端
    ├── src/                           ← 页面与组件
    ├── package.json
    └── .env.local.example
```

---

## 备选：用 conda 代替 venv

```bash
cd backend
conda create -n ff-openhermes python=3.11 -y
conda activate ff-openhermes
pip install -r requirements.txt
# 之后的 .env 配置与启动命令同上
```
