"use client";
import { useState } from "react";
import Link from "next/link";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";
import PageHeader from "@/components/layout/PageHeader";

export default function DistillPage() {
  const sid = useSessionStore((s) => s.activeSid);
  const distill = useSkillStore((s) => s.distill);

  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ created: boolean; name?: string; reason?: string } | null>(null);

  if (!sid) return <div className="p-6 text-text-muted">请先选择一个会话。</div>;

  const handleDistill = async (source: "history" | "text") => {
    if (loading) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await distill(sid, source === "text" ? { source, text } : { source });
      setResult({ created: res.created, name: res.name, reason: res.reason });
    } catch (e) {
      setResult({ created: false, reason: e instanceof Error ? e.message : String(e) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-2xl space-y-5">
      <PageHeader title="蒸馏技能" description="从对话内容中提炼可复用技能，自动命名并加入技能库。" />

      <div className="space-y-2">
        <label className="block text-sm text-text-primary">
          粘贴对话内容
        </label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="粘贴对话文本，或留空后点击「用本会话历史」…"
          rows={8}
          className="w-full px-3 py-2 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary resize-y focus:outline-none focus:ring-1 focus:ring-accent-primary"
        />
      </div>

      <div className="flex gap-3">
        <button
          disabled={loading}
          onClick={() => handleDistill("history")}
          className="px-4 py-2 text-sm rounded-lg border border-border-subtle hover:bg-bg-elevated text-text-primary disabled:opacity-40 transition-colors"
        >
          {loading ? "蒸馏中…" : "用本会话历史"}
        </button>
        <button
          disabled={loading || !text.trim()}
          onClick={() => handleDistill("text")}
          className="px-4 py-2 text-sm rounded-lg bg-accent-primary text-white disabled:opacity-40 hover:opacity-90 transition-opacity"
        >
          {loading ? "蒸馏中…" : "蒸馏"}
        </button>
      </div>

      {result && (
        <div
          className={`rounded-lg px-4 py-3 text-sm border ${
            result.created
              ? "bg-ok/10 border-ok/30 text-ok"
              : "bg-warn/10 border-warn/30 text-warn"
          }`}
        >
          {result.created ? (
            <span>
              已生成技能：<strong>{result.name}</strong>
              {"　"}
              <Link href="/skills" className="underline underline-offset-2 hover:opacity-80">
                前往「技能」页查看
              </Link>
            </span>
          ) : (
            <span>未生成技能：{result.reason ?? "未知原因"}</span>
          )}
        </div>
      )}
    </div>
  );
}
