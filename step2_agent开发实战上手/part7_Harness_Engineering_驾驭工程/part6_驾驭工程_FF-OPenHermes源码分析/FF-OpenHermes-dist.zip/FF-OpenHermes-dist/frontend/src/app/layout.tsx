import "./globals.css";
import type { Metadata } from "next";
import Header from "@/components/layout/Header";
import AppShell from "@/components/layout/AppShell";

export const metadata: Metadata = {
  title: "FF-OpenHermes",
  description: "Self-evolving Agent · Chat + Memory + Skills",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <body className="h-screen flex flex-col bg-bg-primary text-text-primary">
        <Header />
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
