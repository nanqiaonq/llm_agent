import ChatPanel from "@/components/chat/ChatPanel";
import RightPanel from "@/components/chat/RightPanel";

export default function ChatPage() {
  return (
    <div className="h-full flex flex-row overflow-hidden">
      <div className="flex-1 min-w-0 h-full">
        <ChatPanel />
      </div>
      <RightPanel />
    </div>
  );
}
