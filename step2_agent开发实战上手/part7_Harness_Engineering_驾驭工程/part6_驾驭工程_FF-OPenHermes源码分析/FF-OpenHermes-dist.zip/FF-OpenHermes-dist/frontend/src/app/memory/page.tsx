"use client";
import { useEffect } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useMemoryStore } from "@/stores/memoryStore";
import MemoryLayerCards from "@/components/memory/MemoryLayerCards";
import SoulMemoryEditor from "@/components/memory/SoulMemoryEditor";
import SessionHistoryView from "@/components/memory/SessionHistoryView";

export default function MemoryPage() {
  const sid = useSessionStore((s) => s.activeSid);
  const tab = useMemoryStore((s) => s.activeTab);
  const loadAll = useMemoryStore((s) => s.loadAll);

  useEffect(() => {
    if (sid) void loadAll(sid);
  }, [sid, loadAll]);

  if (!sid) return <div className="p-6 text-text-muted">请先选择一个会话。</div>;

  return (
    <div className="h-full flex flex-col p-6 gap-4">
      <MemoryLayerCards />
      <div className="flex-1 min-h-0">
        {tab === "soul" && <SoulMemoryEditor field="soul" />}
        {tab === "memory" && <SoulMemoryEditor field="memory" />}
        {tab === "history" && <SessionHistoryView />}
      </div>
    </div>
  );
}
