"use client";
import { useEffect, useState } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";
import SkillLibrary from "@/components/skills/SkillLibrary";
import SkillDetail from "@/components/skills/SkillDetail";
import EvolutionLog from "@/components/skills/EvolutionLog";
import NewSkillModal from "@/components/skills/NewSkillModal";

export default function SkillsPage() {
  const sid = useSessionStore((s) => s.activeSid);
  const loadAll = useSkillStore((s) => s.loadAll);
  const [newOpen, setNewOpen] = useState(false);

  useEffect(() => {
    if (sid) void loadAll(sid);
  }, [sid, loadAll]);

  useEffect(() => {
    const h = () => setNewOpen(true);
    window.addEventListener("ff-open-new-skill", h);
    return () => window.removeEventListener("ff-open-new-skill", h);
  }, []);

  if (!sid) return <div className="p-6 text-text-muted">请先选择一个会话。</div>;

  return (
    <div className="h-full flex">
      <SkillLibrary />
      <SkillDetail />
      <EvolutionLog />
      <NewSkillModal open={newOpen} onClose={() => setNewOpen(false)} />
    </div>
  );
}
