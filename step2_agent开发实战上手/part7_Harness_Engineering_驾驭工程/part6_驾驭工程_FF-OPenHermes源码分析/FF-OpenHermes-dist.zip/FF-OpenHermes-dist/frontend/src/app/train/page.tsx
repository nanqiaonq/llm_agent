"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";
import { useTrainStream } from "@/hooks/useTrainStream";
import PageHeader from "@/components/layout/PageHeader";
import type { TrainingTask, TrainRoundComplete, TrainActor, TrainDone } from "@/types/api";

// ─── SVG Sparkline ────────────────────────────────────────────────────────────

function PassRateCurve({ points }: { points: number[] }) {
  const W = 320;
  const H = 120;
  const PAD_L = 32;
  const PAD_R = 12;
  const PAD_T = 14;
  const PAD_B = 20;
  const innerW = W - PAD_L - PAD_R;
  const innerH = H - PAD_T - PAD_B;

  if (points.length === 0) {
    return (
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full max-w-sm">
        <text x={W / 2} y={H / 2} textAnchor="middle" fontSize="11" fill="currentColor" className="text-text-muted opacity-50">
          等待第一轮结果…
        </text>
      </svg>
    );
  }

  // x maps round index (0-based) to pixel
  const xOf = (i: number) =>
    PAD_L + (points.length === 1 ? innerW / 2 : (i / (points.length - 1)) * innerW);
  // y maps pass_rate (0-1) to pixel (inverted: 0 at bottom)
  const yOf = (v: number) => PAD_T + innerH * (1 - v);

  const polyline = points.map((v, i) => `${xOf(i)},${yOf(v)}`).join(" ");

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full max-w-sm">
      {/* y=0% reference */}
      <line
        x1={PAD_L} y1={yOf(0)} x2={W - PAD_R} y2={yOf(0)}
        stroke="currentColor" strokeWidth="0.5" strokeDasharray="3 3" className="text-border-subtle opacity-60"
      />
      {/* y=100% reference */}
      <line
        x1={PAD_L} y1={yOf(1)} x2={W - PAD_R} y2={yOf(1)}
        stroke="currentColor" strokeWidth="0.5" strokeDasharray="3 3" className="text-border-subtle opacity-60"
      />
      {/* y-axis labels */}
      <text x={PAD_L - 4} y={yOf(1) + 4} textAnchor="end" fontSize="9" fill="currentColor" className="opacity-50">100%</text>
      <text x={PAD_L - 4} y={yOf(0) + 1} textAnchor="end" fontSize="9" fill="currentColor" className="opacity-50">0%</text>

      {/* Polyline */}
      <polyline
        points={polyline}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        className="text-accent-primary"
      />

      {/* Data points + labels */}
      {points.map((v, i) => (
        <g key={i}>
          <circle cx={xOf(i)} cy={yOf(v)} r="3" fill="currentColor" className="text-accent-primary" />
          <text
            x={xOf(i)}
            y={yOf(v) - 6}
            textAnchor="middle"
            fontSize="9"
            fill="currentColor"
            className="text-text-secondary opacity-80"
          >
            {Math.round(v * 100)}%
          </text>
        </g>
      ))}
    </svg>
  );
}

// ─── Round Card ───────────────────────────────────────────────────────────────

function RoundCard({
  round,
  actor,
  convergedAt,
}: {
  round: TrainRoundComplete;
  actor?: TrainActor;
  convergedAt?: number;
}) {
  const [reflOpen, setReflOpen] = useState(false);
  const isConverged = convergedAt === round.n;

  return (
    <div className="rounded-lg bg-bg-elevated border border-border-subtle px-4 py-3 space-y-2 text-sm">
      {/* header */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="font-medium text-text-primary">第 {round.n} 轮</span>
        <span className="text-text-secondary">·</span>
        <span className="font-semibold text-accent-primary">{Math.round(round.pass_rate * 100)}%</span>
        <span className="text-text-secondary">·</span>
        <span className="text-text-muted text-xs">v{round.version}</span>
        {isConverged && (
          <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-ok/15 text-ok border border-ok/25">
            已收敛
          </span>
        )}
      </div>

      {/* added rules */}
      {round.added.length > 0 && (
        <ul className="space-y-0.5">
          {round.added.map((r, i) => (
            <li key={i} className="text-ok text-xs">+ {r}</li>
          ))}
        </ul>
      )}

      {/* removed rules */}
      {round.removed.length > 0 && (
        <ul className="space-y-0.5">
          {round.removed.map((r, i) => (
            <li key={i} className="text-text-muted text-xs">− {r}</li>
          ))}
        </ul>
      )}

      {/* rationale */}
      <p className="text-text-secondary text-xs leading-relaxed">{round.rationale}</p>

      {/* actor reflection (collapsible) */}
      {actor?.reflection && (
        <div>
          <button
            onClick={() => setReflOpen((o) => !o)}
            className="text-xs text-text-muted hover:text-text-secondary transition-colors"
          >
            {reflOpen ? "▲ 收起 Actor 反思" : "▼ 展开 Actor 反思"}
          </button>
          {reflOpen && (
            <p className="mt-1 text-xs text-text-muted leading-relaxed border-l-2 border-border-subtle pl-2">
              {actor.reflection}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

interface TaskRow {
  id: string;
  title: string;
  prompt: string;
}

export default function TrainPage() {
  const sid = useSessionStore((s) => s.activeSid);
  const skills = useSkillStore((s) => s.skills);
  const loadAll = useSkillStore((s) => s.loadAll);

  // Task counter — stable across renders, no Date.now/Math.random.
  // 初始任务行已占用 t1，新增从 t2 起，避免与初始行 id 撞车。
  const taskCounter = useRef(2);

  const makeId = () => {
    const id = `t${taskCounter.current}`;
    taskCounter.current += 1;
    return id;
  };

  const [selectedSkill, setSelectedSkill] = useState("");
  const [tasks, setTasks] = useState<TaskRow[]>([{ id: "t1", title: "", prompt: "" }]);
  const [passCriteria, setPassCriteria] = useState("");
  const [maxRounds, setMaxRounds] = useState(5);
  const [targetPassRate, setTargetPassRate] = useState(1.0);

  // Results state
  const [rounds, setRounds] = useState<TrainRoundComplete[]>([]);
  const [actors, setActors] = useState<Map<number, TrainActor>>(new Map());
  const [convergedAt, setConvergedAt] = useState<number | undefined>(undefined);
  const [done, setDone] = useState<TrainDone | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [curve, setCurve] = useState<number[]>([]);

  // Load session skills on mount
  useEffect(() => {
    if (sid && skills.length === 0) void loadAll(sid);
  }, [sid, loadAll, skills.length]);

  const sessionSkills = skills.filter((s) => s.scope === "session");

  const handleEvent = useCallback((event: string, data: unknown) => {
    if (event === "round_complete") {
      const d = data as TrainRoundComplete;
      setRounds((prev) => [...prev, d]);
      setCurve((prev) => [...prev, d.pass_rate]);
    } else if (event === "actor") {
      const d = data as TrainActor;
      setActors((prev) => {
        const next = new Map(prev);
        next.set(d.n, d);
        return next;
      });
    } else if (event === "converged") {
      const d = data as { n: number; pass_rate: number; version: string };
      setConvergedAt(d.n);
    } else if (event === "done") {
      setDone(data as TrainDone);
    } else if (event === "error") {
      const d = data as { message: string };
      setError(d.message);
    }
    // round_start: no-op (could add visual indicator)
  }, []);

  const { start, abort, running } = useTrainStream(handleEvent);

  // 组件卸载时中止进行中的训练 SSE，避免连接泄漏（训练中途离开页面）
  useEffect(() => () => abort(), [abort]);

  if (!sid) return <div className="p-6 text-text-muted">请先选择一个会话。</div>;

  // ── Task editing helpers ──

  const addTask = () => {
    if (tasks.length >= 10) return;
    setTasks((prev) => [...prev, { id: makeId(), title: "", prompt: "" }]);
  };

  const removeTask = (idx: number) => {
    setTasks((prev) => prev.filter((_, i) => i !== idx));
  };

  const updateTask = (idx: number, field: "title" | "prompt", value: string) => {
    setTasks((prev) => prev.map((t, i) => (i === idx ? { ...t, [field]: value } : t)));
  };

  // ── Validation & start ──

  const validationError = (() => {
    if (!selectedSkill) return "请选择一个技能";
    const nonEmpty = tasks.filter((t) => t.title.trim() || t.prompt.trim());
    if (nonEmpty.length === 0) return "请至少填写一个任务";
    if (passCriteria.trim().length < 8) return "评判标准至少 8 个字";
    return null;
  })();

  const handleStart = () => {
    if (validationError || running) return;
    // Reset results
    setRounds([]);
    setActors(new Map());
    setConvergedAt(undefined);
    setDone(null);
    setError(null);
    setCurve([]);

    const taskSet: TrainingTask[] = tasks
      .filter((t) => t.title.trim() || t.prompt.trim())
      .map((t) => ({ id: t.id, title: t.title.trim(), prompt: t.prompt.trim() }));

    start(sid, selectedSkill, {
      task_set: taskSet,
      pass_criteria: passCriteria.trim(),
      max_rounds: maxRounds,
      target_pass_rate: targetPassRate,
    });
  };

  return (
    <div className="p-6 max-w-2xl space-y-6">
      {/* Title */}
      <PageHeader title="训练技能" description="多轮迭代提升技能质量——每轮 Actor 自评 + Curator 打补丁，实时看 passRate 曲线。" />

      {/* Skill selector */}
      <div className="space-y-1.5">
        <label className="block text-sm text-text-primary">选择技能</label>
        {sessionSkills.length === 0 ? (
          <p className="text-sm text-text-muted">
            请先在「技能」或「蒸馏技能」页生成一个本会话技能。
          </p>
        ) : (
          <select
            value={selectedSkill}
            onChange={(e) => setSelectedSkill(e.target.value)}
            disabled={running}
            className="w-full px-3 py-2 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary focus:outline-none focus:ring-1 focus:ring-accent-primary disabled:opacity-40"
          >
            <option value="">— 选择一个本会话技能 —</option>
            {sessionSkills.map((s) => (
              <option key={s.name} value={s.name}>
                {s.name} (v{s.version})
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Task set editor */}
      <div className="space-y-2">
        <label className="block text-sm text-text-primary">
          任务集（1–10 条）
        </label>
        <div className="space-y-2">
          {tasks.map((task, idx) => (
            <div key={task.id} className="flex gap-2 items-start">
              <div className="flex-1 space-y-1">
                <input
                  type="text"
                  value={task.title}
                  onChange={(e) => updateTask(idx, "title", e.target.value)}
                  placeholder={`任务 ${idx + 1} 标题`}
                  disabled={running}
                  className="w-full px-3 py-1.5 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary focus:outline-none focus:ring-1 focus:ring-accent-primary disabled:opacity-40"
                />
                <textarea
                  value={task.prompt}
                  onChange={(e) => updateTask(idx, "prompt", e.target.value)}
                  placeholder={`任务 ${idx + 1} 提示词 / 输入内容`}
                  rows={2}
                  disabled={running}
                  className="w-full px-3 py-1.5 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary resize-y focus:outline-none focus:ring-1 focus:ring-accent-primary disabled:opacity-40"
                />
              </div>
              {tasks.length > 1 && (
                <button
                  onClick={() => removeTask(idx)}
                  disabled={running}
                  className="mt-1 text-text-muted hover:text-text-secondary disabled:opacity-40 text-lg leading-none"
                  title="删除此任务"
                >
                  ×
                </button>
              )}
            </div>
          ))}
        </div>
        {tasks.length < 10 && (
          <button
            onClick={addTask}
            disabled={running}
            className="text-sm text-accent-primary hover:opacity-80 disabled:opacity-40 transition-opacity"
          >
            + 添加任务
          </button>
        )}
      </div>

      {/* Pass criteria */}
      <div className="space-y-1.5">
        <label className="block text-sm text-text-primary">评判标准</label>
        <textarea
          value={passCriteria}
          onChange={(e) => setPassCriteria(e.target.value)}
          placeholder="描述如何判断每个任务输出是否合格，例如：输出必须包含结构化 JSON，字段齐全且值类型正确，无多余说明文字。"
          rows={4}
          disabled={running}
          className="w-full px-3 py-2 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary resize-y focus:outline-none focus:ring-1 focus:ring-accent-primary disabled:opacity-40"
        />
        <p className="text-xs text-text-muted">{passCriteria.length} / 800 字（最少 8 字）</p>
      </div>

      {/* Parameters */}
      <div className="flex gap-4 flex-wrap">
        <div className="space-y-1">
          <label className="block text-xs text-text-secondary">最大轮数（1–20）</label>
          <input
            type="number"
            min={1}
            max={20}
            value={maxRounds}
            onChange={(e) => setMaxRounds(Math.min(20, Math.max(1, Number(e.target.value))))}
            disabled={running}
            className="w-24 px-3 py-1.5 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary focus:outline-none focus:ring-1 focus:ring-accent-primary disabled:opacity-40"
          />
        </div>
        <div className="space-y-1">
          <label className="block text-xs text-text-secondary">目标通过率（0–1）</label>
          <input
            type="number"
            min={0}
            max={1}
            step={0.05}
            value={targetPassRate}
            onChange={(e) => setTargetPassRate(Math.min(1, Math.max(0, Number(e.target.value))))}
            disabled={running}
            className="w-24 px-3 py-1.5 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary focus:outline-none focus:ring-1 focus:ring-accent-primary disabled:opacity-40"
          />
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-3">
        <button
          disabled={!!validationError || running}
          onClick={handleStart}
          className="px-4 py-2 text-sm rounded-lg bg-accent-primary text-white disabled:opacity-40 hover:opacity-90 transition-opacity"
        >
          {running ? "训练中…" : "开始训练"}
        </button>
        {running && (
          <button
            onClick={abort}
            className="px-4 py-2 text-sm rounded-lg border border-border-subtle hover:bg-bg-elevated text-text-primary transition-colors"
          >
            中止
          </button>
        )}
      </div>

      {/* Validation hint */}
      {validationError && !running && (
        <p className="text-xs text-text-muted">{validationError}</p>
      )}

      {/* ── Results area ── */}
      {(curve.length > 0 || error || done) && (
        <div className="space-y-4 pt-2 border-t border-border-subtle">
          {/* Error */}
          {error && (
            <div className="rounded-lg px-4 py-3 text-sm bg-danger/10 border border-danger/30 text-danger">
              训练出错：{error}
            </div>
          )}

          {/* PassRate curve */}
          {curve.length > 0 && (
            <div className="rounded-lg bg-bg-surface border border-border-subtle px-4 py-3">
              <p className="text-xs text-text-secondary mb-2">通过率曲线</p>
              <PassRateCurve points={curve} />
            </div>
          )}

          {/* Round cards */}
          {rounds.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs text-text-secondary">各轮详情</p>
              {rounds.map((r) => (
                <RoundCard
                  key={r.n}
                  round={r}
                  actor={actors.get(r.n)}
                  convergedAt={convergedAt}
                />
              ))}
            </div>
          )}

          {/* Done banner */}
          {done && (
            <div
              className={`rounded-lg px-4 py-3 text-sm border ${
                done.converged
                  ? "bg-ok/10 border-ok/30 text-ok"
                  : "bg-warn/10 border-warn/30 text-warn"
              }`}
            >
              <span>
                训练完成 · 最终 v{done.final_version} · passRate{" "}
                <strong>{Math.round(done.final_pass_rate * 100)}%</strong> · 共 {done.rounds} 轮 ·{" "}
                {done.converged ? "已收敛达标" : "未达目标通过率"}
                {"　"}
                <Link href="/skills" className="underline underline-offset-2 hover:opacity-80">
                  前往「技能」页查看新版本
                </Link>
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
