"use client";
import { useEffect, useRef } from "react";
import { SSE_BASE } from "@/services/api";
import { useEventStore } from "@/stores/eventStore";

/** Persistent SSE subscriber for the given session. Auto-reconnects on transient network drops. */
export function useEventStream(sessionId: string | null) {
  const pushReviewDone = useEventStore((s) => s.pushReviewDone);
  const pushPermissionRequest = useEventStore((s) => s.pushPermissionRequest);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (!sessionId) return;
    let cancelled = false;
    let reconnectDelayMs = 1000;

    const connect = async () => {
      while (!cancelled) {
        const ctrl = new AbortController();
        abortRef.current = ctrl;
        try {
          const resp = await fetch(`${SSE_BASE}/api/events/${sessionId}/stream`, {
            method: "GET",
            signal: ctrl.signal,
          });
          if (!resp.ok || !resp.body) {
            console.warn("event stream HTTP", resp.status);
            await sleep(reconnectDelayMs);
            reconnectDelayMs = Math.min(reconnectDelayMs * 2, 15000);
            continue;
          }
          reconnectDelayMs = 1000; // reset on successful connect
          const reader = resp.body.getReader();
          const decoder = new TextDecoder();
          let buf = "";
          while (!cancelled) {
            const { done, value } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            // Same CRLF-tolerant frame split as useSseStream
            let m: RegExpExecArray | null;
            const sep = /\r?\n\r?\n/;
            while ((m = sep.exec(buf))) {
              const frame = buf.slice(0, m.index);
              buf = buf.slice(m.index + m[0].length);
              let event = "";
              const dataLines: string[] = [];
              for (const line of frame.split(/\r?\n/)) {
                if (line.startsWith("event:")) event = line.slice(6).trim();
                else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
              }
              if (!event) continue;
              let data: unknown = null;
              try { data = JSON.parse(dataLines.join("\n")); } catch { /* ignore */ }
              if (data && typeof data === "object") {
                const d = data as Record<string, unknown>;
                if (event === "review_done") {
                  const actions = Array.isArray(d.actions) ? d.actions.map(String) : [];
                  if (actions.length > 0) pushReviewDone({ actions });
                } else if (event === "permission_request") {
                  const requestId = String(d.request_id ?? "");
                  if (requestId) pushPermissionRequest({
                    requestId,
                    tool: String(d.tool ?? ""),
                    command: String(d.command ?? ""),
                  });
                }
                // ready / ping / unknown events ignored
              }
            }
          }
        } catch (e) {
          if ((e as { name?: string }).name === "AbortError") return;
          console.warn("event stream error:", e);
        }
        // Loop back and reconnect after backoff
        if (!cancelled) await sleep(reconnectDelayMs);
        reconnectDelayMs = Math.min(reconnectDelayMs * 2, 15000);
      }
    };

    void connect();
    return () => {
      cancelled = true;
      abortRef.current?.abort();
    };
  }, [sessionId, pushReviewDone, pushPermissionRequest]);
}

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}
