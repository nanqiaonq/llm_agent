"use client";
import { useCallback, useRef, useState } from "react";
import { SSE_BASE } from "@/services/api";
import type { TrainingTask } from "@/types/api";

type EventHandler = (event: string, data: unknown) => void;

export interface TrainBody {
  task_set: TrainingTask[];
  pass_criteria: string;
  max_rounds: number;
  target_pass_rate: number;
}

export function useTrainStream(onEvent: EventHandler) {
  const [running, setRunning] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const start = useCallback(async (sid: string, name: string, body: TrainBody) => {
    setRunning(true);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const resp = await fetch(
        `${SSE_BASE}/api/sessions/${sid}/skills/${encodeURIComponent(name)}/train`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          signal: ctrl.signal,
        }
      );
      if (!resp.ok || !resp.body) {
        onEvent("error", { message: `HTTP ${resp.status}` });
        return;
      }
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        // SSE frames separated by blank line; accept \n\n and \r\n\r\n
        let m: RegExpExecArray | null;
        const frameSep = /\r?\n\r?\n/;
        while ((m = frameSep.exec(buf))) {
          const frame = buf.slice(0, m.index);
          buf = buf.slice(m.index + m[0].length);
          let event = "";
          const dataLines: string[] = [];
          for (const line of frame.split(/\r?\n/)) {
            if (line.startsWith("event:")) event = line.slice(6).trim();
            else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
          }
          if (!event) continue;
          let data: unknown = null;
          try { data = JSON.parse(dataLines.join("\n")); } catch { /* ignore */ }
          onEvent(event, data);
        }
      }
    } catch (e) {
      if ((e as { name?: string }).name !== "AbortError") {
        onEvent("error", { message: String(e) });
      }
    } finally {
      setRunning(false);
      abortRef.current = null;
    }
  }, [onEvent]);

  const abort = useCallback(() => abortRef.current?.abort(), []);

  return { start, abort, running };
}
