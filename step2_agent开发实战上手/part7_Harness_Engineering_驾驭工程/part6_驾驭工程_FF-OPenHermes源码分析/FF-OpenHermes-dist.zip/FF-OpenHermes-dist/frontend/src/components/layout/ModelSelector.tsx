"use client";
import { useState } from "react";
import { ChevronDown, Cpu, Check } from "lucide-react";
import clsx from "clsx";
import { useSessionStore } from "@/stores/sessionStore";

const PRESETS = [
  { id: "deepseek-v4-pro", label: "DeepSeek V4 Pro（默认 · 旗舰）" },
  { id: "deepseek-v4-flash", label: "DeepSeek V4 Flash（快速）" },
];

export default function ModelSelector() {
  const currentModel = useSessionStore((s) => s.currentModel);
  const setCurrentModel = useSessionStore((s) => s.setCurrentModel);
  const [open, setOpen] = useState(false);

  const active = PRESETS.find((p) => p.id === currentModel) || PRESETS[0];

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-bg-surface border border-border-subtle hover:border-accent-primary text-xs transition-colors"
      >
        <Cpu className="w-3.5 h-3.5 text-text-muted" />
        <span className="text-text-primary truncate max-w-[140px]">{active.label}</span>
        <ChevronDown className="w-3.5 h-3.5 text-text-muted" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0" onClick={() => setOpen(false)} />
          <div className="absolute top-full mt-1 right-0 w-64 bg-bg-surface border border-border-subtle rounded-lg shadow-lg z-50">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  setCurrentModel(p.id === PRESETS[0].id ? null : p.id);
                  setOpen(false);
                }}
                className={clsx(
                  "w-full flex items-center gap-2 px-3 py-2 text-xs text-left hover:bg-bg-elevated",
                  active.id === p.id && "bg-bg-elevated/60"
                )}
              >
                <div className="flex-1 min-w-0">
                  <div className="font-mono text-text-primary truncate">{p.id}</div>
                  <div className="text-text-muted text-[10px] truncate">{p.label}</div>
                </div>
                {active.id === p.id && <Check className="w-3.5 h-3.5 text-accent-primary" />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
