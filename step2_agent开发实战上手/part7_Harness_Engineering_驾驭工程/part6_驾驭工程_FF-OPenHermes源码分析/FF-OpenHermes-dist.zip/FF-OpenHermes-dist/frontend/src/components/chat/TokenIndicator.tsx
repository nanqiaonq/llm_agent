"use client";
import { Coins } from "lucide-react";
import { useChatStore } from "@/stores/chatStore";

export default function TokenIndicator() {
  const tokens = useChatStore((s) => s.currentTokens);
  const total = tokens.input + tokens.output;

  if (total === 0) return null;

  return (
    <div className="flex items-center gap-2 px-3 py-1 text-[11px] text-text-muted border-t border-border-subtle">
      <Coins className="w-3 h-3" />
      <span>
        输入 <span className="text-text-secondary font-mono">{tokens.input.toLocaleString()}</span>
        {" · "}
        输出 <span className="text-text-secondary font-mono">{tokens.output.toLocaleString()}</span>
        {" · "}
        合计 <span className="text-accent-primary font-mono">{total.toLocaleString()}</span>
      </span>
    </div>
  );
}
