"use client";
import Link from "next/link";
import { Sparkles, ArrowRight } from "lucide-react";
import type { SkillEvent } from "@/types/api";

export default function SkillEventCard({ event }: { event: SkillEvent }) {
  if (event.type === "review_done") {
    return (
      <div className="rounded-xl border-l-4 border-l-accent-primary border border-border-subtle bg-bg-surface px-4 py-3 shadow-sm max-w-[80%] animate-in fade-in slide-in-from-bottom-1">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent-primary/15 text-accent-primary flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs uppercase tracking-wide text-accent-primary font-semibold mb-0.5">
              后台自动学到 · {event.actions.length} 项
            </div>
            <ul className="text-xs text-text-secondary mt-1 space-y-0.5 list-disc list-inside">
              {event.actions.map((a, i) => <li key={i} className="line-clamp-1">{a}</li>)}
            </ul>
          </div>
          <Link href="/skills" className="self-center text-xs text-accent-primary hover:text-accent-hover flex items-center gap-1 flex-shrink-0">
            查看 <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    );
  }

  return null;
}
