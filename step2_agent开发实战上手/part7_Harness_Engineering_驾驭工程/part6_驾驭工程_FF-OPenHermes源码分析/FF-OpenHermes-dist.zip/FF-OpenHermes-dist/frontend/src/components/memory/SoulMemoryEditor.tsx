"use client";
import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Save, RotateCcw, Sparkles } from "lucide-react";
import { useSessionStore } from "@/stores/sessionStore";
import { useMemoryStore } from "@/stores/memoryStore";

const Monaco = dynamic(() => import("@monaco-editor/react"), { ssr: false });

export default function SoulMemoryEditor({ field }: { field: "soul" | "memory" }) {
  const sid = useSessionStore((s) => s.activeSid);
  const value = useMemoryStore((s) => (field === "soul" ? s.soul : s.memory));
  const setLocal = useMemoryStore((s) => (field === "soul" ? s.setSoul : s.setMemory));
  const save = useMemoryStore((s) => (field === "soul" ? s.saveSoul : s.saveMemory));

  const [original, setOriginal] = useState(value);
  useEffect(() => { setOriginal(value); }, [value]);

  if (!sid) return null;
  const dirty = value !== original;
  const filename = field === "soul" ? "SOUL.md" : "MEMORY.md";

  return (
    <div className="h-full flex flex-col rounded-lg border border-border-subtle bg-bg-surface">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border-subtle">
        <span className="font-mono text-sm text-text-muted">sessions/{sid}/{filename}</span>
        <div className="flex gap-2">
          {field === "memory" && <AIOptimizeButton />}
          <button
            disabled={!dirty}
            onClick={() => setLocal(original)}
            className="px-2 py-1 rounded text-sm hover:bg-bg-elevated disabled:opacity-40 flex items-center gap-1"
          >
            <RotateCcw className="w-4 h-4" /> 重置
          </button>
          <button
            disabled={!dirty}
            onClick={async () => { await save(sid, value); setOriginal(value); }}
            className="px-3 py-1 rounded bg-accent-primary text-white text-sm disabled:opacity-40 flex items-center gap-1"
          >
            <Save className="w-4 h-4" /> 保存
          </button>
        </div>
      </div>
      <div className="flex-1 min-h-0">
        <Monaco
          theme="vs"
          defaultLanguage="markdown"
          value={value}
          onChange={(v) => setLocal(v ?? "")}
          options={{ minimap: { enabled: false }, fontSize: 13, wordWrap: "on" }}
        />
      </div>
    </div>
  );
}

function AIOptimizeButton() {
  const sid = useSessionStore((s) => s.activeSid);
  const optimize = useMemoryStore((s) => s.optimize);
  const optimizing = useMemoryStore((s) => s.optimizing);

  if (!sid) return null;

  const handle = async () => {
    if (!confirm("AI 将重写 MEMORY.md（已自动保留 .bak 备份），继续？")) return;
    const result = await optimize(sid);
    if (!result.ok) alert(`优化失败：${result.error}`);
  };

  return (
    <button
      disabled={optimizing}
      onClick={handle}
      className="px-2 py-1 rounded text-sm hover:bg-accent-primary/15 text-accent-primary disabled:opacity-40 flex items-center gap-1"
    >
      <Sparkles className={`w-4 h-4 ${optimizing ? "animate-pulse" : ""}`} />
      {optimizing ? "优化中…" : "AI 优化"}
    </button>
  );
}
