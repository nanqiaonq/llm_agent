"use client";
import { Sparkles, Terminal, FileText, Globe, Brain } from "lucide-react";

const SAMPLES = [
  {
    icon: Terminal,
    title: "探索工作目录",
    prompt: "用 terminal 列一下当前工作目录的文件和子目录",
  },
  {
    icon: FileText,
    title: "生成项目说明",
    prompt: "为当前工作目录写一个简洁的 README.md，介绍它的用途和结构",
  },
  {
    icon: Globe,
    title: "联网搜索",
    prompt: "用 search_web 搜索 \"LangChain 1.x release notes\"，给我前 3 条摘要",
  },
  {
    icon: Brain,
    title: "记住偏好",
    prompt: "请记住：以后回复请尽量简洁，避免长篇大论",
  },
];

export default function ChatEmpty({ onSamplePrompt }: { onSamplePrompt: (text: string) => void }) {
  return (
    <div className="h-full flex flex-col items-center justify-center px-8 py-12 max-w-2xl mx-auto">
      <div className="w-14 h-14 rounded-2xl bg-bg-surface border border-border-subtle flex items-center justify-center text-accent-primary shadow-sm mb-4">
        <Sparkles className="w-7 h-7" />
      </div>
      <h1 className="text-xl font-semibold text-text-primary mb-1">FF-OpenHermes</h1>
      <p className="text-sm text-text-secondary mb-8">
        一个能记住你、自主写技能、不断进化的 AI 助手
      </p>

      <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3">
        {SAMPLES.map(({ icon: Icon, title, prompt }) => (
          <button
            key={title}
            onClick={() => onSamplePrompt(prompt)}
            className="group flex items-start gap-3 p-4 text-left rounded-xl bg-bg-surface border border-border-subtle hover:border-accent-primary hover:shadow-sm transition-all"
          >
            <div className="w-8 h-8 rounded-lg bg-bg-elevated text-accent-primary flex items-center justify-center flex-shrink-0 group-hover:bg-accent-primary group-hover:text-white transition-colors">
              <Icon className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-text-primary mb-0.5">{title}</div>
              <div className="text-xs text-text-secondary line-clamp-2">{prompt}</div>
            </div>
          </button>
        ))}
      </div>

      <p className="text-xs text-text-muted mt-6">
        点击上方任一卡片直接发送，或在下方输入框自行提问
      </p>
    </div>
  );
}
