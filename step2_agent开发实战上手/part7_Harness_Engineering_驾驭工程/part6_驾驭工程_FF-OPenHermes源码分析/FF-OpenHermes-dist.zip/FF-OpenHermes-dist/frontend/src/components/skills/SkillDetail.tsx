"use client";
import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { Save, Trash2, Zap } from "lucide-react";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";
import EmptyState from "@/components/common/EmptyState";

const Monaco = dynamic(() => import("@monaco-editor/react"), { ssr: false });

export default function SkillDetail() {
  const sid = useSessionStore((s) => s.activeSid);
  const { skills, selected, detail, setDetail, saveDetail, remove, loaded, toggleLoad } = useSkillStore();
  const [original, setOriginal] = useState(detail);
  useEffect(() => { setOriginal(detail); }, [detail]);

  if (!sid) return <div className="flex-1 p-6 text-text-muted">请先选择一个会话。</div>;
  if (!selected)
    return (
      <div className="flex-1 flex flex-col">
        <EmptyState
          icon={Zap}
          title="选择一个技能查看详情"
          hint="从左侧技能库选择，或新建一个本会话技能开始编辑。"
          action={{ label: "+ 新建技能", onClick: () => window.dispatchEvent(new CustomEvent("ff-open-new-skill")) }}
        />
      </div>
    );

  const isGlobal = skills.find(s => s.name === selected)?.scope === "global";
  const dirty = detail !== original;
  const isLoaded = loaded.some(l => l.name === selected);

  return (
    <div className="flex-1 flex flex-col">
      <div className="px-4 py-2 border-b border-border-subtle bg-bg-surface flex items-center gap-2">
        <span className="font-mono text-sm">{selected}</span>
        <span className="text-xs text-text-muted">SKILL.md</span>
        {isGlobal && (
          <span className="px-2 py-0.5 rounded text-xs bg-bg-elevated text-text-muted border border-border-subtle">
            预置技能（只读）
          </span>
        )}
        {!isGlobal && (
          <div className="ml-auto flex gap-2">
            <button
              onClick={() => toggleLoad(sid, selected, 1)}
              className={isLoaded
                ? "px-3 py-1 rounded bg-bg-elevated text-text-secondary text-sm hover:bg-bg-surface"
                : "px-3 py-1 rounded bg-accent-primary text-white text-sm hover:bg-accent-hover"}
            >
              {isLoaded ? "取消加载" : "加载（Level 1）"}
            </button>
            <button
              disabled={!dirty}
              onClick={async () => { await saveDetail(sid, selected, detail); setOriginal(detail); }}
              className="px-3 py-1 rounded bg-accent-primary text-white text-sm disabled:opacity-40 flex items-center gap-1"
            >
              <Save className="w-4 h-4" /> 保存
            </button>
            <button
              onClick={() => { if (confirm(`确定删除技能「${selected}」？`)) remove(sid, selected); }}
              className="px-2 py-1 rounded text-danger hover:bg-danger/10 flex items-center gap-1"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
      <div className="flex-1">
        <Monaco
          theme="vs"
          defaultLanguage="markdown"
          value={detail}
          onChange={(v) => { if (!isGlobal) setDetail(v ?? ""); }}
          options={{ minimap: { enabled: false }, fontSize: 13, wordWrap: "on", readOnly: isGlobal }}
        />
      </div>
    </div>
  );
}
