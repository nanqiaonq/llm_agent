"use client";
import clsx from "clsx";
import { Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { Message, ToolCall } from "@/stores/chatStore";
import ToolCallCard from "./ToolCallCard";
import ThoughtChain from "./ThoughtChain";
import MemoryRetrievalCard from "./MemoryRetrievalCard";

// 把连续相邻的同名工具调用合并为一组（保留执行顺序）
function groupConsecutive(calls: ToolCall[]): ToolCall[][] {
  const groups: ToolCall[][] = [];
  for (const c of calls) {
    const last = groups[groups.length - 1];
    if (last && last[0].name === c.name) last.push(c);
    else groups.push([c]);
  }
  return groups;
}

export default function ChatMessage({ message, streaming }: { message: Message; streaming?: boolean }) {
  const isUser = message.role === "user";
  return (
    <div className={clsx("flex gap-2.5", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <div className="flex-shrink-0 w-7 h-7 rounded-full bg-accent-primary text-white flex items-center justify-center shadow-sm mt-0.5">
          <Sparkles className="w-4 h-4" />
        </div>
      )}
      <div
        className={clsx(
          "max-w-[80%] rounded-xl px-4 py-3",
          isUser
            ? "bg-bubble-user text-text-primary"
            : "bg-bg-surface border border-border-subtle"
        )}
      >
        {!isUser && message.reasoning && (
          <ThoughtChain reasoning={message.reasoning} streaming={streaming} />
        )}
        {message.toolCalls && message.toolCalls.length > 0 && (
          <div className="space-y-2 mb-2">
            {groupConsecutive(message.toolCalls).map((g) => (
              <ToolCallCard key={g[0].tool_call_id} calls={g} />
            ))}
          </div>
        )}
        {/* Markdown rendered for assistant; user messages stay as plain text */}
        {isUser ? (
          <div className="whitespace-pre-wrap text-sm">{message.content}</div>
        ) : (
          <div className="text-sm markdown-body">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                p: ({ children }) => <p className="mb-2 last:mb-0 leading-relaxed">{children}</p>,
                h1: ({ children }) => <h1 className="text-lg font-semibold mt-3 mb-2">{children}</h1>,
                h2: ({ children }) => <h2 className="text-base font-semibold mt-3 mb-2">{children}</h2>,
                h3: ({ children }) => <h3 className="text-sm font-semibold mt-2 mb-1">{children}</h3>,
                ul: ({ children }) => <ul className="list-disc pl-5 mb-2 space-y-1">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal pl-5 mb-2 space-y-1">{children}</ol>,
                li: ({ children }) => <li className="leading-relaxed">{children}</li>,
                blockquote: ({ children }) => (
                  <blockquote className="border-l-2 border-accent-primary pl-3 my-2 text-text-secondary italic">
                    {children}
                  </blockquote>
                ),
                a: ({ href, children }) => (
                  <a href={href} target="_blank" rel="noreferrer" className="text-accent-primary hover:text-accent-hover underline">
                    {children}
                  </a>
                ),
                strong: ({ children }) => <strong className="font-semibold text-text-primary">{children}</strong>,
                em: ({ children }) => <em className="italic">{children}</em>,
                hr: () => <hr className="my-3 border-border-subtle" />,
                code: ({ className, children, ...props }) => {
                  const inline = !className;
                  if (inline) {
                    return (
                      <code className="px-1.5 py-0.5 rounded bg-bg-elevated border border-border-subtle font-mono text-[0.85em]" {...props}>
                        {children}
                      </code>
                    );
                  }
                  return (
                    <code className={clsx("font-mono text-xs", className)} {...props}>
                      {children}
                    </code>
                  );
                },
                pre: ({ children }) => (
                  <pre className="my-2 p-3 rounded-lg bg-bg-elevated border border-border-subtle overflow-x-auto text-xs font-mono">
                    {children}
                  </pre>
                ),
                table: ({ children }) => (
                  <div className="my-2 overflow-hidden rounded-lg border border-border-subtle">
                    <div className="overflow-x-auto">
                      <table className="text-xs border-collapse">{children}</table>
                    </div>
                  </div>
                ),
                th: ({ children }) => (
                  <th className="border-b border-border-subtle px-3 py-1.5 bg-bg-elevated font-semibold text-left whitespace-nowrap">{children}</th>
                ),
                td: ({ children }) => (
                  <td className="border-b border-border-subtle/50 px-3 py-1.5 align-top">{children}</td>
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
            {streaming && <span className="inline-block w-2 h-4 bg-accent-primary ml-0.5 animate-pulse" />}
          </div>
        )}
        {!isUser && message.retrieval && message.retrieval.length > 0 && (
          <div className="mt-2">
            <MemoryRetrievalCard hits={message.retrieval} />
          </div>
        )}
      </div>
    </div>
  );
}
