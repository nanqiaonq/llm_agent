"use client";
import { Brain, Database, History as HistoryIcon } from "lucide-react";
import clsx from "clsx";
import { useMemoryStore } from "@/stores/memoryStore";

export default function MemoryLayerCards() {
  const { activeTab, setTab, stats, turns } = useMemoryStore();

  const cards = [
    {
      key: "soul" as const,
      icon: Brain,
      title: "SOUL.md",
      sub: "Layer 1 · Agent 人格",
      metric: `${stats.soul_tokens} tokens`,
    },
    {
      key: "memory" as const,
      icon: Database,
      title: "MEMORY.md",
      sub: "Layer 1 · 长期记忆",
      metric: `${stats.memory_tokens} tokens`,
    },
    {
      key: "history" as const,
      icon: HistoryIcon,
      title: "会话历史",
      sub: "Layer 3 · SqliteSaver",
      metric: `${turns.length} 轮对话`,
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-4">
      {cards.map(({ key, icon: Icon, title, sub, metric }) => {
        const active = activeTab === key;
        return (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={clsx(
              "text-left p-3.5 rounded-lg border bg-bg-surface hover:bg-bg-elevated transition-colors",
              active ? "border-accent-primary" : "border-border-subtle"
            )}
          >
            <Icon className="w-5 h-5 text-accent-primary mb-1.5" />
            <div className="font-medium text-sm">{title}</div>
            <div className="text-xs text-text-muted">{sub}</div>
            <div className="text-sm font-semibold text-accent-primary mt-2">{metric}</div>
          </button>
        );
      })}
    </div>
  );
}
