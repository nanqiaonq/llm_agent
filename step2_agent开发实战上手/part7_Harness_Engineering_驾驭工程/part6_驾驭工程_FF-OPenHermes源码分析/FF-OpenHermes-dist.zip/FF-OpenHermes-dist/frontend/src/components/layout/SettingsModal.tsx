"use client";
import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { Settings as SettingsIcon, Eye, EyeOff, Save, ShieldCheck, X } from "lucide-react";
import { api } from "@/services/api";

export default function SettingsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState("");
  const [baseUrl, setBaseUrl] = useState("");
  const [tavily, setTavily] = useState("");
  const [hasApiKey, setHasApiKey] = useState(false);
  const [hasTavily, setHasTavily] = useState(false);
  const [showApi, setShowApi] = useState(false);
  const [showTavily, setShowTavily] = useState(false);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setApiKey("");
    setTavily("");
    setShowApi(false);
    setShowTavily(false);
    setLoading(true);
    api
      .getConfig()
      .then((c) => {
        setBaseUrl(c.base_url ?? "");
        setHasApiKey(c.has_api_key);
        setHasTavily(c.has_tavily);
      })
      .catch((e) => setError(String(e)))
      .finally(() => setLoading(false));
  }, [open]);

  if (!open) return null;

  const handleSave = async () => {
    setBusy(true);
    setError(null);
    try {
      const body: { api_key?: string; base_url?: string; tavily_key?: string } = { base_url: baseUrl.trim() };
      if (apiKey.trim()) body.api_key = apiKey.trim();
      if (tavily.trim()) body.tavily_key = tavily.trim();
      await api.saveConfig(body);
      onClose();
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-bg-elevated rounded-xl border border-border-subtle shadow-lg overflow-hidden"
      >
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-border-subtle">
          <div className="flex items-center gap-2">
            <SettingsIcon className="w-4 h-4 text-accent-primary" />
            <h2 className="text-base font-semibold text-text-primary">设置</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-text-muted hover:text-text-primary hover:bg-bg-surface transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-5 py-4 space-y-4">
          {loading ? (
            <div className="text-sm text-text-muted py-6 text-center">加载中…</div>
          ) : (
            <>
              <Field label="API Key" hint={hasApiKey ? "已配置，留空则不修改" : "未配置"}>
                <PasswordInput
                  value={apiKey}
                  onChange={setApiKey}
                  show={showApi}
                  onToggle={() => setShowApi((v) => !v)}
                  placeholder={hasApiKey ? "已配置（留空不修改）" : "sk-..."}
                />
              </Field>

              <Field label="Base URL">
                <input
                  value={baseUrl}
                  onChange={(e) => setBaseUrl(e.target.value)}
                  placeholder="https://api.deepseek.com/v1"
                  className="w-full px-3 py-2 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary focus:outline-none focus:ring-1 focus:ring-accent-primary"
                />
              </Field>

              <Field label="Tavily API Key" hint={hasTavily ? "已配置，留空则不修改" : "未配置（联网搜索用）"}>
                <PasswordInput
                  value={tavily}
                  onChange={setTavily}
                  show={showTavily}
                  onToggle={() => setShowTavily((v) => !v)}
                  placeholder={hasTavily ? "已配置（留空不修改）" : "tvly-..."}
                />
              </Field>

              <div className="flex items-center gap-1.5 text-xs text-text-muted pt-1">
                <ShieldCheck className="w-3.5 h-3.5 flex-shrink-0" />
                API Key 安全存储在本地 .env 文件中，不会上传到任何服务器。
              </div>
              {error && <div className="text-xs text-danger break-words">{error}</div>}
            </>
          )}
        </div>

        <div className="flex justify-end gap-2 px-5 py-3.5 border-t border-border-subtle">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-sm rounded-lg border border-border-subtle text-text-primary hover:bg-bg-surface transition-colors"
          >
            取消
          </button>
          <button
            disabled={busy || loading}
            onClick={handleSave}
            className="px-4 py-1.5 text-sm rounded-lg bg-accent-primary text-white disabled:opacity-40 hover:bg-accent-hover transition-colors flex items-center gap-1.5"
          >
            <Save className="w-4 h-4" /> {busy ? "保存中…" : "保存"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-baseline justify-between gap-2">
        <label className="text-sm font-medium text-text-primary">{label}</label>
        {hint && <span className="text-xs text-text-muted">{hint}</span>}
      </div>
      {children}
    </div>
  );
}

function PasswordInput({
  value,
  onChange,
  show,
  onToggle,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  onToggle: () => void;
  placeholder?: string;
}) {
  return (
    <div className="relative">
      <input
        type={show ? "text" : "password"}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-3 py-2 pr-9 rounded-lg bg-bg-surface border border-border-subtle text-sm text-text-primary focus:outline-none focus:ring-1 focus:ring-accent-primary"
      />
      <button
        type="button"
        onClick={onToggle}
        className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-text-muted hover:text-text-primary"
      >
        {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>
    </div>
  );
}
