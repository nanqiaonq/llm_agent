"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import NavSidebar from "./NavSidebar";

const STORAGE_KEY = "ff-sidebar-width";
const MIN_WIDTH = 200;
const MAX_WIDTH = 480;
const DEFAULT_WIDTH = 240;

export default function AppShell({ children }: { children: React.ReactNode }) {
  const [width, setWidth] = useState(DEFAULT_WIDTH);
  const draggingRef = useRef(false);
  const widthRef = useRef(width);

  // Hydrate from localStorage
  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const n = Number(stored);
      if (Number.isFinite(n)) {
        const clamped = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, n));
        setWidth(clamped);
        widthRef.current = clamped;
      }
    }
  }, []);

  useEffect(() => { widthRef.current = width; }, [width]);

  // Global mouse listeners for drag
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!draggingRef.current) return;
      const next = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, e.clientX));
      setWidth(next);
    };
    const onUp = () => {
      if (!draggingRef.current) return;
      draggingRef.current = false;
      document.body.style.userSelect = "";
      document.body.style.cursor = "";
      if (typeof window !== "undefined") {
        localStorage.setItem(STORAGE_KEY, String(widthRef.current));
      }
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, []);

  const startDrag = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    draggingRef.current = true;
    document.body.style.userSelect = "none";
    document.body.style.cursor = "col-resize";
  }, []);

  return (
    <div className="flex-1 flex overflow-hidden">
      <div style={{ width, flexShrink: 0 }} className="h-full">
        <NavSidebar />
      </div>
      <div
        onMouseDown={startDrag}
        onDoubleClick={() => { setWidth(DEFAULT_WIDTH); widthRef.current = DEFAULT_WIDTH; localStorage.setItem(STORAGE_KEY, String(DEFAULT_WIDTH)); }}
        title="拖拽调整宽度 · 双击恢复"
        className="w-1 bg-border-subtle hover:bg-accent-primary cursor-col-resize transition-colors flex-shrink-0 select-none"
      />
      <main className="flex-1 overflow-auto canvas-dots">{children}</main>
    </div>
  );
}
