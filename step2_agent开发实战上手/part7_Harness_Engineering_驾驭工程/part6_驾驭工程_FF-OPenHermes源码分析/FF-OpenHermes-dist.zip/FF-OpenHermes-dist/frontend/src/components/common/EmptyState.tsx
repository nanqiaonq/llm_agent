"use client";
import type { ComponentType } from "react";

export default function EmptyState({
  icon: Icon,
  title,
  hint,
  action,
}: {
  icon: ComponentType<{ className?: string }>;
  title: string;
  hint?: string;
  action?: { label: string; onClick: () => void };
}) {
  return (
    <div className="h-full w-full flex flex-col items-center justify-center px-8 py-12 text-center">
      <div className="w-14 h-14 rounded-2xl bg-bg-surface border border-border-subtle flex items-center justify-center text-accent-primary shadow-sm mb-4">
        <Icon className="w-7 h-7" />
      </div>
      <div className="text-base font-medium text-text-primary mb-1">{title}</div>
      {hint && <div className="text-sm text-text-secondary max-w-xs mb-5">{hint}</div>}
      {action && (
        <button
          onClick={action.onClick}
          className="px-4 py-2 text-sm rounded-lg bg-accent-primary text-white hover:bg-accent-hover transition-colors shadow-sm"
        >
          {action.label}
        </button>
      )}
    </div>
  );
}
