"use client";
import { useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { MessageSquare, Brain, Zap, FlaskConical, TrendingUp } from "lucide-react";
import clsx from "clsx";
import WorkspaceTree from "./WorkspaceTree";
import { useEventStore } from "@/stores/eventStore";

const groups = [
  {
    label: "工作台",
    items: [
      { href: "/", icon: MessageSquare, label: "对话" },
      { href: "/memory", icon: Brain, label: "记忆" },
      { href: "/skills", icon: Zap, label: "技能" },
    ],
  },
  {
    label: "技能工坊",
    items: [
      { href: "/distill", icon: FlaskConical, label: "蒸馏" },
      { href: "/train", icon: TrendingUp, label: "训练" },
    ],
  },
] as const;

export default function NavSidebar() {
  const pathname = usePathname();
  const unreadCount = useEventStore((s) => s.unread.length);
  const markAllSeen = useEventStore((s) => s.markAllSeen);

  // Auto-mark events seen when user lands on /skills
  useEffect(() => {
    if (pathname === "/skills" && unreadCount > 0) markAllSeen();
  }, [pathname, unreadCount, markAllSeen]);

  return (
    <aside className="h-full w-full border-r border-border-subtle bg-bg-sidebar flex flex-col">
      <nav className="px-3 py-3 space-y-4">
        {groups.map((group) => (
          <div key={group.label} role="group" aria-label={group.label} className="space-y-1">
            <div className="px-3 text-[11px] font-medium uppercase tracking-wider text-text-muted/80">
              {group.label}
            </div>
            {group.items.map(({ href, icon: Icon, label }) => {
              const active = pathname === href;
              const showBadge = href === "/skills" && unreadCount > 0;
              return (
                <Link
                  key={href}
                  href={href}
                  className={clsx(
                    "relative flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                    active
                      ? "bg-bg-surface text-text-primary shadow-sm"
                      : "text-text-secondary hover:bg-bg-elevated hover:text-text-primary"
                  )}
                >
                  <Icon className={clsx("w-4 h-4", active && "text-accent-primary")} />
                  {label}
                  {showBadge && (
                    <span
                      title={`${unreadCount} 个新技能`}
                      className="ml-auto w-2 h-2 rounded-full bg-accent-primary animate-pulse"
                    />
                  )}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="border-t border-border-subtle/60 flex-1 overflow-hidden flex flex-col">
        <WorkspaceTree />
      </div>
    </aside>
  );
}
