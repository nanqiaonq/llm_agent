"use client";
import { useEffect, useMemo, useRef } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useChatStore } from "@/stores/chatStore";
import type { MemoryHit } from "@/stores/chatStore";
import { useWorkspaceStore } from "@/stores/workspaceStore";
import { useEventStore } from "@/stores/eventStore";
import { useSseStream } from "@/hooks/useSseStream";
import { useEventStream } from "@/hooks/useEventStream";
import { api } from "@/services/api";
import ChatMessage from "./ChatMessage";
import ChatInput from "./ChatInput";
import ChatEmpty from "./ChatEmpty";
import SkillEventCard from "./SkillEventCard";
import PermissionModal from "./PermissionModal";
import TokenIndicator from "./TokenIndicator";

export default function ChatPanel() {
  const sid = useSessionStore((s) => s.activeSid);
  const messages = useChatStore((s) => s.messages);
  const pending = useChatStore((s) => s.pendingAssistant);
  const reset = useChatStore((s) => s.reset);
  const loadHistory = useChatStore((s) => s.loadHistory);
  const pushUser = useChatStore((s) => s.pushUser);
  const startAssistant = useChatStore((s) => s.startAssistant);
  const appendToken = useChatStore((s) => s.appendToken);
  const appendReasoning = useChatStore((s) => s.appendReasoning);
  const setRetrieval = useChatStore((s) => s.setRetrieval);
  const toolStart = useChatStore((s) => s.toolStart);
  const toolEnd = useChatStore((s) => s.toolEnd);
  const finishAssistant = useChatStore((s) => s.finishAssistant);
  const setRunning = useChatStore((s) => s.setRunning);
  const refreshWorkspace = useWorkspaceStore((s) => s.refresh);
  const inSessionEvents = useEventStore((s) => s.inSession);
  const resetEvents = useEventStore((s) => s.resetForSession);

  // Subscribe to side-channel events for the active session
  useEventStream(sid);

  // Reset chat + events on session switch and load history
  useEffect(() => {
    reset();
    resetEvents();
    if (!sid) return;
    let cancelled = false;
    api.history(sid).then(({ turns }) => {
      if (!cancelled) loadHistory(turns);
    }).catch((e) => console.error("history load failed:", e));
    return () => { cancelled = true; };
  }, [sid, reset, resetEvents, loadHistory]);

  const handler = useMemo(() => (event: string, data: unknown) => {
    const d = data as Record<string, unknown>;
    if (event === "turn_start") startAssistant(String(d.turn_id ?? ""));
    else if (event === "thinking") appendReasoning(String(d.content ?? ""));
    else if (event === "retrieval") setRetrieval((d.hits ?? []) as MemoryHit[]);
    else if (event === "assistant_token") appendToken(String(d.content ?? ""));
    else if (event === "tool_start") toolStart(d as never);
    else if (event === "tool_end") {
      toolEnd(d as never);
      const toolName = String((d as { name?: string }).name ?? "");
      if (sid && (toolName === "write_file" || toolName === "terminal")) {
        void refreshWorkspace(sid);
      }
    }
    else if (event === "turn_end") finishAssistant();
    else if (event === "usage") {
      const inT = Number(d.input_tokens ?? 0);
      const outT = Number(d.output_tokens ?? 0);
      useChatStore.getState().setUsage(inT, outT);
    }
    else if (event === "error") { console.error("SSE error:", d); finishAssistant(); }
  }, [startAssistant, appendToken, appendReasoning, setRetrieval, toolStart, toolEnd, finishAssistant, sid, refreshWorkspace]);

  const { send, running } = useSseStream(handler);
  useEffect(() => { setRunning(running); }, [running, setRunning]);

  const currentModel = useSessionStore((s) => s.currentModel);

  const onSend = async (text: string) => {
    if (!sid) return;
    pushUser(text);
    await send(sid, text, currentModel);
  };

  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, pending, inSessionEvents]);

  if (!sid) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-text-muted gap-3 px-8">
        <div className="text-text-secondary">尚未选择会话。</div>
        <div className="text-xs">点击顶部的 <span className="px-2 py-0.5 rounded bg-accent-primary text-white font-medium">+ 新建</span> 创建一个会话。</div>
      </div>
    );
  }

  const isEmpty = messages.length === 0 && !pending && inSessionEvents.length === 0;

  return (
    <div className="h-full flex flex-col">
      {isEmpty ? (
        <div className="flex-1 overflow-auto">
          <ChatEmpty onSamplePrompt={onSend} />
        </div>
      ) : (
        <div ref={scrollRef} className="flex-1 overflow-auto px-6 py-4">
          <div className="max-w-3xl mx-auto space-y-4">
            {messages.map((m) => <ChatMessage key={m.id} message={m} />)}
            {pending && <ChatMessage message={pending} streaming />}
            {inSessionEvents.map((e, i) => (
              <SkillEventCard key={`evt_${i}_${e.receivedAt}`} event={e} />
            ))}
          </div>
        </div>
      )}
      <TokenIndicator />
      <ChatInput onSend={onSend} disabled={running} />
      <PermissionModal />
    </div>
  );
}
