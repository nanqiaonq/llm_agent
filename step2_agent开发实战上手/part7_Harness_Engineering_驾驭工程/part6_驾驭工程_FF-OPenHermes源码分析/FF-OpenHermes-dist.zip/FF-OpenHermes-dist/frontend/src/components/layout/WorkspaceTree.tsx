"use client";
import { useEffect } from "react";
import { Folder, FolderOpen, FileText, ChevronRight, ChevronDown, RefreshCw } from "lucide-react";
import { useSessionStore } from "@/stores/sessionStore";
import { useWorkspaceStore } from "@/stores/workspaceStore";
import type { FileNode } from "@/types/api";

export default function WorkspaceTree() {
  const sid = useSessionStore((s) => s.activeSid);
  const session = useSessionStore((s) => s.sessions.find((x) => x.id === s.activeSid));
  const { tree, expanded, refresh, toggle } = useWorkspaceStore();

  useEffect(() => {
    if (sid) void refresh(sid);
  }, [sid, refresh]);

  if (!sid) return <div className="p-3 text-xs text-text-muted">尚未选择会话。</div>;

  return (
    <div className="flex flex-col h-full">
      <div className="px-2 py-1 flex items-center gap-2 border-b border-border-subtle">
        <Folder className="w-3.5 h-3.5 text-accent-primary" />
        <span className="text-xs font-mono truncate flex-1">{session?.workspace_path ?? ""}</span>
        <button onClick={() => sid && refresh(sid)} className="p-1 hover:bg-bg-elevated rounded">
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="flex-1 overflow-auto py-1">
        {tree ? <Node node={tree} depth={0} expanded={expanded} onToggle={toggle} /> : (
          <div className="px-3 text-xs text-text-muted">加载中…</div>
        )}
      </div>
    </div>
  );
}

function Node({ node, depth, expanded, onToggle }: {
  node: FileNode; depth: number;
  expanded: Set<string>; onToggle: (p: string) => void;
}) {
  if (node.type === "file") {
    return (
      <div className="flex items-center gap-1 px-2 py-0.5 text-xs hover:bg-bg-elevated cursor-pointer"
           style={{ paddingLeft: `${depth * 12 + 8}px` }}>
        <FileText className="w-3.5 h-3.5 text-text-muted" />
        <span className="truncate">{node.name}</span>
      </div>
    );
  }
  const isOpen = depth === 0 || expanded.has(node.path);
  const Icon = isOpen ? FolderOpen : Folder;
  const Chevron = isOpen ? ChevronDown : ChevronRight;
  return (
    <>
      <div
        onClick={() => depth > 0 && onToggle(node.path)}
        className="flex items-center gap-1 px-2 py-0.5 text-xs hover:bg-bg-elevated cursor-pointer"
        style={{ paddingLeft: `${depth * 12 + 4}px` }}
      >
        {depth > 0 && <Chevron className="w-3.5 h-3.5 text-text-muted" />}
        <Icon className="w-3.5 h-3.5 text-accent-primary" />
        <span className="truncate font-medium">{node.name}</span>
      </div>
      {isOpen && node.children?.map((c) => (
        <Node key={c.path || c.name} node={c} depth={depth + 1} expanded={expanded} onToggle={onToggle} />
      ))}
    </>
  );
}
