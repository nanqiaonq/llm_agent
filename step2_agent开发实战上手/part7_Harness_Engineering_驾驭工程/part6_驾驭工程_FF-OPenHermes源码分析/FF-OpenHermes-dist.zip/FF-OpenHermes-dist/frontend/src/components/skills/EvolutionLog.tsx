"use client";
import { useState } from "react";
import { Activity, ChevronRight, ChevronDown } from "lucide-react";
import clsx from "clsx";
import { useSkillStore } from "@/stores/skillStore";

interface VersionEntry {
  raw: string;
  header: string;            // e.g. "v1.1 · 2026-04-29 11:45 UTC · 🤖 Auto-Enhanced · added X"
  body: string;              // markdown after the header line
  diff?: string;             // unified diff content (sans fences)
}

function parseHistory(history: string): VersionEntry[] {
  if (!history) return [];
  // Split on "\n## " but keep section header
  const sections = history.split(/\n(?=## )/g);
  const entries: VersionEntry[] = [];
  for (const sec of sections) {
    if (!sec.startsWith("## ")) continue;
    const newlineIdx = sec.indexOf("\n");
    const header = sec.slice(3, newlineIdx === -1 ? undefined : newlineIdx).trim();
    const body = newlineIdx === -1 ? "" : sec.slice(newlineIdx + 1);
    // Extract a fenced ```diff ... ``` block if present
    const diffMatch = body.match(/```diff\n([\s\S]*?)```/);
    entries.push({
      raw: sec,
      header,
      body,
      diff: diffMatch ? diffMatch[1] : undefined,
    });
  }
  return entries;
}

function DiffBlock({ diff }: { diff: string }) {
  const lines = diff.split("\n");
  return (
    <pre className="text-xs font-mono leading-snug overflow-x-auto bg-bg-elevated rounded p-2">
      {lines.map((line, i) => {
        const cls =
          line.startsWith("+") && !line.startsWith("+++") ? "text-ok" :
          line.startsWith("-") && !line.startsWith("---") ? "text-danger" :
          line.startsWith("@@") ? "text-accent-primary" :
          "text-text-muted";
        return (
          <div key={i} className={cls}>
            {line || " "}
          </div>
        );
      })}
    </pre>
  );
}

function VersionCard({ entry, defaultOpen }: { entry: VersionEntry; defaultOpen: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-border-subtle rounded-lg bg-bg-surface mb-2">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-bg-elevated rounded-lg transition-colors"
      >
        {open ? <ChevronDown className="w-4 h-4 text-text-muted" /> : <ChevronRight className="w-4 h-4 text-text-muted" />}
        <span className="text-xs font-medium text-text-primary truncate">{entry.header}</span>
      </button>
      {open && (
        <div className="px-3 pb-3 space-y-2">
          {/* Body without diff fence (since we render the diff specially) */}
          {entry.body && (
            <div className="text-xs text-text-secondary whitespace-pre-wrap">
              {entry.body.replace(/```diff[\s\S]*?```/g, "").trim()}
            </div>
          )}
          {entry.diff && <DiffBlock diff={entry.diff} />}
        </div>
      )}
    </div>
  );
}

export default function EvolutionLog() {
  const { selected, history } = useSkillStore();
  const entries = parseHistory(history);

  if (!selected) return null;

  return (
    <aside className="w-72 border-l border-border-subtle bg-bg-surface overflow-auto">
      <div className="p-3 border-b border-border-subtle flex items-center gap-2 text-sm font-medium">
        <Activity className="w-4 h-4 text-accent-primary" />
        演进历史
      </div>
      {entries.length === 0 && (
        <div className="p-3 text-xs text-text-muted">（暂无版本记录）</div>
      )}
      {entries.length > 0 && (
        <div className={clsx("p-2")}>
          {entries.map((e, i) => (
            <VersionCard key={i} entry={e} defaultOpen={i === 0} />
          ))}
        </div>
      )}
    </aside>
  );
}
