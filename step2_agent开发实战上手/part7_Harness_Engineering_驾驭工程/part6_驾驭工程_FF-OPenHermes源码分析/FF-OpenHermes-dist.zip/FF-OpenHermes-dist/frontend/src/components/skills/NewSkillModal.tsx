"use client";
import { useState } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";

const TEMPLATE = `---
name: __NAME__
description: "Describe when to use this skill. Mention 'use when ...'."
version: 1.0
generated_by: manual
---

# __NAME__

## Overview

## Triggers

## Steps

## Edge Cases

## Verification
`;

export default function NewSkillModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const sid = useSessionStore((s) => s.activeSid);
  const create = useSkillStore((s) => s.create);
  const [name, setName] = useState("");

  if (!open) return null;

  const valid = /^[a-z][a-z0-9-]{1,40}$/.test(name);

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-bg-elevated rounded-lg w-[480px] p-4 space-y-3 border border-border-subtle">
        <h2 className="text-lg font-semibold">新建技能</h2>

        <label className="block text-sm">
          名称（kebab-case）
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="如：extract-web-table"
            className="w-full mt-1 px-2 py-1 rounded bg-bg-surface border border-border-subtle"
          />
          {!valid && name && <span className="text-xs text-danger">仅支持小写字母、数字、连字符（首字符为字母，长度 2-40）。</span>}
        </label>
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onClose} className="px-3 py-1 text-sm rounded hover:bg-bg-surface">取消</button>
          <button
            disabled={!valid || !sid}
            onClick={async () => {
              if (!sid || !valid) return;
              await create(sid, name, TEMPLATE.replaceAll("__NAME__", name));
              setName("");
              onClose();
            }}
            className="px-3 py-1 text-sm rounded bg-accent-primary text-white disabled:opacity-40"
          >
            创建
          </button>
        </div>
      </div>
    </div>
  );
}
