"use client";
import { useState } from "react";
import { Database, ChevronRight, ChevronDown } from "lucide-react";
import type { MemoryHit } from "@/stores/chatStore";

export default function MemoryRetrievalCard({ hits }: { hits: MemoryHit[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-border-subtle rounded-md bg-bg-surface text-sm">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-bg-elevated"
      >
        {open ? <ChevronDown className="w-4 h-4 text-text-muted" /> : <ChevronRight className="w-4 h-4 text-text-muted" />}
        <Database className="w-4 h-4 text-accent-primary" />
        <span className="font-medium">Memory Retrieval</span>
        <span className="text-xs text-text-muted ml-auto">{hits.length} snippets</span>
      </button>
      {open && (
        <div className="px-3 pb-3 space-y-2 text-xs">
          {hits.map((h, i) => (
            <div key={i} className="border-l-2 border-border-subtle pl-2 space-y-0.5">
              <div className="flex items-center gap-1.5 text-[10px] text-text-muted uppercase tracking-wide">
                <span className="px-1 py-0.5 rounded bg-bg-elevated">{h.role}</span>
                <span className="font-mono">@{h.session_id.slice(0, 8)}</span>
              </div>
              <div className="text-text-secondary whitespace-pre-wrap break-words">
                {h.snippet.replace(/>>>/g, "").replace(/<<</g, "")}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
