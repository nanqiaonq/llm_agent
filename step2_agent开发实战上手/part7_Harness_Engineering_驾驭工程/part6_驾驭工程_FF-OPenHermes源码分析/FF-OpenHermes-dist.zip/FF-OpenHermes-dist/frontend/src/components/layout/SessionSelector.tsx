"use client";
import { useEffect, useState, KeyboardEvent } from "react";
import { ChevronDown, Plus, Check, Pencil, Trash2 } from "lucide-react";
import clsx from "clsx";
import { useSessionStore } from "@/stores/sessionStore";

export default function SessionSelector({ onCreateClick }: { onCreateClick: () => void }) {
  const { sessions, activeSid, refresh, setActive, rename, remove } = useSessionStore();
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");

  useEffect(() => { void refresh(); }, [refresh]);

  const active = sessions.find(s => s.id === activeSid);

  const startEdit = (id: string, current: string) => {
    setEditingId(id);
    setEditValue(current);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    const v = editValue.trim();
    if (v && v !== sessions.find(s => s.id === editingId)?.title) {
      await rename(editingId, v);
    }
    setEditingId(null);
  };

  const cancelEdit = () => setEditingId(null);

  const onEditKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") { e.preventDefault(); void saveEdit(); }
    else if (e.key === "Escape") { e.preventDefault(); cancelEdit(); }
  };

  const onDelete = async (id: string, title: string) => {
    if (!confirm(`确定删除会话「${title}」？\n（工作目录文件不会删除，只清除会话元数据）`)) return;
    await remove(id);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 pl-4 pr-3 py-1.5 rounded-lg bg-bg-surface border border-border-subtle hover:border-accent-primary text-sm transition-colors"
      >
        <span className="truncate max-w-[260px] text-text-primary">
          {active ? active.title : "新会话"}
        </span>
        <ChevronDown className="w-4 h-4 text-text-muted" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0" onClick={() => { setOpen(false); cancelEdit(); }} />
          <div className="absolute top-full mt-1 left-0 w-96 max-h-96 overflow-auto bg-bg-surface border border-border-subtle rounded-lg shadow-lg z-50">
            {sessions.length === 0 && (
              <div className="px-3 py-4 text-sm text-text-muted">暂无会话，请在下方新建。</div>
            )}
            {sessions.map(s => {
              const isActive = s.id === activeSid;
              const isEditing = editingId === s.id;
              return (
                <div
                  key={s.id}
                  className={clsx(
                    "group flex items-start gap-2 px-3 py-2 hover:bg-bg-elevated",
                    isActive && "bg-bg-elevated/60"
                  )}
                >
                  <button
                    onClick={() => { if (isEditing) return; setActive(s.id); setOpen(false); }}
                    disabled={isEditing}
                    className="flex-1 min-w-0 text-left"
                  >
                    {isEditing ? (
                      <input
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onKeyDown={onEditKey}
                        onBlur={saveEdit}
                        className="w-full text-sm font-medium bg-bg-primary border border-accent-primary rounded px-2 py-1 outline-none"
                      />
                    ) : (
                      <div className="text-sm font-medium truncate">{s.title}</div>
                    )}
                    <div className="text-xs text-text-muted truncate">{s.workspace_path}</div>
                  </button>
                  <div className="flex items-center gap-0.5 mt-0.5">
                    {isActive && !isEditing && <Check className="w-4 h-4 text-accent-primary mr-1" />}
                    {!isEditing && (
                      <>
                        <button
                          title="重命名"
                          onClick={(e) => { e.stopPropagation(); startEdit(s.id, s.title); }}
                          className="p-1 rounded text-text-muted hover:text-accent-primary hover:bg-bg-surface opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title="删除"
                          onClick={(e) => { e.stopPropagation(); void onDelete(s.id, s.title); }}
                          className="p-1 rounded text-text-muted hover:text-danger hover:bg-bg-surface opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
            <div className="border-t border-border-subtle">
              <button
                onClick={() => { setOpen(false); cancelEdit(); onCreateClick(); }}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-accent-primary hover:bg-bg-elevated"
              >
                <Plus className="w-4 h-4" /> 新建会话
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
