"use client";
import { useEffect, useRef, useState } from "react";
import { PanelRightClose, PanelRightOpen } from "lucide-react";
import { api } from "@/services/api";
import { useSessionStore } from "@/stores/sessionStore";
import type { Turn } from "@/types/api";

const STORAGE_KEY = "ff-rightpanel-open";

type Tab = "history" | "search";

interface MemoryHit {
  session_id: string;
  role: string;
  content: string;
  snippet: string;
  rank: number;
}

export default function RightPanel() {
  const activeSid = useSessionStore((s) => s.activeSid);

  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>("history");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<MemoryHit[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [sysPrompt, setSysPrompt] = useState("");
  const [sysExpanded, setSysExpanded] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Hydrate open state from localStorage
  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === "true") setOpen(true);
  }, []);

  const toggleOpen = () => {
    setOpen((prev) => {
      const next = !prev;
      if (typeof window !== "undefined") localStorage.setItem(STORAGE_KEY, String(next));
      return next;
    });
  };

  // Load history when tab=history and sid changes
  useEffect(() => {
    if (!open || tab !== "history" || !activeSid) {
      setTurns([]);
      return;
    }
    let cancelled = false;
    setHistoryLoading(true);
    api
      .history(activeSid)
      .then((r) => { if (!cancelled) setTurns(r.turns); })
      .catch(() => { if (!cancelled) setTurns([]); })
      .finally(() => { if (!cancelled) setHistoryLoading(false); });
    return () => { cancelled = true; };
  }, [open, tab, activeSid]);

  // Load system prompt when viewing the history(raw context) tab
  useEffect(() => {
    if (!open || tab !== "history" || !activeSid) {
      setSysPrompt("");
      setSysExpanded(false);
      return;
    }
    setSysExpanded(false);
    let cancelled = false;
    api
      .systemPrompt(activeSid)
      .then((r) => { if (!cancelled) setSysPrompt(r.system_prompt ?? ""); })
      .catch(() => { if (!cancelled) setSysPrompt(""); });
    return () => { cancelled = true; };
  }, [open, tab, activeSid]);

  const doSearch = async () => {
    const q = query.trim();
    if (!q) return;
    setSearchLoading(true);
    setSearched(true);
    try {
      const r = await api.searchMemory(q);
      setHits(r.hits);
    } catch {
      setHits([]);
    } finally {
      setSearchLoading(false);
    }
  };

  if (!open) {
    return (
      <div className="flex-shrink-0 w-10 h-full border-l border-border-subtle bg-bg-surface flex flex-col items-center pt-3 gap-3">
        <button
          onClick={toggleOpen}
          title="展开侧栏"
          className="p-1.5 rounded hover:bg-border-subtle text-text-secondary transition-colors"
        >
          <PanelRightOpen size={16} />
        </button>
        <span
          className="text-text-tertiary"
          style={{ writingMode: "vertical-rl", fontSize: 11, letterSpacing: 2, opacity: 0.6 }}
        >
          原始消息
        </span>
      </div>
    );
  }

  return (
    <div className="flex-shrink-0 w-80 h-full border-l border-border-subtle bg-bg-surface flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center border-b border-border-subtle px-3 py-2 gap-2">
        <button
          onClick={() => { setTab("history"); }}
          className={`text-xs px-2 py-1 rounded transition-colors ${
            tab === "history"
              ? "bg-accent-primary text-white"
              : "text-text-secondary hover:text-text-primary hover:bg-border-subtle"
          }`}
        >
          原始消息
        </button>
        <button
          onClick={() => { setTab("search"); }}
          className={`text-xs px-2 py-1 rounded transition-colors ${
            tab === "search"
              ? "bg-accent-primary text-white"
              : "text-text-secondary hover:text-text-primary hover:bg-border-subtle"
          }`}
        >
          检索记忆
        </button>
        <div className="flex-1" />
        <button
          onClick={toggleOpen}
          title="折叠侧栏"
          className="p-1 rounded hover:bg-border-subtle text-text-secondary transition-colors"
        >
          <PanelRightClose size={15} />
        </button>
      </div>

      {/* Tab: History */}
      {tab === "history" && (
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {activeSid && sysPrompt && (
            <div className="space-y-1.5 border-b border-border-subtle pb-3">
              <span className="text-[10px] font-medium text-text-tertiary uppercase tracking-wide">SYSTEM</span>
              <pre className={`text-[11px] text-text-secondary whitespace-pre-wrap break-words font-mono bg-bg-elevated rounded p-2 ${!sysExpanded ? "max-h-40 overflow-hidden" : ""}`}>
                {sysPrompt}
              </pre>
              <button
                onClick={() => setSysExpanded((v) => !v)}
                className="text-[11px] text-accent-primary hover:opacity-80 transition-opacity"
              >
                {sysExpanded ? "收起" : "展开全部"}
              </button>
            </div>
          )}
          {!activeSid && (
            <p className="text-xs text-text-tertiary">未选择会话</p>
          )}
          {activeSid && historyLoading && (
            <p className="text-xs text-text-tertiary">加载中...</p>
          )}
          {activeSid && !historyLoading && turns.length === 0 && (
            <p className="text-xs text-text-tertiary">暂无消息记录</p>
          )}
          {turns.map((t, i) => (
            <div key={i} className="space-y-1.5 border-b border-border-subtle pb-3 last:border-0">
              {t.user && (
                <div>
                  <span className="text-[10px] font-medium text-text-tertiary uppercase tracking-wide">USER</span>
                  <p className="text-xs text-text-secondary mt-0.5 break-words line-clamp-4">{t.user}</p>
                </div>
              )}
              {t.assistant && (
                <div>
                  <span className="text-[10px] font-medium text-text-tertiary uppercase tracking-wide">ASST</span>
                  <p className="text-xs text-text-secondary mt-0.5 break-words line-clamp-4">{t.assistant}</p>
                </div>
              )}
              {t.tool_calls.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1">
                  {t.tool_calls.map((tc, j) => (
                    <span
                      key={j}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-border-subtle text-text-tertiary"
                    >
                      {tc.name}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Tab: Search */}
      {tab === "search" && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex gap-2 p-3 border-b border-border-subtle">
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") doSearch(); }}
              placeholder="输入关键词检索..."
              className="flex-1 text-xs bg-bg-base border border-border-subtle rounded px-2 py-1.5 text-text-primary placeholder:text-text-tertiary focus:outline-none focus:border-accent-primary"
            />
            <button
              onClick={doSearch}
              disabled={searchLoading || !query.trim()}
              className="text-xs px-3 py-1.5 rounded bg-accent-primary text-white disabled:opacity-50 hover:opacity-90 transition-opacity"
            >
              搜索
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {!searched && (
              <p className="text-xs text-text-tertiary">输入关键词后点击搜索</p>
            )}
            {searched && searchLoading && (
              <p className="text-xs text-text-tertiary">搜索中...</p>
            )}
            {searched && !searchLoading && hits.length === 0 && (
              <p className="text-xs text-text-tertiary">未找到相关记忆</p>
            )}
            {hits.map((h, i) => (
              <div key={i} className="border-b border-border-subtle pb-3 last:border-0 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-medium uppercase tracking-wide px-1.5 py-0.5 rounded bg-border-subtle text-text-tertiary">
                    {h.role}
                  </span>
                  <span className="text-[10px] text-text-tertiary font-mono">{h.session_id.slice(0, 8)}</span>
                </div>
                <p className="text-xs text-text-secondary break-words">
                  {h.snippet.replace(/>>>/g, "").replace(/<<</g, "")}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
