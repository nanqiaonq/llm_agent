"use client";
import { useEffect, useState } from "react";
import { Folder, ArrowUp, FolderPlus } from "lucide-react";
import { api } from "@/services/api";

export default function DirectoryPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [cwd, setCwd] = useState<string>(value || "");
  const [parent, setParent] = useState<string | null>(null);
  const [entries, setEntries] = useState<{ name: string; path: string }[]>([]);
  const [drives, setDrives] = useState<string[]>([]);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { void api.fsDrives().then((d) => setDrives(d.drives)); }, []);
  useEffect(() => {
    if (!cwd) {
      // start at first drive
      if (drives.length > 0) setCwd(drives[0]);
      return;
    }
    api.fsBrowse(cwd).then((r) => {
      setEntries(r.entries);
      setParent(r.parent);
      setCwd(r.cwd);
      onChange(r.cwd);
      setError(null);
    }).catch((e) => setError(String(e)));
  }, [cwd, drives, onChange]);

  return (
    <div className="border border-border-subtle rounded-md bg-bg-surface text-sm">
      <div className="px-3 py-2 border-b border-border-subtle flex items-center gap-2">
        <button onClick={() => parent && setCwd(parent)} disabled={!parent}
                className="p-1 rounded hover:bg-bg-elevated disabled:opacity-30">
          <ArrowUp className="w-4 h-4" />
        </button>
        <span className="font-mono text-xs flex-1 truncate">{cwd}</span>
        {drives.length > 1 && (
          <select
            value={drives.find((d) => cwd.startsWith(d)) ?? ""}
            onChange={(e) => setCwd(e.target.value)}
            className="text-xs bg-bg-elevated rounded px-1 py-0.5 border border-border-subtle"
          >
            {drives.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        )}
      </div>
      <div className="max-h-56 overflow-auto">
        {entries.length === 0 && (
          <div className="px-3 py-6 text-center text-xs text-text-muted">（空目录）</div>
        )}
        {entries.map((e) => (
          <button
            key={e.path}
            onClick={() => setCwd(e.path)}
            className="w-full flex items-center gap-2 px-3 py-1.5 text-left hover:bg-bg-elevated"
          >
            <Folder className="w-4 h-4 text-accent-primary" />
            <span className="truncate text-xs">{e.name}</span>
          </button>
        ))}
      </div>
      {error && <div className="px-3 py-2 text-xs text-danger">{error}</div>}
      <div className="border-t border-border-subtle p-2">
        {!creating && (
          <button onClick={() => setCreating(true)} className="text-xs text-accent-primary flex items-center gap-1">
            <FolderPlus className="w-4 h-4" /> 在此创建新子目录
          </button>
        )}
        {creating && (
          <div className="flex gap-2">
            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="文件夹名"
              className="flex-1 px-2 py-1 text-xs bg-bg-elevated rounded border border-border-subtle"
            />
            <button
              onClick={async () => {
                if (!newName.trim()) return;
                // We can't mkdir without a session — instead just navigate to a hypothetical path
                // and let the backend create it on first session creation. Simpler UX: tell user
                // to create the directory via the OS, or use a mkdir POST against the parent.
                // For M1: emit the chosen path via onChange; user is responsible.
                onChange(`${cwd.replace(/\/+$/, "")}/${newName.trim()}`);
                setCreating(false);
                setNewName("");
              }}
              className="px-2 py-1 text-xs rounded bg-accent-primary text-white"
            >
              使用
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
