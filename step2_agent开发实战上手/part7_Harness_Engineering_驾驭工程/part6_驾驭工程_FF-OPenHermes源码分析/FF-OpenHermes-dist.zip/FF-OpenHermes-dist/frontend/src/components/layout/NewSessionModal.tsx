"use client";
import { useState } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import DirectoryPicker from "./DirectoryPicker";

export default function NewSessionModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const create = useSessionStore((s) => s.create);
  const [title, setTitle] = useState("新会话");
  const [workspacePath, setWorkspacePath] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}
           className="w-[520px] bg-bg-elevated rounded-lg border border-border-subtle p-4 space-y-3">
        <h2 className="text-lg font-semibold">新建会话</h2>
        <label className="block text-sm">
          会话名称
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full mt-1 px-2 py-1 rounded bg-bg-surface border border-border-subtle"
          />
        </label>
        <div>
          <div className="text-sm mb-1">工作目录</div>
          <DirectoryPicker value={workspacePath} onChange={setWorkspacePath} />
          <div className="text-xs text-text-muted mt-1 truncate">已选择：{workspacePath || "（未选择）"}</div>
        </div>
        {error && <div className="text-xs text-danger">{error}</div>}
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onClose} className="px-3 py-1 text-sm rounded hover:bg-bg-surface">取消</button>
          <button
            disabled={busy || !workspacePath || !title.trim()}
            onClick={async () => {
              setBusy(true);
              setError(null);
              try {
                await create({ title: title.trim(), workspace_path: workspacePath });
                onClose();
              } catch (e) {
                setError(String(e));
              } finally {
                setBusy(false);
              }
            }}
            className="px-4 py-1 text-sm rounded bg-accent-primary text-white disabled:opacity-40"
          >
            {busy ? "创建中…" : "创建"}
          </button>
        </div>
      </div>
    </div>
  );
}
