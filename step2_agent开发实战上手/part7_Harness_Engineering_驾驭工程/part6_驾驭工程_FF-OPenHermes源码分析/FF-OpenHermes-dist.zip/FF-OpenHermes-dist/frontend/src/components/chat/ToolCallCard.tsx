"use client";
import { useState } from "react";
import { Wrench, ChevronRight, ChevronDown, Check, AlertCircle, Loader2 } from "lucide-react";
import clsx from "clsx";
import type { ToolCall } from "@/stores/chatStore";

function CallBody({ tc }: { tc: ToolCall }) {
  return (
    <div className="space-y-2">
      <div>
        <div className="text-text-muted uppercase tracking-wide mb-1">入参</div>
        <pre className="bg-bg-elevated p-2 rounded overflow-auto max-h-40">
          {JSON.stringify(tc.input, null, 2)}
        </pre>
      </div>
      {tc.output !== undefined && (
        <div>
          <div className="text-text-muted uppercase tracking-wide mb-1">返回</div>
          <pre className="bg-bg-elevated p-2 rounded overflow-auto max-h-60 whitespace-pre-wrap">
            {tc.output}
          </pre>
        </div>
      )}
    </div>
  );
}

export default function ToolCallCard({ calls }: { calls: ToolCall[] }) {
  const [open, setOpen] = useState(false);
  if (calls.length === 0) return null;
  const name = calls[0].name;
  const count = calls.length;
  // 聚合状态：任一 error → error；否则任一 running → running；否则 done
  const status: ToolCall["status"] =
    calls.some((c) => c.status === "error") ? "error" :
    calls.some((c) => c.status === "running") ? "running" : "done";
  const StatusIcon =
    status === "running" ? Loader2 :
    status === "error" ? AlertCircle : Check;
  const statusColor =
    status === "running" ? "text-accent-primary animate-spin" :
    status === "error" ? "text-danger" : "text-ok";

  return (
    <div className="border border-border-subtle rounded-md bg-bg-surface text-sm">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-bg-elevated"
      >
        {open ? <ChevronDown className="w-4 h-4 text-text-muted" /> : <ChevronRight className="w-4 h-4 text-text-muted" />}
        <Wrench className="w-4 h-4 text-accent-primary" />
        <span className="font-mono">{name}</span>
        {count > 1 && (
          <span className="text-xs px-1.5 py-0.5 rounded-full bg-accent-primary/10 text-accent-primary border border-accent-primary/20">
            ×{count}
          </span>
        )}
        <StatusIcon className={clsx("w-4 h-4 ml-auto", statusColor)} />
      </button>
      {open && (
        <div className="px-3 pb-3 text-xs font-mono">
          {count === 1 ? (
            <CallBody tc={calls[0]} />
          ) : (
            <div className="space-y-3">
              {calls.map((c, i) => (
                <div key={c.tool_call_id} className={clsx(i > 0 && "border-t border-border-subtle pt-2")}>
                  <div className="text-text-secondary mb-1.5">第 {i + 1} 次</div>
                  <CallBody tc={c} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
