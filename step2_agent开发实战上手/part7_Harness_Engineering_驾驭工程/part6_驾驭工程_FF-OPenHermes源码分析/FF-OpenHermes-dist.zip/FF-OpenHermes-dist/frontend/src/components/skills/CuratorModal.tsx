"use client";
import { useState } from "react";
import { api } from "@/services/api";
import type { CurateReport } from "@/types/api";

interface Props {
  open: boolean;
  onClose: () => void;
  sid: string;
  onApplied: () => void;
}

type Phase = "idle" | "previewed" | "applied";

export default function CuratorModal({ open, onClose, sid, onApplied }: Props) {
  const [staleDays, setStaleDays] = useState(30);
  const [archiveDays, setArchiveDays] = useState(90);
  const [preview, setPreview] = useState<CurateReport | null>(null);
  const [report, setReport] = useState<CurateReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  async function handlePreview() {
    setLoading(true);
    setError(null);
    try {
      const result = await api.curateSkills(sid, { dry_run: true, stale_days: staleDays, archive_days: archiveDays });
      setPreview(result);
      setPhase("previewed");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  async function handleApply() {
    setLoading(true);
    setError(null);
    try {
      const result = await api.curateSkills(sid, { dry_run: false, stale_days: staleDays, archive_days: archiveDays });
      setReport(result);
      setPhase("applied");
      onApplied();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  function handleClose() {
    setPreview(null);
    setReport(null);
    setPhase("idle");
    setError(null);
    setLoading(false);
    onClose();
  }

  function renderTransitions(r: CurateReport) {
    const t = r.transitions;
    if ("would_mark_stale" in t) {
      // dry_run
      return (
        <div className="space-y-1 text-sm">
          <div className="text-text-muted">检查技能数：<span className="text-white">{t.checked}</span></div>
          <div className="text-text-muted">
            将标记为 stale（{t.would_mark_stale.length} 个）：
            {t.would_mark_stale.length === 0
              ? <span className="text-text-muted ml-1">无</span>
              : <span className="font-mono ml-1">{t.would_mark_stale.join(", ")}</span>}
          </div>
          <div className="text-text-muted">
            将归档（{t.would_archive.length} 个）：
            {t.would_archive.length === 0
              ? <span className="text-text-muted ml-1">无</span>
              : <span className="font-mono ml-1">{t.would_archive.join(", ")}</span>}
          </div>
        </div>
      );
    } else {
      // real run
      return (
        <div className="space-y-1 text-sm">
          <div className="text-text-muted">检查技能数：<span className="text-white">{t.checked}</span></div>
          <div className="text-text-muted">已标记为 stale：<span className="text-white">{t.marked_stale}</span> 个</div>
          <div className="text-text-muted">已归档：<span className="text-white">{t.archived}</span> 个</div>
        </div>
      );
    }
  }

  function renderConsolidations(r: CurateReport) {
    if (r.consolidations.length === 0) {
      return <div className="text-sm text-text-muted">无合并空间（候选技能不足 2 个或 LLM 未返回建议）</div>;
    }
    return (
      <div className="space-y-2">
        {r.consolidations.map((c, i) => (
          <div key={i} className="rounded border border-border-subtle p-2 space-y-0.5 bg-bg-surface text-sm">
            <div className="font-mono text-accent-primary">{c.umbrella}</div>
            <div className="text-text-muted text-xs">合并自：{c.members?.join(", ") ?? "—"}</div>
            {c.rationale && <div className="text-xs text-text-muted">{c.rationale}</div>}
          </div>
        ))}
      </div>
    );
  }

  function renderPrunings(r: CurateReport) {
    if (r.prunings.length === 0) {
      return <div className="text-sm text-text-muted">无可裁剪项</div>;
    }
    return (
      <div className="space-y-1">
        {r.prunings.map((p, i) => (
          <div key={i} className="text-sm flex gap-2">
            <span className="font-mono text-accent-primary">{p.name}</span>
            <span className="text-text-muted">—</span>
            <span className="text-text-muted">{p.reason ?? ""}</span>
          </div>
        ))}
      </div>
    );
  }

  const activeReport = phase === "applied" ? report : preview;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={handleClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-bg-elevated rounded-lg w-[560px] max-h-[80vh] overflow-y-auto p-4 space-y-4 border border-border-subtle"
      >
        <h2 className="text-lg font-semibold">整理技能库</h2>

        {/* 参数区 */}
        {phase !== "applied" && (
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-3">
              <label className="block text-sm">
                <span className="text-text-muted">stale_days</span>
                <input
                  type="number"
                  min={0}
                  value={staleDays}
                  onChange={(e) => setStaleDays(Number(e.target.value))}
                  className="w-full mt-1 px-2 py-1 rounded bg-bg-surface border border-border-subtle text-sm"
                />
              </label>
              <label className="block text-sm">
                <span className="text-text-muted">archive_days</span>
                <input
                  type="number"
                  min={0}
                  value={archiveDays}
                  onChange={(e) => setArchiveDays(Number(e.target.value))}
                  className="w-full mt-1 px-2 py-1 rounded bg-bg-surface border border-border-subtle text-sm"
                />
              </label>
            </div>
            <div className="text-xs text-text-muted">
              演示时可设小值（如 stale_days=0 / archive_days=1）查看态转移效果。
            </div>
          </div>
        )}

        {/* 错误 */}
        {error && (
          <div className="rounded border border-danger/40 bg-danger/10 p-2 text-sm text-danger">
            {error}
          </div>
        )}

        {/* 报告区 */}
        {activeReport && (
          <div className="space-y-3">
            <div className="text-sm font-medium text-text-muted border-b border-border-subtle pb-1">
              {activeReport.dry_run ? "预览结果（dry_run）" : "执行结果"}
            </div>

            {/* dry_run note 说明 */}
            {activeReport.dry_run && activeReport.note && (
              <div className="rounded border border-yellow-500/40 bg-yellow-500/10 p-2 text-sm text-yellow-300">
                {activeReport.note}
              </div>
            )}

            {/* execute 阶段实际执行动作 */}
            {!activeReport.dry_run && activeReport.actions && activeReport.actions.length > 0 && (
              <div>
                <div className="text-xs font-medium text-text-muted uppercase mb-1">实际执行动作</div>
                <div className="space-y-0.5">
                  {activeReport.actions.map((a, i) => (
                    <div key={i} className="font-mono text-xs text-accent-primary">{a}</div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <div className="text-xs font-medium text-text-muted uppercase mb-1">态转移</div>
              {renderTransitions(activeReport)}
            </div>

            <div>
              <div className="text-xs font-medium text-text-muted uppercase mb-1">
                合并建议{activeReport.dry_run ? "（执行后生成）" : ""}
              </div>
              {renderConsolidations(activeReport)}
            </div>

            <div>
              <div className="text-xs font-medium text-text-muted uppercase mb-1">
                裁剪建议{activeReport.dry_run ? "（执行后生成）" : ""}
              </div>
              {renderPrunings(activeReport)}
            </div>
          </div>
        )}

        {/* 操作按钮 */}
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={handleClose} className="px-3 py-1 text-sm rounded hover:bg-bg-surface">
            {phase === "applied" ? "关闭" : "取消"}
          </button>

          {phase !== "applied" && (
            <button
              disabled={loading}
              onClick={handlePreview}
              className="px-3 py-1 text-sm rounded bg-bg-surface border border-border-subtle hover:bg-bg-elevated disabled:opacity-40"
            >
              {loading && phase === "idle" ? "预览中…" : "预览"}
            </button>
          )}

          {phase === "previewed" && (
            <button
              disabled={loading}
              onClick={handleApply}
              className="px-3 py-1 text-sm rounded bg-accent-primary text-white disabled:opacity-40"
            >
              {loading ? "执行中…" : "确认执行"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
