"use client";
import { useState } from "react";
import { ChevronRight, ChevronDown, User, Bot, Wrench } from "lucide-react";
import { useMemoryStore } from "@/stores/memoryStore";
import { useSessionStore } from "@/stores/sessionStore";
import HQSReportCard from "./HQSReportCard";

export default function SessionHistoryView() {
  const turns = useMemoryStore((s) => s.turns);
  const diagnostic = useMemoryStore((s) => s.diagnostic);
  const diagnosticLoading = useMemoryStore((s) => s.diagnosticLoading);
  const runDiagnose = useMemoryStore((s) => s.runDiagnose);
  const sid = useSessionStore((s) => s.activeSid);

  return (
    <div className="space-y-3 h-full overflow-y-auto">
      {sid && turns.length > 0 && (
        <HQSReportCard
          diagnostic={diagnostic}
          loading={diagnosticLoading}
          onRerun={() => sid && runDiagnose(sid)}
        />
      )}

      {turns.length === 0 ? (
        <div className="p-8 rounded-lg border border-dashed border-border-subtle text-center text-text-muted">
          暂无对话记录。请先到对话页发送一条消息。
        </div>
      ) : (
        turns.map((t, i) => <TurnCard key={i} index={i + 1} turn={t} />)
      )}
    </div>
  );
}

function TurnCard({ index, turn }: { index: number; turn: { user: string; assistant: string; tool_calls: { name: string; args: Record<string, unknown> }[] } }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-lg border border-border-subtle bg-bg-surface">
      <button onClick={() => setOpen(o => !o)} className="w-full flex items-center gap-2 px-3 py-2 text-sm">
        {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        <span className="text-text-muted">第 {index} 轮</span>
        <User className="w-4 h-4 text-accent-primary ml-2" />
        <span className="truncate flex-1 text-left">{turn.user.slice(0, 80)}</span>
        {turn.tool_calls.length > 0 && (
          <span className="text-xs text-text-muted">{turn.tool_calls.length} 个工具</span>
        )}
      </button>
      {open && (
        <div className="border-t border-border-subtle p-3 space-y-2 text-sm">
          <div>
            <div className="text-xs text-text-muted uppercase mb-1">用户</div>
            <div className="whitespace-pre-wrap">{turn.user}</div>
          </div>
          {turn.tool_calls.length > 0 && (
            <div>
              <div className="text-xs text-text-muted uppercase mb-1">工具调用</div>
              <ul className="space-y-1">
                {turn.tool_calls.map((tc, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <Wrench className="w-3.5 h-3.5 text-accent-primary" />
                    <span className="font-mono text-xs">{tc.name}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div>
            <div className="text-xs text-text-muted uppercase mb-1 flex items-center gap-1">
              <Bot className="w-3.5 h-3.5" /> 助手
            </div>
            <div className="whitespace-pre-wrap">{turn.assistant}</div>
          </div>
        </div>
      )}
    </div>
  );
}
