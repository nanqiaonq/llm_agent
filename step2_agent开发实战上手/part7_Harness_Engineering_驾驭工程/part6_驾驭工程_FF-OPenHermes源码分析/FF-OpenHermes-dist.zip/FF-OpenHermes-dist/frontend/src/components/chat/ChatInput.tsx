"use client";
import { useState } from "react";
import { Send, Paperclip } from "lucide-react";

export default function ChatInput({ onSend, disabled }: { onSend: (text: string) => void; disabled: boolean }) {
  const [text, setText] = useState("");
  const submit = () => {
    const t = text.trim();
    if (!t || disabled) return;
    onSend(t);
    setText("");
  };
  return (
    <div className="border-t border-border-subtle bg-bg-primary px-4 py-3">
      <div className="max-w-3xl mx-auto flex items-end gap-2 bg-bg-surface border border-border-subtle rounded-2xl px-3 py-2 shadow-sm focus-within:border-accent-primary transition-colors">
        <button
          title="附加文件"
          disabled
          className="self-end p-2 rounded-lg text-text-muted hover:text-accent-primary hover:bg-bg-elevated disabled:opacity-50 transition-colors"
        >
          <Paperclip className="w-4 h-4" />
        </button>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
          placeholder="问点什么……（Shift+Enter 换行）"
          rows={1}
          className="flex-1 bg-transparent text-sm py-2 outline-none resize-none max-h-40 placeholder:text-text-muted"
        />
        <button
          onClick={submit}
          disabled={disabled || !text.trim()}
          title="发送"
          className="self-end w-9 h-9 rounded-full bg-accent-primary text-white flex items-center justify-center disabled:opacity-50 hover:bg-accent-hover transition-colors shadow-sm"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
