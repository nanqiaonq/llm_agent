"use client";
import { useState } from "react";
import { Brain, ChevronDown, ChevronRight } from "lucide-react";
import clsx from "clsx";

interface ThoughtChainProps {
  reasoning: string;
  streaming?: boolean;
}

export default function ThoughtChain({ reasoning, streaming }: ThoughtChainProps) {
  const [open, setOpen] = useState(!!streaming);

  if (!reasoning || !reasoning.trim()) return null;

  return (
    <div className="mb-2 border border-border-subtle rounded-lg bg-bg-elevated/50 text-sm">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-bg-elevated rounded-t-lg"
      >
        {open
          ? <ChevronDown className="w-4 h-4 text-text-muted" />
          : <ChevronRight className="w-4 h-4 text-text-muted" />
        }
        <Brain className="w-4 h-4 text-text-secondary" />
        <span className="text-text-secondary text-xs font-medium">思考过程</span>
        {streaming && (
          <span className="flex items-center gap-1 ml-1">
            <span className="w-1 h-1 rounded-full bg-text-muted animate-pulse" />
            <span className="w-1 h-1 rounded-full bg-text-muted animate-pulse delay-75" />
            <span className="w-1 h-1 rounded-full bg-text-muted animate-pulse delay-150" />
            <span className="text-xs text-text-muted ml-0.5">思考中…</span>
          </span>
        )}
      </button>
      {open && (
        <div
          className={clsx(
            "px-3 pb-3 pt-1",
            "border-t border-border-subtle"
          )}
        >
          <pre className="whitespace-pre-wrap text-xs text-text-muted max-h-64 overflow-y-auto leading-relaxed font-sans">
            {reasoning}
          </pre>
        </div>
      )}
    </div>
  );
}
