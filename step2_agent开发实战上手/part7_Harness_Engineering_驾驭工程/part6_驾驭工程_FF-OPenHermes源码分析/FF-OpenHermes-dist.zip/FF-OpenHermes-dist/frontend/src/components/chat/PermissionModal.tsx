"use client";
import { ShieldAlert, X } from "lucide-react";
import { useEventStore } from "@/stores/eventStore";
import { api } from "@/services/api";

export default function PermissionModal() {
  const pending = useEventStore((s) => s.pendingPermissions);
  const removeRequest = useEventStore((s) => s.removePermissionRequest);

  // Show only the OLDEST pending request (turn-internal sequencing — at most 1 active)
  const current = pending[0];
  if (!current) return null;

  const respond = async (behavior: "allow_once" | "allow_always" | "deny") => {
    try {
      await api.respondPermission(current.requestId, behavior);
    } catch (e) {
      console.error("permission response failed:", e);
    } finally {
      removeRequest(current.requestId);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-bg-surface border border-border-subtle rounded-xl shadow-2xl">
        <div className="px-5 py-4 border-b border-border-subtle flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-warn" />
          <h3 className="text-sm font-semibold text-text-primary">需要授权</h3>
        </div>
        <div className="px-5 py-4 space-y-2">
          <div className="text-xs text-text-secondary">
            Agent 想通过 <span className="font-mono text-accent-primary">{current.tool}</span> 执行一条危险命令：
          </div>
          <pre className="text-xs font-mono p-3 bg-bg-elevated rounded border border-border-subtle overflow-x-auto whitespace-pre-wrap break-all">
            {current.command}
          </pre>
          <div className="text-xs text-text-muted">
            60 秒内未响应将自动拒绝。
          </div>
        </div>
        <div className="px-5 py-3 border-t border-border-subtle flex gap-2 justify-end">
          <button
            onClick={() => respond("deny")}
            className="px-3 py-1.5 rounded-lg text-sm bg-danger/15 text-danger hover:bg-danger/25 transition-colors flex items-center gap-1"
          >
            <X className="w-4 h-4" /> 拒绝
          </button>
          <button
            onClick={() => respond("allow_once")}
            className="px-3 py-1.5 rounded-lg text-sm bg-bg-elevated text-text-primary hover:bg-bg-primary border border-border-subtle transition-colors"
          >
            允许一次
          </button>
          <button
            onClick={() => respond("allow_always")}
            className="px-3 py-1.5 rounded-lg text-sm bg-accent-primary text-white hover:bg-accent-hover transition-colors"
          >
            本会话内总是允许
          </button>
        </div>
      </div>
    </div>
  );
}
