"use client";
import { useEffect, useState } from "react";
import { Sparkles, Plus, Sun, Moon, Settings } from "lucide-react";
import SessionSelector from "./SessionSelector";
import NewSessionModal from "./NewSessionModal";
import SettingsModal from "./SettingsModal";
import ModelSelector from "./ModelSelector";

export default function Header() {
  const [newOpen, setNewOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [dark, setDark] = useState(false);

  // Hydrate from localStorage / OS preference
  useEffect(() => {
    const stored = typeof window !== "undefined" ? localStorage.getItem("ff-theme") : null;
    const isDark = stored === "dark";
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    if (typeof window !== "undefined") localStorage.setItem("ff-theme", next ? "dark" : "light");
  };

  return (
    <header className="h-14 px-4 flex items-center gap-3 border-b border-border-subtle bg-bg-sidebar">
      <div className="flex items-center gap-2 text-accent-primary">
        <Sparkles className="w-5 h-5" />
        <span className="font-semibold text-text-primary">FF-OpenHermes</span>
      </div>

      <SessionSelector onCreateClick={() => setNewOpen(true)} />

      <button
        onClick={() => setNewOpen(true)}
        className="px-3 py-1.5 rounded-lg bg-accent-primary hover:bg-accent-hover text-white text-sm flex items-center gap-1 shadow-sm transition-colors"
      >
        <Plus className="w-4 h-4" /> 新建
      </button>

      <div className="flex-1" />

      <ModelSelector />

      <button
        onClick={() => setSettingsOpen(true)}
        title="设置"
        className="w-9 h-9 rounded-full bg-bg-surface border border-border-subtle text-text-secondary hover:text-accent-primary hover:border-accent-primary flex items-center justify-center transition-colors"
      >
        <Settings className="w-4 h-4" />
      </button>

      <button
        onClick={toggleTheme}
        title={dark ? "切换到浅色" : "切换到深色"}
        className="w-9 h-9 rounded-full bg-bg-surface border border-border-subtle text-text-secondary hover:text-accent-primary hover:border-accent-primary flex items-center justify-center transition-colors"
      >
        {dark ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
      </button>

      <NewSessionModal open={newOpen} onClose={() => setNewOpen(false)} />
      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </header>
  );
}
