"use client";
import { Stethoscope, AlertTriangle, CheckCircle2, RefreshCw } from "lucide-react";
import clsx from "clsx";
import type { HQSDiagnostic, FailureMode } from "@/types/api";

const MODE_LABELS: Record<FailureMode, string> = {
  goal_loss: "目标失焦",
  boundary_break: "越界",
  context_loss: "上下文丢失",
  capability_gap: "能力缺口",
  hybrid: "混合问题",
};

function scoreClass(score: number): string {
  if (score >= 7) return "text-ok border-ok/50 bg-ok/10";
  if (score >= 4) return "text-warn border-warn/50 bg-warn/10";
  return "text-danger border-danger/50 bg-danger/10";
}

export default function HQSReportCard({
  diagnostic,
  onRerun,
  loading,
}: {
  diagnostic: HQSDiagnostic | null;
  onRerun: () => void;
  loading: boolean;
}) {
  if (!diagnostic && !loading) {
    return (
      <div className="rounded-lg border border-dashed border-border-subtle bg-bg-surface p-4 text-center">
        <Stethoscope className="w-6 h-6 text-text-muted mx-auto mb-2" />
        <div className="text-sm text-text-secondary mb-2">本会话还没有诊断记录。</div>
        <button
          onClick={onRerun}
          disabled={loading}
          className="px-3 py-1.5 rounded-lg bg-accent-primary text-white text-xs hover:bg-accent-hover disabled:opacity-40"
        >
          🩺 诊断本次会话
        </button>
      </div>
    );
  }

  if (loading && !diagnostic) {
    return (
      <div className="rounded-lg border border-border-subtle bg-bg-surface p-4 text-center text-sm text-text-secondary">
        正在分析会话…
      </div>
    );
  }

  if (!diagnostic) return null;

  return (
    <div className="rounded-xl border border-border-subtle bg-bg-surface p-4 space-y-3">
      <div className="flex items-start gap-3">
        <div className={clsx("w-16 h-16 rounded-full border-4 flex items-center justify-center font-bold text-2xl", scoreClass(diagnostic.score))}>
          {diagnostic.score}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs uppercase tracking-wide text-text-muted">HQS · 会话质量评分</div>
          <div className="text-sm font-medium text-text-primary mt-0.5">
            {diagnostic.score >= 7 ? "运行良好" : diagnostic.score >= 4 ? "一般" : "存在问题"}
          </div>
          <div className="text-[11px] text-text-muted mt-1">
            诊断时间 {new Date(diagnostic.diagnosed_at).toLocaleString()}
          </div>
        </div>
        <button
          onClick={onRerun}
          disabled={loading}
          title="重新诊断"
          className="p-1.5 rounded text-text-muted hover:text-accent-primary hover:bg-bg-elevated disabled:opacity-40"
        >
          <RefreshCw className={clsx("w-4 h-4", loading && "animate-spin")} />
        </button>
      </div>

      {diagnostic.failure_modes.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {diagnostic.failure_modes.map((m) => (
            <span
              key={m}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-danger/10 text-danger border border-danger/30"
            >
              <AlertTriangle className="w-3 h-3" />
              {MODE_LABELS[m]}
            </span>
          ))}
        </div>
      )}

      <div className="text-xs text-text-secondary leading-relaxed">{diagnostic.analysis}</div>

      {diagnostic.fix_suggestions.length > 0 && (
        <div>
          <div className="text-xs uppercase tracking-wide text-text-muted mb-1">修复建议</div>
          <ul className="space-y-1">
            {diagnostic.fix_suggestions.map((s, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-text-primary">
                <CheckCircle2 className="w-3.5 h-3.5 text-accent-primary flex-shrink-0 mt-0.5" />
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
