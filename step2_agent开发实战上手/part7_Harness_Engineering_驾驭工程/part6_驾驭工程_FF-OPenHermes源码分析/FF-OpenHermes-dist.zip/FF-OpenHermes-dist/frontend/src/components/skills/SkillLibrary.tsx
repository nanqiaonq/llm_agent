"use client";
import { useState } from "react";
import { Bot, PenTool, Package, Check, Wand2 } from "lucide-react";
import clsx from "clsx";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";
import CuratorModal from "./CuratorModal";

export default function SkillLibrary() {
  const sid = useSessionStore((s) => s.activeSid);
  const { skills, loaded, selected, setSelected, loadDetail, loadAll } = useSkillStore();
  const [curatorOpen, setCuratorOpen] = useState(false);

  const sessionSkills = skills.filter(s => s.scope === "session");
  const globalSkills = skills.filter(s => s.scope === "global");

  // 图标按 provenance（created_by）：agent 自学=机器人 / user 你教=笔 / preset 预置=包
  function getIcon(created_by: string | null | undefined) {
    if (created_by === "preset") return Package;
    if (created_by === "agent") return Bot;
    return PenTool;
  }

  function renderSkill(s: typeof skills[0]) {
    const isLoaded = loaded.some(l => l.name === s.name);
    const active = selected === s.name;
    const Icon = getIcon(s.created_by);
    return (
      <button
        key={s.name}
        onClick={() => { setSelected(s.name); if (sid) void loadDetail(sid, s.name); }}
        className={clsx(
          "w-full text-left px-3 py-2 border-l-2 text-sm hover:bg-bg-elevated",
          active ? "border-accent-primary bg-bg-elevated" : "border-transparent"
        )}
      >
        <div className="flex items-center gap-2">
          <Icon className="w-3.5 h-3.5 text-accent-primary" />
          <span className="font-mono truncate flex-1">{s.name}</span>
          {s.created_by === "agent" && (
            <span className="px-1 py-0.5 rounded text-[10px] bg-ok/20 text-ok border border-ok/30 flex-shrink-0">自学的</span>
          )}
          {s.created_by === "user" && (
            <span className="px-1 py-0.5 rounded text-[10px] bg-accent-primary/15 text-accent-primary border border-accent-primary/30 flex-shrink-0">你教的</span>
          )}
          {s.state === "stale" && (
            <span className="px-1 py-0.5 rounded text-xs bg-warn/20 text-warn border border-warn/30">
              待整理
            </span>
          )}
          {isLoaded && <Check className="w-3.5 h-3.5 text-ok" />}
        </div>
        <div className="text-xs text-text-muted truncate">v{s.version}</div>
      </button>
    );
  }

  return (
    <div className="w-64 border-r border-border-subtle bg-bg-surface overflow-auto">
      <div className="p-3 border-b border-border-subtle text-sm font-medium flex items-center justify-between">
        <span>技能</span>
        {sid && (
          <button
            onClick={() => setCuratorOpen(true)}
            className="flex items-center gap-1 px-2 py-0.5 rounded text-xs text-text-muted hover:bg-bg-elevated hover:text-accent-primary"
            title="整理技能库"
          >
            <Wand2 className="w-3 h-3" />
            整理
          </button>
        )}
      </div>

      {/* 本会话自创 */}
      <div className="px-3 py-1.5 text-xs text-text-muted font-medium border-b border-border-subtle bg-bg-elevated">
        本会话自创 ({sessionSkills.length})
      </div>
      {sessionSkills.length === 0 && (
        <div className="p-3 text-xs text-text-muted">
          暂无技能。（执行复杂任务后会自动生成。）
        </div>
      )}
      {sessionSkills.map(renderSkill)}
      <button
        onClick={() => {
          window.dispatchEvent(new CustomEvent("ff-open-new-skill"));
        }}
        className="w-full text-left px-3 py-2 text-sm text-accent-primary hover:bg-bg-elevated border-t border-border-subtle"
      >
        + 新建技能
      </button>

      {/* 全局预置 */}
      {globalSkills.length > 0 && (
        <>
          <div className="px-3 py-1.5 text-xs text-text-muted font-medium border-y border-border-subtle bg-bg-elevated">
            全局预置 ({globalSkills.length})
          </div>
          {globalSkills.map(renderSkill)}
        </>
      )}

      {sid && (
        <CuratorModal
          open={curatorOpen}
          onClose={() => setCuratorOpen(false)}
          sid={sid}
          onApplied={() => loadAll(sid)}
        />
      )}
    </div>
  );
}
