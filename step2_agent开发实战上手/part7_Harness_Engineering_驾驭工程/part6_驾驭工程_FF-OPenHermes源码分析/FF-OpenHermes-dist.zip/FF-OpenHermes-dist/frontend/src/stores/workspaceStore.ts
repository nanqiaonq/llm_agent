"use client";
import { create } from "zustand";
import { api } from "@/services/api";
import type { FileNode } from "@/types/api";

interface State {
  tree: FileNode | null;
  expanded: Set<string>;
  loading: boolean;
  refresh(sid: string): Promise<void>;
  toggle(path: string): void;
}

export const useWorkspaceStore = create<State>((set, get) => ({
  tree: null,
  expanded: new Set(),
  loading: false,

  async refresh(sid) {
    set({ loading: true });
    try {
      const tree = await api.workspaceTree(sid, ".");
      set({ tree });
    } catch (e) {
      console.error("workspace tree load failed:", e);
      set({ tree: null });
    } finally {
      set({ loading: false });
    }
  },

  toggle(path) {
    const e = new Set(get().expanded);
    if (e.has(path)) e.delete(path);
    else e.add(path);
    set({ expanded: e });
  },
}));
