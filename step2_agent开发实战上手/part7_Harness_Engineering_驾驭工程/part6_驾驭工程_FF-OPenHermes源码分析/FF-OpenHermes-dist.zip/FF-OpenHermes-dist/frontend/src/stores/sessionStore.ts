"use client";
import { create } from "zustand";
import type { SessionMeta } from "@/types/api";
import { api } from "@/services/api";

interface State {
  sessions: SessionMeta[];
  activeSid: string | null;
  loading: boolean;
  currentModel: string | null;
  setCurrentModel(model: string | null): void;
  refresh(): Promise<void>;
  setActive(sid: string | null): void;
  create(input: { title: string; workspace_path: string; model?: string }): Promise<SessionMeta>;
  rename(sid: string, title: string): Promise<void>;
  remove(sid: string): Promise<void>;
}

export const useSessionStore = create<State>((set, get) => ({
  sessions: [],
  activeSid: null,
  loading: false,
  currentModel: null,
  setCurrentModel(model) {
    set({ currentModel: model });
  },

  async refresh() {
    set({ loading: true });
    try {
      const { sessions } = await api.listSessions();
      // Persist last active in localStorage
      const stored = typeof window !== "undefined" ? localStorage.getItem("ff-active-sid") : null;
      const active = get().activeSid ?? (stored && sessions.find(s => s.id === stored) ? stored : null);
      set({ sessions, activeSid: active ?? sessions[0]?.id ?? null });
    } finally {
      set({ loading: false });
    }
  },

  setActive(sid) {
    set({ activeSid: sid });
    if (typeof window !== "undefined" && sid) localStorage.setItem("ff-active-sid", sid);
  },

  async create(input) {
    const meta = await api.createSession(input);
    await get().refresh();
    get().setActive(meta.id);
    return meta;
  },

  async rename(sid, title) {
    await api.renameSession(sid, title);
    await get().refresh();
  },

  async remove(sid) {
    await api.deleteSession(sid);
    if (get().activeSid === sid) get().setActive(null);
    await get().refresh();
  },
}));
