"use client";
import { create } from "zustand";
import { api } from "@/services/api";
import type { SkillSummary, LoadedSkill, DistillResponse } from "@/types/api";

interface State {
  skills: SkillSummary[];
  loaded: LoadedSkill[];
  selected: string | null;
  detail: string;
  history: string;
  loading: boolean;
  setSelected(name: string | null): void;
  setDetail(content: string): void;
  loadAll(sid: string): Promise<void>;
  loadDetail(sid: string, name: string): Promise<void>;
  saveDetail(sid: string, name: string, content: string): Promise<void>;
  toggleLoad(sid: string, name: string, level: number): Promise<void>;
  remove(sid: string, name: string): Promise<void>;
  create(sid: string, name: string, content: string): Promise<void>;
  distill(sid: string, body: { source: "history" | "text"; text?: string }): Promise<DistillResponse>;
}

export const useSkillStore = create<State>((set, get) => ({
  skills: [], loaded: [], selected: null, detail: "", history: "", loading: false,

  setSelected: (n) => set({ selected: n, detail: "", history: "" }),
  setDetail: (c) => set({ detail: c }),

  async loadAll(sid) {
    set({ loading: true });
    try {
      const [{ skills }, { loaded }] = await Promise.all([api.listSkills(sid), api.listLoaded(sid)]);
      set({ skills, loaded });
    } finally {
      set({ loading: false });
    }
  },

  async loadDetail(sid, name) {
    const [d, h] = await Promise.all([api.getSkill(sid, name), api.skillHistory(sid, name)]);
    set({ detail: d.content, history: h.history });
  },

  async saveDetail(sid, name, content) {
    await api.updateSkill(sid, name, content);
    set({ detail: content });
    await get().loadAll(sid);
  },

  async toggleLoad(sid, name, level) {
    const isLoaded = get().loaded.some(l => l.name === name);
    if (isLoaded) await api.unloadSkill(sid, name);
    else await api.loadSkill(sid, name, level);
    await get().loadAll(sid);
  },

  async remove(sid, name) {
    await api.deleteSkill(sid, name);
    set({ selected: null, detail: "", history: "" });
    await get().loadAll(sid);
  },

  async create(sid, name, content) {
    await api.createSkill(sid, name, content);
    await get().loadAll(sid);
    set({ selected: name });
    await get().loadDetail(sid, name);
  },

  async distill(sid, body) {
    const result = await api.distillSkill(sid, body);
    if (result.created && result.name) {
      await get().loadAll(sid);
      set({ selected: result.name });
      await get().loadDetail(sid, result.name);
    }
    return result;
  },
}));
