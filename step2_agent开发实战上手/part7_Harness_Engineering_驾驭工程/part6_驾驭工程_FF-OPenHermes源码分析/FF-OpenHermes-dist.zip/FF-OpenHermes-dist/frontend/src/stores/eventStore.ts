"use client";
import { create } from "zustand";
import type {
  SkillEvent,
  ReviewDoneEvent,
  PermissionRequestEvent,
} from "@/types/api";

interface State {
  /** Events the user has not yet "seen" (cleared when navigating to /skills). */
  unread: SkillEvent[];
  /** Events shown inline in the chat stream of the current session. */
  inSession: SkillEvent[];
  /** Active HIL permission requests waiting for user resolution. */
  pendingPermissions: PermissionRequestEvent[];

  pushReviewDone(ev: { actions: string[] }): void;

  pushPermissionRequest(ev: { requestId: string; tool: string; command: string }): void;
  removePermissionRequest(requestId: string): void;

  markAllSeen(): void;
  resetForSession(): void;
}

export const useEventStore = create<State>((set) => ({
  unread: [],
  inSession: [],
  pendingPermissions: [],

  pushReviewDone(ev) {
    const full: ReviewDoneEvent = { type: "review_done", actions: ev.actions, receivedAt: Date.now() };
    set((s) => ({ unread: [...s.unread, full], inSession: [...s.inSession, full] }));
  },

  pushPermissionRequest(ev) {
    const full: PermissionRequestEvent = {
      type: "permission_request",
      requestId: ev.requestId,
      tool: ev.tool,
      command: ev.command,
      receivedAt: Date.now(),
    };
    set((s) => ({
      pendingPermissions: [...s.pendingPermissions, full],
    }));
  },

  removePermissionRequest(requestId) {
    set((s) => ({
      pendingPermissions: s.pendingPermissions.filter(p => p.requestId !== requestId),
    }));
  },

  markAllSeen() {
    set({ unread: [] });
  },

  resetForSession() {
    set({ unread: [], inSession: [], pendingPermissions: [] });
  },
}));
