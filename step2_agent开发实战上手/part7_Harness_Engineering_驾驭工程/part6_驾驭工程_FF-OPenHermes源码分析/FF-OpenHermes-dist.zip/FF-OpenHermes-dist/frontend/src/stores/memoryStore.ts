"use client";
import { create } from "zustand";
import { api } from "@/services/api";
import type { Turn, HQSDiagnostic } from "@/types/api";

type Tab = "soul" | "memory" | "history";

interface State {
  activeTab: Tab;
  soul: string;
  memory: string;
  stats: { soul_tokens: number; memory_tokens: number };
  turns: Turn[];
  loading: boolean;
  optimizing: boolean;
  diagnostic: HQSDiagnostic | null;
  diagnosticLoading: boolean;
  loadDiagnostic(sid: string): Promise<void>;
  runDiagnose(sid: string): Promise<void>;
  setTab(tab: Tab): void;
  loadAll(sid: string): Promise<void>;
  saveSoul(sid: string, content: string): Promise<void>;
  saveMemory(sid: string, content: string): Promise<void>;
  setSoul(content: string): void;
  setMemory(content: string): void;
  optimize(sid: string): Promise<{ ok: boolean; error?: string }>;
}

export const useMemoryStore = create<State>((set, get) => ({
  activeTab: "soul",
  soul: "",
  memory: "",
  stats: { soul_tokens: 0, memory_tokens: 0 },
  turns: [],
  loading: false,
  diagnostic: null,
  diagnosticLoading: false,

  async loadDiagnostic(sid) {
    try {
      const d = await api.getDiagnostic(sid);
      set({ diagnostic: d });
    } catch {
      // 404 means none on file — that's fine, just clear
      set({ diagnostic: null });
    }
  },

  async runDiagnose(sid) {
    set({ diagnosticLoading: true });
    try {
      const d = await api.runDiagnose(sid);
      set({ diagnostic: d });
    } catch (e) {
      console.error("diagnose failed:", e);
    } finally {
      set({ diagnosticLoading: false });
    }
  },

  setTab: (tab) => set({ activeTab: tab }),
  setSoul: (content) => set({ soul: content }),
  setMemory: (content) => set({ memory: content }),

  async loadAll(sid) {
    set({ loading: true });
    try {
      const [soul, memory, stats, history] = await Promise.all([
        api.getSoul(sid),
        api.getMemory(sid),
        api.memoryStats(sid),
        api.history(sid),
      ]);
      set({
        soul: soul.content,
        memory: memory.content,
        stats,
        turns: history.turns,
      });
      // Fetch diagnostic separately (404 is OK)
      void get().loadDiagnostic(sid);
    } finally {
      set({ loading: false });
    }
  },

  async saveSoul(sid, content) {
    await api.putSoul(sid, content);
    const stats = await api.memoryStats(sid);
    set({ soul: content, stats });
  },

  async saveMemory(sid, content) {
    await api.putMemory(sid, content);
    const stats = await api.memoryStats(sid);
    set({ memory: content, stats });
  },

  optimizing: false,

  async optimize(sid) {
    set({ optimizing: true });
    try {
      const { content } = await api.optimizeMemory(sid);
      // Endpoint already wrote MEMORY.md (with .bak). Refresh local state.
      const stats = await api.memoryStats(sid);
      set({ memory: content, stats, optimizing: false });
      return { ok: true };
    } catch (e) {
      set({ optimizing: false });
      return { ok: false, error: String(e) };
    }
  },
}));
