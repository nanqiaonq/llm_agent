"use client";
import { create } from "zustand";
import type { Turn } from "@/types/api";

export interface ToolCall {
  tool_call_id: string;
  name: string;
  input?: unknown;
  output?: string;
  is_error?: boolean;
  status: "running" | "done" | "error";
}

export interface MemoryHit {
  session_id: string;
  role: string;
  content: string;
  snippet: string;
  rank: number;
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  reasoning?: string;
  toolCalls?: ToolCall[];
  retrieval?: MemoryHit[];
}

interface State {
  messages: Message[];
  pendingAssistant: Message | null;
  running: boolean;
  currentTokens: { input: number; output: number };
  setUsage(input: number, output: number): void;
  reset(): void;
  loadHistory(turns: Turn[]): void;
  pushUser(content: string): void;
  startAssistant(turnId: string): void;
  appendToken(token: string): void;
  appendReasoning(token: string): void;
  setRetrieval(hits: MemoryHit[]): void;
  toolStart(tc: { tool_call_id: string; name: string; input: unknown }): void;
  toolEnd(tc: { tool_call_id: string; name: string; output: string; is_error: boolean }): void;
  finishAssistant(): void;
  setRunning(v: boolean): void;
}

export const useChatStore = create<State>((set, get) => ({
  messages: [],
  pendingAssistant: null,
  running: false,
  currentTokens: { input: 0, output: 0 },
  setUsage(input, output) {
    set({ currentTokens: { input, output } });
  },

  reset: () => set({
    messages: [],
    pendingAssistant: null,
    running: false,
    currentTokens: { input: 0, output: 0 },
  }),

  loadHistory: (turns) => set({
    messages: turns.flatMap((t, i) => {
      const out: Message[] = [];
      if (t.user) out.push({ id: `h_u_${i}`, role: "user", content: t.user });
      if (t.assistant) {
        const toolCalls: ToolCall[] = (t.tool_calls ?? []).map((tc, j) => ({
          tool_call_id: `h_tc_${i}_${j}`,
          name: tc.name,
          input: tc.args,
          status: "done" as const,
        }));
        out.push({
          id: `h_a_${i}`,
          role: "assistant",
          content: t.assistant,
          toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
        });
      }
      return out;
    }),
    pendingAssistant: null,
    running: false,
  }),

  pushUser: (content) => set((s) => ({
    messages: [...s.messages, { id: `u_${Date.now()}`, role: "user", content }],
  })),

  startAssistant: (turnId) => set({
    pendingAssistant: { id: `a_${turnId}`, role: "assistant", content: "", reasoning: "", toolCalls: [] },
  }),

  appendToken: (token) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    set({ pendingAssistant: { ...cur, content: cur.content + token } });
  },

  appendReasoning: (token) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    set({ pendingAssistant: { ...cur, reasoning: (cur.reasoning ?? "") + token } });
  },

  setRetrieval: (hits) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    set({ pendingAssistant: { ...cur, retrieval: hits } });
  },

  toolStart: (tc) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    const calls = cur.toolCalls ?? [];
    set({ pendingAssistant: { ...cur, toolCalls: [...calls, { ...tc, status: "running" }] } });
  },

  toolEnd: (tc) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    const calls = (cur.toolCalls ?? []).map(c =>
      c.tool_call_id === tc.tool_call_id
        ? { ...c, output: tc.output, is_error: tc.is_error, status: (tc.is_error ? "error" : "done") as ToolCall["status"] }
        : c
    );
    set({ pendingAssistant: { ...cur, toolCalls: calls } });
  },

  finishAssistant: () => set((s) => ({
    messages: s.pendingAssistant ? [...s.messages, s.pendingAssistant] : s.messages,
    pendingAssistant: null,
  })),

  setRunning: (v) => set({ running: v }),
}));
