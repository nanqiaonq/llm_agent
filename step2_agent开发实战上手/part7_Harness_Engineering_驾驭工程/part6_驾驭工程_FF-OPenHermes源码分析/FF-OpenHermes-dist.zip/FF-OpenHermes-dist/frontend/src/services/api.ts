import type {
  SessionMeta, FileNode, SkillSummary, LoadedSkill, Turn, HQSDiagnostic, DistillResponse, CurateReport,
} from "@/types/api";

const BASE = process.env.NEXT_PUBLIC_API_BASE ?? "http://127.0.0.1:8003";

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    ...init,
  });
  if (!r.ok) throw new Error(`${r.status}: ${await r.text()}`);
  return r.json() as Promise<T>;
}

export const api = {
  // Sessions
  listSessions: () => http<{ sessions: SessionMeta[] }>("/api/sessions"),
  createSession: (body: { title: string; workspace_path: string; model?: string }) =>
    http<SessionMeta>("/api/sessions", { method: "POST", body: JSON.stringify(body) }),
  getSession: (sid: string) => http<SessionMeta>(`/api/sessions/${sid}`),
  renameSession: (sid: string, title: string) =>
    http<SessionMeta>(`/api/sessions/${sid}`, { method: "PUT", body: JSON.stringify({ title }) }),
  deleteSession: (sid: string) =>
    http<{ status: string }>(`/api/sessions/${sid}`, { method: "DELETE" }),

  // Workspace
  workspaceTree: (sid: string, path = ".") =>
    http<FileNode>(`/api/sessions/${sid}/workspace/tree?path=${encodeURIComponent(path)}`),
  workspaceReadFile: (sid: string, path: string) =>
    http<{ content: string; language: string }>(`/api/sessions/${sid}/workspace/file?path=${encodeURIComponent(path)}`),
  workspaceWriteFile: (sid: string, path: string, content: string) =>
    http(`/api/sessions/${sid}/workspace/file`, { method: "PUT", body: JSON.stringify({ path, content }) }),
  workspaceMkdir: (sid: string, path: string) =>
    http(`/api/sessions/${sid}/workspace/mkdir`, { method: "POST", body: JSON.stringify({ path }) }),
  workspaceRename: (sid: string, from: string, to: string) =>
    http(`/api/sessions/${sid}/workspace/rename`, { method: "POST", body: JSON.stringify({ from_path: from, to_path: to }) }),
  workspaceDelete: (sid: string, path: string) =>
    http(`/api/sessions/${sid}/workspace/file?path=${encodeURIComponent(path)}`, { method: "DELETE" }),

  // FS browser
  fsBrowse: (path: string) =>
    http<{ cwd: string; parent: string | null; entries: { name: string; path: string }[] }>(
      `/api/fs/browse?path=${encodeURIComponent(path)}`,
    ),
  fsDrives: () => http<{ drives: string[] }>("/api/fs/drives"),

  // Memory
  getSoul: (sid: string) => http<{ content: string }>(`/api/sessions/${sid}/soul`),
  putSoul: (sid: string, content: string) =>
    http(`/api/sessions/${sid}/soul`, { method: "PUT", body: JSON.stringify({ content }) }),
  getMemory: (sid: string) => http<{ content: string }>(`/api/sessions/${sid}/memory`),
  putMemory: (sid: string, content: string) =>
    http(`/api/sessions/${sid}/memory`, { method: "PUT", body: JSON.stringify({ content }) }),
  memoryStats: (sid: string) =>
    http<{ soul_tokens: number; memory_tokens: number }>(`/api/sessions/${sid}/memory/stats`),
  optimizeMemory: (sid: string) =>
    http<{ content: string }>(`/api/sessions/${sid}/memory/optimize`, { method: "POST" }),
  history: (sid: string) => http<{ turns: Turn[] }>(`/api/sessions/${sid}/history`),
  systemPrompt: (sid: string) => http<{ system_prompt: string }>(`/api/sessions/${sid}/system-prompt`),
  searchMemory: (q: string, topK = 5) =>
    http<{ hits: Array<{ session_id: string; role: string; content: string; snippet: string; rank: number }> }>(
      `/api/memory/search?q=${encodeURIComponent(q)}&top_k=${topK}`,
    ),

  // Skills
  listSkills: (sid: string) => http<{ skills: SkillSummary[] }>(`/api/sessions/${sid}/skills`),
  createSkill: (sid: string, name: string, content: string) =>
    http(`/api/sessions/${sid}/skills`, { method: "POST", body: JSON.stringify({ name, content }) }),
  getSkill: (sid: string, name: string) =>
    http<{ name: string; content: string }>(`/api/sessions/${sid}/skills/${name}`),
  updateSkill: (sid: string, name: string, content: string) =>
    http(`/api/sessions/${sid}/skills/${name}`, { method: "PUT", body: JSON.stringify({ content }) }),
  deleteSkill: (sid: string, name: string) =>
    http(`/api/sessions/${sid}/skills/${name}`, { method: "DELETE" }),
  skillHistory: (sid: string, name: string) =>
    http<{ history: string }>(`/api/sessions/${sid}/skills/${name}/history`),
  loadSkill: (sid: string, name: string, level: number) =>
    http(`/api/sessions/${sid}/skills/${name}/load`, { method: "POST", body: JSON.stringify({ level }) }),
  unloadSkill: (sid: string, name: string) =>
    http(`/api/sessions/${sid}/skills/${name}/unload`, { method: "POST" }),
  listLoaded: (sid: string) => http<{ loaded: LoadedSkill[] }>(`/api/sessions/${sid}/skills/loaded`),
  distillSkill: (sid: string, body: { source: "history" | "text"; text?: string }) =>
    http<DistillResponse>(`/api/sessions/${sid}/skills/distill`, { method: "POST", body: JSON.stringify(body) }),
  curateSkills: (sid: string, body: { dry_run: boolean; stale_days: number; archive_days: number }) =>
    http<CurateReport>(`/api/sessions/${sid}/skills/curate`, { method: "POST", body: JSON.stringify(body) }),

  // Permission (HIL)
  respondPermission: (requestId: string, behavior: "allow_once" | "allow_always" | "deny") =>
    http(`/api/permission/${requestId}`, { method: "POST", body: JSON.stringify({ behavior }) }),

  runDiagnose: (sid: string) => http<HQSDiagnostic>(`/api/sessions/${sid}/diagnose`, { method: "POST" }),
  getDiagnostic: (sid: string) => http<HQSDiagnostic>(`/api/sessions/${sid}/diagnose`),

  // Config (settings)
  getConfig: () =>
    http<{ api_key: string; has_api_key: boolean; base_url: string; tavily_key: string; has_tavily: boolean }>(
      "/api/config",
    ),
  saveConfig: (body: { api_key?: string; base_url?: string; tavily_key?: string }) =>
    http<{ status: string; updated: string[] }>("/api/config", { method: "PUT", body: JSON.stringify(body) }),
};

export const SSE_BASE = BASE;
