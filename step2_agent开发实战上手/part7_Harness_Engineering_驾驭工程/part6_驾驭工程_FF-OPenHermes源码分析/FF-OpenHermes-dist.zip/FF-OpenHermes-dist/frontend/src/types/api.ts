export interface SessionStats {
  turns: number;
  total_tokens: number;
  skills_generated: number;
  skills_enhanced: number;
}

export interface SessionMeta {
  id: string;
  title: string;
  workspace_path: string;
  model: string;
  created_at: string;
  updated_at: string;
  stats: SessionStats;
}

export interface FileNode {
  name: string;
  path: string;
  type: "file" | "directory";
  size?: number;
  children?: FileNode[];
}

export interface SkillSummary {
  name: string;
  description: string;
  version: string;
  generated_by: string;
  created_at: string;
  scope: "session" | "global";
  state?: "active" | "stale" | "archived";
  pinned?: boolean;
  created_by?: "user" | "agent" | "preset" | null;   // provenance：你教的(user) vs 它自学的(agent)
  use_count?: number;
  last_activity?: string;
}

export interface CurateConsolidation { umbrella: string; members?: string[]; rationale?: string; }
export interface CuratePruning { name: string; reason?: string; }
export interface CurateTransitionsReal { checked: number; marked_stale: number; archived: number; }
export interface CurateTransitionsDry { checked: number; would_mark_stale: string[]; would_archive: string[]; }
export interface CurateReport {
  transitions: CurateTransitionsReal | CurateTransitionsDry;
  consolidations: CurateConsolidation[];
  prunings: CuratePruning[];
  actions?: string[];
  dry_run: boolean;
  note?: string;
  skipped?: string;
  error?: string;
}

export interface LoadedSkill {
  name: string;
  level: number;
}

export interface Turn {
  user: string;
  assistant: string;
  tool_calls: { name: string; args: Record<string, unknown> }[];
}

export type SseEvent =
  | { event: "turn_start"; data: { turn_id: string } }
  | { event: "thinking"; data: { content: string } }
  | { event: "assistant_token"; data: { content: string } }
  | { event: "tool_start"; data: { tool_call_id: string; name: string; input: unknown } }
  | { event: "tool_end"; data: { tool_call_id: string; name: string; output: string; is_error: boolean } }
  | { event: "turn_end"; data: { turn_id: string; full_response: string } }
  | { event: "error"; data: { message: string } };

export interface ReviewDoneEvent {
  type: "review_done";
  actions: string[];
  receivedAt: number;
}

/** Union of all events flowing through the side-channel. */
export type SkillEvent = ReviewDoneEvent;

export interface PermissionRequestEvent {
  type: "permission_request";
  requestId: string;
  tool: string;
  command: string;
  receivedAt: number;
}

export type FailureMode = "goal_loss" | "boundary_break" | "context_loss" | "capability_gap" | "hybrid";

export interface HQSDiagnostic {
  score: number;
  failure_modes: FailureMode[];
  analysis: string;
  fix_suggestions: string[];
  diagnosed_at: string;
}

export interface DistillResponse {
  created: boolean;
  name?: string;
  description?: string;
  reason?: string;
}

// --- M4 Training types ---
export interface TrainingTask {
  id: string;
  title: string;
  prompt: string;
}

export interface TrainTaskResult {
  task_id: string;
  output: string;
  pass: boolean;
}

export interface TrainRoundComplete {
  n: number;
  pass_rate: number;
  added: string[];
  removed: string[];
  rationale: string;
  version: string;
}

export interface TrainActor {
  n: number;
  task_results: TrainTaskResult[];
  reflection: string;
}

export interface TrainDone {
  final_version: string;
  final_pass_rate: number;
  rounds: number;
  converged: boolean;
}
