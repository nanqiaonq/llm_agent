"""Centralized config — loads from .env once at import time."""
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
SESSIONS_DIR = BASE_DIR / "sessions"
TEMPLATES_DIR = BASE_DIR / "templates"
STORAGE_DIR = BASE_DIR / "storage"
SKILLS_GLOBAL_DIR = BASE_DIR / "skills_global"

load_dotenv(BASE_DIR / ".env")


class Settings:
    OPENROUTER_API_KEY: str = os.getenv("OPENROUTER_API_KEY", "")
    OPENROUTER_BASE_URL: str = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
    OPENROUTER_MODEL: str = os.getenv("OPENROUTER_MODEL", "deepseek/deepseek-chat-v3.1")

    TAVILY_API_KEY: str = os.getenv("TAVILY_API_KEY", "")

    HOST: str = os.getenv("HOST", "127.0.0.1")
    PORT: int = int(os.getenv("PORT", "8003"))
    CORS_ORIGINS: list[str] = [
        s.strip() for s in os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",") if s.strip()
    ]

    CURATOR_STALE_DAYS: int = int(os.getenv("CURATOR_STALE_DAYS", "30"))
    CURATOR_ARCHIVE_DAYS: int = int(os.getenv("CURATOR_ARCHIVE_DAYS", "90"))
    MEMORY_REFLECTION_INTERVAL: int = int(os.getenv("MEMORY_REFLECTION_INTERVAL", "5"))

    MEMORY_RECALL_ENABLED: bool = os.getenv("MEMORY_RECALL_ENABLED", "true").lower() == "true"
    MEMORY_RECALL_TOP_K: int = int(os.getenv("MEMORY_RECALL_TOP_K", "5"))

    CONTEXT_SUMMARY_ENABLED: bool = os.getenv("CONTEXT_SUMMARY_ENABLED", "true").lower() == "true"
    CONTEXT_SUMMARY_TRIGGER_TOKENS: int = int(os.getenv("CONTEXT_SUMMARY_TRIGGER_TOKENS", "8000"))
    CONTEXT_SUMMARY_KEEP_MESSAGES: int = int(os.getenv("CONTEXT_SUMMARY_KEEP_MESSAGES", "10"))


settings = Settings()
