"""HQS Session diagnostics endpoints."""
import json
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request

from agent.diagnostics import diagnose_session
from agent.history import extract_turns
from agent.llm import build_llm

router = APIRouter()


def _diag_path(session_dir: Path) -> Path:
    return session_dir / "diagnostics.json"


@router.post("/sessions/{sid}/diagnose")
async def run_diagnose(sid: str, request: Request):
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    sd = sm.session_dir(sid)

    turns = await extract_turns(sd / "state.db")
    if not turns:
        raise HTTPException(400, "session has no turns to diagnose")

    diagnostic = await diagnose_session(turns=turns, llm_factory=build_llm)
    if diagnostic is None:
        raise HTTPException(503, "diagnostic LLM call failed (see backend log)")

    payload = diagnostic.model_dump()
    _diag_path(sd).write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return payload


@router.get("/sessions/{sid}/diagnose")
async def get_latest_diagnostic(sid: str, request: Request):
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    sd = sm.session_dir(sid)
    p = _diag_path(sd)
    if not p.exists():
        raise HTTPException(404, "no diagnostic on file for this session")
    return json.loads(p.read_text(encoding="utf-8"))
