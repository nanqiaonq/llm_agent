"""GET /api/events/{sid}/stream — persistent SSE side-channel for session events.

Carries late-arriving events that the chat SSE can't deliver because it closes
at turn_end (e.g. skill_generated, future skill_enhanced). Frontend opens one
of these per active session and keeps it open.
"""
import asyncio
import json
from typing import AsyncGenerator

from fastapi import APIRouter, HTTPException, Request
from sse_starlette.sse import EventSourceResponse

router = APIRouter()

KEEPALIVE_SECONDS = 20


@router.get("/events/{sid}/stream")
async def events_stream(sid: str, request: Request):
    sm = request.app.state.session_manager
    bus = request.app.state.event_bus
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")

    async def gen() -> AsyncGenerator[dict, None]:
        async with bus.subscribe(sid) as q:
            # Send a hello so the client knows the channel is up
            yield {"event": "ready", "data": json.dumps({"session_id": sid})}
            while True:
                if await request.is_disconnected():
                    return
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=KEEPALIVE_SECONDS)
                except asyncio.TimeoutError:
                    # Keepalive ping (SSE comment line — sse-starlette emits properly)
                    yield {"event": "ping", "data": "{}"}
                    continue
                # NOTE: do NOT mutate `ev` — the same dict is fanned out to all
                # subscribers by EventBus. Mutation here would corrupt the dict
                # for any other subscriber on the same session.
                ev_type = ev.get("type", "message")
                payload = {k: v for k, v in ev.items() if k != "type"}
                yield {"event": ev_type, "data": json.dumps(payload, ensure_ascii=False)}

    return EventSourceResponse(gen())
