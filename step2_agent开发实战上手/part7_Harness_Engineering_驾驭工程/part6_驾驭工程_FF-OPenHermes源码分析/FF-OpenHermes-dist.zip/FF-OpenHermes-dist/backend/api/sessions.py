"""Sessions CRUD endpoints."""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from agent.models import CreateSessionRequest, RenameSessionRequest, SessionMeta
from config import settings

router = APIRouter()


@router.get("/sessions")
async def list_sessions(request: Request):
    sm = request.app.state.session_manager
    return {"sessions": [m.model_dump() for m in sm.list()]}


@router.post("/sessions")
async def create_session(req: CreateSessionRequest, request: Request):
    sm = request.app.state.session_manager
    try:
        meta = sm.create(
            title=req.title,
            workspace_path=req.workspace_path,
            model=req.model or settings.OPENROUTER_MODEL,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    return meta.model_dump()


@router.get("/sessions/{sid}")
async def get_session(sid: str, request: Request):
    sm = request.app.state.session_manager
    try:
        return sm.get(sid).model_dump()
    except FileNotFoundError:
        raise HTTPException(404, "session not found")


@router.put("/sessions/{sid}")
async def rename_session(sid: str, req: RenameSessionRequest, request: Request):
    sm = request.app.state.session_manager
    try:
        return sm.rename(sid, req.title).model_dump()
    except FileNotFoundError:
        raise HTTPException(404, "session not found")


@router.delete("/sessions/{sid}")
async def delete_session(sid: str, request: Request):
    sm = request.app.state.session_manager
    sm.delete(sid)
    return {"status": "deleted", "id": sid}
