"""SOUL / MEMORY / Session History endpoints."""
from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel

from agent.history import extract_turns
from agent.llm import build_llm
from agent.prompt_builder import build_system_prompt
from agent.memory_optimizer import optimize_memory_text
from agent.memory_ops import MemoryOps

router = APIRouter()


class WriteContentBody(BaseModel):
    content: str


def _get_session_dir(request: Request, sid: str):
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    return sm.session_dir(sid)


@router.get("/sessions/{sid}/soul")
async def get_soul(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    return {"content": MemoryOps(sd).read_soul()}


@router.put("/sessions/{sid}/soul")
async def put_soul(sid: str, body: WriteContentBody, request: Request):
    sd = _get_session_dir(request, sid)
    MemoryOps(sd).write_soul(body.content)
    return {"status": "ok"}


@router.get("/sessions/{sid}/memory")
async def get_memory(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    return {"content": MemoryOps(sd).read_memory()}


@router.put("/sessions/{sid}/memory")
async def put_memory(sid: str, body: WriteContentBody, request: Request):
    sd = _get_session_dir(request, sid)
    MemoryOps(sd).write_memory(body.content)
    return {"status": "ok"}


@router.get("/sessions/{sid}/memory/stats")
async def memory_stats(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    return MemoryOps(sd).stats()


@router.get("/sessions/{sid}/history")
async def session_history(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    db_path = sd / "state.db"
    turns = await extract_turns(db_path)
    return {"turns": turns}


@router.get("/sessions/{sid}/system-prompt")
async def session_system_prompt(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    gmem = request.app.state.global_memory.read()
    # 刷新技能快照，使展示的 system prompt 与 agent 每轮实际使用的一致（幂等、廉价）
    try:
        from agent.skill_ops import SkillOps
        from config import SKILLS_GLOBAL_DIR
        SkillOps(sd, global_dir=SKILLS_GLOBAL_DIR).rebuild_snapshot()
    except Exception:
        pass
    # recalled 为 per-message 动态召回，不属于稳定的"系统身份"，此处置空
    prompt = build_system_prompt(sd, global_memory=gmem, recalled="")
    return {"system_prompt": prompt}


@router.post("/sessions/{sid}/memory/optimize")
async def optimize_memory(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    ops = MemoryOps(sd)
    current = ops.read_memory()
    new_md = await optimize_memory_text(current=current, llm_factory=build_llm)
    if new_md is None:
        raise HTTPException(503, "memory optimization failed (LLM error or invalid output)")
    ops.write_memory(new_md)  # creates .bak automatically
    return {"content": new_md}


@router.get("/memory/global")
async def get_global_memory(request: Request):
    return {"content": request.app.state.global_memory.read()}


@router.put("/memory/global")
async def put_global_memory(body: WriteContentBody, request: Request):
    request.app.state.global_memory.write(body.content)
    return {"status": "ok"}


@router.post("/memory/global/optimize")
async def optimize_global_memory(request: Request):
    gm = request.app.state.global_memory
    current = gm.read()
    new_md = await optimize_memory_text(current=current, llm_factory=build_llm)
    if new_md is None:
        raise HTTPException(503, "global memory optimization failed")
    gm.write(new_md)
    return {"content": new_md}


@router.get("/memory/search")
async def search_memory(request: Request, q: str, top_k: int = Query(5, ge=1, le=50)):
    """跨会话 F1 FTS5 检索记忆。q 为空返回空列表。"""
    idx = request.app.state.memory_index
    hits = idx.search(q, top_k=top_k)
    return {"hits": hits}
