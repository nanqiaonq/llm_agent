"""POST /api/chat — SSE streaming chat with the agent."""
import json
from typing import AsyncGenerator

from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from sse_starlette.sse import EventSourceResponse

router = APIRouter()


class ChatRequest(BaseModel):
    session_id: str
    message: str
    model: str | None = None


@router.post("/chat")
async def chat(req: ChatRequest, request: Request):
    mgr = request.app.state.agent_manager
    sm = request.app.state.session_manager
    try:
        sm.get(req.session_id)  # 404 fast
    except FileNotFoundError:
        raise HTTPException(404, "session not found")

    async def event_gen() -> AsyncGenerator[dict, None]:
        try:
            async for ev in mgr.astream(req.session_id, req.message, model_override=req.model):
                ev_type = ev.pop("type")
                yield {"event": ev_type, "data": json.dumps(ev, ensure_ascii=False)}
        except Exception as e:
            yield {"event": "error", "data": json.dumps({"message": str(e)}, ensure_ascii=False)}

    return EventSourceResponse(event_gen())
