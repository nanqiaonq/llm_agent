"""Workspace file ops bound to a session's workspace_path."""
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Query
from pydantic import BaseModel

from agent.workspace import WorkspaceOps

router = APIRouter()


def _get_ops(request: Request, sid: str) -> WorkspaceOps:
    sm = request.app.state.session_manager
    try:
        meta = sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    return WorkspaceOps(Path(meta.workspace_path))


class WriteFileBody(BaseModel):
    path: str
    content: str


class MkdirBody(BaseModel):
    path: str


class RenameBody(BaseModel):
    from_path: str
    to_path: str


@router.get("/sessions/{sid}/workspace/tree")
async def tree(sid: str, request: Request, path: str = ".", depth: int = 3):
    ops = _get_ops(request, sid)
    try:
        return ops.tree(path, max_depth=depth)
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(400, str(e))


@router.get("/sessions/{sid}/workspace/file")
async def read_file(sid: str, request: Request, path: str = Query(...)):
    ops = _get_ops(request, sid)
    try:
        return ops.read_file(path)
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(400, str(e))


@router.put("/sessions/{sid}/workspace/file")
async def write_file(sid: str, body: WriteFileBody, request: Request):
    ops = _get_ops(request, sid)
    try:
        ops.write_file(body.path, body.content)
        return {"status": "ok"}
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/sessions/{sid}/workspace/mkdir")
async def mkdir(sid: str, body: MkdirBody, request: Request):
    ops = _get_ops(request, sid)
    ops.mkdir(body.path)
    return {"status": "ok"}


@router.post("/sessions/{sid}/workspace/rename")
async def rename(sid: str, body: RenameBody, request: Request):
    ops = _get_ops(request, sid)
    ops.rename(body.from_path, body.to_path)
    return {"status": "ok"}


@router.delete("/sessions/{sid}/workspace/file")
async def delete_path(sid: str, request: Request, path: str = Query(...)):
    ops = _get_ops(request, sid)
    ops.delete(path)
    return {"status": "ok"}
