"""Skill management endpoints (manual CRUD + load/unload + M4 training)."""
import json
from typing import AsyncGenerator, Literal

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse

from agent.skill_ops import SkillOps
from config import SKILLS_GLOBAL_DIR
from skill_engine.evolver_schemas import TrainingTask

router = APIRouter()


class WriteSkillBody(BaseModel):
    name: str | None = None
    content: str


class LoadBody(BaseModel):
    level: int = 1


class DistillBody(BaseModel):
    source: Literal["history", "text"]
    text: str | None = None


def _get_ops(request: Request, sid: str) -> SkillOps:
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    return SkillOps(sm.session_dir(sid), global_dir=SKILLS_GLOBAL_DIR)


@router.get("/sessions/{sid}/skills")
async def list_skills(sid: str, request: Request):
    return {"skills": _get_ops(request, sid).list_skills()}


@router.post("/sessions/{sid}/skills")
async def create_skill(sid: str, body: WriteSkillBody, request: Request):
    ops = _get_ops(request, sid)
    name = body.name
    if not name:
        raise HTTPException(400, "name required for new skill")
    ops.write_skill(name, body.content, history_line=f"Manual create at v1.0")
    return {"status": "ok", "name": name}


@router.get("/sessions/{sid}/skills/loaded")
async def list_loaded(sid: str, request: Request):
    return {"loaded": _get_ops(request, sid).list_loaded()}


@router.get("/sessions/{sid}/skills/{name}")
async def get_skill(sid: str, name: str, request: Request):
    ops = _get_ops(request, sid)
    try:
        # record_use=False: a UI view bumps view_count, not use_count (use = agent
        # loading the skill via the read_skill tool). Keeps use/view distinct.
        content = ops.read_skill(name, record_use=False)
        if ops.skill_scope(name) == "session":
            try:
                ops.usage.bump_view(name)
            except Exception:
                pass
        return {"name": name, "content": content}
    except FileNotFoundError:
        raise HTTPException(404, "skill not found")


@router.put("/sessions/{sid}/skills/{name}")
async def update_skill(sid: str, name: str, body: WriteSkillBody, request: Request):
    ops = _get_ops(request, sid)
    if ops.skill_scope(name) == "global":
        raise HTTPException(403, "preset (global) skills are read-only")
    ops.write_skill(name, body.content, history_line="Manual edit")
    return {"status": "ok"}


@router.delete("/sessions/{sid}/skills/{name}")
async def delete_skill(sid: str, name: str, request: Request):
    ops = _get_ops(request, sid)
    if ops.skill_scope(name) == "global":
        raise HTTPException(403, "preset (global) skills are read-only")
    ops.delete_skill(name)
    return {"status": "ok"}


@router.get("/sessions/{sid}/skills/{name}/history")
async def get_history(sid: str, name: str, request: Request):
    return {"history": _get_ops(request, sid).read_history(name)}


@router.post("/sessions/{sid}/skills/{name}/load")
async def load(sid: str, name: str, body: LoadBody, request: Request):
    ops = _get_ops(request, sid)
    if ops.skill_scope(name) == "global":
        raise HTTPException(403, "preset skills cannot be loaded in P0")
    if name not in {s["name"] for s in ops.list_skills()}:
        raise HTTPException(404, "skill not found")
    ops.load(name, level=body.level)
    return {"status": "ok"}


@router.post("/sessions/{sid}/skills/{name}/unload")
async def unload(sid: str, name: str, request: Request):
    _get_ops(request, sid).unload(name)
    return {"status": "ok"}


class TrainBody(BaseModel):
    task_set: list[TrainingTask] = Field(..., min_length=1, max_length=10)
    pass_criteria: str = Field(..., min_length=8, max_length=800)
    max_rounds: int = Field(default=5, ge=1, le=20)
    target_pass_rate: float = Field(default=1.0, ge=0, le=1)


@router.post("/sessions/{sid}/skills/{name}/train")
async def train_skill(sid: str, name: str, body: TrainBody, request: Request):
    """M4: Multi-round Verbal RL directed training. SSE event stream."""
    ops = _get_ops(request, sid)
    scope = ops.skill_scope(name)
    if scope == "global":
        raise HTTPException(403, "预置技能只读，不可训练")
    if scope is None:
        raise HTTPException(404, "skill not found")

    sm = request.app.state.session_manager
    session_dir = sm.session_dir(sid)

    from agent.llm import build_llm
    from skill_engine.evolver import train_skill_iterative

    async def event_gen() -> AsyncGenerator[dict, None]:
        async for ev in train_skill_iterative(
            skill_name=name,
            session_dir=session_dir,
            task_set=body.task_set,
            pass_criteria=body.pass_criteria,
            max_rounds=body.max_rounds,
            target_pass_rate=body.target_pass_rate,
            llm_factory=build_llm,
        ):
            ev_type = ev.pop("type")
            yield {"event": ev_type, "data": json.dumps(ev, ensure_ascii=False)}

    return EventSourceResponse(event_gen())


class CurateBody(BaseModel):
    dry_run: bool = False
    stale_days: int = Field(default=30, ge=0, le=3650)
    archive_days: int = Field(default=90, ge=0, le=3650)


@router.post("/sessions/{sid}/skills/curate")
async def curate_skills(sid: str, body: CurateBody, request: Request):
    """E2 curator: phase-1 state transitions + phase-2 LLM consolidation."""
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    sd = sm.session_dir(sid)
    ops = SkillOps(sd, global_dir=SKILLS_GLOBAL_DIR)
    from agent.llm import build_llm
    from skill_engine.curator import curate
    result = await curate(
        ops,
        build_llm,
        stale_days=body.stale_days,
        archive_days=body.archive_days,
        dry_run=body.dry_run,
    )
    return result


@router.post("/sessions/{sid}/skills/distill")
async def distill_skill(sid: str, body: DistillBody, request: Request):
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    sd = sm.session_dir(sid)

    if body.source == "text":
        if not body.text or not body.text.strip():
            raise HTTPException(422, "text required for source=text")
        turn_text = body.text.strip()
    else:  # history
        from agent.history import extract_turns
        try:
            turns = await extract_turns(sd / "state.db")
        except Exception as e:  # degrade gracefully — never surface a 500
            return {"created": False, "reason": f"历史记录读取失败：{e}"}
        if not turns:
            raise HTTPException(422, "no conversation history to distill")
        # Include tool_calls so the generator's "3+ meaningful tool calls" signal
        # survives — mirrors generator._format_turn_for_generator. Without this,
        # tool-heavy sessions would be mis-judged NO_SKILL.
        parts: list[str] = []
        for t in turns:
            seg = f"USER: {t.get('user', '')}\nASSISTANT: {t.get('assistant', '')}"
            for tc in t.get("tool_calls", []):
                seg += f"\n  TOOL_CALL: {tc.get('name')}({tc.get('args', {})})"
            parts.append(seg)
        turn_text = "\n\n".join(parts)

    from skill_engine.generator import generate_skill_from_text
    from agent.llm import build_llm
    result = await generate_skill_from_text(turn_text, sd, build_llm)
    if result is None:
        return {"created": False, "reason": "生成器判定 NO_SKILL 或生成失败（对话过简/不可复用）"}
    return {"created": True, **result}
