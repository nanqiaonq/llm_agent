"""POST /api/permission/{request_id} — frontend → backend permission decision."""
from typing import Literal

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter()


class PermissionResponseBody(BaseModel):
    behavior: Literal["allow_once", "allow_always", "deny"]


@router.post("/permission/{request_id}")
async def respond_permission(request_id: str, body: PermissionResponseBody, request: Request):
    reg = request.app.state.permission_registry
    # Pre-check that request_id is known (idempotent: if already resolved, treat as 404)
    if reg.pending_count() == 0 or request_id not in reg._pending or reg._pending[request_id].done():
        raise HTTPException(404, f"unknown or already-resolved request_id {request_id}")
    reg.resolve(request_id, body.behavior)
    return {"status": "ok", "request_id": request_id, "behavior": body.behavior}
