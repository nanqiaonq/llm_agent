"""Config API — read/write LLM & tool credentials in backend/.env (live-effect, no restart)."""
import os

from fastapi import APIRouter
from pydantic import BaseModel

from config import settings, BASE_DIR

router = APIRouter()

ENV_PATH = BASE_DIR / ".env"


def _mask(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "••••"
    return value[:4] + "••••" + value[-4:]


class ConfigUpdate(BaseModel):
    api_key: str | None = None
    base_url: str | None = None
    tavily_key: str | None = None


def _write_env(updates: dict[str, str]) -> None:
    """Update or append KEY=value lines in backend/.env, preserving comments & other keys."""
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
    seen: set[str] = set()
    out: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in updates:
                out.append(f"{key}={updates[key]}")
                seen.add(key)
                continue
        out.append(line)
    for key, val in updates.items():
        if key not in seen:
            out.append(f"{key}={val}")
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")


def _apply(key: str, value: str) -> None:
    """Live-effect, no restart. Covers both credential consumption paths:
    - LLM (build_llm) reads settings.OPENROUTER_* at call time -> setattr(settings).
    - Tavily (search_tool) reads os.getenv("TAVILY_API_KEY") at call time -> os.environ.
    Both are updated for robustness regardless of which path a given key uses.
    """
    setattr(settings, key, value)
    os.environ[key] = value


def _clean(v: str | None) -> str | None:
    """Sanitize an incoming credential. Returns None when the field must be skipped:
    empty/whitespace, or a masked value echoed back by the frontend (contains the • char)."""
    if not v:
        return None
    v = v.strip().replace("\n", "").replace("\r", "")
    if not v or "•" in v:
        return None
    return v


@router.get("/config")
async def get_config():
    return {
        "api_key": _mask(settings.OPENROUTER_API_KEY),
        "has_api_key": bool(settings.OPENROUTER_API_KEY),
        "base_url": settings.OPENROUTER_BASE_URL,
        "tavily_key": _mask(settings.TAVILY_API_KEY),
        "has_tavily": bool(settings.TAVILY_API_KEY),
    }


@router.put("/config")
async def put_config(body: ConfigUpdate):
    fields = {
        "OPENROUTER_API_KEY": _clean(body.api_key),
        "OPENROUTER_BASE_URL": _clean(body.base_url),
        "TAVILY_API_KEY": _clean(body.tavily_key),
    }
    env_updates = {k: v for k, v in fields.items() if v is not None}
    for k, v in env_updates.items():
        _apply(k, v)
    if env_updates:
        _write_env(env_updates)
    return {"status": "ok", "updated": list(env_updates.keys())}
