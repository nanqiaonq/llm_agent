"""Filesystem browser for the new-session directory picker."""
from fastapi import APIRouter, HTTPException, Query

from agent.fs_browse import browse, list_drives

router = APIRouter()


@router.get("/fs/browse")
async def browse_endpoint(path: str = Query(...)):
    try:
        return browse(path)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/fs/drives")
async def drives_endpoint():
    return {"drives": list_drives()}
