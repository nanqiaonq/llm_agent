"""Tools factory — returns all 10 tools bound to a session + workspace."""
from pathlib import Path
from typing import List, Optional

from langchain_core.tools import BaseTool

from agent.event_bus import EventBus
from agent.permission_registry import PermissionRegistry

from .terminal_tool import create_terminal_tool
from .python_repl_tool import create_python_repl_tool
from .fetch_url_tool import create_fetch_url_tool
from .search_tool import create_search_tool
from .file_tool import create_read_file_tool, create_write_file_tool
from .memory_tool import create_read_memory_tool, create_write_memory_tool
from .skill_tool import create_read_skill_tool, create_skill_manage_tool


def get_session_tools(
    session_dir: Path,
    workspace: Path,
    *,
    event_bus: Optional[EventBus] = None,
    session_id: Optional[str] = None,
    permission_registry: Optional[PermissionRegistry] = None,
    memory_index=None,
) -> List[BaseTool]:
    """Create all 9 tools bound to a specific session + workspace.

    M4 Feature A: when event_bus + session_id + permission_registry are all set,
    the terminal tool will trigger HIL permission_request events for destructive
    commands. Tests that don't care about HIL can omit these.

    F1: when memory_index is provided, appends session_search as 10th tool.
    """
    tools: List[BaseTool] = [
        create_terminal_tool(
            workspace=workspace,
            event_bus=event_bus,
            session_id=session_id,
            permission_registry=permission_registry,
        ),
        create_python_repl_tool(),
        create_fetch_url_tool(),
        create_search_tool(),
        create_read_file_tool(workspace=workspace),
        create_write_file_tool(workspace=workspace),
        create_read_memory_tool(session_dir=session_dir),
        create_write_memory_tool(session_dir=session_dir),
        create_read_skill_tool(session_dir=session_dir),
        create_skill_manage_tool(session_dir=session_dir),
    ]
    if memory_index is not None:
        from .memory_search_tool import create_memory_search_tool
        tools.append(create_memory_search_tool(memory_index))
    return tools
