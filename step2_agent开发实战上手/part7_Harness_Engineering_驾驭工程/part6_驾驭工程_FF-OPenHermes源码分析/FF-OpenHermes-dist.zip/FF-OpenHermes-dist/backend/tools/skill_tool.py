"""read_skill + skill_manage tools."""
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict

from agent.skill_ops import SkillOps
from config import SKILLS_GLOBAL_DIR

# 移植本源 skill_manager_tool.py 的 name 校验：name 由 LLM 生成、可被 prompt injection
# 操纵，必须拦路径穿越（../、/ 等），否则 agent 可调的工具能写到 skills/ 之外。
_VALID_SKILL_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


class ReadSkillInput(BaseModel):
    name: str = Field(description="The skill name (folder name under skills/)")


class ReadSkillTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "read_skill"
    description: str = (
        "Load the full content of a skill (SKILL.md). Use this when SKILLS_SNAPSHOT.md "
        "shows a skill that looks relevant to the current task."
    )
    args_schema: Type[BaseModel] = ReadSkillInput
    session_dir: Path

    def _run(self, name: str) -> str:
        try:
            return SkillOps(self.session_dir, global_dir=SKILLS_GLOBAL_DIR).read_skill(name)
        except FileNotFoundError:
            return f"Skill '{name}' not found in this session."


def create_read_skill_tool(session_dir: Path) -> ReadSkillTool:
    return ReadSkillTool(session_dir=Path(session_dir))


class SkillManageInput(BaseModel):
    action: Literal["create", "patch", "write_file"] = Field(
        description="create=new skill, patch=targeted find-replace in SKILL.md, write_file=add a references/templates/scripts/assets support file")
    name: str = Field(description="skill name (kebab-case folder under skills/)")
    description: Optional[str] = Field(default=None, description="[create] one-line: what it does AND when to use")
    body: Optional[str] = Field(default=None, description="[create] Markdown body (H1 + Overview + Steps + Edge Cases)")
    old_str: Optional[str] = Field(default=None, description="[patch] exact unique text to replace")
    new_str: Optional[str] = Field(default=None, description="[patch] replacement text")
    file_path: Optional[str] = Field(default=None, description="[write_file] rel path under references/|templates/|scripts/|assets/")
    content: Optional[str] = Field(default=None, description="[write_file] file content")


class SkillManageTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "skill_manage"
    description: str = (
        "Create or evolve a reusable skill when a non-trivial, repeatable workflow, technique, "
        "fix, or user preference emerges that future sessions would benefit from. "
        "Be PROACTIVE — if you just solved something reusable or the user corrected your approach, "
        "save it. action=create (new SKILL.md), patch (targeted edit to existing SKILL.md), "
        "write_file (add a references/templates/scripts support file)."
    )
    args_schema: Type[BaseModel] = SkillManageInput
    session_dir: Path

    def _run(self, action: str, name: str, description: Optional[str] = None,
             body: Optional[str] = None, old_str: Optional[str] = None,
             new_str: Optional[str] = None, file_path: Optional[str] = None,
             content: Optional[str] = None) -> str:
        if not _VALID_SKILL_NAME_RE.match(name or ""):
            return (f"skill_manage {action} failed: invalid skill name '{name}' "
                    "(use lowercase letters/digits and . _ - only; no path separators).")
        ops = SkillOps(self.session_dir, global_dir=SKILLS_GLOBAL_DIR)
        try:
            if action == "create":
                if not description or not body:
                    return "create requires both 'description' and 'body'."
                if ops.skill_scope(name) is not None:
                    return f"skill '{name}' already exists — use action=patch to edit it."
                ts = datetime.now(timezone.utc).isoformat(timespec="microseconds")
                # generated_by: skill_manage（非 agent）——foreground 主动 create 归属 user，
                # 若标 generated_by=agent，created_by() 在 usage 记录缺失时会 fallback 误判为
                # agent-created 并被 curator 治理，违背本源「前台 create 属用户、curator 不碰」。
                skill_md = (
                    "---\n" f"name: {name}\n" f'description: "{description}"\n'
                    "version: 1.0\n" "generated_by: skill_manage\n" f"created_at: {ts}\n" "---\n\n" + body
                )
                ops.write_skill(name, skill_md,
                                history_line="v1.0 · Agent-authored via skill_manage")
                return f"Skill '{name}' created."
            if action == "patch":
                if old_str is None or new_str is None:
                    return "patch requires 'old_str' and 'new_str'."
                ops.patch_skill(name, old_str, new_str)
                return f"Skill '{name}' patched."
            if action == "write_file":
                if not file_path or content is None:
                    return "write_file requires 'file_path' and 'content'."
                ops.write_support_file(name, file_path, content)
                return f"Support file '{file_path}' written to skill '{name}'."
            return f"unknown action: {action}"
        except (FileNotFoundError, ValueError) as e:
            return f"skill_manage {action} failed: {e}"


def create_skill_manage_tool(session_dir: Path) -> SkillManageTool:
    return SkillManageTool(session_dir=Path(session_dir))


class SkillArchiveInput(BaseModel):
    name: str = Field(description="要归档的技能名（仅限 agent 自产的零散/被合并技能）")


class SkillArchiveTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "archive_skill"
    description: str = (
        "Archive (soft-delete, recoverable) an agent-created skill that has been "
        "merged into an umbrella or is too trivial to keep. Only works on agent-created, "
        "non-pinned, non-global skills — others are refused."
    )
    args_schema: Type[BaseModel] = SkillArchiveInput
    session_dir: Path
    global_dir: Optional[Path] = None  # None → uses SKILLS_GLOBAL_DIR at runtime

    def _run(self, name: str) -> str:
        # 深度防御：与 skill_manage 一致的 name 校验（即便上游 skill_scope 的 .exists() 语义将来变化也不漏）
        if not _VALID_SKILL_NAME_RE.match(name or ""):
            return f"拒绝：非法技能名 '{name}'（仅限 lowercase 字母数字和 . _ -）"
        gdir = self.global_dir if self.global_dir is not None else SKILLS_GLOBAL_DIR
        ops = SkillOps(self.session_dir, global_dir=gdir)
        scope = ops.skill_scope(name)
        if scope is None:
            return f"skill '{name}' 不存在"
        if scope == "global":
            return f"拒绝：'{name}' 是 global preset，curator 不可归档"
        if ops.created_by(name) != "agent":
            return f"拒绝：'{name}' 非 agent 自产（created_by≠agent），curator 只归档 AI 自产技能"
        rec = ops.usage.get(name)
        if rec and rec.get("pinned"):
            return f"拒绝：'{name}' 已 pin，跳过"
        try:
            ops.archive_skill(name)
        except Exception as e:
            return f"archive '{name}' 失败：{e}"
        return f"已归档 '{name}'（软删，可从 .archive 恢复）"


def create_skill_archive_tool(session_dir: Path, global_dir: Optional[Path] = None) -> SkillArchiveTool:
    return SkillArchiveTool(session_dir=Path(session_dir), global_dir=global_dir)
