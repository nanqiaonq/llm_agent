"""Memory read/write tools — operate on the current session's MEMORY.md."""
from pathlib import Path
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict

from agent.memory_ops import MemoryOps


class WriteMemoryInput(BaseModel):
    entry: str = Field(description="Concise fact or instruction to remember (1-3 lines)")


class ReadMemoryInput(BaseModel):
    pass


class ReadMemoryTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "read_memory"
    description: str = "Read the long-term memory (MEMORY.md) of the current session."
    args_schema: Type[BaseModel] = ReadMemoryInput
    session_dir: Path

    def _run(self) -> str:  # type: ignore[override]
        return MemoryOps(self.session_dir).read_memory()


class WriteMemoryTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "write_memory"
    description: str = (
        "Append a new entry to MEMORY.md. Use this to remember user preferences, "
        "important facts, or context that future turns should know."
    )
    args_schema: Type[BaseModel] = WriteMemoryInput
    session_dir: Path

    def _run(self, entry: str) -> str:
        ops = MemoryOps(self.session_dir)
        cur = ops.read_memory()
        new = cur.rstrip() + f"\n- {entry.strip()}\n"
        ops.write_memory(new)
        return f"Memory updated (+{len(entry)} chars)"


def create_read_memory_tool(session_dir: Path) -> ReadMemoryTool:
    return ReadMemoryTool(session_dir=Path(session_dir))


def create_write_memory_tool(session_dir: Path) -> WriteMemoryTool:
    return WriteMemoryTool(session_dir=Path(session_dir))
