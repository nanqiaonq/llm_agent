"""FetchUrlTool — fetch a URL and return Markdown."""
from typing import Type

import html2text
import requests
from bs4 import BeautifulSoup
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class FetchUrlInput(BaseModel):
    url: str = Field(description="The URL to fetch")


class FetchUrlTool(BaseTool):
    name: str = "fetch_url"
    description: str = "Fetch a URL and return its content as Markdown."
    args_schema: Type[BaseModel] = FetchUrlInput

    def _run(self, url: str) -> str:
        try:
            r = requests.get(url, timeout=15, headers={"User-Agent": "FF-OpenHermes/0.1"})
            r.raise_for_status()
            soup = BeautifulSoup(r.text, "html.parser")
            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()
            h = html2text.HTML2Text()
            h.ignore_links = False
            h.body_width = 0
            md = h.handle(str(soup))
            return md[:8000] + ("\n...[truncated]" if len(md) > 8000 else "")
        except Exception as e:
            return f"Error fetching {url}: {e}"


def create_fetch_url_tool() -> FetchUrlTool:
    return FetchUrlTool()
