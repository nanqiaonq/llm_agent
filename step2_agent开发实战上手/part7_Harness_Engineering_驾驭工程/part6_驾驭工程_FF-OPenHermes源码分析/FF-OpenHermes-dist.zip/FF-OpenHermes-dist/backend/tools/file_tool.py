"""File read/write tools sandboxed to a workspace path."""
from pathlib import Path
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict

from utils.encoding import safe_read_text
from utils.paths import resolve_in


class ReadInput(BaseModel):
    file_path: str = Field(description="Path relative to the workspace root")


class WriteInput(BaseModel):
    file_path: str = Field(description="Path relative to the workspace root")
    content: str = Field(description="Full text content to write")


class WorkspaceReadFileTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "read_file"
    description: str = "Read a file from the current session's workspace. Path is relative to the workspace root."
    args_schema: Type[BaseModel] = ReadInput
    workspace: Path

    def _run(self, file_path: str) -> str:
        try:
            target = resolve_in(self.workspace, file_path)
        except ValueError:
            return f"Access denied: path escapes workspace root"
        if not target.exists():
            return f"File not found: {file_path}"
        if not target.is_file():
            return f"Not a file: {file_path}"
        c = safe_read_text(target)
        if len(c) > 10000:
            c = c[:10000] + "\n...[truncated]"
        return c


class WorkspaceWriteFileTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "write_file"
    description: str = "Write text content to a file in the current session's workspace. Creates parent dirs as needed."
    args_schema: Type[BaseModel] = WriteInput
    workspace: Path

    def _run(self, file_path: str, content: str) -> str:
        try:
            target = resolve_in(self.workspace, file_path)
        except ValueError:
            return f"Access denied: path escapes workspace root"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} chars to {file_path}"


def create_read_file_tool(workspace: Path) -> WorkspaceReadFileTool:
    return WorkspaceReadFileTool(workspace=Path(workspace))


def create_write_file_tool(workspace: Path) -> WorkspaceWriteFileTool:
    return WorkspaceWriteFileTool(workspace=Path(workspace))
