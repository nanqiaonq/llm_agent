"""SafeTerminalTool — sync sandbox + optional async HIL (M4 Feature A).

Three-tier safety:
  1. Absolute BLACKLIST — bypass-impossible (`rm -rf /`, `mkfs`, etc.). Always blocked.
  2. HIL_PREFIXES — softer destructive prefixes. Triggers permission_request event
     when async path is used WITH event_bus+session_id+registry deps; awaits user
     response (60s timeout → deny). Without these deps (e.g. tests, sync path),
     the tool runs the command immediately (preserving M1 behavior).
  3. Safe — runs immediately.

Both `_run` (sync) and `_arun` (async) are implemented. LangChain 1.x dispatches
`_arun` when the agent runs via ainvoke/astream — which is our production path.
"""
import asyncio
import logging
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, ConfigDict, Field

from agent.event_bus import EventBus
from agent.permission_registry import PermissionRegistry, DEFAULT_TIMEOUT_S

logger = logging.getLogger("tools.terminal_tool")

# Tier 1: absolute, no HIL bypass possible
BLACKLISTED = [
    "rm -rf /", "rm -rf /*", "mkfs", "dd if=", ":(){:|:&};:",
    "chmod -R 777 /", "shutdown", "reboot", "halt", "poweroff",
    "format c:", "del /f /s /q c:",
]

# Tier 2: requires user permission (case-insensitive substring match at command start)
HIL_PREFIXES = [
    "rm ", "rmdir ", "mv ", "cp -r", "del ", "erase ", "format ", "diskpart",
    "taskkill", "kill ", "sudo ", "chmod ", "chown ", "doskey", "fsutil",
]


class TerminalInput(BaseModel):
    command: str = Field(description="The shell command to execute")


class SafeTerminalTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "terminal"
    description: str = (
        "Execute shell commands. Working directory is the current session's workspace. "
        "On Windows, runs in cmd.exe with chcp 65001 for UTF-8 output. "
        "Destructive commands (rm, del, mv, format, ...) require user permission."
    )
    args_schema: Type[BaseModel] = TerminalInput

    workspace: Path
    # M4 Feature A — optional HIL deps; when all 3 are set, async path triggers permission flow
    event_bus: Optional[EventBus] = None
    session_id: Optional[str] = None
    permission_registry: Optional[PermissionRegistry] = None
    permission_timeout_s: float = DEFAULT_TIMEOUT_S

    # ── safety classification ──────────────────────────────

    def _is_absolute_blacklist(self, cmd: str) -> bool:
        low = cmd.lower().strip()
        return any(b in low for b in BLACKLISTED)

    def _needs_permission(self, cmd: str) -> bool:
        low = cmd.lower().strip()
        return any(low.startswith(p) for p in HIL_PREFIXES)

    # ── sync path (M1 behavior, used in non-HIL contexts) ──

    def _run(self, command: str) -> str:
        if self._is_absolute_blacklist(command):
            return f"Command blocked for safety (hardcoded blacklist): {command}"
        return self._execute(command)

    # ── async path (Feature A — HIL when deps present) ─────

    async def _arun(self, command: str) -> str:
        if self._is_absolute_blacklist(command):
            return f"Command blocked for safety (hardcoded blacklist): {command}"

        # If HIL deps absent OR command is safe → just run
        if (
            self.event_bus is None
            or self.session_id is None
            or self.permission_registry is None
            or not self._needs_permission(command)
        ):
            # Run subprocess in executor so we don't block the event loop
            return await asyncio.get_event_loop().run_in_executor(
                None, self._execute, command
            )

        # HIL flow
        request_id = uuid.uuid4().hex[:12]
        future = self.permission_registry.register(request_id)
        try:
            self.event_bus.publish(self.session_id, {
                "type": "permission_request",
                "request_id": request_id,
                "tool": "terminal",
                "command": command,
            })
            decision = await self.permission_registry.wait_with_timeout(
                future, timeout_s=self.permission_timeout_s
            )
        finally:
            self.permission_registry.unregister(request_id)

        if decision == "deny":
            return f"User denied permission to run: {command}"

        # decision is allow_once or allow_always — run it
        # (allow_always is per-session-memory; out of scope for this tool — caller can layer it)
        return await asyncio.get_event_loop().run_in_executor(
            None, self._execute, command
        )

    # ── execution helper (shared by sync + async) ──────────

    def _execute(self, command: str) -> str:
        try:
            is_win = sys.platform == "win32"
            if is_win:
                wrapped = f"chcp 65001 >nul 2>&1 && {command}"
                r = subprocess.run(
                    wrapped, shell=True, cwd=str(self.workspace),
                    capture_output=True, timeout=30,
                )
                stdout = self._decode(r.stdout)
                stderr = self._decode(r.stderr)
            else:
                r = subprocess.run(
                    command, shell=True, cwd=str(self.workspace),
                    capture_output=True, text=True, timeout=30,
                    encoding="utf-8", errors="replace",
                )
                stdout, stderr = r.stdout, r.stderr
            out = stdout
            if stderr:
                out += f"\n[stderr]: {stderr}"
            if not out.strip():
                out = "(command completed with no output)"
            if len(out) > 5000:
                out = out[:5000] + "\n...[truncated]"
            return out
        except subprocess.TimeoutExpired:
            return "Command timed out (30s limit)"
        except Exception as e:
            return f"Error: {e}"

    @staticmethod
    def _decode(raw: bytes) -> str:
        if not raw:
            return ""
        for enc in ("utf-8", "gbk"):
            try:
                return raw.decode(enc)
            except UnicodeDecodeError:
                continue
        return raw.decode("latin-1", errors="replace")


def create_terminal_tool(
    workspace: Path,
    *,
    event_bus: Optional[EventBus] = None,
    session_id: Optional[str] = None,
    permission_registry: Optional[PermissionRegistry] = None,
    permission_timeout_s: float = DEFAULT_TIMEOUT_S,
) -> SafeTerminalTool:
    """Factory. Pass event_bus+session_id+permission_registry to enable HIL flow."""
    return SafeTerminalTool(
        workspace=Path(workspace),
        event_bus=event_bus,
        session_id=session_id,
        permission_registry=permission_registry,
        permission_timeout_s=permission_timeout_s,
    )
