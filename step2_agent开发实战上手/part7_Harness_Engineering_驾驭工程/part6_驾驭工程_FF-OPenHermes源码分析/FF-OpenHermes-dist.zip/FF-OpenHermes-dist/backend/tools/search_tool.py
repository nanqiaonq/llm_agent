"""Web search tool via Tavily — gated on TAVILY_API_KEY env var."""
import os
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class SearchInput(BaseModel):
    query: str = Field(description="Search query")


class WebSearchTool(BaseTool):
    name: str = "search_web"
    description: str = (
        "Search the web for up-to-date information. Returns top 5 results with title, URL, snippet."
    )
    args_schema: Type[BaseModel] = SearchInput

    def _run(self, query: str) -> str:
        api_key = os.getenv("TAVILY_API_KEY")
        if not api_key:
            return "TAVILY_API_KEY not configured. Web search unavailable in this session."
        try:
            from tavily import TavilyClient
            client = TavilyClient(api_key=api_key)
            res = client.search(query, max_results=5)
            lines = [f"Search results for: {query}\n"]
            for i, item in enumerate(res.get("results", []), 1):
                lines.append(f"{i}. {item.get('title', '')}")
                lines.append(f"   {item.get('url', '')}")
                lines.append(f"   {item.get('content', '')[:300]}\n")
            return "\n".join(lines) if len(lines) > 1 else "No results."
        except Exception as e:
            return f"Search error: {e}"


def create_search_tool() -> WebSearchTool:
    return WebSearchTool()
