"""session_search tool — cross-session lexical memory retrieval."""
from typing import Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict


class MemorySearchInput(BaseModel):
    query: str = Field(description="Search query for cross-session history lookup")
    top_k: int = Field(default=5, description="Maximum number of results to return")


class MemorySearchTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "session_search"
    description: str = (
        "跨会话历史词法检索。Search cross-session message history using full-text search. "
        "Use when you need to recall facts, context, or previous conversations from other sessions."
    )
    args_schema: Type[BaseModel] = MemorySearchInput
    memory_index: object  # MemoryIndex instance

    def _run(self, query: str, top_k: int = 5) -> str:
        hits = self.memory_index.search(query, top_k=top_k)  # type: ignore[attr-defined]
        if not hits:
            return "No matching messages found in session history."
        lines = []
        for h in hits:
            sid = h["session_id"][:8]
            role = h["role"]
            snippet = h.get("snippet") or h.get("content", "")[:200]
            lines.append(f"[{role}@{sid}] {snippet}")
        return "\n".join(lines)


def create_memory_search_tool(index: object) -> MemorySearchTool:
    return MemorySearchTool(memory_index=index)
