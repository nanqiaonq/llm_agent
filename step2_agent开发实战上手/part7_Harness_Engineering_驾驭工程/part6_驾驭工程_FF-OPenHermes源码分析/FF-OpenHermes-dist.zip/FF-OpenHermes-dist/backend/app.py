"""FF-OpenHermes — FastAPI entrypoint."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import settings, SESSIONS_DIR, TEMPLATES_DIR, STORAGE_DIR


@asynccontextmanager
async def lifespan(app: FastAPI):
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    from agent.session_manager import SessionManager
    from agent.agent_manager import AgentManager
    from agent.event_bus import EventBus
    from agent.memory_index import MemoryIndex
    from agent.global_memory import GlobalMemory

    from agent.permission_registry import PermissionRegistry

    sm = SessionManager(sessions_dir=SESSIONS_DIR, templates_dir=TEMPLATES_DIR)
    bus = EventBus()
    reg = PermissionRegistry()
    mem_index = MemoryIndex(STORAGE_DIR / "memory.db")
    gmem = GlobalMemory(STORAGE_DIR)
    app.state.session_manager = sm
    app.state.event_bus = bus
    app.state.permission_registry = reg
    app.state.memory_index = mem_index
    app.state.global_memory = gmem
    app.state.agent_manager = AgentManager(
        session_manager=sm, event_bus=bus, permission_registry=reg,
        memory_index=mem_index, global_memory=gmem,
    )
    print(f"FF-OpenHermes backend ready · sessions={SESSIONS_DIR}")
    yield


app = FastAPI(title="FF-OpenHermes", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {"name": "FF-OpenHermes", "version": "0.1.0", "status": "running"}


from api.chat import router as chat_router
from api.sessions import router as sessions_router
from api.workspace import router as workspace_router
from api.fs import router as fs_router
from api.memory import router as memory_router
from api.skills import router as skills_router
from api.events import router as events_router

app.include_router(chat_router, prefix="/api")
app.include_router(sessions_router, prefix="/api")
app.include_router(workspace_router, prefix="/api")
app.include_router(fs_router, prefix="/api")
app.include_router(memory_router, prefix="/api")
app.include_router(skills_router, prefix="/api")
app.include_router(events_router, prefix="/api")

from api.permission import router as permission_router
app.include_router(permission_router, prefix="/api")

from api.diagnostics import router as diagnostics_router
app.include_router(diagnostics_router, prefix="/api")

from api.config import router as config_router
app.include_router(config_router, prefix="/api")
