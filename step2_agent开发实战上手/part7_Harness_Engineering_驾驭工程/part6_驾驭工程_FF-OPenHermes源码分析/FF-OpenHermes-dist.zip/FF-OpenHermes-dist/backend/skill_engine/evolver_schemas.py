"""Pydantic schemas for the skill evolver's two-stage LLM output (Actor + Curator).

M4 — Multi-round Verbal RL directed training loop.
Independent from M3 enhancer_schemas.
"""
from pydantic import BaseModel, ConfigDict, Field


class TrainingTask(BaseModel):
    id: str = Field(..., min_length=1, max_length=40)
    title: str = Field(..., min_length=1, max_length=100)
    prompt: str = Field(..., min_length=2, max_length=2000)


class TaskResult(BaseModel):
    """Single task evaluation result.

    'pass' is a Python reserved word — use `passed` as the field name with alias.
    json_mode prompts must instruct the model to output key "pass".
    """
    model_config = ConfigDict(populate_by_name=True)

    task_id: str
    output: str
    passed: bool = Field(..., alias="pass")


class ActorOutput(BaseModel):
    task_results: list[TaskResult] = Field(..., min_length=1)
    reflection: str = Field(..., min_length=10, max_length=800)


class Proposal(BaseModel):
    added: list[str] = Field(default_factory=list, max_length=3)   # each ≤80 chars imperative sentence
    removed: list[str] = Field(default_factory=list, max_length=2)  # must be existing verbatim sentences
    rationale: str = Field(..., min_length=5, max_length=400)


class CuratorOutput(BaseModel):
    proposal: Proposal
    new_skill_md: str = Field(..., min_length=40, max_length=8000)
    pass_rate: float = Field(..., ge=0, le=1)
