"""Lint rules for generator output. Run AFTER Pydantic schema validation passes."""
import re
from dataclasses import dataclass
from typing import Literal

from skill_engine.schemas import GeneratedSkill

LintLevel = Literal["ok", "warn", "error"]
RESERVED_WORDS = {"anthropic", "claude", "openai", "skill", "agent", "hermes", "gpt"}


@dataclass
class LintItem:
    field: Literal["name", "description", "body"]
    level: LintLevel
    rule: str
    message: str


def lint_skill(skill: GeneratedSkill) -> list[LintItem]:
    """Return list of lint findings. Empty list = clean."""
    items: list[LintItem] = []

    # -- name --
    if skill.name.lower() in RESERVED_WORDS:
        items.append(LintItem("name", "error", "name-reserved",
                              f'name cannot be a reserved word "{skill.name}"'))
    if len(skill.name) < 4:
        items.append(LintItem("name", "warn", "name-too-short",
                              "name is short; 4-30 chars improves discoverability"))

    # -- description --
    when_re = re.compile(
        r"(when|use when|适用|用于|何时|场景|trigger|触发|when to|用来|当)", re.IGNORECASE
    )
    if not when_re.search(skill.description):
        items.append(LintItem("description", "warn", "desc-missing-when",
                              'description lacks a "when to use" focus'))
    if "\n" in skill.description:
        items.append(LintItem("description", "warn", "desc-multiline",
                              "description should be single-line for YAML safety"))

    # -- body --
    line_count = skill.body.count("\n") + 1
    if line_count > 500:
        items.append(LintItem("body", "warn", "body-too-long",
                              f"body has {line_count} lines; consider splitting (>500 lines)"))

    return items


def has_errors(items: list[LintItem]) -> bool:
    """True if any item is an error (not just warn)."""
    return any(it.level == "error" for it in items)
