"""Diff and version-bump utilities for the skill enhancer.

Pure-Python: uses stdlib `difflib`. No new dependencies.
"""
import difflib
import re


def unified_diff_str(old: str, new: str, label: str = "skill") -> str:
    """Return unified-diff text between old and new strings. Empty result if no changes."""
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    diff_lines = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"a/{label}", tofile=f"b/{label}", n=2,
    ))
    return "".join(diff_lines)


def bump_minor_version(current: str) -> str:
    """Bump a 'major.minor' version string by 1 in the minor. Falls back to '1.1' on parse failure."""
    m = re.match(r"^(\d+)\.(\d+)$", current.strip())
    if not m:
        return "1.1"
    major, minor = int(m.group(1)), int(m.group(2))
    return f"{major}.{minor + 1}"


_FRONTMATTER_RE = re.compile(r"(^---\n)(.+?)(\n---\n)", re.DOTALL)
_VERSION_LINE_RE = re.compile(r"^version:\s*\S+\s*$", re.MULTILINE)


def replace_frontmatter_version(skill_md: str, new_version: str) -> str:
    """Replace (or insert) the `version:` line inside SKILL.md frontmatter.

    If the frontmatter has no `version:` line, append one before the closing `---`.
    """
    m = _FRONTMATTER_RE.match(skill_md)
    if not m:
        # No frontmatter — return as-is. (This shouldn't happen for skills written
        # by the generator/enhancer, but be defensive.)
        return skill_md
    fm_body = m.group(2)
    if _VERSION_LINE_RE.search(fm_body):
        new_fm = _VERSION_LINE_RE.sub(f"version: {new_version}", fm_body)
    else:
        new_fm = fm_body.rstrip() + f"\nversion: {new_version}"
    return m.group(1) + new_fm + m.group(3) + skill_md[m.end():]


def replace_skill_body(skill_md: str, new_body: str) -> str:
    """Replace the body (everything after the closing `---`) with new_body. Frontmatter preserved."""
    m = _FRONTMATTER_RE.match(skill_md)
    if not m:
        # No frontmatter — replace whole content with new_body (defensive)
        return new_body
    return skill_md[: m.end()] + "\n" + new_body.lstrip("\n")
