"""Skill generator — second LLM call that emits a structured SKILL.md from a turn."""
import json
import logging
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_core.output_parsers import PydanticOutputParser
from pydantic import ValidationError

from agent.skill_ops import SkillOps
from skill_engine.lint import lint_skill, has_errors
from skill_engine.schemas import GeneratedSkill, GeneratorOutput

logger = logging.getLogger("skill_engine.generator")

GENERATOR_SYSTEM_PROMPT = """You are evaluating an Agent's just-completed task and deciding whether the workflow is reusable enough to save as a "skill" for future tasks.

A skill is a structured Markdown document (SKILL.md) that captures:
- The trigger conditions (when to use this)
- The step-by-step procedure
- Edge cases and pitfalls

You MUST output structured JSON matching the GeneratorOutput schema. Follow the three-stage funnel:

## Stage 1 — Extract Signals (5-15 items)
Identify signals from the conversation. Each signal:
- `text`: verbatim excerpt from the conversation, ≤80 characters
- `type`: one of "preference" | "constraint" | "workflow" | "example"

## Stage 2 — Cluster & Deduplicate
Group signals into clusters:
- `preferences`: deduplicated user preferences
- `constraints`: constraints or blacklist items
- `workflows`: workflow steps in order
- `examples`: illustrative examples (≤3)

## Stage 3 — Synthesize Skill
Based on signals and clusters, produce the skill. The schema requires:
- `decision`: either "GENERATE" (the task is worth saving) or "NO_SKILL" (too trivial / one-off / unreproducible)
- `reasoning`: one sentence explaining your decision
- `signals`: the extracted signals from Stage 1 (include even for NO_SKILL if meaningful signals exist)
- `clusters`: the clustered result from Stage 2 (null for NO_SKILL)
- `skill`: required when decision=GENERATE; null otherwise

When you choose GENERATE, the `skill` object must satisfy:
- `name`: kebab-case (lowercase + digits + dashes), 4-30 chars ideally
- `description`: one line, MUST be dual-focus — what this skill does AND when to use it (MUST include "use when" / "适用" / "何时" or similar phrasing)
- `body`: Markdown with H1 + Overview + Steps + Edge Cases sections
- `triggers`: 1-8 short keyword phrases

Output NO_SKILL if:
- The task involved fewer than 3 meaningful tool calls
- The task is highly user-specific and not generalizable
- The output of the task did not succeed
"""


def _format_turn_for_generator(messages: list[BaseMessage]) -> str:
    """Render the turn as plain text for the generator prompt."""
    lines: list[str] = []
    for m in messages:
        role = getattr(m, "type", None)
        content = (getattr(m, "content", "") or "").strip()
        if role == "human":
            lines.append(f"USER: {content}")
        elif role == "ai":
            tcs = getattr(m, "tool_calls", []) or []
            if content:
                lines.append(f"ASSISTANT: {content}")
            for tc in tcs:
                lines.append(f"  TOOL_CALL: {tc.get('name')}({tc.get('args', {})})")
        elif role == "tool":
            short = content[:300] + ("..." if len(content) > 300 else "")
            lines.append(f"  TOOL_RESULT: {short}")
    return "\n".join(lines)


def _resolve_name_conflict(desired: str, ops: SkillOps) -> str:
    """If desired name already exists, append numeric suffix until free."""
    existing = {s["name"] for s in ops.list_skills()}
    if desired not in existing:
        return desired
    i = 2
    while f"{desired}-v{i}" in existing:
        i += 1
    return f"{desired}-v{i}"


async def _invoke_with_retry(structured_runnable, prompt: str, retries: int = 1) -> GeneratorOutput | None:
    """Call the structured runnable; retry once on Pydantic ValidationError; return None on persistent fail."""
    last_err: Exception | None = None
    for attempt in range(retries + 1):
        try:
            result = await structured_runnable.ainvoke(prompt)
            if isinstance(result, GeneratorOutput):
                return result
            # Some LangChain versions return dict; coerce
            return GeneratorOutput.model_validate(result)
        except ValidationError as e:
            last_err = e
            logger.warning("generator output failed Pydantic validation (attempt %d): %s", attempt + 1, e)
        except Exception as e:
            last_err = e
            logger.warning("generator LLM call failed (attempt %d): %s", attempt + 1, e)
            break  # non-validation errors aren't retried
    if last_err:
        logger.warning("generator gave up after retries: %s", last_err)
    return None


async def generate_skill_from_text(
    turn_text: str,
    session_dir: Path,
    llm_factory: Callable[[], BaseChatModel],
) -> dict[str, Any] | None:
    """Core generator. Takes already-formatted turn text, returns {name, description} or None.

    Failures are logged and swallowed — never raised — so this is safe to call from
    a background asyncio task or the active distill endpoint.
    """
    try:
        llm = llm_factory()
        # 结构化输出调优（仅对真实 ChatOpenAI 生效，不影响测试 fake）：
        #  1) streaming=False + max_tokens=4096 —— 避免 "Provider returned error" 及余额不足(402)
        #     被降级到便宜 provider；
        #  2) method="json_mode" —— 被降级时 function_calling 偶发失败(zero valid function call /
        #     字段返回字符串)，json_object 更稳(实证 5/5 vs 4/5)，需用 PydanticOutputParser 注入 schema。
        if getattr(llm, "streaming", None) is True:
            llm.streaming = False
            llm.max_tokens = 4096
        structured = llm.with_structured_output(GeneratorOutput, method="json_mode")
        prompt = (
            GENERATOR_SYSTEM_PROMPT
            + "\n\n--- BEGIN TURN ---\n"
            + turn_text
            + "\n--- END TURN ---\n\nProvide your decision now."
            + "\n\n" + PydanticOutputParser(pydantic_object=GeneratorOutput).get_format_instructions()
        )
        out = await _invoke_with_retry(structured, prompt, retries=1)
        if out is None:
            return None
        if out.decision != "GENERATE" or out.skill is None:
            logger.info("generator decided NO_SKILL: %s", out.reasoning)
            return None

        skill = out.skill

        # Lint after Pydantic
        lint_findings = lint_skill(skill)
        if has_errors(lint_findings):
            err_summary = "; ".join(f"{it.rule}: {it.message}" for it in lint_findings if it.level == "error")
            logger.warning("generator output failed lint: %s", err_summary)
            return None

        # Resolve name conflicts (include global dir so generated names avoid preset names)
        from config import SKILLS_GLOBAL_DIR
        ops = SkillOps(session_dir, global_dir=SKILLS_GLOBAL_DIR)
        final_name = _resolve_name_conflict(skill.name, ops)

        # Format SKILL.md content with frontmatter — microsecond ISO
        # to avoid timestamp collisions when two skills generate in the same second.
        ts = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        # Use json.dumps per trigger to safely escape quotes/backslashes — YAML
        # is a strict superset of JSON for double-quoted strings.
        triggers_yaml = ", ".join(json.dumps(t, ensure_ascii=False) for t in skill.triggers)
        skill_md = (
            "---\n"
            f"name: {final_name}\n"
            f'description: "{skill.description}"\n'
            "version: 1.0\n"
            "generated_by: agent\n"
            f"created_at: {ts}\n"
            f"triggers: [{triggers_yaml}]\n"
            "---\n\n"
            + skill.body
        )

        # HISTORY trace with funnel summary
        sig_counts: dict[str, int] = {}
        for sig in out.signals:
            sig_counts[sig.type] = sig_counts.get(sig.type, 0) + 1
        funnel_summary = " · ".join(
            f"{t} {sig_counts[t]}" for t in ("preference", "constraint", "workflow", "example") if sig_counts.get(t)
        )
        if funnel_summary:
            history_line = (
                f"v1.0 · 🤖 Distilled · signals {len(out.signals)}"
                f"({funnel_summary}) · {out.reasoning[:80]}"
            )
        else:
            history_line = f"v1.0 · 🤖 Auto-Generated by skill engine (reasoning: {out.reasoning[:120]})"
        # Set background origin so write_skill records created_by="agent"
        from agent.skill_provenance import set_write_origin, reset_write_origin, BACKGROUND
        _token = set_write_origin(BACKGROUND)
        try:
            ops.write_skill(final_name, skill_md, history_line=history_line)
        finally:
            reset_write_origin(_token)

        return {"name": final_name, "description": skill.description}

    except Exception as e:
        logger.error("generate_skill_from_text unhandled error: %s\n%s", e, traceback.format_exc())
        return None


async def generate_skill_from_turn(
    messages: list[BaseMessage],
    session_dir: Path,
    llm_factory: Callable[[], BaseChatModel],
) -> dict[str, Any] | None:
    """Top-level generator. Returns {name, description} on success, None on skip/failure.

    Failures are logged and swallowed — never raised — so this is safe to call from
    a background asyncio task. The intent is best-effort enrichment.
    """
    return await generate_skill_from_text(
        _format_turn_for_generator(messages),
        session_dir,
        llm_factory,
    )
