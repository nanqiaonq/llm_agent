"""Skill evolver — multi-round Verbal RL directed training loop (M4).

Each round:
  1. Actor + Evaluator: LLM uses SKILL.md as system prompt, answers each task,
     self-evaluates pass/fail, writes reflection pointing to specific rule gaps.
  2. Curator: proposes minimal patch (added≤3 / removed≤2 / total rules≤14),
     outputs complete newSkillMd with bumped version + passRate.

The generator yields SSE events: round_start / actor / round_complete / converged / done / error.
On LLM failure, yields error event and returns without writing disk (skill preserved).

Independent from M3 enhancer — do NOT import from enhancer.py.
"""
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncGenerator, Callable

from langchain_core.output_parsers import PydanticOutputParser

from agent.skill_ops import SkillOps
from skill_engine.diff import bump_minor_version, replace_frontmatter_version
from skill_engine.evolver_schemas import ActorOutput, CuratorOutput, TrainingTask

logger = logging.getLogger("skill_engine.evolver")


def _actor_system_prompt(pass_criteria: str) -> str:
    return f"""你是 Skill Evolver 的 Actor + Evaluator。

任务：
1. 用给定的 SKILL.md 当 system prompt，顺序应答每个 task，每条任务 output 控制在 80 字以内。
2. 客观判定 pass/fail：{pass_criteria}
3. 写一段中文 reflection（50-200 字），描述这一轮做得好/坏的具体地方，不要泛泛说「需要改进」，必须指出具体哪条规则不够用。

严格 JSON 输出，不要 markdown 代码块，中文。

输出格式说明：
- task_results 是数组，每项包含 task_id、output（≤80字）、pass（布尔值，键名必须是 "pass"）
- reflection 是字符串（50-200字中文）
"""


_CURATOR_SYSTEM_PROMPT = """你是 Skill Evolver 的 Curator。

任务：基于本轮 reflection 提出对 SKILL.md 的最小修改，然后输出修改后的完整 new_skill_md。

约束：
- proposal.added 最多 3 条，每条 ≤80 字，直接以「祈使句」形式写规则正文，不要带序号或前缀
- proposal.removed 最多 2 条，必须是当前 SKILL.md 已有的原句
- 总规则数（初始 + 历史保留 + 本轮新增 - 本轮删除）≤ 14，超了必须删冗余（防膨胀软约束·靠模型自律，与方法论一致，不做后端硬校验）
- new_skill_md 完整覆盖整份文件，YAML frontmatter 的 version 字段必须是给定的 next_version，直接以 --- 开头
- pass_rate 与 task_results 的 pass 比例完全一致，不要乱填
- proposal.rationale 50-200 字，说明为什么这样改

严格 JSON 输出，中文，不要代码块。
"""


async def train_skill_iterative(
    skill_name: str,
    session_dir: Path,
    task_set: list[TrainingTask],
    pass_criteria: str,
    max_rounds: int,
    target_pass_rate: float,
    llm_factory: Callable,
) -> AsyncGenerator[dict, None]:
    """Multi-round Verbal RL training loop. Yields SSE event dicts.

    Event types: round_start / actor / round_complete / converged / done / error

    Session-scoped only: SkillOps is built WITHOUT global_dir, so a global preset
    name resolves to FileNotFoundError → error event (presets are read-only). The
    API layer additionally 403s global scope before reaching here.
    """
    ops = SkillOps(session_dir)

    # 1) Read current session skill
    try:
        skill_md = ops.read_skill(skill_name)
    except FileNotFoundError:
        yield {"type": "error", "message": f"技能 '{skill_name}' 不存在"}
        return

    # Extract current version from frontmatter
    version_match = re.search(r"^version:\s*(\S+)\s*$", skill_md, flags=re.MULTILINE)
    current_version = version_match.group(1) if version_match else "1.0"

    llm = llm_factory()
    # json_mode tuning — same pattern as generator/enhancer
    if getattr(llm, "streaming", None) is True:
        llm.streaming = False
        llm.max_tokens = 4096

    actor_parser = PydanticOutputParser(pydantic_object=ActorOutput)
    curator_parser = PydanticOutputParser(pydantic_object=CuratorOutput)

    final_pass_rate = 0.0
    converged = False
    n = 0

    for n in range(1, max_rounds + 1):
        yield {"type": "round_start", "n": n}

        # ── Actor call ──────────────────────────────────────────
        actor_runnable = llm.with_structured_output(ActorOutput, method="json_mode")

        task_lines = "\n\n".join(
            f"[{t.id}] #{i + 1} {t.title}\n   prompt: {t.prompt}"
            for i, t in enumerate(task_set)
        )
        actor_prompt = (
            _actor_system_prompt(pass_criteria)
            + f"\n\n当前 SKILL.md（第 {n} 轮）：\n\n<skill>\n{skill_md}\n</skill>\n\n"
            f"任务集：\n\n{task_lines}\n\n"
            "请按 schema 输出 task_results + reflection。\n"
            "注意：task_results 每项的 pass 键名必须是 \"pass\"（布尔值）。\n\n"
            + actor_parser.get_format_instructions()
        )

        try:
            actor_out = await actor_runnable.ainvoke(actor_prompt)
            if not isinstance(actor_out, ActorOutput):
                actor_out = ActorOutput.model_validate(actor_out)
        except Exception as e:
            yield {"type": "error", "message": f"Actor 调用失败（第 {n} 轮）：{e}"}
            return

        yield {
            "type": "actor",
            "n": n,
            "task_results": [
                {"task_id": r.task_id, "output": r.output, "pass": r.passed}
                for r in actor_out.task_results
            ],
            "reflection": actor_out.reflection,
        }

        # ── Curator call ────────────────────────────────────────
        next_version = bump_minor_version(current_version)
        curator_runnable = llm.with_structured_output(CuratorOutput, method="json_mode")

        task_result_lines = "\n".join(
            f"- [{r.task_id}] {'通过' if r.passed else '未通过'} | {r.output[:100]}"
            for r in actor_out.task_results
        )
        curator_prompt = (
            _CURATOR_SYSTEM_PROMPT
            + f"\n\n当前 SKILL.md（第 {n} 轮）：\n\n<skill>\n{skill_md}\n</skill>\n\n"
            f"本轮 Actor 反思：\n{actor_out.reflection}\n\n"
            f"本轮任务通过情况：\n{task_result_lines}\n\n"
            f"请输出：\n"
            f"1. proposal.added（本轮要加的规则，直接祈使句）\n"
            f"2. proposal.removed（本轮要删的旧规则原句，必须真实存在于上面的 SKILL.md）\n"
            f"3. proposal.rationale\n"
            f"4. new_skill_md（完整新版，YAML 中 version: {next_version}，直接以 --- 开头）\n"
            f"5. pass_rate（与上面通过条数比例一致）\n\n"
            + curator_parser.get_format_instructions()
        )

        try:
            curator_out = await curator_runnable.ainvoke(curator_prompt)
            if not isinstance(curator_out, CuratorOutput):
                curator_out = CuratorOutput.model_validate(curator_out)
        except Exception as e:
            yield {"type": "error", "message": f"Curator 调用失败（第 {n} 轮）：{e}"}
            return

        # ── Ensure version is correct (model may have ignored next_version) ──
        new_skill_md = curator_out.new_skill_md.replace("<skill>", "").replace("</skill>", "").strip()
        new_skill_md = replace_frontmatter_version(new_skill_md, next_version)

        # ── Write to disk ───────────────────────────────────────
        pr = curator_out.pass_rate
        added = curator_out.proposal.added
        removed = curator_out.proposal.removed
        rationale = curator_out.proposal.rationale

        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        history_parts = [
            f"v{next_version} · {ts} · 🎓 Trained round {n} · passRate {pr:.0%} "
            f"· +{len(added)}/-{len(removed)} · {rationale[:120]}"
        ]
        if added:
            history_parts.append("\n**Added:**")
            for rule in added:
                history_parts.append(f"- {rule}")
        if removed:
            history_parts.append("\n**Removed:**")
            for rule in removed:
                history_parts.append(f"- {rule}")
        history_line = "\n".join(history_parts)

        ops.write_skill(skill_name, new_skill_md, history_line=history_line)

        # ── Update state for next round ─────────────────────────
        skill_md = new_skill_md
        current_version = next_version
        final_pass_rate = pr

        yield {
            "type": "round_complete",
            "n": n,
            "pass_rate": pr,
            "added": added,
            "removed": removed,
            "rationale": rationale,
            "version": next_version,
        }

        if pr >= target_pass_rate:
            converged = True
            yield {"type": "converged", "n": n, "pass_rate": pr, "version": next_version}
            break

    yield {
        "type": "done",
        "final_version": current_version,
        "final_pass_rate": final_pass_rate,
        "rounds": n,
        "converged": converged,
    }
