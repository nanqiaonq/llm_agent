"""Pydantic schemas for the skill generator's structured LLM output."""
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

NAME_RE = r"^[a-z][a-z0-9-]{1,63}$"

SignalType = Literal["preference", "constraint", "workflow", "example"]


class Signal(BaseModel):
    text: str = Field(..., max_length=80, description="从对话中提取的原句（≤80字）")
    type: SignalType = Field(..., description="信号类型")


class Clusters(BaseModel):
    preferences: list[str] = Field(default_factory=list, description="去重概括后的偏好")
    constraints: list[str] = Field(default_factory=list, description="约束/黑名单")
    workflows: list[str] = Field(default_factory=list, description="工作流步骤")
    examples: list[str] = Field(default_factory=list, description="对照示例（≤3）")


class GeneratedSkill(BaseModel):
    """The skill the generator decided to write. Mirrors SKILL.md frontmatter + body."""

    name: str = Field(
        ..., min_length=2, max_length=64,
        description="kebab-case identifier, must start with a lowercase letter",
    )
    description: str = Field(
        ..., min_length=20, max_length=1024,
        description="Two-focus description: what + when to use. Single line preferred.",
    )
    body: str = Field(
        ..., min_length=20, max_length=10_000,
        description="Markdown body with H1 heading and Overview / Steps / Edge Cases sections.",
    )
    triggers: list[str] = Field(
        ..., min_length=1, max_length=8,
        description="Short keywords or phrases that hint when this skill applies.",
    )

    @field_validator("name")
    @classmethod
    def _kebab_case(cls, v: str) -> str:
        import re
        if not re.fullmatch(NAME_RE, v):
            raise ValueError("name must be kebab-case (lowercase a-z, digits, '-'), starting with a letter")
        return v

    @field_validator("body")
    @classmethod
    def _has_h1(cls, v: str) -> str:
        if not any(line.startswith("# ") for line in v.splitlines()):
            raise ValueError("body must contain an H1 heading (# title)")
        return v


class GeneratorOutput(BaseModel):
    """Top-level generator response. Either GENERATE+skill or NO_SKILL."""

    decision: Literal["GENERATE", "NO_SKILL"]
    skill: GeneratedSkill | None = None
    reasoning: str = Field(
        ..., min_length=1, max_length=500,
        description="One-sentence justification for the decision (helps debug bad outputs).",
    )
    signals: list[Signal] = Field(default_factory=list, description="对话中识别的调教信号 · 5-15 条最佳")
    clusters: Clusters | None = Field(default=None, description="signals 聚类去重结果")

    @model_validator(mode="after")
    def _consistency(self) -> "GeneratorOutput":
        if self.decision == "GENERATE" and self.skill is None:
            raise ValueError("decision=GENERATE requires skill to be present")
        if self.decision == "NO_SKILL" and self.skill is not None:
            raise ValueError("decision=NO_SKILL must not include a skill")
        return self
