"""E2 curator — two-phase skill library maintenance.

Phase 1 (pure Python, no LLM): state transitions active → stale → archived
based on latest_activity_at.

Phase 2 (agentic): fork 受限 curator sub-agent 自主整合 agent-created 技能
（create umbrella / archive 成员），对齐本源 curator agentic fork 设计。

Phase 1 不动。Phase 2 从 structured pipeline 改造为 fork sub-agent。
"""
import logging
from datetime import datetime, timezone
from typing import Callable

from langchain.agents import create_agent
from langchain_core.messages import HumanMessage

from agent.skill_ops import SkillOps
from agent.skill_provenance import BACKGROUND, reset_write_origin, set_write_origin

logger = logging.getLogger("skill_engine.curator")

CURATOR_AGENT_PROMPT = """你是技能库管理员（curator），整理一批 AI 自产的技能。你只能调用：
read_skill（看技能内容）、skill_manage（建 umbrella / patch）、archive_skill（归档软删）。

任务：
1. 看候选清单，找出【名字前缀相似 / 主题重叠】的技能簇（如 write-report / write-summary / write-doc）。
2. 对每个簇：先 read_skill 看几个成员内容 → skill_manage(action=create) 建一个 umbrella 技能
   （name 必须全新 kebab-case，body 综合各成员精华）→ 再对每个被合并的成员调 archive_skill 归档。
3. 对【过于零散、单一用例、无复用价值】的技能，直接 archive_skill 归档。
4. 独立且各有价值的技能不要动。

约束：archive_skill 只对 agent 自产/非 pinned/非 global 生效，其余会被拒绝——别强行重试。
整理完简述你做了什么。若没有值得合并/归档的，直接说「无需整理」并停止。
"""


def _candidate_summary(skill: dict) -> str:
    name = skill.get("name", "")
    desc = skill.get("description", "")
    last_activity = skill.get("last_activity") or "无活动记录"
    use_count = skill.get("use_count", 0)
    return f"- {name}: {desc} (use_count={use_count}, last_activity={last_activity})"


def _age_days(ops: SkillOps, name: str, now: datetime) -> float | None:
    """Age in days since latest activity; None if no activity recorded."""
    raw = ops.usage.latest_activity_at(name)
    if raw is None:
        return None
    try:
        dt = datetime.fromisoformat(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None
    return (now - dt).total_seconds() / 86400


def _curatable(skill: dict) -> bool:
    """A skill is curatable iff it is agent-created and not pinned (session-only)."""
    return skill.get("created_by") == "agent" and not skill.get("pinned", False)


def apply_state_transitions(
    ops: SkillOps,
    *,
    stale_days: int = 30,
    archive_days: int = 90,
    execute: bool = True,
) -> dict:
    """Phase 1: pure Python state transitions, no LLM.

    Only processes agent-created, non-pinned skills. ``execute=False`` computes the
    plan without applying it. Returns a consistent shape for both modes.
    """
    now = datetime.now(timezone.utc)
    checked = 0
    to_stale: list[str] = []
    to_archive: list[str] = []

    for skill in ops.list_skills():
        if not _curatable(skill):
            continue
        checked += 1
        age = _age_days(ops, skill["name"], now)
        if age is None:
            continue
        if age > archive_days:
            to_archive.append(skill["name"])
        elif age > stale_days:
            to_stale.append(skill["name"])

    if execute:
        for name in to_archive:
            ops.archive_skill(name)
        for name in to_stale:
            ops.usage.set_state(name, "stale")
        return {"checked": checked, "marked_stale": len(to_stale), "archived": len(to_archive)}

    return {"checked": checked, "would_mark_stale": to_stale, "would_archive": to_archive}


def _gather_candidates(ops: SkillOps, *, exclude: set[str] | None = None) -> list[dict]:
    """Phase-2 candidates: agent-created, not pinned, not archived, not excluded."""
    exclude = exclude or set()
    return [
        s for s in ops.list_skills()
        if _curatable(s)
        and s.get("state", "active") != "archived"
        and s["name"] not in exclude
    ]


async def run_curator_subagent(
    ops: SkillOps,
    llm_factory: Callable,
    *,
    exclude: set[str] | None = None,
) -> dict:
    """Phase 2 agentic：fork 受限 sub-agent 自主整合。返回 {consolidations, prunings, actions}。"""
    candidates = _gather_candidates(ops, exclude=exclude)
    if len(candidates) < 2:
        return {"consolidations": [], "prunings": [], "skipped": "候选技能不足 2 个，跳过整合"}
    candidate_lines = "\n".join(_candidate_summary(s) for s in candidates)

    from tools.skill_tool import create_read_skill_tool, create_skill_manage_tool, create_skill_archive_tool

    agent = create_agent(
        model=llm_factory(),
        tools=[
            create_read_skill_tool(ops.session_dir),
            create_skill_manage_tool(ops.session_dir),
            create_skill_archive_tool(ops.session_dir),
        ],
        middleware=[],
    ).with_config(recursion_limit=10)
    prompt = CURATOR_AGENT_PROMPT + f"\n\n候选技能清单：\n{candidate_lines}\n"

    token = set_write_origin(BACKGROUND)
    try:
        result = await agent.ainvoke(
            {"messages": [HumanMessage(content=prompt)]},
            config={"configurable": {}},
        )
    except Exception as e:
        logger.warning("curator sub-agent failed: %s", e)
        return {"consolidations": [], "prunings": [], "error": str(e)}
    finally:
        reset_write_origin(token)
    return _extract_curator_actions(result)


def _extract_curator_actions(result: dict) -> dict:
    """从 sub-agent tool_calls 提取：skill_manage create=umbrella；archive_skill=归档。"""
    cons, prune, actions = [], [], []
    for m in result.get("messages", []) if isinstance(result, dict) else []:
        for tc in getattr(m, "tool_calls", []) or []:
            name = tc.get("name", "")
            args = tc.get("args", {}) or {}
            if name == "skill_manage" and args.get("action") == "create":
                cons.append({"umbrella": args.get("name", "")})
                actions.append(f"create:{args.get('name', '')}")
            elif name == "archive_skill":
                prune.append({"name": args.get("name", "")})
                actions.append(f"archive:{args.get('name', '')}")
    return {"consolidations": cons, "prunings": prune, "actions": actions}


async def curate(
    ops: SkillOps,
    llm_factory: Callable,
    *,
    stale_days: int = 30,
    archive_days: int = 90,
    dry_run: bool = False,
) -> dict:
    """Orchestrate both phases. dry_run=True: Phase 1 preview only (agentic Phase 2 不支持预览)."""
    execute = not dry_run
    transitions = apply_state_transitions(
        ops, stale_days=stale_days, archive_days=archive_days, execute=execute,
    )
    if dry_run:
        # agentic 整合无法干净预览（agent 调工具即写）→ dry_run 只预览 Phase 1 态转移
        return {
            "transitions": transitions,
            "consolidations": [],
            "prunings": [],
            "dry_run": True,
            "note": "agentic 整合不支持预览，execute 时由 curator sub-agent 真执行（archive 软删可恢复）",
        }
    consolidation = await run_curator_subagent(ops, llm_factory)
    return {"transitions": transitions, **consolidation, "dry_run": False}
