"""Tests for the skill generator end-to-end (with FakeListChatModel)."""
import json
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

from skill_engine.generator import generate_skill_from_turn
from agent.skill_ops import SkillOps


class StructuredFake(FakeListChatModel):
    """Fake model that returns its preset string AS-IF it were the structured output's JSON.

    LangChain's `with_structured_output` normally parses tool_call JSON. We bypass
    that by overriding `bind_tools` (no-op) and feeding the JSON string straight as
    AIMessage content; then `with_structured_output(method='function_calling')` will
    fall back to JSON-mode parsing.

    For this test we'll just stub `with_structured_output` itself to return a callable
    that yields a preset GeneratorOutput-shaped dict.
    """

    structured_response: dict | Exception | None = None

    def with_structured_output(self, schema, **kwargs):  # type: ignore[override]
        outer = self

        class StructuredRunnable:
            async def ainvoke(self, prompt):
                if isinstance(outer.structured_response, Exception):
                    raise outer.structured_response
                return schema.model_validate(outer.structured_response)

        return StructuredRunnable()

    def bind_tools(self, tools, **kwargs):  # avoid NotImplementedError when used elsewhere
        return self


@pytest.fixture
def session_dir(tmp_path: Path) -> Path:
    sd = tmp_path / "sess"
    (sd / "skills").mkdir(parents=True)
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("# Skills Snapshot\n", encoding="utf-8")
    (sd / "loaded_skills.json").write_text("[]", encoding="utf-8")
    return sd


def _sample_turn_messages() -> list:
    return [
        HumanMessage(content="抓取 example.com 的价格表并导出 Excel"),
        AIMessage(content="我来抓取页面", tool_calls=[
            {"id": "tc1", "name": "fetch_url", "args": {"url": "https://example.com"}},
        ]),
        ToolMessage(content="<html>...</html>", tool_call_id="tc1"),
        AIMessage(content="解析表格", tool_calls=[
            {"id": "tc2", "name": "python_repl", "args": {"code": "..."}},
        ]),
        ToolMessage(content="parsed 24 rows", tool_call_id="tc2"),
        AIMessage(content="写入 Excel", tool_calls=[
            {"id": "tc3", "name": "write_file", "args": {"file_path": "prices.xlsx"}},
        ]),
        ToolMessage(content="wrote prices.xlsx", tool_call_id="tc3"),
        AIMessage(content="已导出 24 行价格表到 prices.xlsx"),
    ]


@pytest.mark.asyncio
async def test_generator_writes_skill_when_decision_is_generate(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "Reusable workflow for table scraping",
        "skill": {
            "name": "extract-web-table",
            "description": "Scrape HTML tables from web pages and export to Excel. Use when the user asks for table data extraction.",
            "body": "# extract-web-table\n\n## Overview\nFetch HTML, parse table, write xlsx.",
            "triggers": ["scrape table", "export to excel"],
        },
    }

    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )

    assert result is not None
    assert result["name"] == "extract-web-table"
    skill_md = (session_dir / "skills" / "extract-web-table" / "SKILL.md").read_text(encoding="utf-8")
    assert "extract-web-table" in skill_md
    history = (session_dir / "skills" / "extract-web-table" / "HISTORY.md").read_text(encoding="utf-8")
    assert "v1.0" in history or "Auto-Generated" in history


@pytest.mark.asyncio
async def test_generator_skips_when_decision_is_no_skill(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "NO_SKILL",
        "skill": None,
        "reasoning": "Task too trivial",
    }
    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is None
    # No skills directory created
    skills = list((session_dir / "skills").iterdir())
    skill_dirs = [p for p in skills if p.is_dir()]
    assert skill_dirs == []


@pytest.mark.asyncio
async def test_generator_resolves_name_conflict_with_suffix(session_dir: Path):
    # Pre-create a skill with the same name
    ops = SkillOps(session_dir)
    ops.write_skill(
        "extract-web-table",
        "---\nname: extract-web-table\ndescription: Existing skill. Use when always.\nversion: 1.0\n---\n\n# extract-web-table\nold body",
    )

    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "New variation",
        "skill": {
            "name": "extract-web-table",
            "description": "Scrape HTML tables. Use when the user asks for table data.",
            "body": "# extract-web-table\n\nbody",
            "triggers": ["scrape"],
        },
    }
    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is not None
    assert result["name"] != "extract-web-table"
    assert result["name"].startswith("extract-web-table")
    # Both directories exist
    assert (session_dir / "skills" / "extract-web-table").is_dir()
    assert (session_dir / "skills" / result["name"]).is_dir()


@pytest.mark.asyncio
async def test_generator_returns_none_on_llm_exception(session_dir: Path, caplog):
    fake = StructuredFake(responses=[])
    fake.structured_response = RuntimeError("LLM upstream blew up")

    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is None  # silent failure, no propagation


@pytest.mark.asyncio
async def test_generator_returns_none_on_lint_error(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "ok",
        "skill": {
            "name": "claude",  # reserved -> lint error
            "description": "Does stuff. Use when needed.",
            "body": "# claude\nbody",
            "triggers": ["x"],
        },
    }
    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is None


@pytest.mark.asyncio
async def test_generated_skill_triggers_escape_quotes(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "ok",
        "skill": {
            "name": "quote-skill",
            "description": "Demo. Use when testing.",
            "body": "# quote-skill\nbody content for tests",
            "triggers": ['say "hello"', "back\\slash", "normal trigger"],
        },
    }
    await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    md = (session_dir / "skills" / "quote-skill" / "SKILL.md").read_text(encoding="utf-8")
    # The triggers line should contain JSON-escaped quotes for "say \"hello\""
    triggers_line = next(l for l in md.splitlines() if l.startswith("triggers:"))
    # JSON encoding of `say "hello"` is `"say \"hello\""`
    assert '\\"hello\\"' in triggers_line, f"quotes not escaped: {triggers_line}"
    # Backslash escaped too
    assert "back\\\\slash" in triggers_line, f"backslash not escaped: {triggers_line}"


@pytest.mark.asyncio
async def test_generated_skill_md_has_microsecond_created_at(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "ok",
        "skill": {
            "name": "demo-skill",
            "description": "Demo. Use when testing.",
            "body": "# demo-skill\nbody content",
            "triggers": ["demo"],
        },
    }
    await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    md = (session_dir / "skills" / "demo-skill" / "SKILL.md").read_text(encoding="utf-8")
    # Must contain microsecond fraction in created_at (e.g., "2026-...T...:....123456+00:00")
    import re
    m = re.search(r"created_at:\s*(\S+)", md)
    assert m, f"no created_at in frontmatter: {md}"
    iso = m.group(1)
    # ISO with microseconds has a "." between seconds and timezone
    assert "." in iso, f"created_at lacks microsecond fraction: {iso}"
