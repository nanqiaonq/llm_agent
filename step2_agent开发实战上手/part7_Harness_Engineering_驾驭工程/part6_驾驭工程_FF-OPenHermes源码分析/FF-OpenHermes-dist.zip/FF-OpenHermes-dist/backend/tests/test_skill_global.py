"""Tests for F3 Part A: global preset skills layer."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager
from agent.skill_ops import SkillOps
from config import SKILLS_GLOBAL_DIR


# ── helpers ────────────────────────────────────────────────────────────────────

def _make_skill_md(name: str, description: str = "A skill. Use when testing.") -> str:
    return (
        f"---\nname: {name}\ndescription: {description}\n"
        f"version: 1.0\ngenerated_by: agent\n---\n\n# {name}\nbody\n"
    )


def _make_global_skill_md(name: str, description: str = "A preset. Use when testing.") -> str:
    return (
        f"---\nname: {name}\ndescription: {description}\n"
        f"version: 1.0\ngenerated_by: preset\n---\n\n# {name}\nbody\n"
    )


# ── A8.1 aggregation ───────────────────────────────────────────────────────────

def test_aggregation(tmp_path: Path):
    """session skill A + global skill B → list returns both with correct scopes."""
    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"

    (session_dir / "skills" / "skill-a").mkdir(parents=True)
    (session_dir / "skills" / "skill-a" / "SKILL.md").write_text(
        _make_skill_md("skill-a"), encoding="utf-8"
    )

    (global_dir / "skill-b").mkdir(parents=True)
    (global_dir / "skill-b" / "SKILL.md").write_text(
        _make_global_skill_md("skill-b"), encoding="utf-8"
    )

    ops = SkillOps(session_dir, global_dir=global_dir)
    skills = ops.list_skills()

    assert len(skills) == 2
    by_name = {s["name"]: s for s in skills}
    assert by_name["skill-a"]["scope"] == "session"
    assert by_name["skill-b"]["scope"] == "global"
    assert by_name["skill-b"]["generated_by"] == "preset"


# ── A8.2 shadow ────────────────────────────────────────────────────────────────

def test_shadow(tmp_path: Path):
    """Session skill X shadows global skill X → only 1 entry with scope=session."""
    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"

    (session_dir / "skills" / "shared-x").mkdir(parents=True)
    (session_dir / "skills" / "shared-x" / "SKILL.md").write_text(
        _make_skill_md("shared-x"), encoding="utf-8"
    )

    (global_dir / "shared-x").mkdir(parents=True)
    (global_dir / "shared-x" / "SKILL.md").write_text(
        _make_global_skill_md("shared-x"), encoding="utf-8"
    )

    ops = SkillOps(session_dir, global_dir=global_dir)
    skills = ops.list_skills()

    names = [s["name"] for s in skills]
    assert names.count("shared-x") == 1
    assert next(s for s in skills if s["name"] == "shared-x")["scope"] == "session"


# ── A8.3 read_skill fallback ───────────────────────────────────────────────────

def test_read_skill_global_fallback(tmp_path: Path):
    """global-only name → returns global content."""
    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"
    (session_dir / "skills").mkdir(parents=True)

    (global_dir / "global-only").mkdir(parents=True)
    content = _make_global_skill_md("global-only")
    (global_dir / "global-only" / "SKILL.md").write_text(content, encoding="utf-8")

    ops = SkillOps(session_dir, global_dir=global_dir)
    result = ops.read_skill("global-only")
    assert "global-only" in result


def test_read_skill_session_priority(tmp_path: Path):
    """session skill takes priority over global skill of same name."""
    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"

    (session_dir / "skills" / "my-skill").mkdir(parents=True)
    (session_dir / "skills" / "my-skill" / "SKILL.md").write_text(
        "---\nname: my-skill\n---\n# session version\n", encoding="utf-8"
    )

    (global_dir / "my-skill").mkdir(parents=True)
    (global_dir / "my-skill" / "SKILL.md").write_text(
        "---\nname: my-skill\n---\n# global version\n", encoding="utf-8"
    )

    ops = SkillOps(session_dir, global_dir=global_dir)
    result = ops.read_skill("my-skill")
    assert "session version" in result


def test_read_skill_not_found(tmp_path: Path):
    """Non-existent skill raises FileNotFoundError."""
    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"
    (session_dir / "skills").mkdir(parents=True)
    global_dir.mkdir()

    ops = SkillOps(session_dir, global_dir=global_dir)
    with pytest.raises(FileNotFoundError):
        ops.read_skill("does-not-exist")


# ── A8.4 skill_scope ──────────────────────────────────────────────────────────

def test_skill_scope(tmp_path: Path):
    """skill_scope returns correct values."""
    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"

    (session_dir / "skills" / "sess-skill").mkdir(parents=True)
    (session_dir / "skills" / "sess-skill" / "SKILL.md").write_text("---\n---\n", encoding="utf-8")

    (global_dir / "glob-skill").mkdir(parents=True)
    (global_dir / "glob-skill" / "SKILL.md").write_text("---\n---\n", encoding="utf-8")

    ops = SkillOps(session_dir, global_dir=global_dir)
    assert ops.skill_scope("sess-skill") == "session"
    assert ops.skill_scope("glob-skill") == "global"
    assert ops.skill_scope("nonexistent") is None


def test_skill_scope_session_beats_global(tmp_path: Path):
    """When both session and global have same name, scope=session."""
    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"

    (session_dir / "skills" / "dual").mkdir(parents=True)
    (session_dir / "skills" / "dual" / "SKILL.md").write_text("---\n---\n", encoding="utf-8")
    (global_dir / "dual").mkdir(parents=True)
    (global_dir / "dual" / "SKILL.md").write_text("---\n---\n", encoding="utf-8")

    ops = SkillOps(session_dir, global_dir=global_dir)
    assert ops.skill_scope("dual") == "session"


# ── A8.5 API guard tests ───────────────────────────────────────────────────────

@pytest.fixture
def api_setup(tmp_path: Path):
    """API test fixture with a global_dir containing one preset skill."""
    ws = tmp_path / "ws"
    ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# memory", encoding="utf-8")

    # Create a fake global dir with one preset skill
    gd = tmp_path / "global"
    (gd / "preset-skill").mkdir(parents=True)
    (gd / "preset-skill" / "SKILL.md").write_text(
        _make_global_skill_md("preset-skill"), encoding="utf-8"
    )

    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    # Temporarily patch SKILLS_GLOBAL_DIR in the api.skills module
    import api.skills as skills_api
    orig_gdir = skills_api.SKILLS_GLOBAL_DIR
    skills_api.SKILLS_GLOBAL_DIR = gd

    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")

    yield meta, gd

    # Restore
    skills_api.SKILLS_GLOBAL_DIR = orig_gdir


@pytest.mark.asyncio
async def test_api_list_contains_scope(api_setup):
    """GET /skills returns scope field for each skill."""
    meta, gd = api_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/skills")
        assert r.status_code == 200
        skills = r.json()["skills"]
        preset = next((s for s in skills if s["name"] == "preset-skill"), None)
        assert preset is not None
        assert preset["scope"] == "global"
        assert preset["generated_by"] == "preset"


@pytest.mark.asyncio
async def test_api_get_global_skill_200(api_setup):
    """GET /skills/{global_name} → 200 + content."""
    meta, gd = api_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/skills/preset-skill")
        assert r.status_code == 200
        assert "preset-skill" in r.json()["content"]


@pytest.mark.asyncio
async def test_api_update_global_403(api_setup):
    """PUT /skills/{global_name} → 403."""
    meta, gd = api_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.put(
            f"/api/sessions/{meta.id}/skills/preset-skill",
            json={"content": "new content"},
        )
        assert r.status_code == 403


@pytest.mark.asyncio
async def test_api_delete_global_403(api_setup):
    """DELETE /skills/{global_name} → 403."""
    meta, gd = api_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.delete(f"/api/sessions/{meta.id}/skills/preset-skill")
        assert r.status_code == 403


@pytest.mark.asyncio
async def test_api_load_global_403(api_setup):
    """POST /skills/{global_name}/load → 403."""
    meta, gd = api_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(
            f"/api/sessions/{meta.id}/skills/preset-skill/load",
            json={"level": 1},
        )
        assert r.status_code == 403


@pytest.mark.asyncio
async def test_api_session_skill_still_loadable(api_setup):
    """Session skill (not global) can still be loaded normally."""
    meta, gd = api_setup
    md = "---\nname: sess-demo\ndescription: session demo. Use when testing.\nversion: 1.0\n---\n\n# sess-demo\n"
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        # Create a session skill
        r = await ac.post(f"/api/sessions/{meta.id}/skills", json={"name": "sess-demo", "content": md})
        assert r.status_code == 200
        # Load it — should succeed
        r = await ac.post(f"/api/sessions/{meta.id}/skills/sess-demo/load", json={"level": 1})
        assert r.status_code == 200


# ── A8.6 generator name conflict avoidance ────────────────────────────────────

def test_generator_avoids_global_name(tmp_path: Path):
    """_resolve_name_conflict avoids global preset names."""
    from skill_engine.generator import _resolve_name_conflict

    session_dir = tmp_path / "session"
    global_dir = tmp_path / "global"
    (session_dir / "skills").mkdir(parents=True)

    # Global has "weather-query"
    (global_dir / "weather-query").mkdir(parents=True)
    (global_dir / "weather-query" / "SKILL.md").write_text(
        _make_global_skill_md("weather-query"), encoding="utf-8"
    )

    ops = SkillOps(session_dir, global_dir=global_dir)
    result = _resolve_name_conflict("weather-query", ops)
    assert result != "weather-query"
    assert result.startswith("weather-query-v")


# ── A8.7 smoke: real skills_global has 4 presets ──────────────────────────────

def test_real_skills_global_smoke(tmp_path: Path):
    """Smoke: SkillOps with real SKILLS_GLOBAL_DIR lists preset skills correctly."""
    session_dir = tmp_path / "session"
    (session_dir / "skills").mkdir(parents=True)

    ops = SkillOps(session_dir, global_dir=SKILLS_GLOBAL_DIR)
    skills = ops.list_skills()

    names = {s["name"] for s in skills}
    assert "weather_query" in names

    wq = next(s for s in skills if s["name"] == "weather_query")
    assert wq["scope"] == "global"
    assert wq["generated_by"] == "preset"
    assert len(names) >= 4  # at least 4 presets
