"""Tests for session-history extractor."""
from pathlib import Path

import pytest
from langchain_core.messages import HumanMessage, AIMessage
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

from agent.history import extract_turns


@pytest.mark.asyncio
async def test_empty_db_returns_empty(tmp_path: Path):
    db = tmp_path / "state.db"
    async with AsyncSqliteSaver.from_conn_string(str(db)) as cp:
        await cp.setup()
    turns = await extract_turns(db)
    assert turns == []


@pytest.mark.asyncio
async def test_returns_user_assistant_pairs(tmp_path: Path):
    """Insert a fake checkpoint with messages and verify extract_turns reads them.

    NOTE (langgraph 1.x adaptation):
      - `aput` config now requires `checkpoint_ns` (empty string is fine).
      - `aput` requires `new_versions` keyed by every channel in
        `channel_versions`, so we leave both empty rather than mismatched.
    The production `cp.alist()` walk in `extract_turns` is the part that
    must work end-to-end; this fixture just exercises that walk.
    """
    db = tmp_path / "state.db"
    async with AsyncSqliteSaver.from_conn_string(str(db)) as cp:
        await cp.setup()
        cfg = {"configurable": {"thread_id": "t1", "checkpoint_ns": ""}}
        ckpt = {
            "v": 1,
            "id": "ck1",
            "ts": "2026-04-29T10:00:00Z",
            "channel_values": {
                "messages": [
                    HumanMessage(content="hello"),
                    AIMessage(content="hi"),
                ]
            },
            "channel_versions": {},
            "versions_seen": {},
            "pending_sends": [],
        }
        await cp.aput(cfg, ckpt, {}, {})
    turns = await extract_turns(db)
    assert len(turns) >= 1
    assert turns[0]["user"] == "hello"
    assert turns[0]["assistant"] == "hi"


@pytest.mark.asyncio
async def test_tool_call_then_final_reply_both_preserved(tmp_path: Path):
    """Regression: a single user prompt that produces

        AIMessage(content='thinking', tool_calls=[X])
        ToolMessage(content='result')
        AIMessage(content='final answer')

    must NOT lose the final answer. The first version of extract_turns
    flushed the turn after the first AI message and dropped subsequent ones.
    """
    from langchain_core.messages import ToolMessage
    db = tmp_path / "state.db"
    async with AsyncSqliteSaver.from_conn_string(str(db)) as cp:
        await cp.setup()
        cfg = {"configurable": {"thread_id": "t2", "checkpoint_ns": ""}}
        ckpt = {
            "v": 1,
            "id": "ck1",
            "ts": "2026-04-29T11:00:00Z",
            "channel_values": {
                "messages": [
                    HumanMessage(content="write hello.txt"),
                    AIMessage(content="ok let me do that", tool_calls=[
                        {"id": "tc1", "name": "write_file", "args": {"file_path": "hello.txt"}},
                    ]),
                    ToolMessage(content="wrote 5 chars", tool_call_id="tc1"),
                    AIMessage(content="done!"),
                ]
            },
            "channel_versions": {},
            "versions_seen": {},
            "pending_sends": [],
        }
        await cp.aput(cfg, ckpt, {}, {})
    turns = await extract_turns(db)
    assert len(turns) == 1, f"expected 1 turn, got {len(turns)}: {turns}"
    t = turns[0]
    assert t["user"] == "write hello.txt"
    assert "ok let me do that" in t["assistant"]
    assert "done!" in t["assistant"], f"final reply lost: assistant={t['assistant']!r}"
    assert len(t["tool_calls"]) == 1
    assert t["tool_calls"][0]["name"] == "write_file"
