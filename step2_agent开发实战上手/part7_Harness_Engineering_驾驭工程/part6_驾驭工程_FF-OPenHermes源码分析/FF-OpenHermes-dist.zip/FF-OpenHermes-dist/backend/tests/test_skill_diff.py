"""Tests for diff helper + version bump."""
from skill_engine.diff import unified_diff_str, bump_minor_version, replace_frontmatter_version, replace_skill_body


def test_unified_diff_added_line():
    old = "line a\nline b\nline c\n"
    new = "line a\nline b\nline b.5\nline c\n"
    diff = unified_diff_str(old, new, label="SKILL.md")
    assert "+line b.5" in diff
    assert "@@" in diff  # hunk header present


def test_unified_diff_no_change_returns_empty_or_no_hunk():
    old = "line a\n"
    new = "line a\n"
    diff = unified_diff_str(old, new, label="SKILL.md")
    # No hunks when there are no changes
    assert "@@" not in diff


def test_bump_minor_version_simple():
    assert bump_minor_version("1.0") == "1.1"
    assert bump_minor_version("1.5") == "1.6"
    assert bump_minor_version("2.9") == "2.10"


def test_bump_minor_version_invalid_input():
    # Non-numeric falls back to "1.1"
    assert bump_minor_version("abc") == "1.1"


def test_replace_frontmatter_version():
    before = "---\nname: x\nversion: 1.0\nfoo: bar\n---\n# title"
    after = replace_frontmatter_version(before, "1.1")
    assert "version: 1.1" in after
    assert "name: x" in after  # other lines preserved
    assert "version: 1.0" not in after


def test_replace_frontmatter_version_when_missing_appends():
    """If `version:` line is missing in frontmatter, insert one."""
    before = "---\nname: x\nfoo: bar\n---\n# title"
    after = replace_frontmatter_version(before, "1.1")
    assert "version: 1.1" in after


def test_replace_skill_body_swaps_after_frontmatter():
    full_md = "---\nname: x\nversion: 1.0\n---\n\n# old body\nold content"
    new_md = replace_skill_body(full_md, "# new body\nnew content")
    assert "# new body" in new_md
    assert "# old body" not in new_md
    assert "name: x" in new_md  # frontmatter preserved
