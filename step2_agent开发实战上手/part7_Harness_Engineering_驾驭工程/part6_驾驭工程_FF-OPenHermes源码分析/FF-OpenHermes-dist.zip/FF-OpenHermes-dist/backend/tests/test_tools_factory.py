"""Tests for the tools factory `get_session_tools`."""
from pathlib import Path

import pytest

from tools import get_session_tools


@pytest.fixture
def session_dirs(tmp_path: Path):
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    (sd / "skills").mkdir()
    ws = tmp_path / "ws"
    ws.mkdir()
    return sd, ws


def test_factory_returns_expected_tools(session_dirs):
    sd, ws = session_dirs
    tools = get_session_tools(session_dir=sd, workspace=ws)
    names = sorted(t.name for t in tools)
    assert names == [
        "fetch_url", "python_repl", "read_file", "read_memory", "read_skill",
        "search_web", "skill_manage", "terminal", "write_file", "write_memory",
    ]


def test_read_skill_tool_works(session_dirs):
    sd, ws = session_dirs
    (sd / "skills" / "demo").mkdir()
    (sd / "skills" / "demo" / "SKILL.md").write_text(
        "---\nname: demo\ndescription: demo skill\nversion: 1.0\n---\n# Demo\nbody",
        encoding="utf-8",
    )
    tools = get_session_tools(session_dir=sd, workspace=ws)
    rs = next(t for t in tools if t.name == "read_skill")
    out = rs.invoke({"name": "demo"})
    assert "Demo" in out


def test_read_skill_unknown_returns_message(session_dirs):
    sd, ws = session_dirs
    tools = get_session_tools(session_dir=sd, workspace=ws)
    rs = next(t for t in tools if t.name == "read_skill")
    out = rs.invoke({"name": "ghost"})
    assert "not found" in out.lower()
