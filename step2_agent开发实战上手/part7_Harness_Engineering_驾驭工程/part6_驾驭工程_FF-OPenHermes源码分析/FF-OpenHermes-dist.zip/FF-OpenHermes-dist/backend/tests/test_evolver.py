"""Tests for M4 Skill Evolver — multi-round Verbal RL directed training loop."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager
from skill_engine.evolver import train_skill_iterative
from skill_engine.evolver_schemas import ActorOutput, CuratorOutput, Proposal, TaskResult, TrainingTask


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_session_with_skill(tmp_path: Path, skill_name: str = "my-skill") -> Path:
    sd = tmp_path / "sess"
    skill_dir = sd / "skills" / skill_name
    skill_dir.mkdir(parents=True)
    skill_md = (
        "---\n"
        f"name: {skill_name}\n"
        'description: "Test skill. Use when testing."\n'
        "version: 1.0\n"
        "generated_by: agent\n"
        "---\n\n"
        f"# {skill_name}\n\n"
        "## Overview\nA test skill.\n\n"
        "## Rules\n1. Always be helpful.\n2. Stay on topic.\n"
    )
    (skill_dir / "SKILL.md").write_text(skill_md, encoding="utf-8")
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("# snap\n", encoding="utf-8")
    return sd


def _make_task_set() -> list[TrainingTask]:
    return [
        TrainingTask(id="t1", title="Task One", prompt="Do task one"),
        TrainingTask(id="t2", title="Task Two", prompt="Do task two"),
    ]


class StagedFake:
    """Fake LLM that pops pre-staged structured responses."""

    def __init__(self, staged: list):
        self._staged = list(staged)
        self.prompts: list[str] = []   # records every ainvoke prompt for assertions

    @property
    def streaming(self):
        return False

    def with_structured_output(self, schema, **kwargs):
        outer = self

        class _Runnable:
            async def ainvoke(self, prompt):
                outer.prompts.append(prompt)
                if not outer._staged:
                    raise RuntimeError("StagedFake exhausted")
                payload = outer._staged.pop(0)
                if isinstance(payload, Exception):
                    raise payload
                return schema.model_validate(payload)

        return _Runnable()


def _actor_payload(pass_flags: list[bool]) -> dict:
    return {
        "task_results": [
            {"task_id": f"t{i + 1}", "output": f"output {i + 1}", "pass": v}
            for i, v in enumerate(pass_flags)
        ],
        "reflection": "具体来说，规则2不够用，因为没有明确说明如何处理边缘情况。",
    }


def _curator_payload(pass_rate: float, next_ver: str = "1.1") -> dict:
    return {
        "proposal": {
            "added": ["明确处理边缘情况的规则"],
            "removed": ["Stay on topic."],
            "rationale": "原规则2过于模糊，新增具体边缘情况处理规则更有针对性。",
        },
        "new_skill_md": (
            "---\n"
            "name: my-skill\n"
            'description: "Test skill. Use when testing."\n'
            f"version: {next_ver}\n"
            "generated_by: agent\n"
            "---\n\n"
            "# my-skill\n\n"
            "## Overview\nA test skill.\n\n"
            "## Rules\n1. Always be helpful.\n2. 明确处理边缘情况的规则\n"
        ),
        "pass_rate": pass_rate,
    }


# ---------------------------------------------------------------------------
# A5-1: Schema — TaskResult alias 'pass' → passed
# ---------------------------------------------------------------------------

def test_task_result_alias_pass():
    """TaskResult must accept JSON key 'pass' and expose it as .passed."""
    tr = TaskResult.model_validate({"task_id": "t1", "output": "ok", "pass": True})
    assert tr.passed is True


def test_task_result_passed_field_name():
    """TaskResult can also be constructed with passed= (populate_by_name)."""
    tr = TaskResult(task_id="t1", output="ok", passed=False)
    assert tr.passed is False


_VALID_SKILL_MD = "---\nname: x\nversion: 1.1\ngenerated_by: agent\n---\n\n# x\n\n## Overview\ntest.\n"


def test_curator_output_pass_rate_bounds():
    """CuratorOutput pass_rate must be in [0, 1]."""
    with pytest.raises(Exception):
        CuratorOutput(
            proposal=Proposal(added=[], removed=[], rationale="valid rationale text"),
            new_skill_md=_VALID_SKILL_MD,
            pass_rate=1.5,  # out of range
        )
    # valid
    co = CuratorOutput(
        proposal=Proposal(added=[], removed=[], rationale="valid rationale text"),
        new_skill_md=_VALID_SKILL_MD,
        pass_rate=0.5,
    )
    assert co.pass_rate == 0.5


# ---------------------------------------------------------------------------
# A5-2: Single round — writes skill with bumped version + HISTORY
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_single_round_writes_skill(tmp_path: Path):
    sd = _make_session_with_skill(tmp_path)
    fake = StagedFake([
        _actor_payload([True, False]),   # 1/2 pass → 0.5
        _curator_payload(0.5, "1.1"),
    ])

    events = []
    async for ev in train_skill_iterative(
        skill_name="my-skill",
        session_dir=sd,
        task_set=_make_task_set(),
        pass_criteria="pass if output is correct",
        max_rounds=1,
        target_pass_rate=1.0,
        llm_factory=lambda: fake,
    ):
        events.append(ev)

    types = [e["type"] for e in events]
    assert "round_start" in types
    assert "actor" in types
    assert "round_complete" in types
    assert "done" in types
    # Did not converge (0.5 < 1.0), no "converged" event
    assert "converged" not in types

    rc = next(e for e in events if e["type"] == "round_complete")
    assert rc["n"] == 1
    assert rc["pass_rate"] == 0.5
    assert rc["version"] == "1.1"
    assert len(rc["added"]) == 1
    assert len(rc["removed"]) == 1

    # Skill must be written with bumped version
    md = (sd / "skills" / "my-skill" / "SKILL.md").read_text(encoding="utf-8")
    assert "version: 1.1" in md

    # HISTORY must contain passRate + added/removed summary
    history = (sd / "skills" / "my-skill" / "HISTORY.md").read_text(encoding="utf-8")
    assert "Trained round 1" in history
    assert "50%" in history
    assert "+1/-1" in history


# ---------------------------------------------------------------------------
# A5-3: Converged — passRate ≥ target → 'converged' event + stops early
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_converged_stops_early(tmp_path: Path):
    sd = _make_session_with_skill(tmp_path)
    # Both tasks pass → passRate=1.0 ≥ target_pass_rate=1.0
    fake = StagedFake([
        _actor_payload([True, True]),
        _curator_payload(1.0, "1.1"),
    ])

    events = []
    async for ev in train_skill_iterative(
        skill_name="my-skill",
        session_dir=sd,
        task_set=_make_task_set(),
        pass_criteria="pass if output is correct",
        max_rounds=5,
        target_pass_rate=1.0,
        llm_factory=lambda: fake,
    ):
        events.append(ev)

    types = [e["type"] for e in events]
    assert "converged" in types
    assert "done" in types

    done = next(e for e in events if e["type"] == "done")
    assert done["converged"] is True
    assert done["rounds"] == 1  # stopped after round 1
    assert done["final_pass_rate"] == 1.0


# ---------------------------------------------------------------------------
# A5-4: max_rounds limit — passRate always < target → runs all rounds
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_max_rounds_limit(tmp_path: Path):
    sd = _make_session_with_skill(tmp_path)
    max_rounds = 3
    # Stage 3 actor+curator pairs, all passRate=0.5
    staged = []
    for i in range(max_rounds):
        ver = f"1.{i + 1}"
        staged.append(_actor_payload([True, False]))
        staged.append(_curator_payload(0.5, ver))
    fake = StagedFake(staged)

    events = []
    async for ev in train_skill_iterative(
        skill_name="my-skill",
        session_dir=sd,
        task_set=_make_task_set(),
        pass_criteria="pass if output is correct",
        max_rounds=max_rounds,
        target_pass_rate=1.0,
        llm_factory=lambda: fake,
    ):
        events.append(ev)

    round_completes = [e for e in events if e["type"] == "round_complete"]
    assert len(round_completes) == max_rounds

    done = next(e for e in events if e["type"] == "done")
    assert done["converged"] is False
    assert done["rounds"] == max_rounds
    assert "converged" not in [e["type"] for e in events]


# ---------------------------------------------------------------------------
# A5-5: Accumulation — round 2 Actor receives round 1 newSkillMd
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_accumulation_round2_gets_round1_skillmd(tmp_path: Path):
    sd = _make_session_with_skill(tmp_path)

    captured_prompts: list[str] = []

    class CapturingFake:
        @property
        def streaming(self):
            return False

        _staged = [
            _actor_payload([False, False]),   # round 1: 0/2 pass
            _curator_payload(0.0, "1.1"),
            _actor_payload([True, True]),      # round 2: 2/2 pass
            _curator_payload(1.0, "1.2"),
        ]

        def with_structured_output(self, schema, **kwargs):
            outer = self

            class _Runnable:
                async def ainvoke(self, prompt):
                    captured_prompts.append(prompt)
                    payload = outer._staged.pop(0)
                    return schema.model_validate(payload)

            return _Runnable()

    events = []
    async for ev in train_skill_iterative(
        skill_name="my-skill",
        session_dir=sd,
        task_set=_make_task_set(),
        pass_criteria="pass if output is correct",
        max_rounds=2,
        target_pass_rate=1.0,
        llm_factory=CapturingFake,
    ):
        events.append(ev)

    # The round-2 actor prompt should contain the round-1 curator's newSkillMd
    # (which has version 1.1 in its content)
    round2_actor_prompt = captured_prompts[2]  # [0]=r1-actor, [1]=r1-curator, [2]=r2-actor
    assert "version: 1.1" in round2_actor_prompt

    done = next(e for e in events if e["type"] == "done")
    assert done["converged"] is True
    assert done["rounds"] == 2


# ---------------------------------------------------------------------------
# A5-6: Error cases — global skill → 403; missing skill → error event
# ---------------------------------------------------------------------------

@pytest.fixture
def api_setup(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta


@pytest.mark.asyncio
async def test_train_global_skill_returns_403(api_setup, monkeypatch):
    """Global (preset) skills must be rejected with 403."""
    meta = api_setup

    from agent.skill_ops import SkillOps

    original_scope = SkillOps.skill_scope

    def fake_scope(self, name: str):
        if name == "global-skill":
            return "global"
        return original_scope(self, name)

    monkeypatch.setattr(SkillOps, "skill_scope", fake_scope)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(
            f"/api/sessions/{meta.id}/skills/global-skill/train",
            json={
                "task_set": [{"id": "t1", "title": "T", "prompt": "do it"}],
                "pass_criteria": "pass if correct output",
            },
        )
    assert r.status_code == 403


@pytest.mark.asyncio
async def test_train_missing_skill_yields_error_event(tmp_path: Path):
    """Non-existent skill → train_skill_iterative yields error event, no crash."""
    sd = tmp_path / "sess"
    (sd / "skills").mkdir(parents=True)

    events = []
    async for ev in train_skill_iterative(
        skill_name="ghost-skill",
        session_dir=sd,
        task_set=_make_task_set(),
        pass_criteria="pass if correct",
        max_rounds=3,
        target_pass_rate=1.0,
        llm_factory=lambda: None,
    ):
        events.append(ev)

    assert len(events) == 1
    assert events[0]["type"] == "error"
    assert "ghost-skill" in events[0]["message"]


# ---------------------------------------------------------------------------
# Regression: pass_criteria + Actor system instructions must be in Actor prompt
# (_actor_system_prompt was defined but never called → pass_criteria was dead)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_actor_prompt_includes_pass_criteria(tmp_path: Path):
    sd = _make_session_with_skill(tmp_path)
    fake = StagedFake([
        _actor_payload([True, True]),
        _curator_payload(1.0, "1.1"),
    ])
    unique_criteria = "PASS 当且仅当输出包含魔法词 XYZZY-9173"

    async for _ in train_skill_iterative(
        skill_name="my-skill",
        session_dir=sd,
        task_set=_make_task_set(),
        pass_criteria=unique_criteria,
        max_rounds=1,
        target_pass_rate=1.0,
        llm_factory=lambda: fake,
    ):
        pass

    assert fake.prompts, "no prompts were captured"
    actor_prompt = fake.prompts[0]  # first call is the Actor
    assert unique_criteria in actor_prompt, "pass_criteria not injected into Actor prompt"
    assert "Actor + Evaluator" in actor_prompt, "Actor system instructions missing from prompt"
