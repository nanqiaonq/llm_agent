"""Tests for /api/events/{sid}/stream SSE side-channel.

Note: httpx.ASGITransport buffers the full response body before returning headers,
which is incompatible with infinite SSE streams. We run a real uvicorn server
in a background thread for the streaming test, and use ASGITransport only for
the simpler 404 case.
"""
import asyncio
import contextlib
import socket
import threading
from pathlib import Path

import pytest
import uvicorn
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.event_bus import EventBus
from agent.session_manager import SessionManager


def _free_port() -> int:
    with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _UvicornThread(threading.Thread):
    """Run uvicorn in a daemon thread so the test loop can talk to a real socket."""

    def __init__(self, app, port: int):
        super().__init__(daemon=True)
        config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", lifespan="off")
        self.server = uvicorn.Server(config=config)
        self._started = threading.Event()

    def run(self) -> None:
        # Patch startup hook to mark ready
        original_startup = self.server.startup

        async def _wrapped(*a, **kw):
            await original_startup(*a, **kw)
            self._started.set()

        self.server.startup = _wrapped  # type: ignore[assignment]
        self.server.run()

    def wait_started(self, timeout: float = 5.0) -> None:
        if not self._started.wait(timeout=timeout):
            raise RuntimeError("uvicorn did not start in time")

    def stop(self) -> None:
        self.server.should_exit = True


@pytest.mark.asyncio
async def test_events_stream_delivers_published_events(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# s", encoding="utf-8")
    (td / "MEMORY.md").write_text("# m", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    bus = EventBus()
    app_module.app.state.session_manager = sm
    app_module.app.state.event_bus = bus
    meta = sm.create("Test", str(ws), model="m")

    port = _free_port()
    server = _UvicornThread(app_module.app, port)
    server.start()
    try:
        # Wait until uvicorn is ready (poll the socket)
        for _ in range(50):
            with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
                try:
                    s.connect(("127.0.0.1", port))
                    break
                except OSError:
                    await asyncio.sleep(0.1)
        else:
            pytest.fail("uvicorn server did not become reachable")

        received: list[str] = []

        async def consume_stream():
            # Disable any system proxy (Windows IE settings) so requests go direct to localhost
            async with AsyncClient(base_url=f"http://127.0.0.1:{port}", timeout=5.0, trust_env=False) as ac:
                async with ac.stream("GET", f"/api/events/{meta.id}/stream") as resp:
                    assert resp.status_code == 200
                    saw_event = False
                    async for line in resp.aiter_lines():
                        received.append(line)
                        if line.startswith("event: skill_generated"):
                            saw_event = True
                        elif saw_event and line.startswith("data:"):
                            return  # got both event + data lines; close

        # Start consumer
        task = asyncio.create_task(consume_stream())
        # Give the consumer time to subscribe
        await asyncio.sleep(0.5)
        # Publish
        bus.publish(meta.id, {"type": "skill_generated", "name": "foo", "description": "bar"})
        # Wait for consumer
        try:
            await asyncio.wait_for(task, timeout=3.0)
        except asyncio.TimeoutError:
            pytest.fail(f"event not received in 3s. got: {received[:30]}")

        payload = "\n".join(received)
        assert "skill_generated" in payload
        assert '"name": "foo"' in payload or '"name":"foo"' in payload
    finally:
        server.stop()
        server.join(timeout=5.0)


@pytest.mark.asyncio
async def test_events_stream_404_unknown_session(tmp_path: Path):
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# s", encoding="utf-8")
    (td / "MEMORY.md").write_text("# m", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    bus = EventBus()
    app_module.app.state.session_manager = sm
    app_module.app.state.event_bus = bus

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        resp = await ac.get("/api/events/sess_nonexistent/stream")
    assert resp.status_code == 404
