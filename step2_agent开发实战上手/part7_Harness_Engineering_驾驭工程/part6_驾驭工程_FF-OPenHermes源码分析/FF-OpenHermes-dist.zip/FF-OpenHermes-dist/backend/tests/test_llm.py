"""Test LLM factory configures OpenRouter correctly without making network calls."""
from agent.llm import build_llm


def test_build_llm_uses_openrouter_base_url(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-test-xxx")
    monkeypatch.setenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
    monkeypatch.setenv("OPENROUTER_MODEL", "deepseek/deepseek-chat-v3.1")
    # Reload settings (and agent.llm so it rebinds the new `settings` object)
    import importlib, config
    importlib.reload(config)
    import agent.llm as llm_mod
    importlib.reload(llm_mod)

    llm = llm_mod.build_llm()
    # ChatOpenAI exposes openai_api_base / model
    assert "openrouter.ai" in str(llm.openai_api_base)
    assert llm.model_name == "deepseek/deepseek-chat-v3.1"


def test_build_llm_raises_without_key(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "")
    import importlib, config
    importlib.reload(config)
    import agent.llm as llm_mod
    importlib.reload(llm_mod)
    import pytest
    with pytest.raises(RuntimeError, match="OPENROUTER_API_KEY"):
        llm_mod.build_llm()
