"""P1 思维链功能测试 — 全部使用 fake LLM，禁止真实网络调用。"""
from pathlib import Path
from unittest.mock import AsyncMock

import importlib
import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.messages import AIMessageChunk


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

class ToolBindableFake(FakeListChatModel):
    """FakeListChatModel with bind_tools no-op — required by create_agent."""

    def bind_tools(self, tools, **kwargs):
        return self


def _make_manager(tmp_path: Path, llm_factory):
    from agent.agent_manager import AgentManager
    from agent.session_manager import SessionManager

    workspace = tmp_path / "ws"
    workspace.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    meta = sm.create("Test", str(workspace), model="fake")
    mgr = AgentManager(session_manager=sm, llm_factory=llm_factory)
    return mgr, meta


# ---------------------------------------------------------------------------
# test 1: build_llm reasoning flag returns correct class
# ---------------------------------------------------------------------------

def test_build_llm_reasoning_flag(monkeypatch):
    """reasoning=True → ChatDeepSeek; default/False → ChatOpenAI."""
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-test-xxx")
    monkeypatch.setenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
    monkeypatch.setenv("OPENROUTER_MODEL", "deepseek/deepseek-chat-v3.1")

    import config
    importlib.reload(config)
    import agent.llm as llm_mod
    importlib.reload(llm_mod)

    llm_default = llm_mod.build_llm()
    llm_false = llm_mod.build_llm(reasoning=False)
    llm_true = llm_mod.build_llm(reasoning=True)

    assert "ChatOpenAI" in type(llm_default).__name__, \
        f"Expected ChatOpenAI, got {type(llm_default).__name__}"
    assert "ChatOpenAI" in type(llm_false).__name__, \
        f"Expected ChatOpenAI, got {type(llm_false).__name__}"
    assert "ChatDeepSeek" in type(llm_true).__name__, \
        f"Expected ChatDeepSeek, got {type(llm_true).__name__}"


# ---------------------------------------------------------------------------
# test 2: astream emits thinking event before assistant_token
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_astream_emits_thinking(tmp_path: Path, monkeypatch):
    """AgentManager.astream yields thinking event from reasoning_content chunk."""
    # Build fake chunks: first reasoning chunk, then answer chunk
    reasoning_chunk = AIMessageChunk(
        content="",
        additional_kwargs={"reasoning_content": "我在推理…"},
    )
    answer_chunk = AIMessageChunk(content="这是答案。")

    async def fake_agent_astream(input, config, stream_mode):
        # Yield the reasoning chunk first, then the answer chunk
        yield "messages", (reasoning_chunk, {})
        yield "messages", (answer_chunk, {})

    fake_agent = AsyncMock()
    fake_agent.astream = fake_agent_astream

    # Patch create_agent to return our fake agent
    monkeypatch.setattr(
        "agent.agent_manager.create_agent",
        lambda **kwargs: fake_agent,
    )

    fake_llm = ToolBindableFake(responses=["这是答案。"])
    mgr, meta = _make_manager(tmp_path, lambda **kw: fake_llm)

    events = []
    async for ev in mgr.astream(meta.id, "test"):
        events.append(ev)

    types = [e["type"] for e in events]
    assert "thinking" in types, f"No thinking event in {types}"
    assert "assistant_token" in types, f"No assistant_token event in {types}"

    thinking_idx = next(i for i, e in enumerate(events) if e["type"] == "thinking")
    token_idx = next(i for i, e in enumerate(events) if e["type"] == "assistant_token")
    assert thinking_idx < token_idx, "thinking must appear before assistant_token"

    thinking_ev = events[thinking_idx]
    assert thinking_ev["content"] == "我在推理…"


# ---------------------------------------------------------------------------
# test 3: reasoning content NOT included in full_response
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_reasoning_not_in_full_text(tmp_path: Path, monkeypatch):
    """turn_end full_response must contain only answer content, not reasoning_content."""
    reasoning_chunk = AIMessageChunk(
        content="",
        additional_kwargs={"reasoning_content": "我在推理…"},
    )
    answer_chunk = AIMessageChunk(content="最终答案")

    async def fake_agent_astream(input, config, stream_mode):
        yield "messages", (reasoning_chunk, {})
        yield "messages", (answer_chunk, {})

    fake_agent = AsyncMock()
    fake_agent.astream = fake_agent_astream

    monkeypatch.setattr(
        "agent.agent_manager.create_agent",
        lambda **kwargs: fake_agent,
    )

    fake_llm = ToolBindableFake(responses=["最终答案"])
    mgr, meta = _make_manager(tmp_path, lambda **kw: fake_llm)

    events = []
    async for ev in mgr.astream(meta.id, "test"):
        events.append(ev)

    turn_end = next(e for e in events if e["type"] == "turn_end")
    full_resp = turn_end["full_response"]
    assert "我在推理" not in full_resp, \
        f"reasoning_content leaked into full_response: {full_resp!r}"
    assert "最终答案" in full_resp, \
        f"answer not found in full_response: {full_resp!r}"


# ---------------------------------------------------------------------------
# test 4: no reasoning_content → no thinking event, tokens still work
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_no_reasoning_graceful(tmp_path: Path, monkeypatch):
    """Chunk with empty additional_kwargs → no thinking event emitted."""
    normal_chunk = AIMessageChunk(content="普通回答")

    async def fake_agent_astream(input, config, stream_mode):
        yield "messages", (normal_chunk, {})

    fake_agent = AsyncMock()
    fake_agent.astream = fake_agent_astream

    monkeypatch.setattr(
        "agent.agent_manager.create_agent",
        lambda **kwargs: fake_agent,
    )

    fake_llm = ToolBindableFake(responses=["普通回答"])
    mgr, meta = _make_manager(tmp_path, lambda **kw: fake_llm)

    events = []
    async for ev in mgr.astream(meta.id, "test"):
        events.append(ev)

    thinking_events = [e for e in events if e["type"] == "thinking"]
    assert len(thinking_events) == 0, f"Unexpected thinking events: {thinking_events}"

    token_events = [e for e in events if e["type"] == "assistant_token"]
    assert len(token_events) >= 1
    assert token_events[0]["content"] == "普通回答"
