"""Tests for /api/sessions/{sid}/diagnose endpoints."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    app_module.app.state.session_manager = sm
    meta = sm.create("Test", str(ws), model="m")
    return meta


@pytest.mark.asyncio
async def test_post_diagnose_writes_to_disk_and_returns_payload(setup, monkeypatch):
    meta = setup

    async def fake_extract_turns(db_path):
        return [{"user": "x", "assistant": "y", "tool_calls": []}]

    async def fake_diagnose(turns, llm_factory):
        from agent.diagnostics import HQSDiagnostic
        return HQSDiagnostic(
            score=7, failure_modes=[],
            analysis="good run, minimal issues", fix_suggestions=["use shorter prompts"],
        )

    monkeypatch.setattr("api.diagnostics.extract_turns", fake_extract_turns)
    monkeypatch.setattr("api.diagnostics.diagnose_session", fake_diagnose)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(f"/api/sessions/{meta.id}/diagnose")
    assert r.status_code == 200
    body = r.json()
    assert body["score"] == 7
    assert body["analysis"].startswith("good run")
    # Persisted
    sd = app_module.app.state.session_manager.session_dir(meta.id)
    diag_file = sd / "diagnostics.json"
    assert diag_file.exists()
    import json
    saved = json.loads(diag_file.read_text(encoding="utf-8"))
    assert saved["score"] == 7


@pytest.mark.asyncio
async def test_post_diagnose_503_on_llm_failure(setup, monkeypatch):
    meta = setup

    async def fake_extract_turns(db_path):
        return [{"user": "x", "assistant": "y", "tool_calls": []}]

    async def fake_diagnose_fail(turns, llm_factory):
        return None

    monkeypatch.setattr("api.diagnostics.extract_turns", fake_extract_turns)
    monkeypatch.setattr("api.diagnostics.diagnose_session", fake_diagnose_fail)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(f"/api/sessions/{meta.id}/diagnose")
    assert r.status_code == 503


@pytest.mark.asyncio
async def test_get_diagnose_returns_404_when_no_diagnostic(setup):
    meta = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/diagnose")
    assert r.status_code == 404


@pytest.mark.asyncio
async def test_get_diagnose_returns_persisted_diagnostic(setup):
    meta = setup
    sd = app_module.app.state.session_manager.session_dir(meta.id)
    import json
    (sd / "diagnostics.json").write_text(json.dumps({
        "score": 9,
        "failure_modes": [],
        "analysis": "perfect run",
        "fix_suggestions": [],
        "diagnosed_at": "2026-04-29T12:00:00.000000+00:00",
    }), encoding="utf-8")

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/diagnose")
    assert r.status_code == 200
    assert r.json()["score"] == 9
