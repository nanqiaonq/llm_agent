"""Tests for /api/sessions/{sid}/workspace/* endpoints."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "proj"
    ws.mkdir()
    (ws / "src").mkdir()
    (ws / "src" / "main.py").write_text("print('hi')\n", encoding="utf-8")
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta, ws


@pytest.mark.asyncio
async def test_tree_returns_files(setup):
    meta, ws = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/workspace/tree")
    assert r.status_code == 200
    body = r.json()
    names = [c["name"] for c in body["children"]]
    assert "src" in names


@pytest.mark.asyncio
async def test_read_write_roundtrip(setup):
    meta, ws = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.put(f"/api/sessions/{meta.id}/workspace/file",
                          json={"path": "notes.txt", "content": "hello"})
        assert r.status_code == 200
        r = await ac.get(f"/api/sessions/{meta.id}/workspace/file", params={"path": "notes.txt"})
        assert r.status_code == 200
        assert r.json()["content"] == "hello"


@pytest.mark.asyncio
async def test_mkdir_rename_delete(setup):
    meta, ws = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        await ac.post(f"/api/sessions/{meta.id}/workspace/mkdir", json={"path": "a"})
        await ac.post(f"/api/sessions/{meta.id}/workspace/rename",
                      json={"from_path": "a", "to_path": "b"})
        r = await ac.delete(f"/api/sessions/{meta.id}/workspace/file", params={"path": "b"})
        assert r.status_code == 200
        assert not (ws / "a").exists()
        assert not (ws / "b").exists()
