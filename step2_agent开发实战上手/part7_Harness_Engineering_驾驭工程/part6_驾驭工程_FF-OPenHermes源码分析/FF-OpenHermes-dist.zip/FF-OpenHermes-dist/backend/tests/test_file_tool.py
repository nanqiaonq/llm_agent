"""Tests for file_tool bound to workspace."""
from pathlib import Path

import pytest

from tools.file_tool import create_read_file_tool, create_write_file_tool


def test_read_in_workspace(tmp_path: Path):
    (tmp_path / "a.txt").write_text("hello", encoding="utf-8")
    tool = create_read_file_tool(workspace=tmp_path)
    out = tool.invoke({"file_path": "a.txt"})
    assert out == "hello"


def test_read_blocks_escape(tmp_path: Path):
    (tmp_path.parent / "outside.txt").write_text("nope", encoding="utf-8")
    tool = create_read_file_tool(workspace=tmp_path)
    out = tool.invoke({"file_path": "../outside.txt"})
    assert "Access denied" in out or "escapes" in out


def test_write_creates_dirs(tmp_path: Path):
    tool = create_write_file_tool(workspace=tmp_path)
    tool.invoke({"file_path": "a/b/c.txt", "content": "yo"})
    assert (tmp_path / "a" / "b" / "c.txt").read_text(encoding="utf-8") == "yo"


def test_write_blocks_escape(tmp_path: Path):
    tool = create_write_file_tool(workspace=tmp_path)
    out = tool.invoke({"file_path": "../bad.txt", "content": "x"})
    assert "Access denied" in out or "escapes" in out
