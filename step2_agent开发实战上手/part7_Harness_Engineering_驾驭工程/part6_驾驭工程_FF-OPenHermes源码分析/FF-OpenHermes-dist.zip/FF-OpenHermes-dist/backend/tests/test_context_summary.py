"""Tests for F2: SummarizationMiddleware wiring and behavior."""
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.messages import AIMessage, HumanMessage, RemoveMessage
from langgraph.graph.message import REMOVE_ALL_MESSAGES

from langchain.agents.middleware import SummarizationMiddleware


class SummaryFake(FakeListChatModel):
    """FakeListChatModel that ignores .bind_tools() and returns a fixed summary."""

    def bind_tools(self, tools, **kwargs):  # type: ignore[override]
        return self


# ---------------------------------------------------------------------------
# Test 1: before_model triggers and returns RemoveMessage + summary + kept msgs
# ---------------------------------------------------------------------------

def test_summary_triggers_on_long_conversation():
    """With trigger=('messages', 4) and keep=('messages', 2), feeding 6 messages
    should cause before_model to return a list starting with RemoveMessage(REMOVE_ALL_MESSAGES),
    followed by a summary HumanMessage, then exactly 2 preserved messages."""
    fake = SummaryFake(responses=["FIXED SUMMARY"])
    mw = SummarizationMiddleware(
        model=fake,
        trigger=("messages", 4),
        keep=("messages", 2),
    )

    messages = [
        HumanMessage(content=f"msg {i}") for i in range(6)
    ]
    state = {"messages": messages}
    runtime = MagicMock()

    result = mw.before_model(state, runtime)

    assert result is not None, "Expected summarization to trigger"
    out_msgs = result["messages"]
    assert len(out_msgs) >= 3, "Should have RemoveMessage + summary + kept msgs"

    # First must be RemoveMessage with REMOVE_ALL_MESSAGES id
    assert isinstance(out_msgs[0], RemoveMessage)
    assert out_msgs[0].id == REMOVE_ALL_MESSAGES

    # Second must be the summary HumanMessage
    summary_msg = out_msgs[1]
    assert isinstance(summary_msg, HumanMessage)
    assert "FIXED SUMMARY" in summary_msg.content

    # Remaining must be the preserved (last 2) messages
    preserved = out_msgs[2:]
    assert len(preserved) == 2
    assert preserved[-1].content == "msg 5"
    assert preserved[-2].content == "msg 4"


# ---------------------------------------------------------------------------
# Test 2/2b: astream wires SummarizationMiddleware per CONTEXT_SUMMARY_ENABLED
# Patch target MUST be agent.agent_manager.create_agent (its bound name), not
# langchain.agents.create_agent — agent_manager did `from ... import create_agent`,
# so patching the module attr would not intercept its call (capture stays empty).
# ---------------------------------------------------------------------------

async def _capture_astream_middleware(tmp_path: Path, monkeypatch, *, enabled: bool):
    """Run one astream turn with a fake llm and return the SummarizationMiddleware
    instances that were actually passed into create_agent."""
    from agent.agent_manager import AgentManager
    import agent.agent_manager as _am
    from agent.session_manager import SessionManager
    from config import settings

    monkeypatch.setattr(settings, "CONTEXT_SUMMARY_ENABLED", enabled)

    workspace = tmp_path / "ws"
    workspace.mkdir()
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul\nTest.", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")
    sm = SessionManager(sessions_dir=tmp_path / "sessions", templates_dir=templates_dir)
    meta = sm.create("Test", str(workspace), model="fake")

    fake = SummaryFake(responses=["reply"])
    captured_middleware: list = []
    original_create_agent = _am.create_agent

    def patched_create_agent(**kwargs):
        captured_middleware.extend(kwargs.get("middleware", []))
        return original_create_agent(**kwargs)

    monkeypatch.setattr(_am, "create_agent", patched_create_agent)

    mgr = AgentManager(session_manager=sm, llm_factory=lambda: fake)
    async for _ev in mgr.astream(meta.id, "hi"):
        pass

    return [m for m in captured_middleware if isinstance(m, SummarizationMiddleware)]


@pytest.mark.asyncio
async def test_summary_disabled_no_middleware(tmp_path: Path, monkeypatch):
    """CONTEXT_SUMMARY_ENABLED=False → no SummarizationMiddleware wired."""
    sm_instances = await _capture_astream_middleware(tmp_path, monkeypatch, enabled=False)
    assert len(sm_instances) == 0, f"Expected none when disabled, got {sm_instances}"


@pytest.mark.asyncio
async def test_summary_enabled_wires_middleware(tmp_path: Path, monkeypatch):
    """CONTEXT_SUMMARY_ENABLED=True → exactly one SummarizationMiddleware wired
    (positive proof the astream integration actually attaches it)."""
    sm_instances = await _capture_astream_middleware(tmp_path, monkeypatch, enabled=True)
    assert len(sm_instances) == 1, f"Expected exactly one when enabled, got {sm_instances}"


# ---------------------------------------------------------------------------
# Test 3: Short conversation (<trigger) → before_model returns None (no summary)
# ---------------------------------------------------------------------------

def test_short_conversation_no_summary():
    """With trigger=('messages', 10) and only 3 messages, before_model must
    return None (no summarization triggered)."""
    fake = SummaryFake(responses=["should not be called"])
    mw = SummarizationMiddleware(
        model=fake,
        trigger=("messages", 10),
        keep=("messages", 4),
    )

    messages = [HumanMessage(content=f"msg {i}") for i in range(3)]
    state = {"messages": messages}
    runtime = MagicMock()

    result = mw.before_model(state, runtime)

    assert result is None, (
        f"Expected None for short conversation, got {result}"
    )


# ---------------------------------------------------------------------------
# Test 5: SafeSummarizationMiddleware preserves history when summary LLM fails
# (stock middleware would replace all history with an error string)
# ---------------------------------------------------------------------------

class FailingModel(SummaryFake):
    """Summary model whose invoke/ainvoke always raises (LLM down)."""

    def invoke(self, *args, **kwargs):  # type: ignore[override]
        raise RuntimeError("summary LLM down")

    async def ainvoke(self, *args, **kwargs):  # type: ignore[override]
        raise RuntimeError("summary LLM down")


def _six_msgs():
    return [HumanMessage(content=f"m{i}") for i in range(6)]


def test_stock_summary_destroys_history_on_failure_contrast():
    """Documents WHY SafeSummarizationMiddleware exists: the stock middleware
    wipes history (RemoveMessage) and substitutes an error string on LLM failure."""
    mw = SummarizationMiddleware(
        model=FailingModel(responses=["x"]), trigger=("messages", 4), keep=("messages", 2)
    )
    result = mw.before_model({"messages": _six_msgs()}, MagicMock())
    assert result is not None
    assert isinstance(result["messages"][0], RemoveMessage)
    assert "Error generating summary" in result["messages"][1].content


def test_safe_summary_skips_on_failure_sync():
    from agent.safe_summarization import SafeSummarizationMiddleware

    mw = SafeSummarizationMiddleware(
        model=FailingModel(responses=["x"]), trigger=("messages", 4), keep=("messages", 2)
    )
    result = mw.before_model({"messages": _six_msgs()}, MagicMock())
    assert result is None, "Failed summary must be a no-op (history preserved), not a wipe"


@pytest.mark.asyncio
async def test_safe_summary_skips_on_failure_async():
    from agent.safe_summarization import SafeSummarizationMiddleware

    mw = SafeSummarizationMiddleware(
        model=FailingModel(responses=["x"]), trigger=("messages", 4), keep=("messages", 2)
    )
    result = await mw.abefore_model({"messages": _six_msgs()}, MagicMock())
    assert result is None, "Failed summary (async) must preserve history"


@pytest.mark.asyncio
async def test_safe_summary_happy_path_async():
    """SafeSummarizationMiddleware does not break the normal async summarize path."""
    from agent.safe_summarization import SafeSummarizationMiddleware

    mw = SafeSummarizationMiddleware(
        model=SummaryFake(responses=["FIXED SUMMARY"]), trigger=("messages", 4), keep=("messages", 2)
    )
    result = await mw.abefore_model({"messages": _six_msgs()}, MagicMock())
    assert result is not None
    assert isinstance(result["messages"][0], RemoveMessage)
    assert "FIXED SUMMARY" in result["messages"][1].content
    assert [m.content for m in result["messages"][2:]] == ["m4", "m5"]
