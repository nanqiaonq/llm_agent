"""Tests for the in-memory permission registry."""
import asyncio

import pytest

from agent.permission_registry import PermissionRegistry


@pytest.mark.asyncio
async def test_register_and_resolve():
    reg = PermissionRegistry()
    fut = reg.register("req1")
    reg.resolve("req1", "allow_once")
    assert await fut == "allow_once"


@pytest.mark.asyncio
async def test_resolve_unknown_id_is_noop():
    reg = PermissionRegistry()
    # Should not raise
    reg.resolve("ghost", "allow_once")


@pytest.mark.asyncio
async def test_unregister_removes_entry():
    reg = PermissionRegistry()
    reg.register("req1")
    reg.unregister("req1")
    # Resolve after unregister is a no-op
    reg.resolve("req1", "allow_once")
    assert reg.pending_count() == 0


@pytest.mark.asyncio
async def test_wait_with_timeout_returns_deny_on_timeout():
    reg = PermissionRegistry()
    fut = reg.register("req1")
    decision = await reg.wait_with_timeout(fut, timeout_s=0.1)
    assert decision == "deny"


@pytest.mark.asyncio
async def test_wait_with_timeout_returns_decision_when_resolved():
    reg = PermissionRegistry()
    fut = reg.register("req1")

    async def respond_later():
        await asyncio.sleep(0.05)
        reg.resolve("req1", "allow_always")

    asyncio.create_task(respond_later())
    decision = await reg.wait_with_timeout(fut, timeout_s=2.0)
    assert decision == "allow_always"


@pytest.mark.asyncio
async def test_resolve_twice_is_safe():
    reg = PermissionRegistry()
    fut = reg.register("req1")
    reg.resolve("req1", "allow_once")
    reg.resolve("req1", "deny")  # second resolve must not raise
    assert await fut == "allow_once"
