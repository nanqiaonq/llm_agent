"""Tests for skill lint rules."""
import pytest

from skill_engine.lint import lint_skill, LintLevel, LintItem
from skill_engine.schemas import GeneratedSkill


def _mk(**overrides) -> GeneratedSkill:
    base = dict(
        name="my-skill",
        description="Does something specific. Use when the user asks for that thing.",
        body="# my-skill\n\n## Overview\nbla.",
        triggers=["something"],
    )
    base.update(overrides)
    return GeneratedSkill(**base)


def test_clean_skill_returns_no_errors():
    items = lint_skill(_mk())
    assert all(it.level != "error" for it in items)


def test_reserved_name_errors():
    items = lint_skill(_mk(name="claude"))
    rules = {it.rule for it in items if it.level == "error"}
    assert "name-reserved" in rules


def test_short_name_warns():
    items = lint_skill(_mk(name="ab"))
    rules = {it.rule for it in items}
    assert "name-too-short" in rules


def test_description_missing_when_warns():
    items = lint_skill(_mk(description="Does something cool. " * 4))
    rules = {it.rule for it in items}
    assert "desc-missing-when" in rules


def test_description_multiline_warns():
    items = lint_skill(_mk(description="line one. Use when needed.\nline two."))
    rules = {it.rule for it in items}
    assert "desc-multiline" in rules


def test_body_too_long_warns():
    long_body = "# t\n" + ("x\n" * 600)
    items = lint_skill(_mk(body=long_body))
    rules = {it.rule for it in items}
    assert "body-too-long" in rules


def test_has_errors_helper():
    from skill_engine.lint import has_errors
    assert has_errors([LintItem(field="name", level="error", rule="x", message="x")])
    assert not has_errors([LintItem(field="name", level="warn", rule="x", message="x")])
    assert not has_errors([])
