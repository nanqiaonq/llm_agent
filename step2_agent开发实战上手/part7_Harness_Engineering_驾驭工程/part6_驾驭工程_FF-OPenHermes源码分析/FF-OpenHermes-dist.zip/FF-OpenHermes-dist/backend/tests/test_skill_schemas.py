"""Tests for Pydantic schemas used by the skill generator."""
import pytest
from pydantic import ValidationError

from skill_engine.schemas import GeneratedSkill, GeneratorOutput


def test_generated_skill_minimal_valid():
    s = GeneratedSkill(
        name="extract-web-table",
        description="Scrape HTML tables from web pages and export to Excel. Use when the user asks to scrape table or save webpage data.",
        body="# extract-web-table\n\n## Overview\n...",
        triggers=["scrape table", "extract table"],
    )
    assert s.name == "extract-web-table"
    assert len(s.triggers) == 2


def test_generated_skill_rejects_uppercase_name():
    with pytest.raises(ValidationError, match="kebab-case"):
        GeneratedSkill(
            name="ExtractTable",
            description="Long enough description that mentions when to use it.",
            body="# title\nhi",
            triggers=["x"],
        )


def test_generated_skill_rejects_empty_triggers():
    with pytest.raises(ValidationError):
        GeneratedSkill(
            name="x-skill",
            description="Long enough description that mentions when to use it.",
            body="# title",
            triggers=[],
        )


def test_generated_skill_rejects_long_name():
    with pytest.raises(ValidationError):
        GeneratedSkill(
            name="x" * 65,
            description="Long enough description that mentions when to use it.",
            body="# t",
            triggers=["a"],
        )


def test_generator_output_no_skill_branch():
    o = GeneratorOutput(decision="NO_SKILL", skill=None, reasoning="Task too trivial")
    assert o.decision == "NO_SKILL"
    assert o.skill is None


def test_generator_output_generate_branch_requires_skill():
    with pytest.raises(ValidationError, match="skill"):
        GeneratorOutput(decision="GENERATE", skill=None, reasoning="x")
