"""Tests for agent/skill_provenance.py — ContextVar write-origin tracking."""
import pytest

from agent.skill_provenance import (
    BACKGROUND,
    FOREGROUND,
    get_write_origin,
    is_background,
    reset_write_origin,
    set_write_origin,
)


def test_default_is_foreground():
    assert get_write_origin() == FOREGROUND
    assert not is_background()


def test_set_and_get():
    token = set_write_origin(BACKGROUND)
    try:
        assert get_write_origin() == BACKGROUND
        assert is_background()
    finally:
        reset_write_origin(token)


def test_reset_restores_default():
    token = set_write_origin(BACKGROUND)
    reset_write_origin(token)
    assert get_write_origin() == FOREGROUND
    assert not is_background()


def test_nested_tokens_restore_correctly():
    token1 = set_write_origin(BACKGROUND)
    assert is_background()
    token2 = set_write_origin(FOREGROUND)
    assert not is_background()
    reset_write_origin(token2)
    assert is_background()
    reset_write_origin(token1)
    assert not is_background()


def test_set_none_defaults_to_foreground():
    token = set_write_origin(None)  # type: ignore[arg-type]
    try:
        assert get_write_origin() == FOREGROUND
    finally:
        reset_write_origin(token)
