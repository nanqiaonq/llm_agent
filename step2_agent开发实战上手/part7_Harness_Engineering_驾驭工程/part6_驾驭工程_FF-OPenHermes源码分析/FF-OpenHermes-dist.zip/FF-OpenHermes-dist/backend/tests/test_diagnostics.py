"""Tests for HQS Session diagnostics."""
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from agent.diagnostics import HQSDiagnostic, diagnose_session


class StagedFake(FakeListChatModel):
    structured_response: dict | Exception | None = None

    def with_structured_output(self, schema, **kwargs):  # type: ignore[override]
        outer = self

        class StructuredRunnable:
            async def ainvoke(self, prompt):
                if isinstance(outer.structured_response, Exception):
                    raise outer.structured_response
                return schema.model_validate(outer.structured_response)

        return StructuredRunnable()

    def bind_tools(self, tools, **kwargs):
        return self


def _sample_turns():
    return [
        {"user": "Help me list files", "assistant": "Done.", "tool_calls": [{"name": "terminal", "args": {}}]},
        {"user": "Now write hello.txt", "assistant": "Wrote it.", "tool_calls": [{"name": "write_file", "args": {}}]},
    ]


@pytest.mark.asyncio
async def test_diagnose_returns_hqs_diagnostic():
    fake = StagedFake(responses=[])
    fake.structured_response = {
        "score": 8,
        "failure_modes": [],
        "analysis": "Agent executed both tasks correctly with minimal tool calls.",
        "fix_suggestions": [],
    }
    result = await diagnose_session(turns=_sample_turns(), llm_factory=lambda: fake)
    assert result is not None
    assert result.score == 8
    assert result.failure_modes == []


@pytest.mark.asyncio
async def test_diagnose_with_failure_modes():
    fake = StagedFake(responses=[])
    fake.structured_response = {
        "score": 4,
        "failure_modes": ["context_loss", "capability_gap"],
        "analysis": "Agent forgot earlier instructions and lacked the right tool for the second task.",
        "fix_suggestions": [
            "Use a longer-context model",
            "Install browser_use tool for JS-rendered content",
        ],
    }
    result = await diagnose_session(turns=_sample_turns(), llm_factory=lambda: fake)
    assert result is not None
    assert result.score == 4
    assert "context_loss" in result.failure_modes
    assert len(result.fix_suggestions) == 2


@pytest.mark.asyncio
async def test_diagnose_returns_none_on_llm_failure():
    fake = StagedFake(responses=[])
    fake.structured_response = RuntimeError("LLM upstream blew up")
    result = await diagnose_session(turns=_sample_turns(), llm_factory=lambda: fake)
    assert result is None


def test_hqs_score_clamped_0_to_10():
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        HQSDiagnostic(
            score=15, failure_modes=[],
            analysis="bla bla bla bla bla bla", fix_suggestions=[],
        )
    with pytest.raises(ValidationError):
        HQSDiagnostic(
            score=-1, failure_modes=[],
            analysis="bla bla bla bla bla bla", fix_suggestions=[],
        )


def test_hqs_failure_modes_max_5():
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        HQSDiagnostic(
            score=5,
            failure_modes=["goal_loss"] * 6,
            analysis="bla bla bla bla bla bla",
            fix_suggestions=[],
        )
