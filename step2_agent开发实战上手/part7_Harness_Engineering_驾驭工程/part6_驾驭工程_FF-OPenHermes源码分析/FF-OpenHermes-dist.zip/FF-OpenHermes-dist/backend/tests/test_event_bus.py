"""Tests for the per-process EventBus."""
import asyncio

import pytest

from agent.event_bus import EventBus


@pytest.mark.asyncio
async def test_publish_no_subscribers_is_noop():
    bus = EventBus()
    bus.publish("sess1", {"type": "x"})  # should not raise


@pytest.mark.asyncio
async def test_subscribe_receives_published_events():
    bus = EventBus()
    received: list[dict] = []

    async with bus.subscribe("sess1") as q:
        bus.publish("sess1", {"type": "skill_generated", "name": "foo"})
        bus.publish("sess1", {"type": "skill_generated", "name": "bar"})
        # consume both
        for _ in range(2):
            ev = await asyncio.wait_for(q.get(), timeout=1.0)
            received.append(ev)

    assert [e["name"] for e in received] == ["foo", "bar"]


@pytest.mark.asyncio
async def test_publish_to_other_session_not_received():
    bus = EventBus()
    async with bus.subscribe("sess1") as q:
        bus.publish("sess2", {"type": "skill_generated", "name": "other"})
        bus.publish("sess1", {"type": "skill_generated", "name": "mine"})
        ev = await asyncio.wait_for(q.get(), timeout=1.0)
        assert ev["name"] == "mine"
        # No more events queued
        assert q.empty()


@pytest.mark.asyncio
async def test_multiple_subscribers_same_session_each_get_event():
    bus = EventBus()
    async with bus.subscribe("sess1") as q1, bus.subscribe("sess1") as q2:
        bus.publish("sess1", {"type": "skill_generated", "name": "shared"})
        ev1 = await asyncio.wait_for(q1.get(), timeout=1.0)
        ev2 = await asyncio.wait_for(q2.get(), timeout=1.0)
        assert ev1["name"] == "shared"
        assert ev2["name"] == "shared"


@pytest.mark.asyncio
async def test_unsubscribe_on_context_exit():
    bus = EventBus()
    async with bus.subscribe("sess1") as q:
        pass
    # After exit, publish should not error and should have no subscribers
    bus.publish("sess1", {"type": "x"})
    # Internal state: no subscribers tracked for sess1
    assert "sess1" not in bus._subscribers or len(bus._subscribers["sess1"]) == 0
