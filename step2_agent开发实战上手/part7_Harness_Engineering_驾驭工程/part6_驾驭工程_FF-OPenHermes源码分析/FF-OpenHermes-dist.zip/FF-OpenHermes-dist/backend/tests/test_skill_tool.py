"""Tests for SkillManageTool (skill_manage)."""
from pathlib import Path

import pytest

from agent.skill_ops import SkillOps
from tools import get_session_tools
from tools.skill_tool import create_skill_manage_tool


@pytest.fixture
def session_dir(tmp_path: Path) -> Path:
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "skills").mkdir()
    return sd


# ── create ─────────────────────────────────────────────────────────────────────

def test_skill_manage_create(session_dir: Path):
    tool = create_skill_manage_tool(session_dir)
    result = tool._run(
        action="create",
        name="test-skill",
        description="A test skill. Use when testing.",
        body="# Test Skill\n\nDoes testing things.\n",
    )
    assert "created" in result.lower()
    skill_md = session_dir / "skills" / "test-skill" / "SKILL.md"
    assert skill_md.exists()
    content = skill_md.read_text(encoding="utf-8")
    assert "name: test-skill" in content
    assert 'description: "A test skill. Use when testing."' in content
    assert "generated_by: skill_manage" in content


def test_skill_manage_rejects_name_traversal(session_dir: Path):
    """name 路径穿越被拒（C1 修复）：create('../evil') 返回错误且不写到 skills/ 之外。"""
    tool = create_skill_manage_tool(session_dir)
    for bad in ["../evil", "a/b", "../../etc/x", ".hidden", "UpperCase"]:
        result = tool._run(action="create", name=bad,
                            description="x. use when y.", body="# x\n")
        assert "invalid skill name" in result.lower(), f"name {bad!r} should be rejected"
    # 确认确实没逃出 skills/ 写文件
    assert not (session_dir / "evil").exists()
    assert not (session_dir.parent / "etc").exists()


def test_skill_manage_create_foreground_is_user(session_dir: Path):
    """Foreground create → created_by=user (provenance 对齐本源硬断言)."""
    tool = create_skill_manage_tool(session_dir)
    tool._run(
        action="create",
        name="fg-skill",
        description="Foreground skill. Use when verifying provenance.",
        body="# FG Skill\n\nProvenance test.\n",
    )
    ops = SkillOps(session_dir)
    assert ops.created_by("fg-skill") == "user", (
        "foreground create must yield created_by='user', not 'agent'"
    )


def test_skill_manage_created_by_no_agent_fallback(session_dir: Path):
    """I1 修复：usage 记录缺失时 created_by 不因 frontmatter 误判 user skill 为 agent。"""
    tool = create_skill_manage_tool(session_dir)
    tool._run(action="create", name="fb-skill",
              description="x. use when y.", body="# x\n")
    ops = SkillOps(session_dir)
    ops.usage.forget("fb-skill")  # 模拟 usage 记录丢失 → 走 frontmatter fallback
    assert ops.created_by("fb-skill") != "agent", (
        "usage 缺失时不得 fallback 误判 user skill 为 agent（generated_by=skill_manage 非 agent）"
    )


def test_skill_manage_create_duplicate(session_dir: Path):
    tool = create_skill_manage_tool(session_dir)
    tool._run(
        action="create",
        name="existing-skill",
        description="Existing. Use when existing.",
        body="# Existing\n\nBody.\n",
    )
    result = tool._run(
        action="create",
        name="existing-skill",
        description="Duplicate. Use when duplicating.",
        body="# Dup\n\nBody.\n",
    )
    assert "already exists" in result


# ── patch ──────────────────────────────────────────────────────────────────────

def test_skill_manage_patch(session_dir: Path):
    tool = create_skill_manage_tool(session_dir)
    tool._run(
        action="create",
        name="patch-skill",
        description="Patch target. Use when patching.",
        body="# Patch Skill\n\nOriginal body content.\n",
    )
    result = tool._run(
        action="patch",
        name="patch-skill",
        old_str="Original body content.",
        new_str="Updated body content.",
    )
    assert "patched" in result.lower()
    content = (session_dir / "skills" / "patch-skill" / "SKILL.md").read_text(encoding="utf-8")
    assert "Updated body content." in content
    assert "Original body content." not in content


def test_skill_manage_patch_missing_args(session_dir: Path):
    tool = create_skill_manage_tool(session_dir)
    result = tool._run(action="patch", name="any-skill")
    assert "requires" in result.lower()
    # Must not raise — returns error string
    assert isinstance(result, str)


# ── write_file ─────────────────────────────────────────────────────────────────

def test_skill_manage_write_file(session_dir: Path):
    tool = create_skill_manage_tool(session_dir)
    tool._run(
        action="create",
        name="file-skill",
        description="File skill. Use when writing files.",
        body="# File Skill\n\nBody.\n",
    )
    result = tool._run(
        action="write_file",
        name="file-skill",
        file_path="references/cheatsheet.md",
        content="# Cheatsheet\nkey: value\n",
    )
    assert "written" in result.lower()
    target = session_dir / "skills" / "file-skill" / "references" / "cheatsheet.md"
    assert target.exists()
    assert "key: value" in target.read_text(encoding="utf-8")


def test_skill_manage_bad_path_returns_error(session_dir: Path):
    tool = create_skill_manage_tool(session_dir)
    tool._run(
        action="create",
        name="bad-path-skill",
        description="Bad path skill. Use when testing bad paths.",
        body="# Bad Path\n\nBody.\n",
    )
    result = tool._run(
        action="write_file",
        name="bad-path-skill",
        file_path="evil.txt",
        content="content",
    )
    # Must not raise — returns error string
    assert isinstance(result, str)
    assert "failed" in result.lower() or "must start with" in result.lower()


# ── registration ───────────────────────────────────────────────────────────────

def test_skill_manage_tool_registered(session_dir: Path, tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir()
    (session_dir / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    tools = get_session_tools(session_dir=session_dir, workspace=ws)
    names = [t.name for t in tools]
    assert "skill_manage" in names
