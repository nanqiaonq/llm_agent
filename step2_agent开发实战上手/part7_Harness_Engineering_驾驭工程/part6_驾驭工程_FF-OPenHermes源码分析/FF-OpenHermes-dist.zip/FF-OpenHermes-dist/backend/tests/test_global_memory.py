"""Tests for GlobalMemory .bak write pattern."""
import pytest

from agent.global_memory import GlobalMemory


def test_read_empty(tmp_path):
    gm = GlobalMemory(tmp_path / "storage")
    assert gm.read() == ""


def test_write_then_read(tmp_path):
    gm = GlobalMemory(tmp_path / "storage")
    gm.write("# Global Memory\nsome important fact")
    assert gm.read() == "# Global Memory\nsome important fact"


def test_backup_on_overwrite(tmp_path):
    storage = tmp_path / "storage"
    gm = GlobalMemory(storage)
    gm.write("first content")
    gm.write("second content")
    bak = storage / "MEMORY.md.bak"
    assert bak.exists()
    assert bak.read_text(encoding="utf-8") == "first content"
    assert gm.read() == "second content"


def test_storage_dir_created(tmp_path):
    storage = tmp_path / "deep" / "nested" / "storage"
    gm = GlobalMemory(storage)
    assert storage.exists()
    gm.write("hello")
    assert (storage / "MEMORY.md").exists()
