"""Tests for Pydantic session models."""
import pytest

from agent.models import SessionMeta, SessionStats


def test_session_meta_minimal():
    m = SessionMeta(
        id="sess_x",
        title="t",
        workspace_path="C:/tmp/proj",
        model="deepseek/deepseek-chat-v3.1",
    )
    assert m.id == "sess_x"
    assert m.stats.turns == 0


def test_session_meta_serializes():
    m = SessionMeta(
        id="sess_x",
        title="t",
        workspace_path="C:/tmp/proj",
        model="deepseek/deepseek-chat-v3.1",
    )
    j = m.model_dump_json()
    assert "workspace_path" in j


def test_session_meta_rejects_empty_workspace():
    with pytest.raises(ValueError):
        SessionMeta(
            id="sess_x",
            title="t",
            workspace_path="",
            model="deepseek/deepseek-chat-v3.1",
        )
