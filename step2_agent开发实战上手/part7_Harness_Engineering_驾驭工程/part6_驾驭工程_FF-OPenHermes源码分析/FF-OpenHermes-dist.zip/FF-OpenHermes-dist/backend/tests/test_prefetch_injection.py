"""Test that AgentManager prefetch emits retrieval events when memory_index has hits."""
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from agent.agent_manager import AgentManager
from agent.memory_index import MemoryIndex
from agent.session_manager import SessionManager


class ToolBindableFake(FakeListChatModel):
    def bind_tools(self, tools, **kwargs):
        return self


def _make_manager(tmp_path: Path, memory_index: MemoryIndex):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    meta = sm.create("Test", str(workspace), model="fake")
    fake = ToolBindableFake(responses=["I found relevant information from your history."])
    mgr = AgentManager(
        session_manager=sm,
        llm_factory=lambda: fake,
        memory_index=memory_index,
    )
    return mgr, meta


@pytest.mark.asyncio
async def test_retrieval_event_emitted(tmp_path: Path):
    """Index a fact in session A, then query from session B and check retrieval event."""
    idx = MemoryIndex(tmp_path / "memory.db")

    # Seed session A with relevant content
    idx.index_message("session_A_fixed", "user", "The secret passphrase is deployment pipeline integration")
    idx.index_message("session_A_fixed", "assistant", "I have noted the passphrase for future reference")

    mgr, meta = _make_manager(tmp_path, idx)

    events = []
    async for ev in mgr.astream(meta.id, "deployment pipeline"):
        events.append(ev)

    types = [e["type"] for e in events]
    assert "turn_start" in types
    assert "turn_end" in types

    retrieval_events = [e for e in events if e["type"] == "retrieval"]
    assert len(retrieval_events) >= 1
    hits = retrieval_events[0]["hits"]
    assert len(hits) >= 1
    # The hit should be from session_A not from the current session
    assert all(h["session_id"] == "session_A_fixed" for h in hits)


@pytest.mark.asyncio
async def test_no_retrieval_event_when_no_hits(tmp_path: Path):
    """When memory index is empty, no retrieval event should be emitted."""
    idx = MemoryIndex(tmp_path / "memory_empty.db")
    mgr, meta = _make_manager(tmp_path, idx)

    events = []
    async for ev in mgr.astream(meta.id, "completely unrelated query xyz"):
        events.append(ev)

    retrieval_events = [e for e in events if e["type"] == "retrieval"]
    assert len(retrieval_events) == 0


@pytest.mark.asyncio
async def test_messages_indexed_after_turn(tmp_path: Path):
    """After a turn, user and assistant messages are indexed."""
    idx = MemoryIndex(tmp_path / "memory_index.db")
    mgr, meta = _make_manager(tmp_path, idx)

    events = []
    async for ev in mgr.astream(meta.id, "unique marker phrase xyzzy"):
        events.append(ev)

    # Now search for the indexed user message
    hits = idx.search("unique marker phrase xyzzy")
    user_hits = [h for h in hits if h["role"] == "user" and h["session_id"] == meta.id]
    assert len(user_hits) >= 1
