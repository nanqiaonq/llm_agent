"""Tests for /api/chat SSE endpoint.

API DRIFT NOTE: Like test_agent_manager.py, we subclass FakeListChatModel to
make .bind_tools() a no-op, since create_agent calls bind_tools whenever the
agent has any tools (and AgentManager always wires up the 9 session tools).
"""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient
from langchain_core.language_models.fake_chat_models import FakeListChatModel

import app as app_module
from agent.agent_manager import AgentManager
from agent.session_manager import SessionManager


class ToolBindableFakeListChatModel(FakeListChatModel):
    """FakeListChatModel that ignores .bind_tools() — required for create_agent."""

    def bind_tools(self, tools, **kwargs):  # type: ignore[override]
        return self


@pytest.mark.asyncio
async def test_chat_streams_events(tmp_path: Path, monkeypatch):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory", encoding="utf-8")

    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    meta = sm.create("T", str(workspace), model="fake")

    fake = ToolBindableFakeListChatModel(responses=["fake reply text"])
    mgr = AgentManager(session_manager=sm, llm_factory=lambda: fake)

    # Inject test deps into app
    app_module.app.state.session_manager = sm
    app_module.app.state.agent_manager = mgr

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        async with ac.stream("POST", "/api/chat", json={"session_id": meta.id, "message": "hi"}) as resp:
            assert resp.status_code == 200
            chunks = []
            async for line in resp.aiter_lines():
                chunks.append(line)
    body = "\n".join(chunks)
    assert "turn_start" in body
    assert "turn_end" in body
