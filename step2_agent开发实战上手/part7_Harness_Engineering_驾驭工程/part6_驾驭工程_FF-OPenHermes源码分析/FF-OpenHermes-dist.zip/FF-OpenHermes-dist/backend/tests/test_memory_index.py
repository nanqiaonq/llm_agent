"""Tests for MemoryIndex FTS5 dual-table search."""
import pytest

from agent.memory_index import MemoryIndex


@pytest.fixture
def idx(tmp_path):
    return MemoryIndex(tmp_path / "test_memory.db")


def test_english_bm25_hit(idx):
    idx.index_message("sess1", "user", "The quick brown fox jumps over the lazy dog")
    idx.index_message("sess1", "assistant", "Python programming is very useful for data science")
    results = idx.search("python programming")
    assert len(results) >= 1
    assert any("python" in r["content"].lower() or "python" in r.get("snippet", "").lower() for r in results)


def test_cjk_trigram_hit(idx):
    idx.index_message("sess_cjk", "user", "今天我们讨论大语言模型的应用场景，包括智能助手和代码生成")
    idx.index_message("sess_cjk", "assistant", "机器学习是人工智能的重要分支，深度学习是其核心技术")
    results = idx.search("大语言模型")
    assert len(results) >= 1
    assert any("大语言模型" in r["content"] for r in results)


def test_exclude_session(idx):
    idx.index_message("session_A", "user", "apple banana cherry deployment pipeline")
    idx.index_message("session_B", "user", "apple banana cherry deployment pipeline")
    results = idx.search("apple banana", exclude_session="session_A")
    session_ids = [r["session_id"] for r in results]
    assert "session_A" not in session_ids
    assert "session_B" in session_ids


def test_top_k_limit(idx):
    for i in range(20):
        idx.index_message(f"s{i}", "user", f"machine learning neural network deep learning model {i}")
    results = idx.search("machine learning", top_k=3)
    assert len(results) <= 3


def test_empty_query_returns_empty(idx):
    idx.index_message("sess1", "user", "some content")
    assert idx.search("") == []
    assert idx.search("   ") == []


def test_empty_content_skipped(idx):
    # should not raise
    idx.index_message("sess1", "user", "")
    idx.index_message("sess1", "user", "  ")
    results = idx.search("anything")
    assert results == []


def test_mixed_cjk_english_routes_to_like(idx):
    # A query mixing English with a short (<3 char) CJK token has a short CJK
    # token, so it routes to the LIKE fallback (not trigram). LIKE uses OR
    # semantics across tokens, so a hit on either token returns the row.
    idx.index_message("sess_mix", "user", "我用 docker 部署后端服务")
    idx.index_message("sess_mix", "assistant", "kubernetes 编排集群")
    results = idx.search("部署 docker")  # 部署=2 CJK chars -> LIKE path
    assert len(results) >= 1
    assert any("docker" in r["content"] for r in results)


def test_like_snippet_centred_on_match(idx):
    # Short-CJK LIKE path: when the keyword sits deep in a long message, the
    # snippet must contain the matched token, not a fixed leading prefix.
    long_prefix = "前言" + "x" * 300
    idx.index_message("sess_long", "user", long_prefix + "关键命中点" + "y" * 50)
    results = idx.search("命中", top_k=5)  # 2 CJK chars -> LIKE path
    assert len(results) >= 1
    hit = next(r for r in results if r["session_id"] == "sess_long")
    assert "命中" in hit["snippet"], f"snippet should center on match, got: {hit['snippet'][:60]}"
