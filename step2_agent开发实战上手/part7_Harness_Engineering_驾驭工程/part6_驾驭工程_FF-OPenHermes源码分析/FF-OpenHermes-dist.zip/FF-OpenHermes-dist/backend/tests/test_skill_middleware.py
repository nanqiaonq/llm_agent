"""Tests for SkillEngineMiddleware trigger logic (agentic combined sub-agent)."""
import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

from agent.middleware import SkillEngineMiddleware
from agent.event_bus import EventBus
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    meta = sm.create("Test", str(ws), model="m")
    bus = EventBus()
    return sm, meta, bus


def _simple_msgs() -> list:
    return [HumanMessage(content="hi"), AIMessage(content="hello")]


# ---------------------------------------------------------------------------
# 1. nudge 命中 → spawn_review_subagent 被调
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_nudge_triggers_spawn_review_subagent(setup, monkeypatch):
    """turns=5 (multiple of interval=5) → spawn_review_subagent called."""
    sm, meta, bus = setup
    sm.update_stats(meta.id, turns=5)

    spawn_mock = AsyncMock(return_value={"actions": ["skill_manage:create"]})
    monkeypatch.setattr("agent.middleware.spawn_review_subagent", spawn_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        memory_reflection_interval=5,
    )
    await mw.run_for_session(meta.id, _simple_msgs())

    spawn_mock.assert_called_once()


@pytest.mark.asyncio
async def test_nudge_not_triggered_off_interval(setup, monkeypatch):
    """turns=4 (not a multiple of 5) → spawn_review_subagent not called."""
    sm, meta, bus = setup
    sm.update_stats(meta.id, turns=4)

    spawn_mock = AsyncMock(return_value=None)
    monkeypatch.setattr("agent.middleware.spawn_review_subagent", spawn_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        memory_reflection_interval=5,
    )
    await mw.run_for_session(meta.id, _simple_msgs())

    spawn_mock.assert_not_called()


@pytest.mark.asyncio
async def test_nudge_not_triggered_at_turns_zero(setup, monkeypatch):
    """turns=0 → spawn_review_subagent not called (0 % 5 == 0 but n>0 guard)."""
    sm, meta, bus = setup
    # turns default is 0 — should NOT trigger
    spawn_mock = AsyncMock(return_value=None)
    monkeypatch.setattr("agent.middleware.spawn_review_subagent", spawn_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        memory_reflection_interval=5,
    )
    await mw.run_for_session(meta.id, _simple_msgs())

    spawn_mock.assert_not_called()


# ---------------------------------------------------------------------------
# 2. nudge 命中 → publishes review_done event + updates review_actions stats
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_nudge_publishes_review_done_event(setup, monkeypatch):
    """nudge 命中 → review_done 事件 + review_actions stats 更新。"""
    sm, meta, bus = setup
    sm.update_stats(meta.id, turns=5)

    actions = ["skill_manage:create", "write_memory:user prefers"]
    spawn_mock = AsyncMock(return_value={"actions": actions})
    monkeypatch.setattr("agent.middleware.spawn_review_subagent", spawn_mock)

    received: list[dict] = []

    async def consume():
        async with bus.subscribe(meta.id) as q:
            ev = await asyncio.wait_for(q.get(), timeout=2.0)
            received.append(ev)

    consumer_task = asyncio.create_task(consume())
    await asyncio.sleep(0.05)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        memory_reflection_interval=5,
    )
    await mw.run_for_session(meta.id, _simple_msgs())
    await asyncio.wait_for(consumer_task, timeout=3.0)

    assert len(received) == 1
    assert received[0]["type"] == "review_done"
    assert received[0]["actions"] == actions
    assert sm.get(meta.id).stats.review_actions == 2


@pytest.mark.asyncio
async def test_nudge_no_event_when_no_actions(setup, monkeypatch):
    """spawn_review_subagent returns None → no event published."""
    sm, meta, bus = setup
    sm.update_stats(meta.id, turns=5)

    spawn_mock = AsyncMock(return_value=None)
    monkeypatch.setattr("agent.middleware.spawn_review_subagent", spawn_mock)

    # Subscribe to check no events arrive
    received: list[dict] = []

    async def consume():
        async with bus.subscribe(meta.id) as q:
            try:
                ev = await asyncio.wait_for(q.get(), timeout=0.3)
                received.append(ev)
            except asyncio.TimeoutError:
                pass

    consumer_task = asyncio.create_task(consume())
    await asyncio.sleep(0.05)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        memory_reflection_interval=5,
    )
    await mw.run_for_session(meta.id, _simple_msgs())
    await asyncio.wait_for(consumer_task, timeout=1.0)

    assert received == []


# ---------------------------------------------------------------------------
# 3. sync after_agent returns quickly (fire-and-forget)
# ---------------------------------------------------------------------------

def test_middleware_sync_after_agent_returns_quickly(setup, monkeypatch):
    """The sync after_agent fallback must not block on the sub-agent LLM call."""
    sm, meta, bus = setup

    async def slow_spawn(*args, **kwargs):
        await asyncio.sleep(5)
        return None

    monkeypatch.setattr("agent.middleware.spawn_review_subagent", slow_spawn)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
    )

    monkeypatch.setattr("agent.middleware._resolve_session_id", lambda state: meta.id)

    state = {"messages": _simple_msgs()}

    import time
    start = time.monotonic()
    mw.after_agent(state, runtime=None)
    elapsed = time.monotonic() - start

    assert elapsed < 1.0, f"sync after_agent blocked for {elapsed:.2f}s — must fire-and-forget"


# ---------------------------------------------------------------------------
# 4. session not found → silently returns (no crash)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_run_for_session_missing_session(setup, monkeypatch):
    """FileNotFoundError for session → silently returns, no exception propagated."""
    sm, meta, bus = setup
    spawn_mock = AsyncMock(return_value=None)
    monkeypatch.setattr("agent.middleware.spawn_review_subagent", spawn_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
    )
    # Use a non-existent session_id
    await mw.run_for_session("nonexistent-session-id", _simple_msgs())
    spawn_mock.assert_not_called()


# ---------------------------------------------------------------------------
# 5. before_model/REFLECTION_PROMPT removed check (regression)
# ---------------------------------------------------------------------------

def test_before_model_injection_removed():
    """SkillEngineMiddleware has no before_model/abefore_model; module has no REFLECTION_PROMPT."""
    import agent.middleware as mw_mod

    assert not hasattr(SkillEngineMiddleware, "before_model") or \
        not callable(getattr(SkillEngineMiddleware, "before_model", None)) or \
        not hasattr(mw_mod, "REFLECTION_PROMPT"), \
        "before_model still present in middleware"

    assert not hasattr(mw_mod, "REFLECTION_PROMPT"), \
        "REFLECTION_PROMPT constant still in agent.middleware"
    assert not hasattr(mw_mod, "REFLECTION_PROMPT_MARKER"), \
        "REFLECTION_PROMPT_MARKER constant still in agent.middleware"
    assert not hasattr(SkillEngineMiddleware, "_maybe_inject_reflection"), \
        "_maybe_inject_reflection method still present"


# ---------------------------------------------------------------------------
# 6. no detect/enhancer/generator imports in middleware
# ---------------------------------------------------------------------------

def test_middleware_no_old_imports():
    """middleware 不再导入 detect / enhancer / generator。"""
    import agent.middleware as mw_mod
    assert not hasattr(mw_mod, "count_tool_calls_in_turn"), "detect still imported"
    assert not hasattr(mw_mod, "used_existing_skill"), "detect still imported"
    assert not hasattr(mw_mod, "enhance_skill_from_turn"), "enhancer still imported"
    assert not hasattr(mw_mod, "generate_skill_from_turn"), "generator still imported"
    assert not hasattr(mw_mod, "review_memory_from_turn"), "old review still imported"
