"""Tests for skill scanning + loaded-skills tracker."""
from pathlib import Path

import pytest

from agent.skill_ops import SkillOps


@pytest.fixture
def ops(tmp_path: Path) -> SkillOps:
    sdir = tmp_path / "sess"
    (sdir / "skills" / "weather-query").mkdir(parents=True)
    (sdir / "skills" / "weather-query" / "SKILL.md").write_text(
        "---\nname: weather-query\ndescription: Query weather. Use when user asks about weather.\nversion: 1.0\n---\n\n# Weather Query\n",
        encoding="utf-8",
    )
    (sdir / "loaded_skills.json").write_text("[]", encoding="utf-8")
    return SkillOps(sdir)


def test_list_skills(ops: SkillOps):
    skills = ops.list_skills()
    assert len(skills) == 1
    assert skills[0]["name"] == "weather-query"
    assert skills[0]["version"] == "1.0"


def test_read_skill(ops: SkillOps):
    body = ops.read_skill("weather-query")
    assert "Weather Query" in body


def test_write_skill_creates_dir_and_history(ops: SkillOps):
    md = "---\nname: new-skill\ndescription: A new skill. Use when testing.\nversion: 1.0\n---\n\n# New Skill\n"
    ops.write_skill("new-skill", md, history_line="Initial version")
    assert (ops.skills_dir / "new-skill" / "SKILL.md").exists()
    assert "Initial version" in (ops.skills_dir / "new-skill" / "HISTORY.md").read_text(encoding="utf-8")


def test_load_unload(ops: SkillOps):
    ops.load("weather-query", level=1)
    assert ops.is_loaded("weather-query")
    loaded = ops.list_loaded()
    assert loaded[0]["name"] == "weather-query"
    assert loaded[0]["level"] == 1
    ops.unload("weather-query")
    assert not ops.is_loaded("weather-query")


def test_snapshot_renders(ops: SkillOps):
    snap = ops.rebuild_snapshot()
    assert "weather-query" in snap
    assert "Use when user asks about weather" in snap


# ── patch_skill ────────────────────────────────────────────────────────────────

@pytest.fixture
def ops_with_skill(tmp_path: Path) -> SkillOps:
    sdir = tmp_path / "sess"
    skill_dir = sdir / "skills" / "my-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        "---\nname: my-skill\ndescription: A skill.\nversion: 1.0\n---\n\n# My Skill\nOriginal text here.\n",
        encoding="utf-8",
    )
    return SkillOps(sdir)


def test_patch_skill_replaces(ops_with_skill: SkillOps):
    ops_with_skill.patch_skill("my-skill", "Original text here.", "Updated text here.")
    content = (ops_with_skill.skills_dir / "my-skill" / "SKILL.md").read_text(encoding="utf-8")
    assert "Updated text here." in content
    assert "Original text here." not in content
    rec = ops_with_skill.usage.get("my-skill")
    assert rec is not None
    assert rec.get("patch_count", 0) >= 1


def test_patch_skill_not_found(ops_with_skill: SkillOps):
    with pytest.raises(FileNotFoundError):
        ops_with_skill.patch_skill("ghost-skill", "x", "y")


def test_patch_skill_old_str_absent(ops_with_skill: SkillOps):
    with pytest.raises(ValueError, match="not found"):
        ops_with_skill.patch_skill("my-skill", "nonexistent string", "replacement")


def test_patch_skill_old_str_not_unique(ops_with_skill: SkillOps):
    # Write a skill with duplicate string
    ops_with_skill.write_skill(
        "dup-skill",
        "---\nname: dup-skill\ndescription: Dup.\nversion: 1.0\n---\n\ndup dup\n",
    )
    with pytest.raises(ValueError, match="matches \\d+ places"):
        ops_with_skill.patch_skill("dup-skill", "dup", "replacement")


# ── write_support_file ─────────────────────────────────────────────────────────

def test_write_support_file(ops_with_skill: SkillOps):
    ops_with_skill.write_support_file("my-skill", "references/note.md", "# Notes\nSome content.")
    target = ops_with_skill.skills_dir / "my-skill" / "references" / "note.md"
    assert target.exists()
    assert target.read_text(encoding="utf-8") == "# Notes\nSome content."


def test_write_support_file_rejects_bad_prefix(ops_with_skill: SkillOps):
    with pytest.raises(ValueError, match="rel_path must start with"):
        ops_with_skill.write_support_file("my-skill", "evil.md", "content")


def test_write_support_file_rejects_traversal(ops_with_skill: SkillOps):
    with pytest.raises(ValueError, match="path traversal"):
        ops_with_skill.write_support_file("my-skill", "references/../../etc/x", "content")
