"""Tests for Distiller funnel upgrade (M2) + distill API endpoint."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager
from skill_engine.generator import generate_skill_from_text


class StructuredFake:
    """Minimal fake that stubs with_structured_output to return a preset GeneratorOutput."""

    def __init__(self, response: dict | Exception | None):
        self._response = response

    @property
    def streaming(self):
        return False

    def with_structured_output(self, schema, **kwargs):
        outer = self

        class _Runnable:
            async def ainvoke(self, prompt):
                if isinstance(outer._response, Exception):
                    raise outer._response
                return schema.model_validate(outer._response)

        return _Runnable()


@pytest.fixture
def session_dir(tmp_path: Path) -> Path:
    sd = tmp_path / "sess"
    (sd / "skills").mkdir(parents=True)
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("# Skills Snapshot\n", encoding="utf-8")
    (sd / "loaded_skills.json").write_text("[]", encoding="utf-8")
    return sd


# ---------------------------------------------------------------------------
# A4-1: funnel GENERATE — signals + clusters + skill → SKILL.md written, HISTORY has funnel summary
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_funnel_generate_writes_skill_with_history_trace(session_dir: Path):
    fake = StructuredFake({
        "decision": "GENERATE",
        "reasoning": "Reusable table-scraping workflow",
        "signals": [
            {"text": "抓取价格表", "type": "workflow"},
            {"text": "导出 Excel", "type": "workflow"},
            {"text": "不要修改原始数据", "type": "constraint"},
            {"text": "每次都用 requests 库", "type": "preference"},
        ],
        "clusters": {
            "preferences": ["使用 requests 库"],
            "constraints": ["不要修改原始数据"],
            "workflows": ["抓取页面", "解析表格", "导出 Excel"],
            "examples": [],
        },
        "skill": {
            "name": "scrape-table-export",
            "description": "Scrape HTML tables and export to Excel. Use when user asks for web table extraction.",
            "body": "# scrape-table-export\n\n## Overview\nFetch HTML, parse table, write xlsx.\n\n## Steps\n1. fetch\n2. parse\n\n## Edge Cases\nNone.",
            "triggers": ["scrape table", "export excel"],
        },
    })

    result = await generate_skill_from_text(
        "USER: 抓取价格表\nASSISTANT: 已导出",
        session_dir,
        lambda: fake,
    )

    assert result is not None
    assert result["name"] == "scrape-table-export"

    skill_md = (session_dir / "skills" / "scrape-table-export" / "SKILL.md").read_text(encoding="utf-8")
    assert "scrape-table-export" in skill_md

    history = (session_dir / "skills" / "scrape-table-export" / "HISTORY.md").read_text(encoding="utf-8")
    # HISTORY trace must contain funnel summary (signals count + type breakdown)
    assert "Distilled" in history
    assert "signals" in history
    assert "workflow" in history


# ---------------------------------------------------------------------------
# A4-2: dual-focus description lint — "use when" passes; missing → lint warn (not blocked)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_dual_focus_description_with_use_when_passes(session_dir: Path):
    fake = StructuredFake({
        "decision": "GENERATE",
        "reasoning": "ok",
        "signals": [],
        "clusters": None,
        "skill": {
            "name": "demo-skill",
            "description": "Demo skill. Use when testing dual-focus descriptions.",
            "body": "# demo-skill\n\n## Overview\nDemo.\n\n## Steps\n1. step\n\n## Edge Cases\nNone.",
            "triggers": ["demo"],
        },
    })
    result = await generate_skill_from_text("USER: test\nASSISTANT: ok", session_dir, lambda: fake)
    assert result is not None
    assert result["name"] == "demo-skill"


@pytest.mark.asyncio
async def test_description_missing_when_is_warn_not_blocked(session_dir: Path):
    """description without 'use when' produces a lint WARN but skill still writes."""
    fake = StructuredFake({
        "decision": "GENERATE",
        "reasoning": "ok",
        "signals": [],
        "clusters": None,
        "skill": {
            "name": "warn-skill",
            "description": "Does stuff without a when-clause here",
            "body": "# warn-skill\n\n## Overview\nDemo.\n\n## Steps\n1. step\n\n## Edge Cases\nNone.",
            "triggers": ["stuff"],
        },
    })
    result = await generate_skill_from_text("USER: test\nASSISTANT: ok", session_dir, lambda: fake)
    # lint warn must not block; skill should still be written
    assert result is not None
    assert result["name"] == "warn-skill"


# ---------------------------------------------------------------------------
# A4-3: backward compat — old-style GeneratorOutput without signals/clusters still works
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_backward_compat_no_signals_no_clusters(session_dir: Path):
    fake = StructuredFake({
        "decision": "GENERATE",
        "reasoning": "Still works without new fields",
        "skill": {
            "name": "compat-skill",
            "description": "Compat test. Use when verifying backward compat.",
            "body": "# compat-skill\n\n## Overview\nOld style.\n\n## Steps\n1. step\n\n## Edge Cases\nNone.",
            "triggers": ["compat"],
        },
        # signals and clusters intentionally omitted — should default to [] and None
    })
    result = await generate_skill_from_text("USER: test\nASSISTANT: ok", session_dir, lambda: fake)
    assert result is not None
    assert result["name"] == "compat-skill"


# ---------------------------------------------------------------------------
# A4-4: NO_SKILL → returns None
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_no_skill_returns_none(session_dir: Path):
    fake = StructuredFake({
        "decision": "NO_SKILL",
        "skill": None,
        "reasoning": "Too trivial",
        "signals": [],
        "clusters": None,
    })
    result = await generate_skill_from_text("USER: hi\nASSISTANT: hello", session_dir, lambda: fake)
    assert result is None
    skill_dirs = [p for p in (session_dir / "skills").iterdir() if p.is_dir()]
    assert skill_dirs == []


# ---------------------------------------------------------------------------
# A4-5: distill API endpoint tests (TestClient style)
# ---------------------------------------------------------------------------

@pytest.fixture
def api_setup(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta


@pytest.mark.asyncio
async def test_distill_source_text_creates_skill(api_setup, monkeypatch):
    meta = api_setup
    fake_result = {"name": "api-test-skill", "description": "API test. Use when testing distill endpoint."}

    async def fake_generate(turn_text, session_dir, llm_factory):
        return fake_result

    monkeypatch.setattr("skill_engine.generator.generate_skill_from_text", fake_generate)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(
            f"/api/sessions/{meta.id}/skills/distill",
            json={"source": "text", "text": "USER: 抓取表格\nASSISTANT: 已完成"},
        )
    assert r.status_code == 200
    data = r.json()
    assert data["created"] is True
    assert data["name"] == "api-test-skill"


@pytest.mark.asyncio
async def test_distill_source_text_empty_returns_422(api_setup):
    meta = api_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(
            f"/api/sessions/{meta.id}/skills/distill",
            json={"source": "text", "text": ""},
        )
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_distill_source_history_no_history_returns_422(api_setup, monkeypatch):
    meta = api_setup

    async def fake_extract_turns(db_path):
        return []

    monkeypatch.setattr("agent.history.extract_turns", fake_extract_turns)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(
            f"/api/sessions/{meta.id}/skills/distill",
            json={"source": "history"},
        )
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_distill_no_skill_returns_created_false(api_setup, monkeypatch):
    meta = api_setup

    async def fake_generate(turn_text, session_dir, llm_factory):
        return None

    monkeypatch.setattr("skill_engine.generator.generate_skill_from_text", fake_generate)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(
            f"/api/sessions/{meta.id}/skills/distill",
            json={"source": "text", "text": "some text"},
        )
    assert r.status_code == 200
    data = r.json()
    assert data["created"] is False
    assert "reason" in data


@pytest.mark.asyncio
async def test_distill_history_preserves_tool_calls(api_setup, monkeypatch):
    """I-2 regression: history turn_text must include TOOL_CALL lines so the
    generator's '3+ meaningful tool calls' signal is not silently lost."""
    meta = api_setup

    async def fake_extract_turns(db_path):
        return [{
            "user": "抓取表格",
            "assistant": "好的",
            "tool_calls": [
                {"name": "fetch_url", "args": {"url": "x"}},
                {"name": "python_repl", "args": {}},
            ],
        }]

    monkeypatch.setattr("agent.history.extract_turns", fake_extract_turns)

    captured: dict = {}

    async def fake_generate(turn_text, session_dir, llm_factory):
        captured["turn_text"] = turn_text
        return {"name": "x-skill", "description": "y"}

    monkeypatch.setattr("skill_engine.generator.generate_skill_from_text", fake_generate)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(f"/api/sessions/{meta.id}/skills/distill", json={"source": "history"})

    assert r.status_code == 200
    assert "TOOL_CALL: fetch_url" in captured["turn_text"]
    assert "TOOL_CALL: python_repl" in captured["turn_text"]


@pytest.mark.asyncio
async def test_distill_history_extract_error_degrades(api_setup, monkeypatch):
    """I-1 regression: extract_turns failure returns created:false, never a 500."""
    meta = api_setup

    async def boom(db_path):
        raise RuntimeError("db corrupt")

    monkeypatch.setattr("agent.history.extract_turns", boom)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(f"/api/sessions/{meta.id}/skills/distill", json={"source": "history"})

    assert r.status_code == 200
    data = r.json()
    assert data["created"] is False
    assert "失败" in data["reason"]
