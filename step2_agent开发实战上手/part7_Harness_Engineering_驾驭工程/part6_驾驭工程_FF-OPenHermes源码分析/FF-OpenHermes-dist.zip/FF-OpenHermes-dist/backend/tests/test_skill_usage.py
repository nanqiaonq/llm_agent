"""Tests for agent/skill_usage.py — UsageStore telemetry + SkillOps integration."""
import json
from pathlib import Path

import pytest

from agent.skill_ops import SkillOps
from agent.skill_provenance import BACKGROUND, FOREGROUND, reset_write_origin, set_write_origin
from agent.skill_usage import UsageStore


# ─── UsageStore unit tests ────────────────────────────────────────────────────

@pytest.fixture
def store(tmp_path: Path) -> UsageStore:
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    return UsageStore(skills_dir)


def test_mark_created_records_created_by_and_at(store: UsageStore):
    store.mark_created("my-skill", "agent")
    rec = store.get("my-skill")
    assert rec is not None
    assert rec["created_by"] == "agent"
    assert rec["created_at"] is not None


def test_mark_created_user(store: UsageStore):
    store.mark_created("my-skill", "user")
    rec = store.get("my-skill")
    assert rec["created_by"] == "user"


def test_bump_use_increments_count_and_timestamp(store: UsageStore):
    store.mark_created("sk", "user")
    store.bump_use("sk")
    store.bump_use("sk")
    rec = store.get("sk")
    assert rec["use_count"] == 2
    assert rec["last_used_at"] is not None


def test_bump_view_increments(store: UsageStore):
    store.mark_created("sk", "user")
    store.bump_view("sk")
    rec = store.get("sk")
    assert rec["view_count"] == 1
    assert rec["last_viewed_at"] is not None


def test_bump_patch_increments(store: UsageStore):
    store.mark_created("sk", "user")
    store.bump_patch("sk")
    store.bump_patch("sk")
    rec = store.get("sk")
    assert rec["patch_count"] == 2
    assert rec["last_patched_at"] is not None


def test_get_returns_none_for_missing(store: UsageStore):
    assert store.get("nonexistent") is None


def test_all_returns_dict(store: UsageStore):
    store.mark_created("a", "user")
    store.mark_created("b", "agent")
    data = store.all()
    assert "a" in data and "b" in data


def test_forget_removes_record(store: UsageStore):
    store.mark_created("sk", "user")
    assert store.get("sk") is not None
    store.forget("sk")
    assert store.get("sk") is None


def test_latest_activity_at_excludes_created_at(store: UsageStore):
    store.mark_created("sk", "user")
    # No bumps yet — only created_at exists
    assert store.latest_activity_at("sk") is None


def test_latest_activity_at_after_use(store: UsageStore):
    store.mark_created("sk", "user")
    store.bump_use("sk")
    result = store.latest_activity_at("sk")
    assert result is not None


def test_activity_count(store: UsageStore):
    store.mark_created("sk", "user")
    store.bump_use("sk")
    store.bump_view("sk")
    store.bump_patch("sk")
    assert store.activity_count("sk") == 3


def test_set_pinned(store: UsageStore):
    store.mark_created("sk", "user")
    store.set_pinned("sk", True)
    assert store.get("sk")["pinned"] is True
    store.set_pinned("sk", False)
    assert store.get("sk")["pinned"] is False


def test_set_state(store: UsageStore):
    store.mark_created("sk", "user")
    store.set_state("sk", "stale")
    assert store.get("sk")["state"] == "stale"


def test_set_archived(store: UsageStore):
    store.mark_created("sk", "user")
    store.set_archived("sk")
    rec = store.get("sk")
    assert rec["state"] == "archived"
    assert rec["archived_at"] is not None


def test_sequential_rmw_no_lost_update(store: UsageStore):
    """Sequential bumps must not lose any update (no file I/O race in single process)."""
    store.mark_created("sk", "user")
    for _ in range(5):
        store.bump_use("sk")
    assert store.get("sk")["use_count"] == 5


def test_usage_file_is_valid_json(store: UsageStore, tmp_path: Path):
    store.mark_created("sk", "user")
    usage_file = store._usage_file
    assert usage_file.exists()
    data = json.loads(usage_file.read_text())
    assert "sk" in data


# ─── SkillOps integration tests ──────────────────────────────────────────────

SKILL_MD = (
    "---\nname: test-skill\ndescription: A test skill. Use when testing.\n"
    "version: 1.0\ngenerated_by: agent\ncreated_at: 2025-01-01T00:00:00+00:00\n---\n\n# Test\n"
)


@pytest.fixture
def ops(tmp_path: Path) -> SkillOps:
    return SkillOps(tmp_path / "session")


def test_write_skill_background_origin_creates_agent(ops: SkillOps):
    token = set_write_origin(BACKGROUND)
    try:
        ops.write_skill("bg-skill", SKILL_MD)
    finally:
        reset_write_origin(token)
    rec = ops.usage.get("bg-skill")
    assert rec is not None
    assert rec["created_by"] == "agent"


def test_write_skill_foreground_origin_creates_user(ops: SkillOps):
    # Default is foreground
    ops.write_skill("fg-skill", SKILL_MD)
    rec = ops.usage.get("fg-skill")
    assert rec is not None
    assert rec["created_by"] == "user"


def test_write_skill_existing_bumps_patch(ops: SkillOps):
    ops.write_skill("sk", SKILL_MD)
    first_rec = ops.usage.get("sk")
    assert first_rec["created_by"] == "user"
    # Second write = patch
    ops.write_skill("sk", SKILL_MD + "\nExtra")
    rec = ops.usage.get("sk")
    assert rec["patch_count"] == 1
    assert rec["created_by"] == "user"  # unchanged


def test_read_skill_bumps_use(ops: SkillOps):
    ops.write_skill("sk", SKILL_MD)
    # Reset use_count (write_skill doesn't bump use)
    assert ops.usage.get("sk")["use_count"] == 0
    ops.read_skill("sk")
    assert ops.usage.get("sk")["use_count"] == 1


def test_read_skill_record_use_false_does_not_bump_use(ops: SkillOps):
    """UI-view path (record_use=False) must NOT bump use_count — keeps use (agent
    loads via tool) and view (human inspects) telemetry distinct for the curator."""
    ops.write_skill("sk", SKILL_MD)
    ops.read_skill("sk", record_use=False)
    assert ops.usage.get("sk")["use_count"] == 0  # not miscounted as a use
    # view is bumped separately by the API layer
    ops.usage.bump_view("sk")
    assert ops.usage.get("sk")["view_count"] == 1
    assert ops.usage.get("sk")["use_count"] == 0


def test_read_skill_global_no_telemetry(tmp_path: Path):
    global_dir = tmp_path / "global"
    (global_dir / "preset-skill").mkdir(parents=True)
    (global_dir / "preset-skill" / "SKILL.md").write_text(SKILL_MD, encoding="utf-8")
    ops = SkillOps(tmp_path / "session", global_dir=global_dir)
    ops.read_skill("preset-skill")
    # No usage record for global (preset) skill
    assert ops.usage.get("preset-skill") is None


def test_list_skills_merges_usage(ops: SkillOps):
    token = set_write_origin(BACKGROUND)
    try:
        ops.write_skill("agent-skill", SKILL_MD)
    finally:
        reset_write_origin(token)
    ops.read_skill("agent-skill")
    skills = ops.list_skills()
    entry = next(s for s in skills if s["name"] == "agent-skill")
    assert entry["created_by"] == "agent"
    assert entry["use_count"] == 1


def test_list_skills_global_has_preset_created_by(tmp_path: Path):
    global_dir = tmp_path / "global"
    (global_dir / "preset-skill").mkdir(parents=True)
    (global_dir / "preset-skill" / "SKILL.md").write_text(SKILL_MD, encoding="utf-8")
    ops = SkillOps(tmp_path / "session", global_dir=global_dir)
    skills = ops.list_skills()
    entry = next(s for s in skills if s["name"] == "preset-skill")
    assert entry["created_by"] == "preset"


def test_delete_skill_removes_usage(ops: SkillOps):
    ops.write_skill("sk", SKILL_MD)
    assert ops.usage.get("sk") is not None
    ops.delete_skill("sk")
    assert ops.usage.get("sk") is None


def test_created_by_helper_session(ops: SkillOps):
    ops.write_skill("sk", SKILL_MD)
    assert ops.created_by("sk") == "user"


def test_created_by_helper_global(tmp_path: Path):
    global_dir = tmp_path / "global"
    (global_dir / "preset-skill").mkdir(parents=True)
    (global_dir / "preset-skill" / "SKILL.md").write_text(SKILL_MD, encoding="utf-8")
    ops = SkillOps(tmp_path / "session", global_dir=global_dir)
    assert ops.created_by("preset-skill") == "preset"


def test_created_by_helper_missing(ops: SkillOps):
    assert ops.created_by("nonexistent") is None
