"""Tests for FastAPI app entrypoint."""
import pytest
from httpx import ASGITransport, AsyncClient

from app import app


@pytest.mark.asyncio
async def test_root_returns_status():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.get("/")
    assert resp.status_code == 200
    body = resp.json()
    assert body["name"] == "FF-OpenHermes"
    assert body["status"] == "running"
