"""Tests for memory tools bound to session dir."""
from pathlib import Path

import pytest

from tools.memory_tool import create_read_memory_tool, create_write_memory_tool


def test_read_memory_returns_content(tmp_path: Path):
    (tmp_path / "MEMORY.md").write_text("# Memory\nfacts here", encoding="utf-8")
    tool = create_read_memory_tool(session_dir=tmp_path)
    out = tool.invoke({})
    assert "facts here" in out


def test_write_memory_appends(tmp_path: Path):
    (tmp_path / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")
    tool = create_write_memory_tool(session_dir=tmp_path)
    tool.invoke({"entry": "User prefers concise answers."})
    content = (tmp_path / "MEMORY.md").read_text(encoding="utf-8")
    assert "User prefers concise answers." in content


def test_write_memory_creates_backup(tmp_path: Path):
    (tmp_path / "MEMORY.md").write_text("v1", encoding="utf-8")
    tool = create_write_memory_tool(session_dir=tmp_path)
    tool.invoke({"entry": "new entry"})
    assert (tmp_path / "MEMORY.md.bak").exists()
