"""Tests for SOUL/MEMORY file operations."""
from pathlib import Path

import pytest

from agent.memory_ops import MemoryOps


@pytest.fixture
def ops(tmp_path: Path) -> MemoryOps:
    sdir = tmp_path / "sess_x"
    sdir.mkdir()
    (sdir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (sdir / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    return MemoryOps(sdir)


def test_read_soul(ops: MemoryOps):
    assert ops.read_soul().startswith("# Soul")


def test_write_soul_persists(ops: MemoryOps):
    ops.write_soul("new soul")
    assert ops.read_soul() == "new soul"


def test_read_memory(ops: MemoryOps):
    assert ops.read_memory().startswith("# Memory")


def test_write_memory_creates_backup(ops: MemoryOps):
    ops.write_memory("v1")
    ops.write_memory("v2")
    assert (ops.session_dir / "MEMORY.md.bak").exists()
    assert (ops.session_dir / "MEMORY.md.bak").read_text(encoding="utf-8") == "v1"


def test_token_count():
    # rough: 1 token ~ 4 chars for English. Just check it returns int.
    from agent.memory_ops import approx_tokens
    assert approx_tokens("hello world") > 0
