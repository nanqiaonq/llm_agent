"""Tests for /api/sessions/{sid}/{soul,memory,history}."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.memory_index import MemoryIndex
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# default soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# default memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta


@pytest.mark.asyncio
async def test_get_put_soul(setup):
    meta = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/soul")
        assert r.status_code == 200
        assert "default soul" in r.json()["content"]
        r = await ac.put(f"/api/sessions/{meta.id}/soul", json={"content": "new soul"})
        assert r.status_code == 200
        r = await ac.get(f"/api/sessions/{meta.id}/soul")
        assert r.json()["content"] == "new soul"


@pytest.mark.asyncio
async def test_memory_stats(setup):
    meta = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/memory/stats")
        assert r.status_code == 200
        body = r.json()
        assert "soul_tokens" in body
        assert "memory_tokens" in body


@pytest.mark.asyncio
async def test_history_empty(setup):
    meta = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/history")
        assert r.status_code == 200
        assert r.json()["turns"] == []


@pytest.mark.asyncio
async def test_memory_optimize_endpoint_writes_new_content(setup, monkeypatch):
    meta = setup
    sd = app_module.app.state.session_manager.session_dir(meta.id)
    (sd / "MEMORY.md").write_text("# Memory\n- foo\n- foo (dupe)\n", encoding="utf-8")

    async def fake_optimize(current, llm_factory):
        return "# Long-term Memory\n\n## Preferences\n- foo\n"

    monkeypatch.setattr("api.memory.optimize_memory_text", fake_optimize)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(f"/api/sessions/{meta.id}/memory/optimize")
    assert r.status_code == 200
    body = r.json()
    assert "Preferences" in body["content"]
    # .bak created by MemoryOps.write_memory
    assert (sd / "MEMORY.md.bak").exists()


@pytest.mark.asyncio
async def test_memory_optimize_endpoint_503_on_llm_failure(setup, monkeypatch):
    meta = setup
    sd = app_module.app.state.session_manager.session_dir(meta.id)
    (sd / "MEMORY.md").write_text("# Memory\n- foo\n", encoding="utf-8")

    async def fake_optimize_fail(current, llm_factory):
        return None

    monkeypatch.setattr("api.memory.optimize_memory_text", fake_optimize_fail)

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post(f"/api/sessions/{meta.id}/memory/optimize")
    assert r.status_code == 503
    # MEMORY.md unchanged
    md = (sd / "MEMORY.md").read_text(encoding="utf-8")
    assert "# Memory\n- foo\n" == md


@pytest.fixture
def search_setup(tmp_path: Path):
    """Fixture that injects a fresh MemoryIndex into app.state for search tests."""
    idx = MemoryIndex(tmp_path / "memory_index.db")
    app_module.app.state.memory_index = idx
    return idx


@pytest.mark.asyncio
async def test_search_memory_returns_hits(search_setup):
    idx = search_setup
    idx.index_message("sess-1", "user", "the quick brown fox jumps")
    idx.index_message("sess-1", "assistant", "lazy dog resting")
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/memory/search?q=fox")
    assert r.status_code == 200
    body = r.json()
    assert len(body["hits"]) >= 1
    hit = body["hits"][0]
    assert "session_id" in hit
    assert "role" in hit
    assert "snippet" in hit


@pytest.mark.asyncio
async def test_search_memory_empty_query(search_setup):
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/memory/search?q=")
    assert r.status_code == 200
    assert r.json() == {"hits": []}


@pytest.mark.asyncio
async def test_search_memory_respects_top_k(search_setup):
    idx = search_setup
    for i in range(5):
        idx.index_message(f"sess-{i}", "user", f"apple fruit number {i}")
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/memory/search?q=apple&top_k=2")
    assert r.status_code == 200
    assert len(r.json()["hits"]) == 2


@pytest.mark.asyncio
async def test_search_memory_top_k_out_of_bounds(search_setup):
    """top_k 超出 [1,50] 上界 → 422（FastAPI Query 约束，堵滥用放大面）。"""
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/memory/search?q=x&top_k=999")
    assert r.status_code == 422
