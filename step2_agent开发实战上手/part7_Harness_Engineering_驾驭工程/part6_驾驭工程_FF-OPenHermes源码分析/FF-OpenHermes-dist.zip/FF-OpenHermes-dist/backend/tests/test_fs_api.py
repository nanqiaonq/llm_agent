"""Tests for /api/fs/* directory picker endpoints."""
import sys
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module


@pytest.mark.asyncio
async def test_browse_lists_dirs(tmp_path: Path):
    (tmp_path / "a").mkdir()
    (tmp_path / "f.txt").write_text("x")
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/fs/browse", params={"path": str(tmp_path)})
    assert r.status_code == 200
    names = [e["name"] for e in r.json()["entries"]]
    assert "a" in names
    assert "f.txt" not in names


@pytest.mark.asyncio
async def test_drives_endpoint():
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/fs/drives")
    assert r.status_code == 200
    assert isinstance(r.json()["drives"], list)
