"""Tests for encoding fallback util."""
from pathlib import Path

import pytest

from utils.encoding import safe_read_text


def test_utf8_file(tmp_path: Path):
    p = tmp_path / "u.txt"
    p.write_text("héllo 中文", encoding="utf-8")
    assert safe_read_text(p) == "héllo 中文"


def test_gbk_file(tmp_path: Path):
    p = tmp_path / "g.txt"
    p.write_bytes("中文测试".encode("gbk"))
    assert "中文测试" in safe_read_text(p)


def test_replace_fallback(tmp_path: Path):
    p = tmp_path / "bad.bin"
    p.write_bytes(b"\xff\xfe\x00garbage")
    # Should not raise
    safe_read_text(p)
