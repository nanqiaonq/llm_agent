"""Tests for path-safety utilities."""
import os
from pathlib import Path

import pytest

from utils.paths import normalize_path, is_subpath, resolve_in


def test_normalize_expands_tilde(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("USERPROFILE", str(tmp_path))  # Windows
    monkeypatch.setenv("HOME", str(tmp_path))           # POSIX
    assert normalize_path("~/foo") == str((tmp_path / "foo").resolve())


def test_is_subpath_simple(tmp_path: Path):
    parent = tmp_path / "p"
    parent.mkdir()
    (parent / "child").mkdir()
    assert is_subpath(parent, parent / "child")
    assert is_subpath(parent, parent)  # self counts
    assert not is_subpath(parent, tmp_path)


def test_is_subpath_traversal_blocked(tmp_path: Path):
    parent = tmp_path / "p"
    parent.mkdir()
    assert not is_subpath(parent, parent / ".." / "evil")


def test_resolve_in_strips_leading_dot_slash(tmp_path: Path):
    f = tmp_path / "x.txt"
    f.write_text("hi")
    resolved = resolve_in(tmp_path, "./x.txt")
    assert resolved == f.resolve()


def test_resolve_in_rejects_escape(tmp_path: Path):
    with pytest.raises(ValueError, match="escapes"):
        resolve_in(tmp_path, "../../etc/passwd")
