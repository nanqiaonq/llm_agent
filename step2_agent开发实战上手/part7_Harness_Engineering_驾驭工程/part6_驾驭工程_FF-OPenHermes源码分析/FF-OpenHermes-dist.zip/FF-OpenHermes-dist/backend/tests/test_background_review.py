"""Tests for spawn_review_subagent (agentic combined review sub-agent)."""
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch, call

import pytest
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

from skill_engine.background_review import (
    spawn_review_subagent,
    _format_trace,
    _extract_tool_actions,
    COMBINED_REVIEW_PROMPT,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _session_dir(tmp_path: Path) -> Path:
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")
    return sd


def _human_ai_messages() -> list:
    return [HumanMessage(content="I am an AI instructor"), AIMessage(content="Got it")]


def _make_fake_agent(return_value: dict):
    """Return a fake agent whose ainvoke returns return_value."""
    agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = AsyncMock(return_value=return_value)
    agent.with_config = MagicMock(return_value=configured)
    return agent, configured


# ---------------------------------------------------------------------------
# 1. _format_trace
# ---------------------------------------------------------------------------

def test_format_trace_human_ai():
    msgs = [HumanMessage(content="hello"), AIMessage(content="world")]
    result = _format_trace(msgs)
    assert "USER: hello" in result
    assert "ASSISTANT: world" in result


def test_format_trace_skips_tool_messages():
    msgs = [
        HumanMessage(content="hi"),
        ToolMessage(content="tool result", tool_call_id="1"),
        AIMessage(content="done"),
    ]
    result = _format_trace(msgs)
    assert "tool result" not in result
    assert "USER: hi" in result
    assert "ASSISTANT: done" in result


def test_format_trace_empty_ai_content_skipped():
    msgs = [HumanMessage(content="x"), AIMessage(content="")]
    result = _format_trace(msgs)
    assert "ASSISTANT" not in result


# ---------------------------------------------------------------------------
# 2. _extract_tool_actions
# ---------------------------------------------------------------------------

def test_extract_tool_actions_skill_manage_and_write_memory():
    ai_msg = MagicMock()
    ai_msg.tool_calls = [
        {"name": "skill_manage", "args": {"action": "create"}},
        {"name": "write_memory", "args": {"entry": "user is an AI instructor"}},
        {"name": "read_skill", "args": {"name": "foo"}},  # not in output
    ]
    result = _extract_tool_actions({"messages": [ai_msg]})
    assert len(result) == 2
    assert "skill_manage:create" in result
    assert any("write_memory:" in r for r in result)


def test_extract_tool_actions_empty_result():
    result = _extract_tool_actions({"messages": []})
    assert result == []


def test_extract_tool_actions_non_dict_result():
    result = _extract_tool_actions("not a dict")
    assert result == []


# ---------------------------------------------------------------------------
# 3. spawn_review_subagent — tools whitelist
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_spawn_review_tools_whitelist(tmp_path):
    """fork 的 create_agent 收到 tools 恰为 [skill_manage, write_memory, read_skill, read_memory]"""
    sd = _session_dir(tmp_path)
    captured_tools: list = []

    fake_agent, configured_agent = _make_fake_agent({"messages": []})

    def fake_create_agent(model, tools, middleware):
        captured_tools.extend(tools)
        return fake_agent

    with patch("skill_engine.background_review.create_agent", fake_create_agent):
        await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    tool_names = [t.name for t in captured_tools]
    assert set(tool_names) == {"skill_manage", "write_memory", "read_skill", "read_memory"}
    # Exactly 4 tools — no terminal/python/search
    assert len(captured_tools) == 4


# ---------------------------------------------------------------------------
# 4. spawn_review_subagent — no middleware (防递归)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_spawn_review_no_middleware(tmp_path):
    """create_agent 收到 middleware=[]（④ 防递归）"""
    sd = _session_dir(tmp_path)
    captured_kwargs: dict = {}

    fake_agent, _ = _make_fake_agent({"messages": []})

    def fake_create_agent(model, tools, middleware):
        captured_kwargs["middleware"] = middleware
        return fake_agent

    with patch("skill_engine.background_review.create_agent", fake_create_agent):
        await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    assert captured_kwargs["middleware"] == []


# ---------------------------------------------------------------------------
# 5. spawn_review_subagent — recursion_limit
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_spawn_review_recursion_limit(tmp_path):
    """`.with_config(recursion_limit=16)` 被调用（① 步数上限）"""
    sd = _session_dir(tmp_path)
    fake_agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = AsyncMock(return_value={"messages": []})
    fake_agent.with_config = MagicMock(return_value=configured)

    with patch("skill_engine.background_review.create_agent", return_value=fake_agent):
        await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    fake_agent.with_config.assert_called_once_with(recursion_limit=16)


# ---------------------------------------------------------------------------
# 6. spawn_review_subagent — BACKGROUND provenance
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_spawn_review_background_origin(tmp_path):
    """ainvoke 期间 get_write_origin()==BACKGROUND + 退出后恢复 foreground"""
    from agent.skill_provenance import get_write_origin, BACKGROUND

    sd = _session_dir(tmp_path)
    origin_during: list[str] = []

    async def fake_ainvoke(inputs, config=None):
        origin_during.append(get_write_origin())
        return {"messages": []}

    fake_agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = fake_ainvoke
    fake_agent.with_config = MagicMock(return_value=configured)

    with patch("skill_engine.background_review.create_agent", return_value=fake_agent):
        await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    assert origin_during == [BACKGROUND]
    # After call, restored to foreground
    assert get_write_origin() == "foreground"


# ---------------------------------------------------------------------------
# 7. spawn_review_subagent — empty trace → None
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_spawn_review_empty_trace(tmp_path):
    """空对话 → None，不 fork"""
    sd = _session_dir(tmp_path)
    # Only tool messages — no human/ai text
    msgs = [ToolMessage(content="result", tool_call_id="1")]

    with patch("skill_engine.background_review.create_agent") as mock_ca:
        result = await spawn_review_subagent(msgs, sd, lambda: MagicMock())

    assert result is None
    mock_ca.assert_not_called()


# ---------------------------------------------------------------------------
# 8. spawn_review_subagent — swallows error → None
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_spawn_review_swallows_error(tmp_path):
    """create_agent/ainvoke 抛异常 → None 不传播"""
    sd = _session_dir(tmp_path)

    with patch("skill_engine.background_review.create_agent", side_effect=RuntimeError("boom")):
        result = await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    assert result is None


@pytest.mark.asyncio
async def test_spawn_review_ainvoke_error_swallowed(tmp_path):
    """ainvoke 抛异常 → None 不传播"""
    sd = _session_dir(tmp_path)
    fake_agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = AsyncMock(side_effect=ValueError("LLM failed"))
    fake_agent.with_config = MagicMock(return_value=configured)

    with patch("skill_engine.background_review.create_agent", return_value=fake_agent):
        result = await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    assert result is None


# ---------------------------------------------------------------------------
# 9. spawn_review_subagent — actions extraction from result
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_spawn_review_returns_actions(tmp_path):
    """sub-agent 调了 skill_manage + write_memory → 返回 {actions: [...]}"""
    sd = _session_dir(tmp_path)

    ai_msg = MagicMock()
    ai_msg.tool_calls = [
        {"name": "skill_manage", "args": {"action": "create"}},
        {"name": "write_memory", "args": {"entry": "user prefers Chinese"}},
    ]
    fake_result = {"messages": [ai_msg]}

    fake_agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = AsyncMock(return_value=fake_result)
    fake_agent.with_config = MagicMock(return_value=configured)

    with patch("skill_engine.background_review.create_agent", return_value=fake_agent):
        result = await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    assert result is not None
    assert "actions" in result
    assert len(result["actions"]) == 2


@pytest.mark.asyncio
async def test_spawn_review_no_actions_returns_none(tmp_path):
    """sub-agent 未调任何 skill_manage/write_memory → 返回 None"""
    sd = _session_dir(tmp_path)

    # No tool_calls at all
    fake_result = {"messages": [AIMessage(content="Nothing to save.")]}

    fake_agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = AsyncMock(return_value=fake_result)
    fake_agent.with_config = MagicMock(return_value=configured)

    with patch("skill_engine.background_review.create_agent", return_value=fake_agent):
        result = await spawn_review_subagent(_human_ai_messages(), sd, lambda: MagicMock())

    assert result is None
