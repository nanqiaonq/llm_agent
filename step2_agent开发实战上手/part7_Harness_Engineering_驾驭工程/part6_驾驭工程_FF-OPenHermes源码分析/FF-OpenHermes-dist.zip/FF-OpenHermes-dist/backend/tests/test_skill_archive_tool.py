"""Tests for SkillArchiveTool — 守卫硬门控（三道），archive 工具不进 get_session_tools。"""
from pathlib import Path

import pytest

from agent.skill_ops import SkillOps
from agent.skill_provenance import BACKGROUND, set_write_origin, reset_write_origin
from tools.skill_tool import create_skill_archive_tool


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SKILL_MD = """\
---
name: {name}
description: "Test skill {name}. Use when testing."
version: 1.0
generated_by: agent
created_at: 2025-01-01T00:00:00+00:00
---

# {name}

## Overview
Test.
"""


def _make_ops(tmp_path: Path, global_dir: Path | None = None) -> SkillOps:
    return SkillOps(tmp_path / "session", global_dir=global_dir)


def _create_agent_skill(ops: SkillOps, name: str) -> None:
    token = set_write_origin(BACKGROUND)
    try:
        ops.write_skill(name, SKILL_MD.format(name=name))
    finally:
        reset_write_origin(token)


def _create_user_skill(ops: SkillOps, name: str) -> None:
    ops.write_skill(name, SKILL_MD.format(name=name))


# ---------------------------------------------------------------------------
# 1. 正常归档（agent-created）
# ---------------------------------------------------------------------------

def test_archive_agent_created(tmp_path: Path):
    """created_by=agent 技能 → 归档成功，移到 .archive。"""
    ops = _make_ops(tmp_path)
    _create_agent_skill(ops, "write-report")

    tool = create_skill_archive_tool(ops.session_dir)
    result = tool._run("write-report")

    assert "已归档" in result
    assert not (ops.skills_dir / "write-report").exists()
    assert (ops.skills_dir / ".archive" / "write-report").exists()


# ---------------------------------------------------------------------------
# 2. 守卫①：拒绝 user-created
# ---------------------------------------------------------------------------

def test_archive_refuses_user(tmp_path: Path):
    """created_by=user → 返回"拒绝"串，技能未动。"""
    ops = _make_ops(tmp_path)
    _create_user_skill(ops, "user-skill")

    tool = create_skill_archive_tool(ops.session_dir)
    result = tool._run("user-skill")

    assert "拒绝" in result
    # 技能未动
    assert (ops.skills_dir / "user-skill").exists()
    assert not (ops.skills_dir / ".archive" / "user-skill").exists()


# ---------------------------------------------------------------------------
# 3. 守卫②：拒绝 global preset
# ---------------------------------------------------------------------------

def test_archive_refuses_global(tmp_path: Path):
    """global preset → 返回"拒绝"，未动。"""
    global_dir = tmp_path / "global"
    (global_dir / "global-preset").mkdir(parents=True)
    (global_dir / "global-preset" / "SKILL.md").write_text(
        SKILL_MD.format(name="global-preset"), encoding="utf-8"
    )
    ops = _make_ops(tmp_path, global_dir=global_dir)

    # 传 global_dir 让工具能识别 global preset
    tool = create_skill_archive_tool(ops.session_dir, global_dir=global_dir)
    result = tool._run("global-preset")

    assert "拒绝" in result
    # global 目录未动
    assert (global_dir / "global-preset" / "SKILL.md").exists()
    # session 侧没有创建 .archive
    assert not (ops.skills_dir / ".archive" / "global-preset").exists()


# ---------------------------------------------------------------------------
# 4. 守卫③：拒绝 pinned
# ---------------------------------------------------------------------------

def test_archive_refuses_pinned(tmp_path: Path):
    """pinned 技能 → 返回"拒绝"，未动。"""
    ops = _make_ops(tmp_path)
    _create_agent_skill(ops, "pinned-skill")
    ops.usage.set_pinned("pinned-skill", True)

    tool = create_skill_archive_tool(ops.session_dir)
    result = tool._run("pinned-skill")

    assert "拒绝" in result
    # 技能未动
    assert (ops.skills_dir / "pinned-skill").exists()
    assert not (ops.skills_dir / ".archive" / "pinned-skill").exists()


# ---------------------------------------------------------------------------
# 5. 不存在的技能
# ---------------------------------------------------------------------------

def test_archive_missing(tmp_path: Path):
    """不存在 → 返回"不存在"。"""
    ops = _make_ops(tmp_path)
    tool = create_skill_archive_tool(ops.session_dir)
    result = tool._run("nonexistent-skill")

    assert "不存在" in result


# ---------------------------------------------------------------------------
# 6. archive 工具不在 get_session_tools
# ---------------------------------------------------------------------------

def test_archive_tool_not_in_session_tools(tmp_path: Path):
    """get_session_tools 不含 archive_skill（前台无归档权）。"""
    from tools import get_session_tools

    tools = get_session_tools(
        session_dir=tmp_path / "session",
        workspace=tmp_path / "workspace",
    )
    tool_names = [t.name for t in tools]
    assert "archive_skill" not in tool_names
