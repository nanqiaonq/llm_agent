"""Verify AgentManager wires SkillEngineMiddleware and triggers it on multi-tool turns."""
import asyncio
from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from agent.agent_manager import AgentManager
from agent.event_bus import EventBus
from agent.session_manager import SessionManager
from tests.test_agent_manager import setup as base_setup  # reuse fixture


class ToolBindableFake(FakeListChatModel):
    def bind_tools(self, tools, **kwargs):
        return self


@pytest.mark.asyncio
async def test_agent_manager_accepts_event_bus_and_middleware(tmp_path: Path):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    meta = sm.create("Test", str(workspace), model="fake")

    bus = EventBus()
    fake = ToolBindableFake(responses=["short reply"])
    mgr = AgentManager(
        session_manager=sm,
        llm_factory=lambda: fake,
        event_bus=bus,  # NEW M2 param
    )

    # Just iterate through and ensure no error.
    events = []
    async for ev in mgr.astream(meta.id, "hi"):
        events.append(ev)
    types = [e["type"] for e in events]
    assert "turn_start" in types
    assert "turn_end" in types


@pytest.mark.asyncio
async def test_agent_manager_accepts_model_override(tmp_path: Path):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    meta = sm.create("Test", str(workspace), model="m")

    bus = EventBus()
    captured_models: list[str] = []

    def llm_factory(model=None):
        captured_models.append(model or "default")
        from langchain_core.language_models.fake_chat_models import FakeListChatModel
        class Fake(FakeListChatModel):
            def bind_tools(self, tools, **kwargs):
                return self
        return Fake(responses=["short reply"])

    mgr = AgentManager(session_manager=sm, llm_factory=llm_factory, event_bus=bus)
    events = []
    async for ev in mgr.astream(meta.id, "hi", model_override="qwen/qwen-2.5-72b-instruct"):
        events.append(ev)
    # Verify the factory was invoked with the overridden model
    assert "qwen/qwen-2.5-72b-instruct" in captured_models
