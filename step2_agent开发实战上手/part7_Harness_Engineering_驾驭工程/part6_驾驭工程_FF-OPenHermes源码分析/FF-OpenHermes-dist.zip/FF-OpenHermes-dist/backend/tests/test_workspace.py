"""Tests for workspace file operations."""
from pathlib import Path

import pytest

from agent.workspace import WorkspaceOps


@pytest.fixture
def ws(tmp_path: Path) -> WorkspaceOps:
    root = tmp_path / "proj"
    root.mkdir()
    (root / "src").mkdir()
    (root / "src" / "main.py").write_text("print('hi')\n", encoding="utf-8")
    (root / "README.md").write_text("# Test\n", encoding="utf-8")
    (root / "node_modules").mkdir()
    (root / "node_modules" / "junk.js").write_text("x", encoding="utf-8")
    (root / ".git").mkdir()
    (root / ".git" / "HEAD").write_text("x", encoding="utf-8")
    return WorkspaceOps(root)


def test_tree_excludes_node_modules_and_git(ws: WorkspaceOps):
    tree = ws.tree()
    names = [c["name"] for c in tree["children"]]
    assert "src" in names
    assert "README.md" in names
    assert "node_modules" not in names
    assert ".git" not in names


def test_tree_directories_first(ws: WorkspaceOps):
    tree = ws.tree()
    types = [c["type"] for c in tree["children"]]
    # Find first file index — every dir must come before it
    first_file = next((i for i, t in enumerate(types) if t == "file"), len(types))
    assert all(t == "directory" for t in types[:first_file])


def test_read_file(ws: WorkspaceOps):
    res = ws.read_file("src/main.py")
    assert res["content"] == "print('hi')\n"
    assert res["language"] == "python"


def test_read_file_blocks_escape(ws: WorkspaceOps):
    with pytest.raises(ValueError, match="escapes"):
        ws.read_file("../escape.txt")


def test_write_file_creates_parent_dirs(ws: WorkspaceOps):
    ws.write_file("docs/notes/a.md", "# Hi")
    assert (ws.root / "docs" / "notes" / "a.md").read_text(encoding="utf-8") == "# Hi"


def test_mkdir_rename_delete(ws: WorkspaceOps):
    ws.mkdir("foo")
    assert (ws.root / "foo").is_dir()
    ws.rename("foo", "bar")
    assert (ws.root / "bar").is_dir()
    assert not (ws.root / "foo").exists()
    ws.delete("bar")
    assert not (ws.root / "bar").exists()


def test_delete_outside_root_blocked(ws: WorkspaceOps):
    with pytest.raises(ValueError):
        ws.delete("../README.md")
