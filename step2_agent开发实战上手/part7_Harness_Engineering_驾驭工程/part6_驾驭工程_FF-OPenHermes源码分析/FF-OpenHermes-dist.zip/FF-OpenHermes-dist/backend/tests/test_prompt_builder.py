"""Tests for prompt_builder."""
import json
from pathlib import Path

import pytest

from agent.prompt_builder import build_system_prompt


@pytest.fixture
def sdir(tmp_path: Path) -> Path:
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "SOUL.md").write_text("SOUL CONTENT", encoding="utf-8")
    (sd / "MEMORY.md").write_text("MEMORY CONTENT", encoding="utf-8")
    (sd / "skills").mkdir()
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("SNAPSHOT CONTENT", encoding="utf-8")
    (sd / "skills" / "demo").mkdir()
    (sd / "skills" / "demo" / "SKILL.md").write_text("DEMO SKILL FULL CONTENT", encoding="utf-8")
    (sd / "loaded_skills.json").write_text(json.dumps([{"name": "demo", "level": 1}]), encoding="utf-8")
    return sd


def test_includes_all_layers(sdir: Path):
    p = build_system_prompt(sdir)
    assert "SOUL CONTENT" in p
    assert "MEMORY CONTENT" in p
    assert "SNAPSHOT CONTENT" in p
    assert "DEMO SKILL FULL CONTENT" in p


def test_layer_order(sdir: Path):
    p = build_system_prompt(sdir)
    soul_idx = p.index("SOUL CONTENT")
    mem_idx = p.index("MEMORY CONTENT")
    snap_idx = p.index("SNAPSHOT CONTENT")
    demo_idx = p.index("DEMO SKILL FULL CONTENT")
    assert soul_idx < mem_idx < snap_idx < demo_idx


def test_omits_skill_when_only_level_0(tmp_path: Path):
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "SOUL.md").write_text("SOUL", encoding="utf-8")
    (sd / "MEMORY.md").write_text("MEM", encoding="utf-8")
    (sd / "skills").mkdir()
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("SNAP", encoding="utf-8")
    (sd / "skills" / "demo").mkdir()
    (sd / "skills" / "demo" / "SKILL.md").write_text("FULL", encoding="utf-8")
    (sd / "loaded_skills.json").write_text(json.dumps([{"name": "demo", "level": 0}]), encoding="utf-8")
    p = build_system_prompt(sd)
    assert "FULL" not in p  # level-0 doesn't inject full body


def test_protocol_footer_present(sdir: Path):
    p = build_system_prompt(sdir)
    assert "## Protocol" in p or "Protocol" in p
