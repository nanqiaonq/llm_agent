"""Tests for E2 curator — state transitions, agentic Phase 2, dry_run."""
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.messages import AIMessage

from agent.skill_ops import SkillOps
from agent.skill_provenance import BACKGROUND, set_write_origin, reset_write_origin
from skill_engine.curator import (
    apply_state_transitions,
    run_curator_subagent,
    _extract_curator_actions,
    curate,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SKILL_TEMPLATE = """\
---
name: {name}
description: "{desc}. Use when {use}."
version: 1.0
generated_by: agent
created_at: 2025-01-01T00:00:00+00:00
---

# {name}

## Overview
{desc}.

## Steps
1. Do the thing.
"""


def _make_ops(tmp_path: Path, global_dir: Path | None = None) -> SkillOps:
    return SkillOps(tmp_path / "session", global_dir=global_dir)


def _create_skill(ops: SkillOps, name: str, *, as_agent: bool = True, pinned: bool = False) -> None:
    """Write a skill and set created_by appropriately."""
    md = SKILL_TEMPLATE.format(name=name, desc=f"Skill {name}", use=f"testing {name}")
    if as_agent:
        token = set_write_origin(BACKGROUND)
        try:
            ops.write_skill(name, md)
        finally:
            reset_write_origin(token)
    else:
        ops.write_skill(name, md)
    if pinned:
        ops.usage.set_pinned(name, True)


def _set_last_used_days_ago(ops: SkillOps, name: str, days: float) -> None:
    """Directly patch .usage.json to set last_used_at to `days` days ago."""
    usage_file = ops.usage._usage_file
    data = json.loads(usage_file.read_text()) if usage_file.exists() else {}
    rec = data.get(name, {})
    dt = datetime.now(timezone.utc) - timedelta(days=days)
    rec["last_used_at"] = dt.isoformat()
    data[name] = rec
    usage_file.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _make_fake_agent(return_value: dict):
    """Return a fake agent whose ainvoke returns return_value."""
    agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = AsyncMock(return_value=return_value)
    agent.with_config = MagicMock(return_value=configured)
    return agent, configured


# ---------------------------------------------------------------------------
# A2: archive_skill (ops layer — Phase 1 依赖)
# ---------------------------------------------------------------------------

def test_archive_skill_moves_to_archive_dir(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "my-skill")

    ops.archive_skill("my-skill")

    assert not (ops.skills_dir / "my-skill").exists()
    assert (ops.skills_dir / ".archive" / "my-skill").exists()
    assert (ops.skills_dir / ".archive" / "my-skill" / "SKILL.md").exists()


def test_archive_skill_not_in_list_skills(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "my-skill")
    ops.archive_skill("my-skill")

    names = [s["name"] for s in ops.list_skills()]
    assert "my-skill" not in names


def test_archive_skill_state_archived(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "my-skill")
    ops.archive_skill("my-skill")

    rec = ops.usage.get("my-skill")
    assert rec is not None
    assert rec["state"] == "archived"


def test_archive_skill_content_preserved(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "my-skill")
    original_content = (ops.skills_dir / "my-skill" / "SKILL.md").read_text()

    ops.archive_skill("my-skill")

    archived_content = (ops.skills_dir / ".archive" / "my-skill" / "SKILL.md").read_text()
    assert archived_content == original_content


def test_archive_skill_collision_adds_timestamp_suffix(tmp_path: Path):
    ops = _make_ops(tmp_path)
    archive_dir = ops.skills_dir / ".archive"
    archive_dir.mkdir(parents=True, exist_ok=True)
    (archive_dir / "my-skill").mkdir()
    (archive_dir / "my-skill" / "SKILL.md").write_text("old", encoding="utf-8")

    _create_skill(ops, "my-skill")
    ops.archive_skill("my-skill")

    archived = list(archive_dir.iterdir())
    names = [p.name for p in archived]
    assert "my-skill" in names
    assert any(n.startswith("my-skill-") for n in names)


def test_archive_skill_missing_raises(tmp_path: Path):
    ops = _make_ops(tmp_path)
    with pytest.raises(FileNotFoundError):
        ops.archive_skill("nonexistent")


def test_list_skills_excludes_dot_prefix_dirs(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "real-skill")
    hidden = ops.skills_dir / ".hidden-dir"
    (hidden / "some-skill").mkdir(parents=True)
    (hidden / "some-skill" / "SKILL.md").write_text("---\nname: some-skill\n---\n", encoding="utf-8")

    names = [s["name"] for s in ops.list_skills()]
    assert "real-skill" in names
    assert "some-skill" not in names


# ---------------------------------------------------------------------------
# A3: Phase 1 — state transitions（回归）
# ---------------------------------------------------------------------------

def test_phase1_archives_old_skill(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "old-skill")
    _set_last_used_days_ago(ops, "old-skill", days=100)

    result = apply_state_transitions(ops, stale_days=30, archive_days=90)

    assert result["archived"] == 1
    assert not (ops.skills_dir / "old-skill").exists()
    assert ops.usage.get("old-skill")["state"] == "archived"


def test_phase1_marks_stale(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "stale-skill")
    _set_last_used_days_ago(ops, "stale-skill", days=35)

    result = apply_state_transitions(ops, stale_days=30, archive_days=90)

    assert result["marked_stale"] == 1
    assert result["archived"] == 0
    assert (ops.skills_dir / "stale-skill").exists()
    assert ops.usage.get("stale-skill")["state"] == "stale"


def test_phase1_keeps_recent_active(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "fresh-skill")
    _set_last_used_days_ago(ops, "fresh-skill", days=5)

    result = apply_state_transitions(ops, stale_days=30, archive_days=90)

    assert result["marked_stale"] == 0
    assert result["archived"] == 0
    assert (ops.skills_dir / "fresh-skill").exists()


def test_phase1_ignores_non_agent_skills(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "user-skill", as_agent=False)
    _set_last_used_days_ago(ops, "user-skill", days=100)

    result = apply_state_transitions(ops, stale_days=30, archive_days=90)

    assert result["checked"] == 0
    assert result["archived"] == 0
    assert (ops.skills_dir / "user-skill").exists()


def test_phase1_ignores_pinned_skills(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "pinned-skill", as_agent=True, pinned=True)
    _set_last_used_days_ago(ops, "pinned-skill", days=100)

    result = apply_state_transitions(ops, stale_days=30, archive_days=90)

    assert result["archived"] == 0
    assert (ops.skills_dir / "pinned-skill").exists()


def test_phase1_no_activity_skips(tmp_path: Path):
    ops = _make_ops(tmp_path)
    _create_skill(ops, "never-used")

    result = apply_state_transitions(ops, stale_days=30, archive_days=90)

    assert result["archived"] == 0
    assert result["marked_stale"] == 0


def test_phase1_ignores_global_skills(tmp_path: Path):
    global_dir = tmp_path / "global"
    (global_dir / "preset").mkdir(parents=True)
    (global_dir / "preset" / "SKILL.md").write_text(
        SKILL_TEMPLATE.format(name="preset", desc="Preset", use="preset"), encoding="utf-8"
    )
    ops = SkillOps(tmp_path / "session", global_dir=global_dir)

    result = apply_state_transitions(ops, stale_days=30, archive_days=90)
    assert result["archived"] == 0


# ---------------------------------------------------------------------------
# B1: _extract_curator_actions
# ---------------------------------------------------------------------------

def test_extract_curator_actions_create_and_archive():
    """从 fake tool_calls 提取 create=consolidation / archive=pruning。"""
    ai_msg = MagicMock()
    ai_msg.tool_calls = [
        {"name": "skill_manage", "args": {"action": "create", "name": "write-tools"}},
        {"name": "archive_skill", "args": {"name": "write-report"}},
        {"name": "archive_skill", "args": {"name": "write-summary"}},
        {"name": "read_skill", "args": {"name": "write-report"}},  # not extracted
    ]
    result = _extract_curator_actions({"messages": [ai_msg]})

    assert len(result["consolidations"]) == 1
    assert result["consolidations"][0]["umbrella"] == "write-tools"
    assert len(result["prunings"]) == 2
    assert result["prunings"][0]["name"] == "write-report"
    assert "create:write-tools" in result["actions"]
    assert "archive:write-report" in result["actions"]


def test_extract_curator_actions_empty():
    result = _extract_curator_actions({"messages": []})
    assert result == {"consolidations": [], "prunings": [], "actions": []}


def test_extract_curator_actions_non_dict():
    result = _extract_curator_actions("not a dict")
    assert result == {"consolidations": [], "prunings": [], "actions": []}


# ---------------------------------------------------------------------------
# B2: run_curator_subagent — tools whitelist
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_run_curator_subagent_tools(tmp_path: Path):
    """fork 的 create_agent 收到 tools=[read_skill, skill_manage, archive_skill] + middleware=[]。"""
    ops = _make_ops(tmp_path)
    _create_skill(ops, "skill-a")
    _create_skill(ops, "skill-b")

    captured_tools: list = []
    captured_kwargs: dict = {}

    fake_agent, _ = _make_fake_agent({"messages": []})

    def fake_create_agent(model, tools, middleware):
        captured_tools.extend(tools)
        captured_kwargs["middleware"] = middleware
        return fake_agent

    with patch("skill_engine.curator.create_agent", fake_create_agent):
        await run_curator_subagent(ops, lambda: MagicMock())

    tool_names = [t.name for t in captured_tools]
    assert set(tool_names) == {"read_skill", "skill_manage", "archive_skill"}
    assert len(captured_tools) == 3
    assert captured_kwargs["middleware"] == []


@pytest.mark.asyncio
async def test_run_curator_subagent_recursion_limit(tmp_path: Path):
    """.with_config(recursion_limit=10) 被调用。"""
    ops = _make_ops(tmp_path)
    _create_skill(ops, "skill-a")
    _create_skill(ops, "skill-b")

    fake_agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = AsyncMock(return_value={"messages": []})
    fake_agent.with_config = MagicMock(return_value=configured)

    with patch("skill_engine.curator.create_agent", return_value=fake_agent):
        await run_curator_subagent(ops, lambda: MagicMock())

    fake_agent.with_config.assert_called_once_with(recursion_limit=10)


# ---------------------------------------------------------------------------
# B3: run_curator_subagent — BACKGROUND provenance
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_run_curator_background_origin(tmp_path: Path):
    """ainvoke 期间 get_write_origin()==BACKGROUND + 退出恢复 foreground。"""
    from agent.skill_provenance import get_write_origin

    ops = _make_ops(tmp_path)
    _create_skill(ops, "skill-a")
    _create_skill(ops, "skill-b")

    origin_during: list[str] = []

    async def fake_ainvoke(inputs, config=None):
        origin_during.append(get_write_origin())
        return {"messages": []}

    fake_agent = MagicMock()
    configured = MagicMock()
    configured.ainvoke = fake_ainvoke
    fake_agent.with_config = MagicMock(return_value=configured)

    with patch("skill_engine.curator.create_agent", return_value=fake_agent):
        await run_curator_subagent(ops, lambda: MagicMock())

    assert origin_during == [BACKGROUND]
    assert get_write_origin() == "foreground"


# ---------------------------------------------------------------------------
# B4: run_curator_subagent — <2 candidates → skipped, no fork
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_run_curator_lt_2_candidates(tmp_path: Path):
    """<2 候选 → skipped，不 fork sub-agent。"""
    ops = _make_ops(tmp_path)
    _create_skill(ops, "only-one")

    with patch("skill_engine.curator.create_agent") as mock_ca:
        result = await run_curator_subagent(ops, lambda: MagicMock())

    assert "skipped" in result
    mock_ca.assert_not_called()


# ---------------------------------------------------------------------------
# B5: curate() dry_run skips Phase 2
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_curate_dry_run_skips_phase2(tmp_path: Path):
    """dry_run=True → consolidations 空 + note，不 fork sub-agent。"""
    ops = _make_ops(tmp_path)
    _create_skill(ops, "skill-a")
    _create_skill(ops, "skill-b")

    with patch("skill_engine.curator.create_agent") as mock_ca:
        result = await curate(ops, lambda: MagicMock(), dry_run=True)

    assert result["dry_run"] is True
    assert result["consolidations"] == []
    assert "note" in result
    mock_ca.assert_not_called()


# ---------------------------------------------------------------------------
# B6: curate() Phase 1 preserved
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_curate_phase1_preserved(tmp_path: Path):
    """apply_state_transitions（态转移）仍工作。"""
    ops = _make_ops(tmp_path)
    _create_skill(ops, "old-skill")
    _set_last_used_days_ago(ops, "old-skill", days=100)

    fake_agent, _ = _make_fake_agent({"messages": []})

    with patch("skill_engine.curator.create_agent", return_value=fake_agent):
        result = await curate(ops, lambda: MagicMock(), stale_days=30, archive_days=90, dry_run=False)

    assert result["transitions"]["archived"] == 1
    assert not (ops.skills_dir / "old-skill").exists()
