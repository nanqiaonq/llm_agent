"""Tests for AgentManager runtime — uses a fake LLM.

API DRIFT NOTE (LangChain 1.2.x):
  - `create_agent(prompt=...)` is now `create_agent(system_prompt=...)`.
  - `FakeListChatModel.bind_tools` raises NotImplementedError, but
    `create_agent` calls `bind_tools` whenever any tool is present in the
    agent's tool set. Because `AgentManager` always wires up the 9 session
    tools, we subclass FakeListChatModel here to make `bind_tools` a no-op
    (returns self). The fake still doesn't actually emit tool calls — it
    just streams its canned text response — which is exactly what we need
    to assert that token streaming produces the response text end-to-end.
"""
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from agent.agent_manager import AgentManager
from agent.session_manager import SessionManager


class ToolBindableFakeListChatModel(FakeListChatModel):
    """FakeListChatModel that ignores .bind_tools() — required for create_agent."""

    def bind_tools(self, tools, **kwargs):  # type: ignore[override]
        return self


@pytest.fixture
def setup(tmp_path: Path):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul\nYou are a test assistant.", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")
    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    meta = sm.create("Test", str(workspace), model="fake")
    return sm, meta


@pytest.mark.asyncio
async def test_streaming_emits_token_and_done(setup):
    sm, meta = setup
    fake = ToolBindableFakeListChatModel(responses=["Hello user, this is a fake response."])
    mgr = AgentManager(session_manager=sm, llm_factory=lambda: fake)

    events: list[dict] = []
    async for ev in mgr.astream(meta.id, "Hi"):
        events.append(ev)

    types = [e["type"] for e in events]
    assert "turn_start" in types
    assert "turn_end" in types
    full = "".join(e["content"] for e in events if e["type"] == "assistant_token")
    assert "fake response" in full
