"""Tests for SessionManager (per-session directory layout)."""
from pathlib import Path

import pytest

from agent.session_manager import SessionManager


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    ws = tmp_path / "myproj"
    ws.mkdir()
    return ws


@pytest.fixture
def manager(tmp_path: Path):
    sessions = tmp_path / "sessions"
    templates = tmp_path / "templates"
    templates.mkdir()
    (templates / "SOUL.md").write_text("# Soul template", encoding="utf-8")
    (templates / "MEMORY.md").write_text("# Memory template", encoding="utf-8")
    return SessionManager(sessions_dir=sessions, templates_dir=templates)


def test_create_session_makes_dir_and_meta(manager: SessionManager, workspace: Path):
    meta = manager.create("Title 1", str(workspace), model="m")
    sdir = manager.session_dir(meta.id)
    assert sdir.exists()
    assert (sdir / "meta.json").exists()
    assert (sdir / "SOUL.md").read_text(encoding="utf-8").startswith("# Soul template")
    assert (sdir / "MEMORY.md").read_text(encoding="utf-8").startswith("# Memory template")
    assert (sdir / "skills").is_dir()
    assert (sdir / "loaded_skills.json").exists()


def test_create_rejects_missing_workspace(manager: SessionManager, tmp_path: Path):
    with pytest.raises(ValueError, match="workspace_path"):
        manager.create("Title", str(tmp_path / "does-not-exist"), model="m")


def test_list_sorted_by_updated_at(manager: SessionManager, workspace: Path):
    a = manager.create("A", str(workspace), model="m")
    b = manager.create("B", str(workspace), model="m")
    rows = manager.list()
    ids = [r.id for r in rows]
    # b should come before a (more recent)
    assert ids.index(b.id) < ids.index(a.id)


def test_get_meta_roundtrip(manager: SessionManager, workspace: Path):
    meta = manager.create("Roundtrip", str(workspace), model="m")
    loaded = manager.get(meta.id)
    assert loaded.id == meta.id
    assert loaded.workspace_path == str(workspace.resolve())


def test_rename_updates_title(manager: SessionManager, workspace: Path):
    meta = manager.create("Old", str(workspace), model="m")
    manager.rename(meta.id, "New")
    assert manager.get(meta.id).title == "New"


def test_delete_removes_session_only(manager: SessionManager, workspace: Path):
    meta = manager.create("Doomed", str(workspace), model="m")
    sdir = manager.session_dir(meta.id)
    assert sdir.exists()
    (workspace / "untouched.txt").write_text("keep me", encoding="utf-8")
    manager.delete(meta.id)
    assert not sdir.exists()
    assert (workspace / "untouched.txt").exists()  # workspace not deleted
