"""Tests for fs_browse used by NewSessionModal directory picker."""
import sys
from pathlib import Path

import pytest

from agent.fs_browse import browse, list_drives


def test_browse_lists_dirs_only(tmp_path: Path):
    (tmp_path / "a").mkdir()
    (tmp_path / "b").mkdir()
    (tmp_path / "f.txt").write_text("x")
    items = browse(str(tmp_path))
    names = [it["name"] for it in items["entries"]]
    assert "a" in names
    assert "b" in names
    assert "f.txt" not in names


def test_browse_returns_parent(tmp_path: Path):
    sub = tmp_path / "sub"
    sub.mkdir()
    res = browse(str(sub))
    assert res["parent"] == str(tmp_path.resolve()).replace("\\", "/")


def test_browse_root_no_parent(tmp_path: Path):
    res = browse(str(tmp_path))  # not actual root, but our impl walks up
    assert "parent" in res


@pytest.mark.skipif(sys.platform != "win32", reason="windows only")
def test_list_drives_windows():
    drives = list_drives()
    assert any(d.endswith(":\\") or d.endswith(":/") for d in drives)
