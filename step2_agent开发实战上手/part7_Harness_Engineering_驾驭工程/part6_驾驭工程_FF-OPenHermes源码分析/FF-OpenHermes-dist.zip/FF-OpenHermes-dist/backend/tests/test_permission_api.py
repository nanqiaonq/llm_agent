"""Tests for POST /api/permission/{request_id}."""
import asyncio

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.permission_registry import PermissionRegistry


@pytest.mark.asyncio
async def test_permission_post_resolves_pending_future():
    reg = PermissionRegistry()
    app_module.app.state.permission_registry = reg
    fut = reg.register("req1")

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        resp = await ac.post("/api/permission/req1", json={"behavior": "allow_once"})
    assert resp.status_code == 200
    decision = await asyncio.wait_for(fut, timeout=1.0)
    assert decision == "allow_once"


@pytest.mark.asyncio
async def test_permission_post_unknown_id_returns_404():
    reg = PermissionRegistry()
    app_module.app.state.permission_registry = reg
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        resp = await ac.post("/api/permission/ghost", json={"behavior": "deny"})
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_permission_post_invalid_behavior_returns_422():
    reg = PermissionRegistry()
    app_module.app.state.permission_registry = reg
    reg.register("req1")
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        resp = await ac.post("/api/permission/req1", json={"behavior": "ZIBOOP"})
    assert resp.status_code == 422
