"""Tests for /api/sessions REST endpoints."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def client_setup(tmp_path: Path):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    app_module.app.state.session_manager = sm
    return workspace


@pytest.mark.asyncio
async def test_create_list_get_rename_delete(client_setup):
    workspace = client_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        # Create
        r = await ac.post("/api/sessions", json={
            "title": "First", "workspace_path": str(workspace),
            "model": "deepseek/deepseek-chat-v3.1",
        })
        assert r.status_code == 200
        sid = r.json()["id"]

        # List
        r = await ac.get("/api/sessions")
        assert r.status_code == 200
        assert any(s["id"] == sid for s in r.json()["sessions"])

        # Get
        r = await ac.get(f"/api/sessions/{sid}")
        assert r.status_code == 200
        assert r.json()["title"] == "First"

        # Rename
        r = await ac.put(f"/api/sessions/{sid}", json={"title": "Renamed"})
        assert r.status_code == 200
        assert r.json()["title"] == "Renamed"

        # Delete
        r = await ac.delete(f"/api/sessions/{sid}")
        assert r.status_code == 200

        # Confirm gone
        r = await ac.get(f"/api/sessions/{sid}")
        assert r.status_code == 404


@pytest.mark.asyncio
async def test_create_rejects_missing_workspace(client_setup):
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post("/api/sessions", json={
            "title": "X", "workspace_path": "C:/does/not/exist",
            "model": "deepseek/deepseek-chat-v3.1",
        })
        assert r.status_code == 400
