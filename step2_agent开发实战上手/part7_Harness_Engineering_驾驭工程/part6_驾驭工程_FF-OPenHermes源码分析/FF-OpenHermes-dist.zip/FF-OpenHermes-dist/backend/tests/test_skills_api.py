"""Tests for /api/sessions/{sid}/skills/* endpoints."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta


@pytest.mark.asyncio
async def test_skill_crud_and_load(setup):
    meta = setup
    md = "---\nname: demo\ndescription: demo. Use when testing.\nversion: 1.0\n---\n\n# Demo\nbody"
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        # Create
        r = await ac.post(f"/api/sessions/{meta.id}/skills",
                          json={"name": "demo", "content": md})
        assert r.status_code == 200

        # List
        r = await ac.get(f"/api/sessions/{meta.id}/skills")
        assert r.status_code == 200
        assert any(s["name"] == "demo" for s in r.json()["skills"])

        # Get detail
        r = await ac.get(f"/api/sessions/{meta.id}/skills/demo")
        assert "Demo" in r.json()["content"]

        # Load level 1
        r = await ac.post(f"/api/sessions/{meta.id}/skills/demo/load", json={"level": 1})
        assert r.status_code == 200

        # Loaded
        r = await ac.get(f"/api/sessions/{meta.id}/skills/loaded")
        assert any(it["name"] == "demo" for it in r.json()["loaded"])

        # Unload
        r = await ac.post(f"/api/sessions/{meta.id}/skills/demo/unload")
        assert r.status_code == 200

        # Delete
        r = await ac.delete(f"/api/sessions/{meta.id}/skills/demo")
        assert r.status_code == 200
        r = await ac.get(f"/api/sessions/{meta.id}/skills/demo")
        assert r.status_code == 404
