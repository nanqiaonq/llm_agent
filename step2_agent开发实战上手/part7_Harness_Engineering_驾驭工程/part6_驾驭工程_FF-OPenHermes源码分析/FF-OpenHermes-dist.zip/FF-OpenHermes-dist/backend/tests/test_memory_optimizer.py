"""Tests for MEMORY.md AI optimization."""
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from agent.memory_optimizer import optimize_memory_text, OptimizedMemory


class StagedFake(FakeListChatModel):
    structured_response: dict | Exception | None = None

    def with_structured_output(self, schema, **kwargs):  # type: ignore[override]
        outer = self

        class StructuredRunnable:
            async def ainvoke(self, prompt):
                if isinstance(outer.structured_response, Exception):
                    raise outer.structured_response
                return schema.model_validate(outer.structured_response)

        return StructuredRunnable()

    def bind_tools(self, tools, **kwargs):
        return self


@pytest.mark.asyncio
async def test_optimize_returns_markdown_string():
    fake = StagedFake(responses=[])
    fake.structured_response = {
        "summary": "User prefers concise replies and Chinese language.",
        "sections": [
            {"title": "Preferences", "bullets": ["Concise", "Chinese language"]},
            {"title": "Workflow", "bullets": ["Always test before commit"]},
        ],
    }
    md = await optimize_memory_text(
        current="# Memory\n- short replies\n- chinese please\n- write tests\n",
        llm_factory=lambda: fake,
    )
    assert md is not None
    assert "Preferences" in md
    assert "Concise" in md
    assert "## " in md  # headings present


@pytest.mark.asyncio
async def test_optimize_returns_none_on_llm_failure():
    fake = StagedFake(responses=[])
    fake.structured_response = RuntimeError("LLM upstream blew up")
    md = await optimize_memory_text(
        current="# Memory\n- foo\n",
        llm_factory=lambda: fake,
    )
    assert md is None


def test_optimized_memory_schema_validates_minimal():
    o = OptimizedMemory(summary="A", sections=[{"title": "X", "bullets": ["a"]}])
    assert o.summary == "A"
    assert len(o.sections) == 1


def test_optimized_memory_section_requires_at_least_one_bullet():
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        OptimizedMemory(summary="A", sections=[{"title": "Empty", "bullets": []}])
