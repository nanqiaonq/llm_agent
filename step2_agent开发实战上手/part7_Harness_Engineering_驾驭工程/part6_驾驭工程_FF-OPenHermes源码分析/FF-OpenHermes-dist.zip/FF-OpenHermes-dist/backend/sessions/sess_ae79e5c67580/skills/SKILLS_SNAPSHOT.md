# Skills Snapshot


Available skills (use `read_skill('<name>')` to load full content):

- **conda-deploy** (v1.0) — 固定的 conda 部署流程：建环境→装依赖→启动服务
- **pg-query-degradation** (v1.0) — PostgreSQL 查询退化排查：定位索引失效
- **long_document_workflow** (v1.0) — Use when user requests to generate a long document with specific topic and format. This skill provides a structured workflow for creating well-organized, multi-section documents with consistent formatting.
- **pdf_to_markdown** (v1.0) — Use when user requests to convert PDF files to Markdown format. Triggers include: any mention of "PDF to markdown", "convert pdf", "extract text from pdf", "pdf conversion", or requests to transform PDF documents into structured markdown with preserved formatting. Also use when processing PDF reports, articles, or documents for markdown-based workflows.
- **storyboard_generator** (v1.0) — Use when user requests to generate a complete storyboard for a film or video project. This skill provides a structured workflow for creating detailed shot-by-shot storyboards including visual descriptions, camera angles, movements, dialogue, and timing. Trigger keywords: "电影分镜", "分镜脚本", "storyboard", "shot list", "镜头脚本", "视频分镜", "拍摄脚本", "visual storyboard", "电影镜头规划".
- **weather_query** (v1.0) — 根据用户输入的城市名称查询实时天气信息。触发关键词包括：天气、气温、温度、下雨、刮风、湿度、天气预报。当用户说"查天气"、"今天天气"、"XX市天气"时使用此技能。中文用户为主，但支持全球城市查询。
