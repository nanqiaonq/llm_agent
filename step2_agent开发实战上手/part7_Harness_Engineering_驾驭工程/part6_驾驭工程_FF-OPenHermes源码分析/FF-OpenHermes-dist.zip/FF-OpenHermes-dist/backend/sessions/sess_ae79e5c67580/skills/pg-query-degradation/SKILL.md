---
name: pg-query-degradation
description: PostgreSQL 查询退化排查：定位索引失效
version: 1.0
generated_by: agent
created_at: 2026-06-12
---

# pg-query-degradation

EXPLAIN ANALYZE 看全表扫描 → 检查 WHERE 是否用函数包裹字段致索引失效。
