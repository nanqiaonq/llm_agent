# Long-term Memory

This file is your persistent memory across the lifetime of this session.
It is loaded into your system prompt every turn. Use the `write_memory`
tool to add facts that will be useful in future turns.

<!-- Memory entries below this line. Keep concise. -->
