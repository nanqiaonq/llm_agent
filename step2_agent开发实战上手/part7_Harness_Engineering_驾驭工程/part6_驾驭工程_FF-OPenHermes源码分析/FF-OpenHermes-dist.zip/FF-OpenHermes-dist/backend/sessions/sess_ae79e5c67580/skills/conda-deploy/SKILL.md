---
name: conda-deploy
description: 固定的 conda 部署流程：建环境→装依赖→启动服务
version: 1.0
generated_by: skill_manage
created_at: 2026-06-12
---

# conda-deploy

conda create → pip install → uvicorn 启动。
