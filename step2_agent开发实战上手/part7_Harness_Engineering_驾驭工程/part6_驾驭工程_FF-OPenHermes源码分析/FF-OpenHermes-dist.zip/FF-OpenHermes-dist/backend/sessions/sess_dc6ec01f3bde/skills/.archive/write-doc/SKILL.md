---
name: write-doc
description: 把零散笔记整理成结构化文档：概述+小节+总结
version: 1.0
generated_by: agent
created_at: 2026-06-12
---

# write-doc

结构化文档整理。
