---
name: write-summary
description: 把长文档压缩成结构化摘要：要点+结论
version: 1.0
generated_by: agent
created_at: 2026-06-12
---

# write-summary

结构化摘要生成。
