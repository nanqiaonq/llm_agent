---
name: my-precious
description: 我私藏的发布流程：build→tag→push→release
version: 1.0
generated_by: skill_manage
created_at: 2026-06-12
---

# my-precious

user 手工维护的关键资产。
