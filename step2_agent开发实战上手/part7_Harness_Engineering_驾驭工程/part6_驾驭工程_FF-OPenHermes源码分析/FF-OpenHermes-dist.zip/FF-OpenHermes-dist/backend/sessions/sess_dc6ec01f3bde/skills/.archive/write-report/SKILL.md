---
name: write-report
description: 把分析结果写成结构化报告：标题+背景+发现+结论
version: 1.0
generated_by: agent
created_at: 2026-06-12
---

# write-report

结构化报告生成。
