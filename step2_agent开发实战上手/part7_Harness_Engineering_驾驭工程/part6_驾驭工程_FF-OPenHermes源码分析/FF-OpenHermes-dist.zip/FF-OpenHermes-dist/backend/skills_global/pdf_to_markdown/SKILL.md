---
name: pdf_to_markdown
description: 'Use when user requests to convert PDF files to Markdown format. Triggers include: any mention of "PDF to markdown", "convert pdf", "extract text from pdf", "pdf conversion", or requests to transform PDF documents into structured markdown with preserved formatting. Also use when processing PDF reports, articles, or documents for markdown-based workflows.'
version: "1.0"
generated_by: preset
---

# PDF转Markdown技能

## 概述
本技能提供将PDF文档转换为结构化Markdown格式的功能，支持文本提取、格式保留和内容重组。

## 触发条件
当用户需要处理以下PDF转换任务时使用：
- 将PDF文档转换为Markdown格式
- 从PDF中提取文本内容
- 处理PDF报告、论文、文章
- 为内容分析或重新格式化准备PDF内容
- 将PDF集成到Markdown工作流中

触发关键词：pdf转markdown、转换pdf、提取pdf文本、pdf转换、pdf处理、pdf文档转换

## 执行步骤

### 第1步：确认PDF文件
1. 询问用户PDF文件的位置或提供方式：
   - 本地文件路径
   - 网络URL链接
   - 是否需要上传

2. 确认PDF文件的基本信息：
   - 文件大小（避免处理过大的文件）
   - 页面数量
   - 内容类型（纯文本、扫描件、表格等）

### 第2步：选择转换模式
1. 根据PDF内容类型选择适当的转换策略：
   - **文本型PDF**：直接提取文本，保留格式
   - **扫描型PDF**：需要OCR识别（如果支持）
   - **表格型PDF**：特殊处理表格结构
   - **混合型PDF**：综合处理策略

2. 询问用户转换偏好：
   - 是否保留原始格式（标题、列表、粗体等）
   - 是否提取图片和图表
   - 是否生成目录结构
   - 输出详细程度

### 第3步：执行转换
1. 使用适当的工具处理PDF：
   - 对于文本型PDF，使用pdfminer或PyPDF2
   - 对于需要OCR的PDF，使用pytesseract（如果可用）
   - 对于表格，使用tabula-py或camelot

2. 转换过程：
   - 逐页提取内容
   - 识别文档结构（标题、段落、列表）
   - 转换格式标记（粗体、斜体、链接）
   - 处理特殊元素（表格、代码块）

### 第4步：格式化和清理
1. 清理转换后的Markdown：
   - 修复换行和空格问题
   - 确保标题层次正确
   - 标准化列表格式
   - 处理特殊字符

2. 增强可读性：
   - 添加适当的空白行
   - 确保代码块正确标记
   - 处理长行断行

### 第5步：输出和验证
1. 生成最终Markdown文件：
   - 包含元信息（源文件、转换日期）
   - 提供转换摘要
   - 标记可能的转换问题

2. 验证转换质量：
   - 检查内容完整性
   - 验证格式正确性
   - 提供质量报告

## 输出格式

转换结果应以清晰的Markdown格式输出，包含：

1. **元信息**：源PDF信息、转换时间、页面数
2. **内容结构**：保留原始文档的层次结构
3. **格式标记**：适当的Markdown格式（标题、列表、代码块等）
4. **转换摘要**：处理统计和注意事项

## 常见错误处理

1. **加密PDF**：提示用户提供解密密码或使用未加密版本
2. **扫描PDF**：建议使用OCR工具或提供文本版本
3. **损坏PDF**：尝试修复或建议重新获取文件
4. **超大文件**：建议分页处理或优化内存使用
5. **复杂格式**：标记无法完全转换的部分

## 最佳实践

1. **预处理检查**：先检查PDF属性，选择合适的工具
2. **渐进式转换**：先转换少量页面验证效果
3. **保留原始结构**：尽量保持文档的原始组织
4. **清晰标记问题**：明确标注转换中遇到的问题
5. **提供转换摘要**：让用户了解转换质量和限制

## 注意事项

1. 转换质量取决于PDF的原始质量
2. 扫描件需要OCR支持，准确率可能有限
3. 复杂布局（如多栏、图文混排）可能无法完美转换
4. 建议先转换小样本验证效果
5. 对于重要文档，建议人工校对转换结果

## 技术依赖

本技能可能需要以下Python库：
- PyPDF2 / pdfminer.six：文本提取
- pytesseract：OCR功能（可选）
- tabula-py / camelot：表格提取
- markdown：格式处理

请确保这些库已安装或提供替代方案。
