"""Path-safety utilities — sandbox enforcement."""
from pathlib import Path


def normalize_path(p: str | Path) -> str:
    """Expand ~ and resolve to absolute string path."""
    s = str(p)
    if s.startswith("~"):
        s = str(Path(s).expanduser())
    return str(Path(s).resolve())


def is_subpath(parent: str | Path, child: str | Path) -> bool:
    """True iff `child` is `parent` or a descendant of it."""
    try:
        p = Path(parent).resolve()
        c = Path(child).resolve()
    except (OSError, ValueError):
        return False
    if p == c:
        return True
    try:
        c.relative_to(p)
        return True
    except ValueError:
        return False


def resolve_in(root: str | Path, rel: str) -> Path:
    """Resolve `rel` (relative-or-absolute) inside `root`. Raise ValueError on escape."""
    root_p = Path(root).resolve()
    cleaned = rel.replace("\\", "/")
    while cleaned.startswith("./"):
        cleaned = cleaned[2:]
    candidate = (root_p / cleaned).resolve()
    if not is_subpath(root_p, candidate):
        raise ValueError(f"Path escapes sandbox root: {rel}")
    return candidate
