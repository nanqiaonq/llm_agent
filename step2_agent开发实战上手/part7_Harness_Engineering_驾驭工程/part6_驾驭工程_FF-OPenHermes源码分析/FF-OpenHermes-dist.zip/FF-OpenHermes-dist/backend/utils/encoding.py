"""Shared encoding utilities — safe file reading with fallback."""
from pathlib import Path


def safe_read_text(path: Path) -> str:
    """Read text with encoding fallback: UTF-8 -> GBK -> UTF-8(replace)."""
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        pass
    try:
        return path.read_text(encoding="gbk")
    except UnicodeDecodeError:
        pass
    return path.read_text(encoding="utf-8", errors="replace")
