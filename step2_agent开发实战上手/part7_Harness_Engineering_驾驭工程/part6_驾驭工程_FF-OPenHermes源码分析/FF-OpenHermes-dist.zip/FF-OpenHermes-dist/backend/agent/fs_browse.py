"""Filesystem browser for the new-session directory picker."""
import os
import string
import sys
from pathlib import Path
from typing import Any


def list_drives() -> list[str]:
    """Windows: return drive letters like ['C:/', 'D:/']. Other: ['/']."""
    if sys.platform != "win32":
        return ["/"]
    drives: list[str] = []
    for letter in string.ascii_uppercase:
        root = f"{letter}:/"
        if os.path.exists(root):
            drives.append(root)
    return drives


def browse(path: str) -> dict[str, Any]:
    """List sub-directories of `path`. Returns entries + parent + cwd."""
    p = Path(path).expanduser().resolve()
    if not p.exists() or not p.is_dir():
        raise ValueError(f"not a directory: {path}")

    entries: list[dict[str, Any]] = []
    try:
        for child in p.iterdir():
            if not child.is_dir():
                continue
            if child.name.startswith(".") and child.name not in (".claude",):
                continue
            entries.append({
                "name": child.name,
                "path": str(child).replace("\\", "/"),
            })
    except PermissionError:
        pass
    entries.sort(key=lambda e: e["name"].lower())

    parent = str(p.parent).replace("\\", "/") if p.parent != p else None
    return {
        "cwd": str(p).replace("\\", "/"),
        "parent": parent,
        "entries": entries,
    }
