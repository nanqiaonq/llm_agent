"""AgentManager — wraps LangChain create_agent + AsyncSqliteSaver per session.

M2 additions: optional EventBus + SkillEngineMiddleware for auto-generated skills.
"""
import uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Callable

from langchain.agents import create_agent
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

from agent.event_bus import EventBus
from agent.llm import build_llm
from agent.middleware import SkillEngineMiddleware
from agent.permission_registry import PermissionRegistry
from agent.prompt_builder import build_system_prompt
from agent.session_manager import SessionManager
from agent.skill_ops import SkillOps
from config import settings, SKILLS_GLOBAL_DIR
from tools import get_session_tools


class AgentManager:
    """Per-call agent builder. Each chat() builds a fresh agent so SOUL/MEMORY/SKILLS are re-read."""

    def __init__(
        self,
        session_manager: SessionManager,
        llm_factory: Callable[[], BaseChatModel] | None = None,
        event_bus: EventBus | None = None,
        permission_registry: "PermissionRegistry | None" = None,
        memory_index=None,
        global_memory=None,
    ) -> None:
        self.sessions = session_manager
        self.llm_factory = llm_factory or build_llm
        self.event_bus = event_bus
        self.permission_registry = permission_registry
        self.memory_index = memory_index
        self.global_memory = global_memory

    async def astream(
        self,
        session_id: str,
        user_message: str,
        model_override: str | None = None,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Stream agent events for a single user turn."""
        meta = self.sessions.get(session_id)
        sdir = self.sessions.session_dir(session_id)
        workspace = Path(meta.workspace_path)

        turn_id = uuid.uuid4().hex[:8]
        yield {"type": "turn_start", "turn_id": turn_id}

        # F1 prefetch: recall memories (all sessions, incl. current) before building prompt
        recalled = ""
        if self.memory_index is not None and settings.MEMORY_RECALL_ENABLED:
            hits = self.memory_index.search(
                user_message, top_k=settings.MEMORY_RECALL_TOP_K,
            )
            if hits:
                recalled = "\n".join(
                    f"- [{h['role']}@{h['session_id'][:8]}] {h['snippet']}" for h in hits
                )
                yield {"type": "retrieval", "turn_id": turn_id, "hits": hits}
        gmem = self.global_memory.read() if self.global_memory is not None else ""
        # F3 A5: rebuild snapshot each turn so global preset skills are visible
        # to the agent (prompt_builder reads this file below). Idempotent + cheap.
        # Assumes one in-flight turn per session (single-user sessions); concurrent
        # turns on the same session_id would race on this file write.
        SkillOps(sdir, global_dir=SKILLS_GLOBAL_DIR).rebuild_snapshot()
        system_prompt = build_system_prompt(sdir, global_memory=gmem, recalled=recalled)
        tools = get_session_tools(
            session_dir=sdir,
            workspace=workspace,
            event_bus=self.event_bus,
            session_id=session_id,
            permission_registry=self.permission_registry,
            memory_index=self.memory_index,
        )
        # M4 Feature D: pass model_override through to the factory if it accepts it
        # P1 思维链: use reasoning=True so ChatDeepSeek extracts reasoning_content
        try:
            llm = self.llm_factory(model=model_override, reasoning=True) if model_override \
                  else self.llm_factory(reasoning=True)
        except TypeError:
            try:
                llm = self.llm_factory(model=model_override) if model_override else self.llm_factory()
            except TypeError:
                # Factory doesn't accept any kwarg — fall back to plain call (test fakes)
                llm = self.llm_factory()

        # F2: context summarization (trim + compact, LangGraph-native, checkpointer-safe).
        # SafeSummarizationMiddleware: on summary-LLM failure, keeps full history
        # instead of wiping it (stock middleware would replace history with an error
        # string — silent data loss). See agent/safe_summarization.py.
        mw_list: list = []
        if settings.CONTEXT_SUMMARY_ENABLED:
            from agent.safe_summarization import SafeSummarizationMiddleware
            # P1 思维链副作用修正：摘要用非 reasoning llm（ChatOpenAI）。对话主 llm 现在是
            # reasoning 版 ChatDeepSeek，但后台摘要不需要推理——复用它会浪费大量 reasoning
            # tokens。单独构造 reasoning=False 的 llm 做摘要，恢复改动前的行为。
            try:
                summary_llm = self.llm_factory(reasoning=False)
            except TypeError:
                summary_llm = self.llm_factory()
            mw_list.append(SafeSummarizationMiddleware(
                model=summary_llm,
                trigger=("tokens", settings.CONTEXT_SUMMARY_TRIGGER_TOKENS),
                keep=("messages", settings.CONTEXT_SUMMARY_KEEP_MESSAGES),
            ))
        # M2: skill engine middleware (only when event_bus provided)
        if self.event_bus is not None:
            mw_list.append(SkillEngineMiddleware(
                session_manager=self.sessions,
                event_bus=self.event_bus,
                llm_factory=self.llm_factory,
                memory_reflection_interval=settings.MEMORY_REFLECTION_INTERVAL,
            ))

        full_text = ""
        tool_id_counter = 0

        db_path = sdir / "state.db"
        async with AsyncSqliteSaver.from_conn_string(str(db_path)) as cp:
            # NOTE: LangChain 1.2.x renamed `prompt` -> `system_prompt` (API drift from plan).
            agent = create_agent(
                model=llm,
                tools=tools,
                system_prompt=system_prompt,
                checkpointer=cp,
                middleware=mw_list,
            )

            try:
                async for mode, data in agent.astream(
                    {"messages": [HumanMessage(content=user_message)]},
                    config={"configurable": {"thread_id": session_id}},
                    stream_mode=["messages", "updates"],
                ):
                    if mode == "messages":
                        msg, metadata = data
                        # P1 思维链: emit reasoning_content before answer tokens
                        rc = (getattr(msg, "additional_kwargs", None) or {}).get("reasoning_content")
                        if rc:
                            yield {"type": "thinking", "content": rc}
                        # Token-level streaming from the LLM
                        if hasattr(msg, "content") and msg.content and getattr(msg, "type", "") in ("AIMessageChunk", "ai"):
                            if not getattr(msg, "tool_calls", None):
                                full_text += msg.content
                                yield {"type": "assistant_token", "content": msg.content}
                        # M4 Feature D: emit usage when LangChain attaches usage_metadata
                        usage_meta = getattr(msg, "usage_metadata", None)
                        if usage_meta and isinstance(usage_meta, dict):
                            yield {
                                "type": "usage",
                                "input_tokens": int(usage_meta.get("input_tokens", 0)),
                                "output_tokens": int(usage_meta.get("output_tokens", 0)),
                            }

                    elif mode == "updates":
                        if not isinstance(data, dict):
                            continue
                        for node, payload in data.items():
                            if node == "model" and isinstance(payload, dict):
                                for m in payload.get("messages", []):
                                    for tc in getattr(m, "tool_calls", []) or []:
                                        tool_id_counter += 1
                                        yield {
                                            "type": "tool_start",
                                            "tool_call_id": tc.get("id", f"tc_{tool_id_counter}"),
                                            "name": tc.get("name"),
                                            "input": tc.get("args", {}),
                                        }
                            elif node == "tools" and isinstance(payload, dict):
                                for m in payload.get("messages", []):
                                    yield {
                                        "type": "tool_end",
                                        "tool_call_id": getattr(m, "tool_call_id", ""),
                                        "name": getattr(m, "name", ""),
                                        "output": str(getattr(m, "content", ""))[:5000],
                                        "is_error": False,
                                    }

            except Exception as e:
                yield {"type": "error", "code": "agent_error", "message": str(e)}

        # F1 index: persist user + assistant messages for future retrieval
        if self.memory_index is not None:
            self.memory_index.index_message(session_id, "user", user_message)
            if full_text.strip():
                self.memory_index.index_message(session_id, "assistant", full_text)

        yield {"type": "turn_end", "turn_id": turn_id, "full_response": full_text}
        self.sessions.update_stats(session_id, turns=1)
