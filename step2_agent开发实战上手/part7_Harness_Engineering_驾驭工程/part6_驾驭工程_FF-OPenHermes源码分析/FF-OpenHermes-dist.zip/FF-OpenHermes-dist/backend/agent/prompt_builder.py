"""Build the multi-layer system prompt for a session."""
import json
from pathlib import Path

from utils.encoding import safe_read_text

MAX_LAYER_CHARS = 20_000

PROTOCOL_FOOTER = """
## Protocol

- The user's working directory is the **workspace**. `terminal`, `python_repl`,
  `read_file`, `write_file` operate inside it.
- `MEMORY.md` is your long-term notebook. Use `write_memory` for facts that
  should survive across turns.
- `SKILLS_SNAPSHOT.md` lists available skills. If one looks relevant, call
  `read_skill('<name>')` to load its full content.
- Be concise. Cite tool results, don't paraphrase them.
"""


def _read(p: Path) -> str:
    if not p.exists():
        return ""
    c = safe_read_text(p)
    if len(c) > MAX_LAYER_CHARS:
        c = c[:MAX_LAYER_CHARS] + "\n...[truncated]"
    return c


def build_system_prompt(session_dir: Path, *, global_memory: str = "", recalled: str = "") -> str:
    """Layered prompt: SOUL -> MEMORY -> global_memory -> recalled -> SKILLS_SNAPSHOT -> loaded skills -> protocol."""
    sd = Path(session_dir)
    parts: list[str] = []

    soul = _read(sd / "SOUL.md")
    if soul:
        parts.append(f"<!-- Soul -->\n{soul}")

    memory = _read(sd / "MEMORY.md")
    if memory:
        parts.append(f"<!-- Memory -->\n{memory}")

    if global_memory:
        parts.append(f"<!-- Global Memory -->\n{global_memory}")

    if recalled:
        parts.append(f"<!-- Recalled -->\n{recalled}")

    # NOTE: this snapshot is rebuilt every turn by AgentManager.astream (F3 A5)
    # so it reflects global preset skills + session skills. Do not remove that
    # per-turn rebuild — without it a fresh session shows the stale seed snapshot
    # ("No skills yet") and preset skills become invisible to the agent.
    snap = _read(sd / "skills" / "SKILLS_SNAPSHOT.md")
    if snap:
        parts.append(f"<!-- Skills Snapshot (Level 0) -->\n{snap}")

    # Loaded skills at Level 1 — inject full content
    loaded_path = sd / "loaded_skills.json"
    if loaded_path.exists():
        try:
            loaded = json.loads(safe_read_text(loaded_path))
        except json.JSONDecodeError:
            loaded = []
        for item in loaded:
            if item.get("level") != 1:
                continue
            full = _read(sd / "skills" / item["name"] / "SKILL.md")
            if full:
                parts.append(f"<!-- Loaded Skill: {item['name']} (Level 1) -->\n{full}")

    parts.append(PROTOCOL_FOOTER.strip())
    return "\n\n".join(parts)
