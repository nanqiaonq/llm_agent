"""Per-session skill usage telemetry — sidecar .usage.json.

File lives at session_dir/skills/.usage.json, keyed by skill name.
All operations are best-effort: failures log at DEBUG and never raise,
so a broken sidecar never interrupts the underlying skill operation.

Atomic RMW via tempfile + os.replace (same pattern as Hermes reference).
File-locking via fcntl (Unix) with no-lock fallback for exotic platforms.
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

try:
    import fcntl as _fcntl
except ImportError:  # pragma: no cover — non-Unix (Windows CI, etc.)
    _fcntl = None  # type: ignore[assignment]

STATE_ACTIVE = "active"
STATE_STALE = "stale"
STATE_ARCHIVED = "archived"
_VALID_STATES = {STATE_ACTIVE, STATE_STALE, STATE_ARCHIVED}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _empty_record() -> dict[str, Any]:
    return {
        "created_by": None,
        "use_count": 0,
        "view_count": 0,
        "patch_count": 0,
        "last_used_at": None,
        "last_viewed_at": None,
        "last_patched_at": None,
        "created_at": _now_iso(),
        "state": STATE_ACTIVE,
        "pinned": False,
        "archived_at": None,
    }


@contextmanager
def _file_lock(lock_path: Path):
    """Exclusive file lock around .usage.json RMW. No-op if fcntl unavailable."""
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    if _fcntl is None:
        yield
        return
    fd = open(lock_path, "a+", encoding="utf-8")
    try:
        _fcntl.flock(fd, _fcntl.LOCK_EX)
        yield
    finally:
        try:
            _fcntl.flock(fd, _fcntl.LOCK_UN)
        except (OSError, IOError):
            pass
        fd.close()


class UsageStore:
    """Per-session usage telemetry store backed by session_dir/skills/.usage.json."""

    def __init__(self, skills_dir: Path) -> None:
        self._skills_dir = Path(skills_dir)
        self._usage_file = self._skills_dir / ".usage.json"
        self._lock_path = self._skills_dir / ".usage.json.lock"

    # ── internal I/O ──────────────────────────────────────────────────────

    def _load(self) -> dict[str, dict[str, Any]]:
        if not self._usage_file.exists():
            return {}
        try:
            data = json.loads(self._usage_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            logger.debug("UsageStore._load failed: %s", e)
            return {}
        if not isinstance(data, dict):
            return {}
        return {k: v for k, v in data.items() if isinstance(v, dict)}

    def _save(self, data: dict[str, dict[str, Any]]) -> None:
        try:
            self._skills_dir.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=str(self._skills_dir), prefix=".usage_", suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, sort_keys=True, ensure_ascii=False)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp, self._usage_file)
            except BaseException:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise
        except Exception as e:
            logger.debug("UsageStore._save failed: %s", e, exc_info=True)

    def _mutate(self, name: str, mutator) -> None:
        """Load → apply mutator(record) in-place → save. Best-effort."""
        if not name:
            return
        try:
            with _file_lock(self._lock_path):
                data = self._load()
                rec = data.get(name)
                if not isinstance(rec, dict):
                    rec = _empty_record()
                mutator(rec)
                data[name] = rec
                self._save(data)
        except Exception as e:
            logger.debug("UsageStore._mutate(%s) failed: %s", name, e, exc_info=True)

    # ── public API ────────────────────────────────────────────────────────

    def mark_created(self, name: str, created_by: str) -> None:
        """Record first-creation with created_by ('agent'|'user'). Best-effort."""
        try:
            with _file_lock(self._lock_path):
                data = self._load()
                rec = data.get(name)
                if not isinstance(rec, dict):
                    rec = _empty_record()
                rec["created_by"] = created_by
                data[name] = rec
                self._save(data)
        except Exception as e:
            logger.debug("UsageStore.mark_created(%s) failed: %s", name, e, exc_info=True)

    def bump_use(self, name: str) -> None:
        def _apply(rec: dict) -> None:
            rec["use_count"] = int(rec.get("use_count") or 0) + 1
            rec["last_used_at"] = _now_iso()
        self._mutate(name, _apply)

    def bump_view(self, name: str) -> None:
        def _apply(rec: dict) -> None:
            rec["view_count"] = int(rec.get("view_count") or 0) + 1
            rec["last_viewed_at"] = _now_iso()
        self._mutate(name, _apply)

    def bump_patch(self, name: str) -> None:
        def _apply(rec: dict) -> None:
            rec["patch_count"] = int(rec.get("patch_count") or 0) + 1
            rec["last_patched_at"] = _now_iso()
        self._mutate(name, _apply)

    def get(self, name: str) -> dict[str, Any] | None:
        data = self._load()
        rec = data.get(name)
        if not isinstance(rec, dict):
            return None
        base = _empty_record()
        for k, v in base.items():
            rec.setdefault(k, v)
        return rec

    def all(self) -> dict[str, dict[str, Any]]:
        return self._load()

    def set_pinned(self, name: str, pinned: bool) -> None:
        def _apply(rec: dict) -> None:
            rec["pinned"] = bool(pinned)
        self._mutate(name, _apply)

    def set_state(self, name: str, state: str) -> None:
        if state not in _VALID_STATES:
            return

        def _apply(rec: dict) -> None:
            rec["state"] = state
            if state == STATE_ARCHIVED:
                rec["archived_at"] = _now_iso()
            elif state == STATE_ACTIVE:
                rec["archived_at"] = None
        self._mutate(name, _apply)

    def set_archived(self, name: str) -> None:
        self.set_state(name, STATE_ARCHIVED)

    def forget(self, name: str) -> None:
        """Remove usage record entirely (on skill deletion). Best-effort."""
        if not name:
            return
        try:
            with _file_lock(self._lock_path):
                data = self._load()
                if name in data:
                    del data[name]
                    self._save(data)
        except Exception as e:
            logger.debug("UsageStore.forget(%s) failed: %s", name, e, exc_info=True)

    def latest_activity_at(self, name: str) -> str | None:
        """Newest of last_used/viewed/patched_at. Excludes created_at (never-active detection)."""
        rec = self.get(name)
        if rec is None:
            return None
        latest_dt = None
        latest_raw = None
        for key in ("last_used_at", "last_viewed_at", "last_patched_at"):
            raw = rec.get(key)
            if not raw:
                continue
            try:
                dt = datetime.fromisoformat(str(raw))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            except (TypeError, ValueError):
                continue
            if latest_dt is None or dt > latest_dt:
                latest_dt = dt
                latest_raw = str(raw)
        return latest_raw

    def activity_count(self, name: str) -> int:
        """Total use + view + patch count. Excludes created_at."""
        rec = self.get(name)
        if rec is None:
            return 0
        total = 0
        for key in ("use_count", "view_count", "patch_count"):
            try:
                total += int(rec.get(key) or 0)
            except (TypeError, ValueError):
                continue
        return total
