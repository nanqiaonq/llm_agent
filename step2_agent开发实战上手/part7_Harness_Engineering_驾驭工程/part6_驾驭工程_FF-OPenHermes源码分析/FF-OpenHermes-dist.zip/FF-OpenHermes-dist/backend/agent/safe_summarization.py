"""Fail-safe wrapper around langchain's SummarizationMiddleware.

The stock SummarizationMiddleware swallows any summary-LLM exception and returns
the literal string ``"Error generating summary: ..."`` (summarization.py:611-612 /
637-638). before_model/abefore_model then wrap that string as the new summary and
emit ``RemoveMessage(REMOVE_ALL_MESSAGES)`` — i.e. a single transient LLM hiccup
would permanently REPLACE the whole conversation history with an error string.

This subclass detects that error sentinel in the freshly-built summary and, instead
of destroying history, returns ``None`` (no-op for this turn). The full history is
preserved and summarization is retried on the next turn once the LLM recovers.
"""
from typing import Any

from langchain.agents.middleware import SummarizationMiddleware

# Matches the sentinel produced by SummarizationMiddleware._create_summary /
# _acreate_summary on any exception.
_SUMMARY_ERROR_SENTINEL = "Error generating summary:"


class SafeSummarizationMiddleware(SummarizationMiddleware):
    """SummarizationMiddleware that skips (keeps full history) on summary failure."""

    def before_model(self, state: Any, runtime: Any) -> "dict[str, Any] | None":
        return self._guard(super().before_model(state, runtime))

    async def abefore_model(self, state: Any, runtime: Any) -> "dict[str, Any] | None":
        return self._guard(await super().abefore_model(state, runtime))

    @staticmethod
    def _guard(result: "dict[str, Any] | None") -> "dict[str, Any] | None":
        if result is None:
            return None
        for msg in result.get("messages", []):
            content = getattr(msg, "content", "")
            if isinstance(content, str) and _SUMMARY_ERROR_SENTINEL in content:
                # Summary LLM failed: drop the destructive RemoveMessage update and
                # keep the original history intact for this turn.
                return None
        return result
