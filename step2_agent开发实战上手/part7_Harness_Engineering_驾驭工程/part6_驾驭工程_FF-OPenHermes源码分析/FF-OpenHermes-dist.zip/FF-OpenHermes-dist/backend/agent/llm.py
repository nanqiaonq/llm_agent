"""LLM factory — OpenRouter via langchain-openai ChatOpenAI."""
from langchain_openai import ChatOpenAI

from config import settings


def build_llm(
    model: str | None = None,
    temperature: float = 0.7,
    streaming: bool = True,
    reasoning: bool = False,
):
    """Build a LangChain LLM configured for OpenRouter.

    reasoning=True  → ChatDeepSeek (extracts reasoning_content for P1 思维链)
    reasoning=False → ChatOpenAI   (default, unchanged behaviour)
    """
    if not settings.OPENROUTER_API_KEY:
        raise RuntimeError("OPENROUTER_API_KEY is not set in .env")
    if reasoning:
        from langchain_deepseek import ChatDeepSeek  # noqa: PLC0415
        return ChatDeepSeek(
            model=model or settings.OPENROUTER_MODEL,
            api_key=settings.OPENROUTER_API_KEY,
            api_base=settings.OPENROUTER_BASE_URL,
            temperature=temperature,
            streaming=streaming,
        )
    return ChatOpenAI(
        model=model or settings.OPENROUTER_MODEL,
        api_key=settings.OPENROUTER_API_KEY,
        base_url=settings.OPENROUTER_BASE_URL,
        temperature=temperature,
        streaming=streaming,
        default_headers={
            "HTTP-Referer": "http://localhost:3000",
            "X-Title": "FF-OpenHermes",
        },
    )
