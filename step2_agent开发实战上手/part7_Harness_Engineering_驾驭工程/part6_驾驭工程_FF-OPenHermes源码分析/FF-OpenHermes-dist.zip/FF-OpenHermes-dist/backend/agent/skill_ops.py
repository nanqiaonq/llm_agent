"""Skill operations — scan, read, write, load/unload."""
import json
import logging
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from utils.encoding import safe_read_text
from agent.skill_provenance import is_background
from agent.skill_usage import UsageStore

logger = logging.getLogger(__name__)

FRONTMATTER_RE = re.compile(r"^---\n(.+?)\n---\n", re.DOTALL)


def parse_frontmatter(md: str) -> dict[str, str]:
    """Naive YAML frontmatter parser — sufficient for our SKILL.md format."""
    m = FRONTMATTER_RE.match(md)
    if not m:
        return {}
    data: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            data[k.strip()] = v.strip().strip('"').strip("'")
    return data


class SkillOps:
    def __init__(self, session_dir: Path, global_dir: Path | None = None) -> None:
        self.session_dir = Path(session_dir)
        self.skills_dir = self.session_dir / "skills"
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        self.loaded_path = self.session_dir / "loaded_skills.json"
        self.global_dir = Path(global_dir) if global_dir else None
        self.usage = UsageStore(self.skills_dir)

    # ── list / read ────────────────────────────────────────

    def list_skills(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        seen: set[str] = set()

        # Session skills first (skip hidden dirs like .archive, .usage.json etc.)
        for sd in sorted(self.skills_dir.iterdir()):
            if not sd.is_dir():
                continue
            if sd.name.startswith("."):
                continue
            md = sd / "SKILL.md"
            if not md.exists():
                continue
            content = safe_read_text(md)
            fm = parse_frontmatter(content)
            seen.add(sd.name)
            entry: dict[str, Any] = {
                "name": sd.name,
                "description": fm.get("description", ""),
                "version": fm.get("version", "1.0"),
                "generated_by": fm.get("generated_by", "manual"),
                "created_at": fm.get("created_at", ""),
                "scope": "session",
                "created_by": None,  # overridden by usage merge below; keeps key always present
            }
            # Merge usage telemetry (best-effort)
            try:
                rec = self.usage.get(sd.name)
                if rec is not None:
                    entry["created_by"] = rec.get("created_by")
                    entry["state"] = rec.get("state", "active")
                    entry["pinned"] = rec.get("pinned", False)
                    entry["use_count"] = rec.get("use_count", 0)
                    entry["view_count"] = rec.get("view_count", 0)
                    entry["patch_count"] = rec.get("patch_count", 0)
                    entry["last_activity"] = self.usage.latest_activity_at(sd.name)
            except Exception as e:
                logger.debug("list_skills usage merge failed for %s: %s", sd.name, e)
            out.append(entry)

        # Global skills (session name shadows global)
        if self.global_dir and self.global_dir.is_dir():
            for sd in sorted(self.global_dir.iterdir()):
                if not sd.is_dir():
                    continue
                if sd.name in seen:
                    continue
                md = sd / "SKILL.md"
                if not md.exists():
                    continue
                content = safe_read_text(md)
                fm = parse_frontmatter(content)
                out.append({
                    "name": sd.name,
                    "description": fm.get("description", ""),
                    "version": fm.get("version", "1.0"),
                    "generated_by": fm.get("generated_by", "manual"),
                    "created_at": fm.get("created_at", ""),
                    "scope": "global",
                    "created_by": "preset",
                })

        return out

    def read_skill(self, name: str, *, record_use: bool = True) -> str:
        """Read a skill's SKILL.md (session-first, global fallback).

        record_use=True (default, the agent `read_skill` tool path) bumps use_count.
        UI views should pass record_use=False (the API bumps view_count instead) so a
        human inspecting a skill is not miscounted as the agent *using* it — keeping
        use/view telemetry distinct for the curator.
        """
        md = self.skills_dir / name / "SKILL.md"
        if md.exists():
            if record_use:
                try:
                    self.usage.bump_use(name)
                except Exception as e:
                    logger.debug("read_skill bump_use failed for %s: %s", name, e)
            return safe_read_text(md)
        if self.global_dir:
            gmd = self.global_dir / name / "SKILL.md"
            if gmd.exists():
                return safe_read_text(gmd)
        raise FileNotFoundError(f"skill {name} not found")

    def skill_scope(self, name: str) -> str | None:
        """Return 'session', 'global', or None. Session takes priority."""
        if (self.skills_dir / name / "SKILL.md").exists():
            return "session"
        if self.global_dir and (self.global_dir / name / "SKILL.md").exists():
            return "global"
        return None

    def read_history(self, name: str) -> str:
        h = self.skills_dir / name / "HISTORY.md"
        return safe_read_text(h) if h.exists() else ""

    # ── write ──────────────────────────────────────────────

    def write_skill(self, name: str, content: str, history_line: str | None = None) -> None:
        sdir = self.skills_dir / name
        # Key "new" on the actual SKILL.md, not the dir: a dir that exists without a
        # SKILL.md (crashed mid-write) should still mark_created so created_by is set.
        is_new = not (sdir / "SKILL.md").exists()
        sdir.mkdir(parents=True, exist_ok=True)
        (sdir / "SKILL.md").write_text(content, encoding="utf-8")
        if history_line:
            self._append_history(name, history_line)
        # Telemetry (best-effort)
        try:
            if is_new:
                created_by = "agent" if is_background() else "user"
                self.usage.mark_created(name, created_by)
            else:
                self.usage.bump_patch(name)
        except Exception as e:
            logger.debug("write_skill telemetry failed for %s: %s", name, e)
        self.rebuild_snapshot()

    def delete_skill(self, name: str) -> None:
        d = self.skills_dir / name
        if d.exists():
            shutil.rmtree(d)
        self.unload(name)
        try:
            self.usage.forget(name)
        except Exception as e:
            logger.debug("delete_skill usage.forget failed for %s: %s", name, e)
        self.rebuild_snapshot()

    def patch_skill(self, name: str, old_str: str, new_str: str) -> None:
        """SKILL.md 内定向 find-replace。skill 不存在 / old_str 不存在 / old_str 非唯一 → raise。"""
        md_path = self.skills_dir / name / "SKILL.md"
        if not md_path.exists():
            raise FileNotFoundError(f"skill {name} not found")
        content = safe_read_text(md_path)
        count = content.count(old_str)
        if count == 0:
            raise ValueError(f"old_str not found in {name}/SKILL.md")
        if count > 1:
            raise ValueError(f"old_str matches {count} places in {name}/SKILL.md — make it unique")
        self.write_skill(name, content.replace(old_str, new_str))  # is_new=False → bump_patch

    def write_support_file(self, name: str, rel_path: str, content: str) -> None:
        """写 references/templates/scripts/assets/ 支持文件。skill 不存在 / 非法前缀 / 路径穿越 → raise。"""
        if not (self.skills_dir / name / "SKILL.md").exists():
            raise FileNotFoundError(f"skill {name} not found")
        allowed = ("references/", "templates/", "scripts/", "assets/")
        if not rel_path.startswith(allowed):
            raise ValueError(f"rel_path must start with one of {allowed}")
        base = (self.skills_dir / name).resolve()
        target = (self.skills_dir / name / rel_path).resolve()
        if not str(target).startswith(str(base) + "/") and target != base:
            raise ValueError("path traversal rejected")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        try:
            self.usage.bump_patch(name)
        except Exception as e:
            logger.debug("write_support_file bump_patch failed for %s: %s", name, e)

    def archive_skill(self, name: str) -> None:
        """Move skills/{name}/ → skills/.archive/{name}/ (never deletes, recoverable).

        On collision, appends UTC ISO timestamp suffix. Updates usage state to archived.
        """
        src = self.skills_dir / name
        if not src.exists():
            raise FileNotFoundError(f"skill {name} not found")
        archive_dir = self.skills_dir / ".archive"
        archive_dir.mkdir(parents=True, exist_ok=True)
        dest = archive_dir / name
        if dest.exists():
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
            dest = archive_dir / f"{name}-{ts}"
        shutil.move(str(src), str(dest))
        self.unload(name)
        try:
            self.usage.set_archived(name)
        except Exception as e:
            logger.debug("archive_skill set_archived failed for %s: %s", name, e)
        self.rebuild_snapshot()

    def created_by(self, name: str) -> str | None:
        """Return created_by for a session skill ('agent'|'user'|None), or 'preset' for global."""
        scope = self.skill_scope(name)
        if scope == "global":
            return "preset"
        rec = self.usage.get(name)
        if rec is not None:
            return rec.get("created_by")
        # Frontmatter fallback (no usage record yet): only trust generated_by:agent.
        # generated_by:manual is intentionally NOT mapped to "user" — without a usage
        # record we can't confirm provenance, so stay conservative (return None) and
        # let the curator treat it as unowned rather than risk auto-curating a user skill.
        md = self.skills_dir / name / "SKILL.md"
        if md.exists():
            fm = parse_frontmatter(safe_read_text(md))
            gb = fm.get("generated_by", "")
            if gb == "agent":
                return "agent"
        return None

    def _append_history(self, name: str, line: str) -> None:
        h = self.skills_dir / name / "HISTORY.md"
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
        entry = f"\n## {ts}\n{line}\n"
        if h.exists():
            existing = safe_read_text(h)
            h.write_text(existing + entry, encoding="utf-8")
        else:
            h.write_text(f"# Evolution History · {name}\n{entry}", encoding="utf-8")

    # ── snapshot ───────────────────────────────────────────

    def rebuild_snapshot(self) -> str:
        skills = self.list_skills()
        lines = ["# Skills Snapshot\n"]
        if not skills:
            lines.append("\nNo skills yet.\n")
        else:
            lines.append("\nAvailable skills (use `read_skill('<name>')` to load full content):\n")
            for s in skills:
                lines.append(f"- **{s['name']}** (v{s['version']}) — {s['description']}")
        snap = "\n".join(lines) + "\n"
        (self.skills_dir / "SKILLS_SNAPSHOT.md").write_text(snap, encoding="utf-8")
        return snap

    # ── loaded tracker ─────────────────────────────────────

    def list_loaded(self) -> list[dict[str, Any]]:
        if not self.loaded_path.exists():
            return []
        try:
            return json.loads(safe_read_text(self.loaded_path))
        except json.JSONDecodeError:
            return []

    def is_loaded(self, name: str) -> bool:
        return any(it["name"] == name for it in self.list_loaded())

    def load(self, name: str, level: int = 1) -> None:
        loaded = self.list_loaded()
        loaded = [it for it in loaded if it["name"] != name]
        loaded.append({"name": name, "level": level})
        self.loaded_path.write_text(json.dumps(loaded, ensure_ascii=False, indent=2), encoding="utf-8")

    def unload(self, name: str) -> None:
        loaded = [it for it in self.list_loaded() if it["name"] != name]
        self.loaded_path.write_text(json.dumps(loaded, ensure_ascii=False, indent=2), encoding="utf-8")
