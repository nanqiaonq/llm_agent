"""Per-session directory manager. Each session has its own dir with meta/SOUL/MEMORY/state.db/skills."""
import json
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

from agent.models import SessionMeta, SessionStats
from utils.encoding import safe_read_text


class SessionManager:
    def __init__(self, sessions_dir: Path, templates_dir: Path) -> None:
        self.sessions_dir = Path(sessions_dir)
        self.templates_dir = Path(templates_dir)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)

    def session_dir(self, sid: str) -> Path:
        safe = "".join(c for c in sid if c.isalnum() or c in "-_")
        return self.sessions_dir / safe

    # ── CRUD ───────────────────────────────────────────────

    def create(self, title: str, workspace_path: str, model: str) -> SessionMeta:
        ws = Path(workspace_path).expanduser().resolve()
        if not ws.exists() or not ws.is_dir():
            raise ValueError(f"workspace_path does not exist or is not a directory: {workspace_path}")

        sid = f"sess_{uuid.uuid4().hex[:12]}"
        sdir = self.session_dir(sid)
        sdir.mkdir(parents=True, exist_ok=False)

        # Copy templates
        for name in ("SOUL.md", "MEMORY.md"):
            src = self.templates_dir / name
            dst = sdir / name
            dst.write_text(safe_read_text(src) if src.exists() else f"# {name}", encoding="utf-8")

        # Skills directory + empty snapshot
        (sdir / "skills").mkdir()
        (sdir / "skills" / "SKILLS_SNAPSHOT.md").write_text("# Skills Snapshot\n\nNo skills yet.\n", encoding="utf-8")

        # Loaded skills tracker
        (sdir / "loaded_skills.json").write_text("[]", encoding="utf-8")

        meta = SessionMeta(
            id=sid,
            title=title,
            workspace_path=str(ws),
            model=model,
            stats=SessionStats(),
        )
        self._write_meta(meta)
        return meta

    def get(self, sid: str) -> SessionMeta:
        path = self.session_dir(sid) / "meta.json"
        if not path.exists():
            raise FileNotFoundError(f"Session {sid} not found")
        return SessionMeta.model_validate_json(safe_read_text(path))

    def list(self) -> list[SessionMeta]:
        out: list[SessionMeta] = []
        for sdir in sorted(self.sessions_dir.iterdir()):
            if not sdir.is_dir() or sdir.name.startswith("."):
                continue
            mp = sdir / "meta.json"
            if not mp.exists():
                continue
            try:
                out.append(SessionMeta.model_validate_json(safe_read_text(mp)))
            except Exception:
                continue
        out.sort(key=lambda m: m.updated_at, reverse=True)
        return out

    def rename(self, sid: str, title: str) -> SessionMeta:
        meta = self.get(sid)
        meta.title = title
        meta.updated_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        self._write_meta(meta)
        return meta

    def delete(self, sid: str) -> None:
        sdir = self.session_dir(sid)
        if sdir.exists():
            shutil.rmtree(sdir)

    def touch(self, sid: str) -> None:
        meta = self.get(sid)
        meta.updated_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        self._write_meta(meta)

    def update_stats(self, sid: str, **delta: int) -> None:
        meta = self.get(sid)
        for k, v in delta.items():
            cur = getattr(meta.stats, k, 0)
            setattr(meta.stats, k, cur + v)
        meta.updated_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        self._write_meta(meta)

    # ── helpers ────────────────────────────────────────────

    def _write_meta(self, meta: SessionMeta) -> None:
        path = self.session_dir(meta.id) / "meta.json"
        path.write_text(meta.model_dump_json(indent=2), encoding="utf-8")
