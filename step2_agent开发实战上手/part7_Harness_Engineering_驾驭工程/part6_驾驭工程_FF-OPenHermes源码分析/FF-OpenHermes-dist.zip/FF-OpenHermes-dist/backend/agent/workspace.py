"""Workspace file operations bound to a session's workspace_path."""
from pathlib import Path
from typing import Any

from utils.encoding import safe_read_text
from utils.paths import resolve_in

EXCLUDE_DIRS = {
    "node_modules", ".git", ".next", "dist", "build", ".cache",
    ".vscode", "__pycache__", ".DS_Store", "coverage", ".venv", "venv",
    ".pytest_cache",
}

LANG_MAP = {
    ".ts": "typescript", ".tsx": "tsx", ".js": "javascript", ".jsx": "jsx",
    ".py": "python", ".rs": "rust", ".go": "go", ".java": "java",
    ".c": "c", ".cpp": "cpp", ".h": "c", ".css": "css", ".scss": "scss",
    ".html": "html", ".json": "json", ".yaml": "yaml", ".yml": "yaml",
    ".md": "markdown", ".sh": "bash", ".sql": "sql", ".xml": "xml",
    ".toml": "toml",
}


class WorkspaceOps:
    def __init__(self, root: Path | str) -> None:
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise ValueError(f"workspace root does not exist or is not a dir: {root}")

    # ── tree ───────────────────────────────────────────────

    def tree(self, rel_path: str = ".", max_depth: int = 3) -> dict[str, Any]:
        target = resolve_in(self.root, rel_path)
        return self._node(target, max_depth)

    def _node(self, p: Path, depth: int) -> dict[str, Any]:
        rel = str(p.relative_to(self.root)).replace("\\", "/")
        if not p.is_dir():
            # 普通文件 / 特殊文件(socket、fifo、坏软链)统一作为叶子节点，
            # 避免对非目录调用 iterdir() 触发 NotADirectoryError
            try:
                size = p.stat().st_size
            except OSError:
                size = 0
            return {
                "name": p.name,
                "path": rel if rel != "." else "",
                "type": "file",
                "size": size,
            }
        children = []
        if depth > 0:
            try:
                entries = list(p.iterdir())
            except PermissionError:
                entries = []
            for e in entries:
                if e.name in EXCLUDE_DIRS:
                    continue
                if e.name.startswith(".") and e.name not in (".env",):
                    continue
                children.append(self._node(e, depth - 1))
            children.sort(key=lambda n: (n["type"] != "directory", n["name"].lower()))
        return {
            "name": p.name if rel != "." else self.root.name,
            "path": rel if rel != "." else "",
            "type": "directory",
            "children": children,
        }

    # ── file ops ───────────────────────────────────────────

    def read_file(self, rel: str) -> dict[str, Any]:
        target = resolve_in(self.root, rel)
        if not target.is_file():
            raise FileNotFoundError(f"not a file: {rel}")
        content = safe_read_text(target)
        ext = target.suffix.lower()
        return {
            "content": content,
            "language": LANG_MAP.get(ext, "plaintext"),
            "lines": content.count("\n") + 1,
            "size": target.stat().st_size,
        }

    def write_file(self, rel: str, content: str) -> None:
        target = resolve_in(self.root, rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    def mkdir(self, rel: str) -> None:
        target = resolve_in(self.root, rel)
        target.mkdir(parents=True, exist_ok=True)

    def rename(self, rel_from: str, rel_to: str) -> None:
        src = resolve_in(self.root, rel_from)
        dst = resolve_in(self.root, rel_to)
        src.rename(dst)

    def delete(self, rel: str) -> None:
        target = resolve_in(self.root, rel)
        if target.is_dir():
            import shutil
            shutil.rmtree(target)
        elif target.exists():
            target.unlink()
