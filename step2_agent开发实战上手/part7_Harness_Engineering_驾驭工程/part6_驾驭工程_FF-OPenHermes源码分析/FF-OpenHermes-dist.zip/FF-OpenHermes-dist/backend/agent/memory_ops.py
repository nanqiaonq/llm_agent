"""SOUL.md / MEMORY.md operations for a session."""
from pathlib import Path

from utils.encoding import safe_read_text


def approx_tokens(s: str) -> int:
    """Cheap token estimate: 1 token ≈ 4 chars for English, 1.5 chars for CJK."""
    if not s:
        return 0
    cjk = sum(1 for c in s if "一" <= c <= "鿿")
    other = len(s) - cjk
    return int(cjk / 1.5 + other / 4)


class MemoryOps:
    def __init__(self, session_dir: Path) -> None:
        self.session_dir = Path(session_dir)
        self.soul = self.session_dir / "SOUL.md"
        self.memory = self.session_dir / "MEMORY.md"

    def read_soul(self) -> str:
        return safe_read_text(self.soul) if self.soul.exists() else ""

    def write_soul(self, content: str) -> None:
        self._backup_then_write(self.soul, content)

    def read_memory(self) -> str:
        return safe_read_text(self.memory) if self.memory.exists() else ""

    def write_memory(self, content: str) -> None:
        self._backup_then_write(self.memory, content)

    def stats(self) -> dict[str, int]:
        return {
            "soul_tokens": approx_tokens(self.read_soul()),
            "memory_tokens": approx_tokens(self.read_memory()),
        }

    def _backup_then_write(self, p: Path, content: str) -> None:
        if p.exists():
            (p.parent / f"{p.name}.bak").write_text(safe_read_text(p), encoding="utf-8")
        p.write_text(content, encoding="utf-8")
