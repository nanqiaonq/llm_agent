"""GlobalMemory — persistent cross-session MEMORY.md with .bak on overwrite.

Mirrors the .bak pattern from memory_ops.MemoryOps._backup_then_write.
"""
from pathlib import Path

from utils.encoding import safe_read_text


class GlobalMemory:
    """Manages a single global MEMORY.md under storage_dir."""

    def __init__(self, storage_dir: "str | Path") -> None:
        self._dir = Path(storage_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path = self._dir / "MEMORY.md"

    def read(self) -> str:
        if self._path.exists():
            return safe_read_text(self._path)
        return ""

    def write(self, content: str) -> None:
        if self._path.exists():
            bak = self._dir / "MEMORY.md.bak"
            bak.write_text(safe_read_text(self._path), encoding="utf-8")
        self._path.write_text(content, encoding="utf-8")
