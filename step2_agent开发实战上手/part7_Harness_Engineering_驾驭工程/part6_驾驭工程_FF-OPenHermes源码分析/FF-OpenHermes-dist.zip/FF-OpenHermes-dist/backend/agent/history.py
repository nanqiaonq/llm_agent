"""Extract conversation turns from a session's state.db checkpoint store."""
from pathlib import Path
from typing import Any

from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver


async def extract_turns(db_path: Path) -> list[dict[str, Any]]:
    """Walk all checkpoints and pair user → assistant messages into turns.

    A single user prompt may produce multiple AIMessages (e.g. one with
    tool_calls + reasoning content, then more after tool execution, then
    a final answer). We accumulate all AI content + tool_calls under the
    last HumanMessage and only flush a turn when the next HumanMessage
    arrives (or at the end).
    """
    if not db_path.exists():
        return []
    turns: list[dict[str, Any]] = []
    async with AsyncSqliteSaver.from_conn_string(str(db_path)) as cp:
        latest_messages: list[Any] = []
        async for tup in cp.alist(None):
            ckpt = tup.checkpoint
            if ckpt and "channel_values" in ckpt:
                msgs = ckpt["channel_values"].get("messages", []) or []
                # Latest checkpoint usually has the longest message list — keep it
                if len(msgs) > len(latest_messages):
                    latest_messages = msgs

    cur_user: str | None = None
    cur_assistant: str = ""
    cur_tools: list[dict[str, Any]] = []

    def flush() -> None:
        nonlocal cur_user, cur_assistant, cur_tools
        if cur_user is not None:
            turns.append({
                "user": cur_user,
                "assistant": cur_assistant,
                "tool_calls": cur_tools,
            })
        cur_user = None
        cur_assistant = ""
        cur_tools = []

    for m in latest_messages:
        role = getattr(m, "type", None)
        content = getattr(m, "content", "") or ""
        if role == "human":
            flush()
            cur_user = content
        elif role == "ai":
            tcs = getattr(m, "tool_calls", []) or []
            for tc in tcs:
                cur_tools.append({"name": tc.get("name", ""), "args": tc.get("args", {})})
            if content:
                # Accumulate AI content across multiple AIMessages within one user turn
                cur_assistant = (cur_assistant + "\n\n" + content) if cur_assistant else content
        # tool messages are skipped — their outputs are not surfaced in turn replay
        # (live tool_end events deliver outputs in real time; replay only shows name+args)

    flush()
    return turns
