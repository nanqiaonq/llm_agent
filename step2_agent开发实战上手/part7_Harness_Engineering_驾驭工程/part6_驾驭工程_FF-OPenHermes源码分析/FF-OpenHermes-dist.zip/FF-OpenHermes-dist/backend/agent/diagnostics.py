"""HQS Session diagnostics — LLM-driven failure-mode analysis (case-09 port).

Inspired by `FF-ProjectBuilder/cases/case-09-harness-diagnostics`. Translates the
Vercel AI SDK + Zod streamObject implementation into Python: Pydantic +
LangChain `with_structured_output(method="function_calling")`.

Failure modes use the Microsoft 5-class taxonomy (PRD §3.4 risks).
"""
import logging
import traceback
from datetime import datetime, timezone
from typing import Any, Callable, Literal

from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field

logger = logging.getLogger("agent.diagnostics")

DIAGNOSE_SYSTEM_PROMPT = """You are an expert agent-harness auditor.

Given a session's turn-by-turn trace (user inputs, assistant outputs, tool calls),
produce an HQS Diagnostic:

- `score` (0-10): Overall harness quality. 0-3 = serious failures, 4-6 = mediocre,
  7-10 = solid. Be honest — most early-stage runs land in the 5-7 range.
- `failure_modes` (0-5 items): pick zero or more from this exact list:
    * goal_loss      — agent lost track of the user's actual ask
    * boundary_break — agent exceeded its scope/permissions
    * context_loss   — agent forgot earlier turn content
    * capability_gap — agent lacked the right tool for the task
    * hybrid         — multiple failure modes intertwined
- `analysis` (1-3 sentences): explain the score using the trace.
- `fix_suggestions` (0-5 items): concrete, actionable improvements (each ≤ 200 chars).
"""


FailureMode = Literal["goal_loss", "boundary_break", "context_loss", "capability_gap", "hybrid"]


class HQSDiagnostic(BaseModel):
    score: int = Field(..., ge=0, le=10)
    failure_modes: list[FailureMode] = Field(default_factory=list, max_length=5)
    analysis: str = Field(..., min_length=10, max_length=2000)
    fix_suggestions: list[str] = Field(default_factory=list, max_length=5)
    diagnosed_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="microseconds"))


def _format_turns_for_diag(turns: list[dict[str, Any]]) -> str:
    lines: list[str] = []
    for i, t in enumerate(turns, 1):
        lines.append(f"--- Turn {i} ---")
        u = (t.get("user") or "").strip()[:300]
        a = (t.get("assistant") or "").strip()[:500]
        lines.append(f"USER: {u}")
        for tc in t.get("tool_calls") or []:
            lines.append(f"  TOOL_CALL: {tc.get('name', '')}({tc.get('args', {})})")
        lines.append(f"ASSISTANT: {a}")
    return "\n".join(lines)


async def diagnose_session(
    turns: list[dict[str, Any]],
    llm_factory: Callable[[], BaseChatModel],
) -> HQSDiagnostic | None:
    """Run the structured LLM call. Returns HQSDiagnostic or None on failure."""
    try:
        llm = llm_factory()
        structured = llm.with_structured_output(HQSDiagnostic, method="function_calling")
        prompt = (
            DIAGNOSE_SYSTEM_PROMPT
            + "\n\n--- SESSION TRACE ---\n"
            + _format_turns_for_diag(turns)
            + "\n--- END ---\n\nProduce the HQSDiagnostic JSON now."
        )
        result = await structured.ainvoke(prompt)
        if not isinstance(result, HQSDiagnostic):
            result = HQSDiagnostic.model_validate(result)
        # The LLM happily makes up a `diagnosed_at` value — overwrite with the real
        # server-side timestamp so the UI shows when WE diagnosed, not whatever the
        # model invented.
        result.diagnosed_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        return result
    except Exception as e:
        logger.error("diagnose_session failed: %s\n%s", e, traceback.format_exc())
        return None
