"""Skill write-origin provenance — ContextVar distinguishing background agent writes from foreground user writes.

Usage:
    token = set_write_origin(BACKGROUND)
    try:
        ...  # skill write happens here
    finally:
        reset_write_origin(token)

    # inside a write handler:
    created_by = "agent" if is_background() else "user"
"""
import contextvars

_write_origin: contextvars.ContextVar[str] = contextvars.ContextVar(
    "skill_write_origin",
    default="foreground",
)

BACKGROUND = "background"   # 后台自沉淀（M2 generator / 未来 background_review）
FOREGROUND = "foreground"   # 前台用户指令


def set_write_origin(origin: str) -> contextvars.Token:
    """Bind write origin to current async context. Returns token for reset."""
    return _write_origin.set(origin or FOREGROUND)


def reset_write_origin(token: contextvars.Token) -> None:
    """Restore prior write origin via token returned by set_write_origin."""
    _write_origin.reset(token)


def get_write_origin() -> str:
    """Return active write origin (default: 'foreground')."""
    return _write_origin.get()


def is_background() -> bool:
    """True iff current write origin is BACKGROUND."""
    return _write_origin.get() == BACKGROUND
