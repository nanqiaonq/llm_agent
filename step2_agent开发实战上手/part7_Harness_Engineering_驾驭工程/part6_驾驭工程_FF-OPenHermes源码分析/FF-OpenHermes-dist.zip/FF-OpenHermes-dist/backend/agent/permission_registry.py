"""In-memory registry of pending permission requests.

Tools register a Future, publish a permission_request event, then await the future
(with a timeout). The REST endpoint POST /api/permission/{request_id} resolves the
future. On 60s timeout the future auto-resolves to "deny".
"""
import asyncio
import logging
from typing import Literal

logger = logging.getLogger("agent.permission_registry")

Decision = Literal["allow_once", "allow_always", "deny"]
DEFAULT_TIMEOUT_S = 60.0


class PermissionRegistry:
    """Per-process registry mapping request_id → asyncio.Future[Decision]."""

    def __init__(self) -> None:
        self._pending: dict[str, asyncio.Future[Decision]] = {}

    def register(self, request_id: str) -> asyncio.Future[Decision]:
        """Register a new pending request. Returns the future to await."""
        fut: asyncio.Future[Decision] = asyncio.get_event_loop().create_future()
        self._pending[request_id] = fut
        return fut

    def resolve(self, request_id: str, decision: Decision) -> None:
        """Resolve the future for `request_id`. No-op if id unknown or already resolved."""
        fut = self._pending.get(request_id)
        if fut is None:
            logger.debug("resolve: unknown request_id %s", request_id)
            return
        if fut.done():
            logger.debug("resolve: %s already resolved", request_id)
            return
        fut.set_result(decision)

    def unregister(self, request_id: str) -> None:
        """Remove a request_id from the registry. Cleanup after the tool consumed the future."""
        self._pending.pop(request_id, None)

    def pending_count(self) -> int:
        return len(self._pending)

    async def wait_with_timeout(
        self,
        future: asyncio.Future[Decision],
        timeout_s: float = DEFAULT_TIMEOUT_S,
    ) -> Decision:
        """Wait for the future with a timeout. On timeout, returns 'deny'."""
        try:
            return await asyncio.wait_for(future, timeout=timeout_s)
        except asyncio.TimeoutError:
            return "deny"
