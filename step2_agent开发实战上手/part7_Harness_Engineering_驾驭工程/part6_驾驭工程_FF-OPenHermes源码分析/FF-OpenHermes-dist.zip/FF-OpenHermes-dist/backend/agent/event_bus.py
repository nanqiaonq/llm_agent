"""In-memory pub/sub bus for late-arriving session events (skill generation, etc).

This decouples background tasks (e.g. SkillEngineMiddleware running after turn_end)
from frontend subscribers (SSE on /api/events/{sid}/stream). Lives on app.state.
"""
import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

logger = logging.getLogger("agent.event_bus")

QUEUE_MAX = 64  # per-subscriber buffer; drop on overflow


class EventBus:
    def __init__(self) -> None:
        self._subscribers: dict[str, set[asyncio.Queue]] = {}

    def publish(self, session_id: str, event: dict) -> None:
        """Fan out event to all subscribers of session_id. Non-blocking; drops on full queue."""
        subs = self._subscribers.get(session_id)
        if not subs:
            return
        for q in subs:
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("event_bus dropped event for %s (subscriber queue full)", session_id)

    @asynccontextmanager
    async def subscribe(self, session_id: str) -> AsyncIterator[asyncio.Queue]:
        """Async context manager. Yields a Queue; events arrive via q.get(). Auto-unsubscribes on exit."""
        q: asyncio.Queue = asyncio.Queue(maxsize=QUEUE_MAX)
        self._subscribers.setdefault(session_id, set()).add(q)
        try:
            yield q
        finally:
            self._subscribers[session_id].discard(q)
            if not self._subscribers[session_id]:
                self._subscribers.pop(session_id, None)
