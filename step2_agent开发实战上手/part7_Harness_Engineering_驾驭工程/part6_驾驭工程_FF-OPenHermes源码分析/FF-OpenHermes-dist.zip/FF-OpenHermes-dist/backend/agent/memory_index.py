"""MemoryIndex — FTS5 dual-table full-text search across sessions.

Two tables:
- messages_fts (unicode61): English BM25 relevance search.
- messages_fts_trigram: CJK substring search via trigram tokenizer.

Migrated from HermesAgent hermes_state.py:320-373 (SQL) and 2619-2918
(search logic), simplified for FF schema (content-only, no sessions JOIN,
no source/role/active filters).
"""
import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Optional


_CREATE_SQL = """
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    ts REAL NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(content);

CREATE TRIGGER IF NOT EXISTS messages_fts_insert AFTER INSERT ON messages BEGIN
    INSERT INTO messages_fts(rowid, content) VALUES (new.id, COALESCE(new.content, ''));
END;

CREATE TRIGGER IF NOT EXISTS messages_fts_delete AFTER DELETE ON messages BEGIN
    DELETE FROM messages_fts WHERE rowid = old.id;
END;

CREATE TRIGGER IF NOT EXISTS messages_fts_update AFTER UPDATE ON messages BEGIN
    DELETE FROM messages_fts WHERE rowid = old.id;
    INSERT INTO messages_fts(rowid, content) VALUES (new.id, COALESCE(new.content, ''));
END;

CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts_trigram USING fts5(content, tokenize='trigram');

CREATE TRIGGER IF NOT EXISTS messages_fts_trigram_insert AFTER INSERT ON messages BEGIN
    INSERT INTO messages_fts_trigram(rowid, content) VALUES (new.id, COALESCE(new.content, ''));
END;

CREATE TRIGGER IF NOT EXISTS messages_fts_trigram_delete AFTER DELETE ON messages BEGIN
    DELETE FROM messages_fts_trigram WHERE rowid = old.id;
END;

CREATE TRIGGER IF NOT EXISTS messages_fts_trigram_update AFTER UPDATE ON messages BEGIN
    DELETE FROM messages_fts_trigram WHERE rowid = old.id;
    INSERT INTO messages_fts_trigram(rowid, content) VALUES (new.id, COALESCE(new.content, ''));
END;
"""


class MemoryIndex:
    """Global cross-session FTS5 memory index.

    NOTE (teaching simplification): a single sqlite3 connection guarded by a
    threading.Lock is used for both reads and writes. Calls run synchronously
    inside the async event loop, so heavy concurrency would serialize/block.
    A production setup would use aiosqlite or a thread pool; kept simple here
    on purpose since session memory writes are low-frequency (≤2 per turn).
    """

    def __init__(self, db_path: "str | Path") -> None:
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db_path = db_path
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_CREATE_SQL)
        self._conn.commit()

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def index_message(self, session_id: str, role: str, content: str) -> None:
        """Insert a message row; triggers auto-sync FTS tables."""
        if not content or not content.strip():
            return
        with self._lock:
            self._conn.execute(
                "INSERT INTO messages(session_id, role, content, ts) VALUES (?,?,?,?)",
                (session_id, role, content, time.time()),
            )
            self._conn.commit()

    # ------------------------------------------------------------------
    # Search helpers (migrated from hermes_state.py:2619-2700)
    # ------------------------------------------------------------------

    @staticmethod
    def _sanitize_fts5_query(query: str) -> str:
        """Sanitize user input for safe use in FTS5 MATCH queries.

        Migrated verbatim from HermesAgent hermes_state.py:2619-2669.
        """
        _quoted_parts: list = []

        def _preserve_quoted(m: re.Match) -> str:
            _quoted_parts.append(m.group(0))
            return f"\x00Q{len(_quoted_parts) - 1}\x00"

        sanitized = re.sub(r'"[^"]*"', _preserve_quoted, query)
        sanitized = re.sub(r'[+{}()\"^]', " ", sanitized)
        sanitized = re.sub(r"\*+", "*", sanitized)
        sanitized = re.sub(r"(^|\s)\*", r"\1", sanitized)
        sanitized = re.sub(r"(?i)^(AND|OR|NOT)\b\s*", "", sanitized.strip())
        sanitized = re.sub(r"(?i)\s+(AND|OR|NOT)\s*$", "", sanitized.strip())
        sanitized = re.sub(r"\b(\w+(?:[._-]\w+)+)\b", r'"\1"', sanitized)
        for i, quoted in enumerate(_quoted_parts):
            sanitized = sanitized.replace(f"\x00Q{i}\x00", quoted)
        return sanitized.strip()

    @staticmethod
    def _is_cjk_codepoint(cp: int) -> bool:
        return (0x4E00 <= cp <= 0x9FFF or    # CJK Unified Ideographs
                0x3400 <= cp <= 0x4DBF or    # CJK Extension A
                0x20000 <= cp <= 0x2A6DF or  # CJK Extension B
                0x3000 <= cp <= 0x303F or    # CJK Symbols
                0x3040 <= cp <= 0x309F or    # Hiragana
                0x30A0 <= cp <= 0x30FF or    # Katakana
                0xAC00 <= cp <= 0xD7AF)      # Hangul Syllables

    @staticmethod
    def _contains_cjk(text: str) -> bool:
        for ch in text:
            cp = ord(ch)
            if (0x4E00 <= cp <= 0x9FFF or
                0x3400 <= cp <= 0x4DBF or
                0x20000 <= cp <= 0x2A6DF or
                0x3000 <= cp <= 0x303F or
                0x3040 <= cp <= 0x309F or
                0x30A0 <= cp <= 0x30FF or
                0xAC00 <= cp <= 0xD7AF):
                return True
        return False

    @classmethod
    def _count_cjk(cls, text: str) -> int:
        return sum(1 for ch in text if cls._is_cjk_codepoint(ord(ch)))

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        top_k: int = 5,
        exclude_session: Optional[str] = None,
    ) -> list[dict]:
        """Search messages. Routes to trigram (CJK), LIKE (short CJK), or BM25 (English).

        Returns list of {session_id, role, content, snippet, rank}.
        """
        if not query or not query.strip():
            return []

        sanitized = self._sanitize_fts5_query(query)
        if not sanitized:
            return []

        is_cjk = self._contains_cjk(query)

        if is_cjk:
            raw_query = sanitized.strip('"').strip()
            cjk_count = self._count_cjk(raw_query)
            _tokens_for_check = [
                t for t in raw_query.split()
                if t.upper() not in {"AND", "OR", "NOT"} and self._contains_cjk(t)
            ]
            _any_short_cjk = any(
                self._count_cjk(t) < 3 for t in _tokens_for_check
            )

            if cjk_count >= 3 and not _any_short_cjk:
                # Trigram FTS5 path
                tokens = raw_query.split()
                parts = []
                for tok in tokens:
                    if tok.upper() in {"AND", "OR", "NOT"}:
                        parts.append(tok)
                    else:
                        parts.append('"' + tok.replace('"', '""') + '"')
                trigram_query = " ".join(parts)

                where_clauses = ["messages_fts_trigram MATCH ?"]
                params: list = [trigram_query]
                if exclude_session:
                    where_clauses.append("m.session_id != ?")
                    params.append(exclude_session)
                params.append(top_k)

                sql = f"""
                    SELECT m.session_id, m.role, m.content,
                           snippet(messages_fts_trigram, 0, '>>>', '<<<', '...', 40) AS snippet,
                           rank
                    FROM messages_fts_trigram
                    JOIN messages m ON m.id = messages_fts_trigram.rowid
                    WHERE {' AND '.join(where_clauses)}
                    ORDER BY rank
                    LIMIT ?
                """
                with self._lock:
                    try:
                        cursor = self._conn.execute(sql, params)
                        return [dict(row) for row in cursor.fetchall()]
                    except sqlite3.OperationalError:
                        return []
            else:
                # Short CJK: LIKE fallback
                non_op_tokens = [
                    t for t in raw_query.split()
                    if t.upper() not in {"AND", "OR", "NOT"}
                ] or [raw_query]
                token_clauses = []
                like_params: list = []
                for tok in non_op_tokens:
                    esc = tok.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
                    token_clauses.append("m.content LIKE ? ESCAPE '\\'")
                    like_params.append(f"%{esc}%")
                where_clauses = [f"({' OR '.join(token_clauses)})"]
                if exclude_session:
                    where_clauses.append("m.session_id != ?")
                    like_params.append(exclude_session)

                # Snippet centred on the first token's match (instr) instead of a
                # fixed 200-char prefix, so the LLM sees the matched region when the
                # hit lies deep in a long message. Mirrors HermesAgent's instr-based
                # LIKE snippet. The instr param is the SELECT's first '?', so it must
                # lead the param list, ahead of WHERE params and top_k.
                snippet_token = non_op_tokens[0]
                sql = f"""
                    SELECT m.session_id, m.role, m.content,
                           substr(m.content, MAX(1, instr(m.content, ?) - 40), 120) AS snippet,
                           0 AS rank
                    FROM messages m
                    WHERE {' AND '.join(where_clauses)}
                    ORDER BY m.ts DESC
                    LIMIT ?
                """
                with self._lock:
                    cursor = self._conn.execute(sql, [snippet_token, *like_params, top_k])
                    return [dict(row) for row in cursor.fetchall()]
        else:
            # English BM25 path
            where_clauses = ["messages_fts MATCH ?"]
            params = [sanitized]
            if exclude_session:
                where_clauses.append("m.session_id != ?")
                params.append(exclude_session)
            params.append(top_k)

            sql = f"""
                SELECT m.session_id, m.role, m.content,
                       snippet(messages_fts, 0, '>>>', '<<<', '...', 40) AS snippet,
                       rank
                FROM messages_fts
                JOIN messages m ON m.id = messages_fts.rowid
                WHERE {' AND '.join(where_clauses)}
                ORDER BY rank
                LIMIT ?
            """
            with self._lock:
                try:
                    cursor = self._conn.execute(sql, params)
                    return [dict(row) for row in cursor.fetchall()]
                except sqlite3.OperationalError:
                    return []
