"""LLM-powered MEMORY.md compactor.

Takes the current MEMORY.md text and rewrites it into a structured, deduplicated
form. Returns the new Markdown string on success, None on LLM failure.
"""
import logging
import traceback
from typing import Callable

from langchain_core.language_models import BaseChatModel
from langchain_core.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field

logger = logging.getLogger("agent.memory_optimizer")

OPTIMIZE_SYSTEM_PROMPT = """You are tidying up an agent's long-term memory file (MEMORY.md).

The current contents may have:
- Duplicate or near-duplicate entries
- Outdated information that contradicts later entries
- Disorganized order — facts about preferences mixed with facts about workflow

Reorganize into structured sections (e.g. "Preferences", "Workflow", "Facts about User",
"Project Conventions") with concise bulleted entries. Drop duplicates. Keep the user's
voice / wording style; do NOT inject opinions or speculation.

Output JSON matching OptimizedMemory:
- `summary`: 1-2 sentence top-line description of who the user is / what they care about
- `sections`: list of { title, bullets } — at least 1 section, each with at least 1 bullet
"""


class OptimizedSection(BaseModel):
    title: str = Field(..., min_length=1, max_length=80)
    bullets: list[str] = Field(..., min_length=1, max_length=20)


class OptimizedMemory(BaseModel):
    summary: str = Field(..., min_length=1, max_length=400)
    sections: list[OptimizedSection] = Field(..., min_length=1, max_length=10)


def _format_optimized_as_markdown(opt: OptimizedMemory) -> str:
    lines: list[str] = ["# Long-term Memory", "", f"_{opt.summary}_", ""]
    for sec in opt.sections:
        lines.append(f"## {sec.title}")
        lines.append("")
        for b in sec.bullets:
            lines.append(f"- {b}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


async def optimize_memory_text(
    current: str,
    llm_factory: Callable[[], BaseChatModel],
) -> str | None:
    """Run a structured LLM call to rewrite MEMORY.md text. Returns new Markdown or None."""
    try:
        llm = llm_factory()
        # 结构化输出调优（仅对真实 ChatOpenAI 生效，不影响测试 fake）：
        #  1) streaming=False + max_tokens=4096 —— 避免 "Provider returned error" 及余额不足(402)
        #     被降级到便宜 provider；
        #  2) method="json_mode" —— 被降级时 function_calling 偶发失败，json_object 更稳，
        #     需用 PydanticOutputParser 注入 schema。
        if getattr(llm, "streaming", None) is True:
            llm.streaming = False
            llm.max_tokens = 4096
        structured = llm.with_structured_output(OptimizedMemory, method="json_mode")
        prompt = (
            OPTIMIZE_SYSTEM_PROMPT
            + "\n\n--- CURRENT MEMORY.md ---\n"
            + current
            + "\n--- END ---\n\nProduce the OptimizedMemory JSON now."
            + "\n\n" + PydanticOutputParser(pydantic_object=OptimizedMemory).get_format_instructions()
        )
        result = await structured.ainvoke(prompt)
        if not isinstance(result, OptimizedMemory):
            result = OptimizedMemory.model_validate(result)
        return _format_optimized_as_markdown(result)
    except Exception as e:
        logger.error("optimize_memory_text failed: %s\n%s", e, traceback.format_exc())
        return None
