"""SkillEngineMiddleware — hooks `after_agent` and forks a combined review sub-agent.

API DRIFT NOTE (LangChain 1.2.x / LangGraph 1.x):
    - `AgentMiddleware.after_agent(state, runtime)` is the SYNC hook.
      `aafter_agent(state, runtime)` is the async variant — when overridden,
      LangGraph wraps both via `RunnableCallable` and dispatches the async
      one inside an async run. We override `aafter_agent` so the agent's
      ainvoke/astream path picks it up.
    - `state` shape in 1.x is `{"messages": [...], ...}` — there is NO
      `configurable` key here (that lives on the RunnableConfig, not state).
      To reach `thread_id` from inside a middleware hook, use
      `langgraph.config.get_config()` (context-aware helper).
    - The runtime parameter exposes `runtime.context`, `runtime.store`,
      `runtime.stream_writer`, etc. — but NOT `thread_id`.

This middleware schedules the heavy generation work via `asyncio.create_task`
so the agent's turn_end stream is not blocked by the sub-agent LLM call.
The public `run_for_session(session_id, messages)` is what tests call directly
AND what the create_task target invokes.
"""
import asyncio
import contextvars
import logging
from typing import Any, Callable

from langchain.agents.middleware import AgentMiddleware
from langchain_core.language_models import BaseChatModel
from agent.event_bus import EventBus
from agent.session_manager import SessionManager
from skill_engine.background_review import spawn_review_subagent

logger = logging.getLogger("agent.middleware")


def _resolve_session_id(state: Any) -> str | None:
    """Best-effort extraction of the thread_id (== session_id) from state and runtime config.

    Try several shapes because LangChain 1.x/LangGraph layers expose this differently:
    1. `state["configurable"]["thread_id"]` — original plan assumption (rare in 1.x).
    2. `langgraph.config.get_config()["configurable"]["thread_id"]` — context-aware helper.
    """
    # Shape 1: state-as-dict with configurable key (uncommon in 1.x)
    if isinstance(state, dict):
        cfg = state.get("configurable")
        if isinstance(cfg, dict):
            tid = cfg.get("thread_id")
            if tid:
                return tid
    # Shape 2: in-context RunnableConfig
    try:
        from langgraph.config import get_config
        cfg = get_config() or {}
        configurable = cfg.get("configurable") if isinstance(cfg, dict) else None
        if isinstance(configurable, dict):
            tid = configurable.get("thread_id")
            if tid:
                return tid
    except Exception:
        pass
    return None


class SkillEngineMiddleware(AgentMiddleware):
    """LangChain 1.x middleware: after each agent turn, nudge → fork combined sub-agent.

    Trigger condition:
        - turns > 0 and turns % reflection_interval == 0 (nudge)
        → spawn_review_subagent: sub-agent autonomously saves memory + skill (agentic)

    Failures are logged and NEVER propagate — running this is best-effort.
    """

    def __init__(
        self,
        session_manager: SessionManager,
        event_bus: EventBus,
        llm_factory: Callable[[], BaseChatModel],
        memory_reflection_interval: int = 5,
    ) -> None:
        super().__init__()
        self._sm = session_manager
        self._bus = event_bus
        self._llm_factory = llm_factory
        self._reflection_interval = memory_reflection_interval

    async def aafter_agent(self, state: Any, runtime: Any) -> dict[str, Any] | None:  # type: ignore[override]
        """Async hook — preferred when agent runs via ainvoke/astream."""
        try:
            self._dispatch(state)
        except Exception as e:
            logger.warning("aafter_agent dispatch failed: %s", e)
        return None

    def after_agent(self, state: Any, runtime: Any) -> dict[str, Any] | None:  # type: ignore[override]
        """Sync fallback. Fire-and-forget on a daemon thread to avoid blocking the caller.

        Why a thread instead of `asyncio.run`: if the caller is on a sync stack with no
        running loop, `asyncio.run(coro)` BLOCKS until the coroutine finishes — which for
        us means waiting on the sub-agent LLM (5-15s). A daemon thread spawning
        a fresh loop returns immediately and runs in the background.
        """
        try:
            self._dispatch(state)
        except Exception as e:
            logger.warning("after_agent dispatch failed: %s", e)
        return None

    def _dispatch(self, state: Any) -> None:
        """Shared state extraction + background scheduling for both sync and async hooks."""
        messages = state.get("messages", []) if isinstance(state, dict) else []
        session_id = _resolve_session_id(state)
        if not session_id or not messages:
            return
        # create_task 跑在主 loop（快、复用 llm 连接池），但传一个全新空 contextvars.Context() 隔离：
        # 默认 create_task 会复制父对话 astream 的 context（内含父 AsyncSqliteSaver checkpointer），
        # fork sub-agent 继承它后，主对话关闭 state.db 就报 "Cannot operate on a closed database"
        # （端到端真跑暴露，单纯 ainvoke config 隔离不够）。全新空 Context() 彻底切断继承，是根治。
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                self.run_for_session(session_id, messages),
                context=contextvars.Context(),
            )
            return
        except RuntimeError:
            pass
        # 无 running loop（同步调用栈）：daemon thread 兜底，asyncio.run 本就是干净 context。
        import threading

        def _run_in_thread():
            try:
                asyncio.run(self.run_for_session(session_id, messages))
            except Exception as e:
                logger.warning("background review task crashed: %s", e)

        threading.Thread(target=_run_in_thread, daemon=True).start()

    async def run_for_session(self, session_id: str, messages: list[Any]) -> None:
        """每轮自审：nudge 命中 → fork combined sub-agent 自主沉淀 memory+skill（agentic）。"""
        try:
            try:
                meta = self._sm.get(session_id)
            except FileNotFoundError:
                return
            sdir = self._sm.session_dir(session_id)

            n = meta.stats.turns
            if n > 0 and n % self._reflection_interval == 0:        # nudge 触发（每 interval 轮）
                summary = await spawn_review_subagent(messages, sdir, self._llm_factory)
                if summary and summary.get("actions"):
                    self._sm.update_stats(session_id, review_actions=len(summary["actions"]))
                    self._bus.publish(session_id, {
                        "type": "review_done",
                        "actions": summary["actions"],
                    })
        except Exception as e:
            logger.error("run_for_session error: %s", e)
