"""Pydantic data models for Sessions and related entities."""
from datetime import datetime, timezone

from pydantic import BaseModel, Field, field_validator


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


class SessionStats(BaseModel):
    turns: int = 0
    total_tokens: int = 0
    skills_generated: int = 0
    skills_enhanced: int = 0
    memory_saved: int = 0
    review_actions: int = 0


class SessionMeta(BaseModel):
    id: str
    title: str
    workspace_path: str
    model: str
    created_at: str = Field(default_factory=_now_iso)
    updated_at: str = Field(default_factory=_now_iso)
    stats: SessionStats = Field(default_factory=SessionStats)

    @field_validator("workspace_path")
    @classmethod
    def _wp_nonempty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("workspace_path must not be empty")
        return v


class CreateSessionRequest(BaseModel):
    title: str = "New Session"
    workspace_path: str
    model: str | None = None


class RenameSessionRequest(BaseModel):
    title: str
