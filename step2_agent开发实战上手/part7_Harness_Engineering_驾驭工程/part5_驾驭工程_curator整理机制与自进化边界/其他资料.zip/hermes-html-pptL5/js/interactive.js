/**
 * Harness Engineering L5 · Architect Blueprint
 * js/interactive.js — slideHooks 注册区（骨架版 / 待填充）
 *
 * 架构规范（沿用 L4 hermes-html-ppt 实战验证）：
 *   - 键名格式：'slides/SXX-filename.html'（完整路径）
 *   - 值格式：function () { ...; return function cleanup() { ... }; }
 *   - 所有 setTimeout / setInterval 必须 push 到 timerIds[]，cleanup 一次性 clearTimeout
 *   - 所有 addEventListener 必须在 cleanup 中 removeEventListener
 *   - 禁止内联 IIFE；禁止 window.onload 替代 slideHooks
 *   - 每个 🔴🔴 / 🔴 页至少含 3 处 // ←FM1/FM2/FM3 注释（quality-guard 验证）
 *
 * 当前状态：骨架（无 hook 注册）
 * 待 html-courseware-interactive-eng / slide-writer 填充本课交互页 hook
 *
 * 模板参考：见 ../_reference/hook_examples.js
 *   - 模板 A: step-reveal（三柱架构 / 四层揭示）
 *   - 模板 B: tab-switch（4 重约束 / 多面板切换）
 */

window.slideHooks = window.slideHooks || {};

/* =====================================================
   L5 交互页 hook 注册区（待填充）
   =====================================================
   填充示例：
   window.slideHooks['slides/S07-curator-four-gates.html'] = function () {
     var slide = document.querySelector('.slide');
     if (!slide) return;  // ←FM-2: querySelector 防 null

     var timerIds = [];   // ←FM-NEW: 定时器统一收集
     // ... 交互逻辑 ...

     return function cleanup() {  // ←FM-1: 必须 return cleanup
       timerIds.forEach(function (id) { clearTimeout(id); });
       // ... removeEventListener ...
     };
   };
   ===================================================== */

/* =====================================================
   C4 hook · S05-curator-two-phases.html
   Tab 切换（Phase 1 / Phase 2）+ 时序条 pulse 联动
   + Phase 2 内嵌 Umbrella 4 步 mini 动画（v2 新增）
   ===================================================== */
window.slideHooks['slides/S08-curator-two-phases.html'] = function () {
  var slide = document.querySelector('[data-slide-id="S08"]');
  if (!slide) return function noop() {};  // ←FM-1: noop cleanup 防 DOM 缺失早退

  var tablist  = slide.querySelector('#c4-tablist');
  if (!tablist) return function noop() {};

  var tabs     = Array.prototype.slice.call(slide.querySelectorAll('.c4-tab'));
  var panels   = Array.prototype.slice.call(slide.querySelectorAll('.c4-panel'));
  var tnodeP1  = slide.querySelector('#c4-tnode-p1');
  var tnodeP2  = slide.querySelector('#c4-tnode-p2');

  // Umbrella mini 动画的 4 个 step 元素
  var miniSteps = Array.prototype.slice.call(slide.querySelectorAll('.c4-mini-step'));

  var timerIds = [];   // ←FM-2: 所有 setTimeout push 到此，cleanup 一次性 clear

  // ── mini 动画：重置所有 step 到隐藏状态 ──────────────────────
  function resetMiniAnim() {
    // ←FM mini-reset: 切回 Phase 1 或 cleanup 时隐藏所有 step
    miniSteps.forEach(function (s) {
      s.classList.remove('c4-mini-visible');
    });
  }

  // ── mini 动画：4 步 fade-up 序列（间隔 900ms）────────────────
  function startMiniAnim() {
    resetMiniAnim();
    var DELAYS = [0, 900, 1800, 2700];
    miniSteps.forEach(function (s, i) {
      var tid = setTimeout(function () {
        s.classList.add('c4-mini-visible');
      }, DELAYS[i]);
      timerIds.push(tid);  // ←FM-2: push timerIds[]（mini 动画定时器）
    });
  }

  // ── 触发时序节点 pulse 动画（class toggle 方式）────────────────
  function pulseTnode(el, cls) {
    if (!el) return;
    el.classList.remove('pulse-p1', 'pulse-p2');
    // 强制重绘，使 animation 从头触发
    var dummy = el.offsetWidth; // eslint-disable-line no-unused-vars
    el.classList.add(cls);
    var tid = setTimeout(function () {
      el.classList.remove(cls);
    }, 1200);
    timerIds.push(tid);  // ←FM-2: push timerIds[]
  }

  // ── 切换到指定 tab ─────────────────────────────────────────────
  function activateTab(idx) {
    tabs.forEach(function (tab, i) {
      var selected = i === idx;
      tab.setAttribute('aria-selected', selected ? 'true' : 'false');
      tab.setAttribute('tabindex', selected ? '0' : '-1');
      panels[i].classList.toggle('is-active', selected);
    });
    // 联动时序条 pulse
    if (idx === 0) {
      pulseTnode(tnodeP1, 'pulse-p1');
      resetMiniAnim();   // ←FM-mini: 切回 Phase 1 → reset mini 动画
    }
    if (idx === 1) {
      pulseTnode(tnodeP2, 'pulse-p2');
      startMiniAnim();   // ←FM-mini: Phase 2 激活 → 播放 mini 4 步序列
    }
  }

  // ── click 切换（事件委托）────────────────────────────────────
  function handleClick(e) {
    var btn = e.target.closest('.c4-tab');
    if (!btn) return;
    var idx = parseInt(btn.getAttribute('data-tab-index'), 10);
    if (!isNaN(idx)) activateTab(idx);
  }

  // ── 键盘 ArrowLeft / ArrowRight ─────────────────────────────
  function handleKeydown(e) {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    var len = tabs.length;
    var cur = parseInt(
      (tablist.querySelector('[aria-selected="true"]') || tabs[0]).getAttribute('data-tab-index'),
      10
    );
    if (isNaN(cur)) cur = 0;
    var next = e.key === 'ArrowRight' ? (cur + 1) % len : (cur + len - 1) % len;
    activateTab(next);
    tabs[next].focus();
  }

  // ── 初始状态：Phase 1 激活 + 节点 ③ pulse ─────────────────
  activateTab(0);

  tablist.addEventListener('click', handleClick);
  tablist.addEventListener('keydown', handleKeydown);

  // ── cleanup ─────────────────────────────────────────────────
  return function cleanup() {  // ←FM-3: cleanup removeEventListener + clearTimeout + mini reset
    timerIds.forEach(clearTimeout);
    timerIds = [];
    tablist.removeEventListener('click', handleClick);
    tablist.removeEventListener('keydown', handleKeydown);
    // 重置到 Phase 1
    activateTab(0);
    if (tnodeP1) tnodeP1.classList.remove('pulse-p1', 'pulse-p2');
    if (tnodeP2) tnodeP2.classList.remove('pulse-p1', 'pulse-p2');
    resetMiniAnim();  // ←FM mini cleanup: 重置 Umbrella mini 所有 step 到隐藏状态
  };
};


/* =====================================================
   C5 hook · S06-curator-rules-and-myths.html
   左：5 规则 click-to-expand（同时只一条展开）
   右：3 误解 toggle 揭晓（独立 state）
   ===================================================== */
window.slideHooks['slides/S09-curator-rules-and-myths.html'] = function () {
  var slide = document.querySelector('[data-slide-id="S06"]');
  if (!slide) return function noop() {};  // ←FM-1: noop cleanup 防 DOM 缺失早退

  var rulesList = slide.querySelector('#c5-rules-list');
  var quizList  = slide.querySelector('#c5-quiz-list');
  if (!rulesList || !quizList) return function noop() {};

  // ── 独立 state 对象（R3 防御：左右不共享 DOM 状态）────────────
  var rulesState = { expandedRule: null };              // ←FM-2: 独立 state
  var quizState  = { revealed: {} };                    // ←FM-2: 独立 state（Set 降级为 {}）

  // ── LEFT: 规则展开逻辑 ─────────────────────────────────────
  function expandRule(idx) {
    var items = Array.prototype.slice.call(rulesList.querySelectorAll('.c5-rule-item'));
    var sameClicked = rulesState.expandedRule === idx;

    // 关闭所有
    items.forEach(function (item) {
      item.classList.remove('is-expanded');
    });

    // 若不是点同一条，展开新条
    if (!sameClicked) {
      items[idx] && items[idx].classList.add('is-expanded');
      rulesState.expandedRule = idx;
    } else {
      rulesState.expandedRule = null;
    }
  }

  function handleRulesClick(e) {
    var item = e.target.closest('.c5-rule-item');
    if (!item) return;
    var idx = parseInt(item.getAttribute('data-rule-idx'), 10);
    if (!isNaN(idx)) expandRule(idx);
  }

  // ── RIGHT: 误解揭晓逻辑 ────────────────────────────────────
  function toggleQuiz(idx) {
    var answerEl = slide.querySelector('#c5-quiz-answer-' + idx);
    var btnEl    = slide.querySelector('[data-quiz-btn="' + idx + '"]');
    if (!answerEl) return;

    var revealed = !!quizState.revealed[idx];
    quizState.revealed[idx] = !revealed;

    answerEl.classList.toggle('is-visible', !revealed);
    if (btnEl) {
      btnEl.classList.toggle('is-revealed', !revealed);
      btnEl.textContent = !revealed ? '▲ 收起' : '▽ 揭晓';
    }
  }

  function handleQuizClick(e) {
    var btn = e.target.closest('.c5-quiz-btn');
    if (!btn) return;
    var idx = parseInt(btn.getAttribute('data-quiz-btn'), 10);
    if (!isNaN(idx)) toggleQuiz(idx);
  }

  rulesList.addEventListener('click', handleRulesClick);
  quizList.addEventListener('click', handleQuizClick);

  // ── cleanup ─────────────────────────────────────────────────
  return function cleanup() {  // ←FM-3: cleanup removeEventListener
    rulesList.removeEventListener('click', handleRulesClick);
    quizList.removeEventListener('click', handleQuizClick);

    // 重置规则展开状态
    rulesState.expandedRule = null;
    var items = Array.prototype.slice.call(rulesList.querySelectorAll('.c5-rule-item'));
    items.forEach(function (item) { item.classList.remove('is-expanded'); });

    // 重置误解揭晓状态
    quizState.revealed = {};
    var answers = Array.prototype.slice.call(quizList.querySelectorAll('.c5-quiz-answer'));
    answers.forEach(function (a) { a.classList.remove('is-visible'); });
    var btns = Array.prototype.slice.call(quizList.querySelectorAll('.c5-quiz-btn'));
    btns.forEach(function (b) {
      b.classList.remove('is-revealed');
      b.textContent = '▽ 揭晓';
    });
  };
};


/* =====================================================
   C6 hook · S07-curator-full-run.html
   沉浸式终端模拟器：打字机 + 暂停 + 重播
   ===================================================== */
window.slideHooks['slides/S10-curator-full-run.html'] = function () {
  var slide = document.querySelector('[data-slide-id="S07"]');
  if (!slide) return function noop() {};  // ←FM-1: noop cleanup 防 DOM 缺失早退

  var timerIds  = [];  // ←FM-2: 所有 setTimeout/setInterval push 到此，cleanup 一次性 clear

  var startBtn  = slide.querySelector('#c6-btn-start');
  var pauseBtn  = slide.querySelector('#c6-btn-pause');
  var replayBtn = slide.querySelector('#c6-btn-replay');
  var stdoutEl  = slide.querySelector('#c6-stdout');
  var statusTag = slide.querySelector('#c6-status-tag');

  if (!startBtn || !stdoutEl) return function noop() {};

  // ── prefers-reduced-motion 检测 ─────────────────────────────
  var reducedMotion = window.matchMedia
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
    : false;

  // ── 动画状态 ─────────────────────────────────────────────────
  var animState = { running: false, paused: false, lineIdx: 0, charIdx: 0 };

  // ── LINES 数据（5 段输出 + tooltip 元数据）──────────────────
  // 格式：{ text, cls, delay(段间停顿ms), tooltip(可选) }
  var LINES = [
    // 段 1：4 道闸门
    { text: '─────────────────────────────────────────────', cls: 'c6-divider', delay: 0 },
    { text: '> maybe_run_curator() invoked',  cls: 'c6-head has-tooltip', delay: 0,
      tooltip: '源码入口 L1656 · maybe_run_curator()' },
    { text: '> Gate 1: enabled ✓',            cls: 'c6-gate', delay: 0 },
    { text: '> Gate 2: not paused ✓',         cls: 'c6-gate', delay: 0 },
    { text: '> Gate 3: not first run ✓',      cls: 'c6-gate', delay: 0 },
    { text: '> Gate 4: 8d > 7d interval ✓',   cls: 'c6-gate', delay: 0 },

    // 段 2：Phase 1
    { text: '─────────────────────────────────────────────', cls: 'c6-divider', delay: 1100 },
    { text: '> Phase 1 starts...',             cls: 'c6-p1 has-tooltip', delay: 0,
      tooltip: '源码入口 L255 · apply_automatic_transitions()' },
    { text: '  📁 skill-A (last 100d) → archive ✓', cls: 'c6-p1', delay: 0 },
    { text: '  📁 skill-B (last 45d)  → mark stale ✓', cls: 'c6-p1', delay: 0 },
    { text: '  📁 skill-C (active)    → no change',  cls: 'c6-p1', delay: 0 },
    { text: '> Phase 1 done: 1 archived, 1 stale',   cls: 'c6-p1', delay: 0 },

    // 段 3：Phase 2
    { text: '─────────────────────────────────────────────', cls: 'c6-divider', delay: 1200 },
    { text: '> Phase 2 forking aux agent...',  cls: 'c6-p2 has-tooltip', delay: 0,
      tooltip: '源码入口 L1515 · _run_llm_review() fork AIAgent' },
    { text: '  🤖 reviewing 12 agent-created skills',      cls: 'c6-p2', delay: 0 },
    { text: '  🗂️  proposed merge: A+B+C → hermes-troubleshooting (umbrella)', cls: 'c6-p2', delay: 0 },
    { text: '  ✓ skill_manage executed',        cls: 'c6-p2', delay: 0 },
    { text: '> Phase 2 done: 3 consolidations', cls: 'c6-p2', delay: 0 },

    // 段 4：REPORT.md
    { text: '─────────────────────────────────────────────', cls: 'c6-divider', delay: 1000 },
    { text: '> REPORT.md written ✓',            cls: 'c6-report has-tooltip', delay: 0,
      tooltip: '报告写入 curator logs 目录' },
    { text: '$ cat ~/.hermes/logs/curator/2026-05-11_03:00/REPORT.md', cls: 'c6-cat', delay: 300 },

    // 段 5：REPORT 内容
    { text: '─────────────────────────────────────────────', cls: 'c6-divider', delay: 700 },
    { text: '  ## Structured summary',          cls: 'c6-yaml', delay: 0 },
    { text: '  consolidations:',                cls: 'c6-yaml', delay: 0 },
    { text: '    - from: hermes-gateway-debug-1024', cls: 'c6-yaml', delay: 0 },
    { text: '      into: hermes-troubleshooting',   cls: 'c6-yaml', delay: 0 },
    { text: '      reason: 同一故障域窄 skill',      cls: 'c6-yaml', delay: 0 },
    { text: '    - from: port-conflict-restart',    cls: 'c6-yaml', delay: 0 },
    { text: '      into: hermes-troubleshooting',   cls: 'c6-yaml', delay: 0 },
    { text: '      reason: 同一故障域窄 skill',      cls: 'c6-yaml', delay: 0 },
    { text: '    ...',                              cls: 'c6-yaml', delay: 0 },
    { text: '─────────────────────────────────────────────', cls: 'c6-divider', delay: 0 },
  ];

  // ── 光标元素 ─────────────────────────────────────────────────
  var cursorEl = null;

  function ensureCursor() {
    if (!cursorEl) {
      cursorEl = document.createElement('span');
      cursorEl.className = 'c6-cursor';
    }
  }

  function appendCursor() {
    ensureCursor();
    stdoutEl.appendChild(cursorEl);
    stdoutEl.scrollTop = stdoutEl.scrollHeight;
  }

  function removeCursor() {
    if (cursorEl && cursorEl.parentNode) {
      cursorEl.parentNode.removeChild(cursorEl);
    }
  }

  // ── 创建一行 DOM 元素 ────────────────────────────────────────
  function createLineEl(lineData) {
    var el = document.createElement('span');
    el.className = 'c6-line ' + lineData.cls;
    if (lineData.tooltip) {
      el.setAttribute('data-tooltip', lineData.tooltip);
    }
    return el;
  }

  // ── 打字机核心：逐字符写入一行，完成后 resolve ─────────────
  function typewriteLine(lineData, onDone) {
    var el = createLineEl(lineData);
    removeCursor();
    stdoutEl.appendChild(el);
    appendCursor();

    var text = lineData.text;
    var i = 0;
    var CHAR_DELAY = reducedMotion ? 0 : 22;  // ms/char

    function nextChar() {
      if (!animState.running) return;  // 被 cleanup 停止
      if (animState.paused) {
        // 暂停：轮询等待
        var tid = setTimeout(nextChar, 120);
        timerIds.push(tid);  // ←FM-2: push timerIds[]
        return;
      }
      if (i < text.length) {
        el.textContent += text[i++];
        stdoutEl.scrollTop = stdoutEl.scrollHeight;
        var tid2 = setTimeout(nextChar, CHAR_DELAY);
        timerIds.push(tid2);  // ←FM-2: push timerIds[]
      } else {
        // 行完成：换行
        el.textContent += '\n';
        onDone();
      }
    }
    nextChar();
  }

  // ── 推进到下一行（含段间停顿）────────────────────────────────
  function processNextLine() {
    if (!animState.running) return;
    if (animState.lineIdx >= LINES.length) {
      // 全部完成
      removeCursor();
      animState.running = false;
      setStatus('done');
      startBtn.disabled  = false;
      pauseBtn.disabled  = true;
      replayBtn.disabled = false;
      return;
    }

    var lineData = LINES[animState.lineIdx];
    animState.lineIdx++;

    var doType = function () {
      if (!animState.running) return;
      // reduced-motion：直接全量写入
      if (reducedMotion) {
        var el = createLineEl(lineData);
        el.textContent = lineData.text + '\n';
        stdoutEl.appendChild(el);
        stdoutEl.scrollTop = stdoutEl.scrollHeight;
        processNextLine();
      } else {
        typewriteLine(lineData, processNextLine);
      }
    };

    if (lineData.delay > 0) {
      var tid = setTimeout(doType, lineData.delay);
      timerIds.push(tid);  // ←FM-2: push timerIds[]
    } else {
      doType();
    }
  }

  // ── status tag ─────────────────────────────────────────────
  function setStatus(state) {
    if (!statusTag) return;
    statusTag.className = 'c6-status-tag ' + state;
    var labels = { running: '▶ 运行中…', paused: '⏸ 暂停', done: '✓ 完成', ready: '就绪' };
    statusTag.textContent = labels[state] || state;
  }

  // ── 启动动画 ────────────────────────────────────────────────
  function startAnimation() {
    if (animState.running && !animState.paused) return;  // 防重入
    if (animState.paused) {
      // 从暂停恢复
      animState.paused = false;
      setStatus('running');
      pauseBtn.textContent = '⏸ 暂停';
      return;
    }
    // 全新启动
    animState.running = true;
    animState.paused  = false;
    animState.lineIdx = 0;
    setStatus('running');
    startBtn.disabled  = true;
    pauseBtn.disabled  = false;
    replayBtn.disabled = false;
    processNextLine();
  }

  // ── 暂停 ────────────────────────────────────────────────────
  function pauseAnimation() {
    if (!animState.running || animState.paused) return;
    animState.paused = true;
    setStatus('paused');
    pauseBtn.textContent = '▶ 继续';
  }

  // ── 清空 stdout + 停止所有定时器 ───────────────────────────
  function resetStdout() {
    timerIds.forEach(clearTimeout);  // ←FM-2: clearTimeout 所有 push 过的 id
    timerIds = [];
    cursorEl = null;
    animState.running = false;
    animState.paused  = false;
    animState.lineIdx = 0;
    if (stdoutEl) stdoutEl.innerHTML = '';
  }

  // ── 重播 ────────────────────────────────────────────────────
  function replayAnimation() {
    resetStdout();
    setStatus('ready');
    startBtn.disabled  = false;
    pauseBtn.disabled  = true;
    pauseBtn.textContent = '⏸ 暂停';
    replayBtn.disabled = false;
    // 短延后再启动，让 UI 刷新
    var tid = setTimeout(function () {
      startAnimation();
    }, 80);
    timerIds.push(tid);  // ←FM-2: push timerIds[]
  }

  startBtn.addEventListener('click',  startAnimation);
  pauseBtn.addEventListener('click',  pauseAnimation);
  replayBtn.addEventListener('click', replayAnimation);

  // ── cleanup ─────────────────────────────────────────────────
  return function cleanup() {  // ←FM-3: cleanup removeEventListener + clearTimeout + reset
    timerIds.forEach(clearTimeout);
    timerIds = [];
    startBtn.removeEventListener('click',  startAnimation);
    pauseBtn.removeEventListener('click',  pauseAnimation);
    replayBtn.removeEventListener('click', replayAnimation);
    if (stdoutEl) stdoutEl.innerHTML = '';
    cursorEl = null;
    animState.running = false;
    animState.paused  = false;
    startBtn.disabled  = false;
    pauseBtn.disabled  = true;
    pauseBtn.textContent = '⏸ 暂停';
    replayBtn.disabled = true;
    setStatus('ready');
  };
};
