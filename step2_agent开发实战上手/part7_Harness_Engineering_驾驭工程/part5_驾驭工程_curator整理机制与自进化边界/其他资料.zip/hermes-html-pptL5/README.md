# Harness Engineering L5 · Curator + 血统隔离 + 诚实边界

Harness Engineering 驾驭工程 · 第五节（系列终章）HTML 课件骨架。

**当前状态**：🟡 骨架阶段（仅含通用框架 + L5 封面 + L4 参考样本）。完整 slide 内容待生成。

---

## 主题与章节规划

来源：`../lesson.md`（1603 行）+ `../plan.md`。

L5 三机制 + 横评收束：

| 章 | 主题 | 核心命题 |
|---|---|---|
| 第 0 章 | 开场角色声明 + 衔接 L4 | 打碎"GEPA 默认架构"直觉，建立四维评价坐标系 |
| 第 1 章 | Curator 定期整理机制 | idle 触发 + Phase 1 自动 + Phase 2 LLM Review + 五条护栏 |
| 第 2 章 | Skill 血统隔离（ContextVar） | 78 行代码解决"Agent 覆盖用户 skill"的 Reddit 痛点 |
| 第 3 章 | 自进化的诚实边界（Demo 3） | PDF 卖点 vs 源码真相，30 行 dspy.GEPA 真跑 |
| 第 4 章 | 系列交付 + 学员带走 | 四件产物收束 |
| 第 5 章 | 系列收束 · 三句话自测题 | 终章 |

---

## 目录结构

```
hermes-html-pptL5/
├── README.md                 # 本文档
├── index.html                # 入口（已 L5 化：title + meta + 目录副标题）
├── css/
│   └── main.css              # 全局样式（L4 视觉系统 1:1 沿用，含 :root 变量）
├── js/
│   ├── main.js               # 导航框架（loadSlide/翻页/工具栏/钢笔/画板 全功能就绪）
│   └── interactive.js        # 仅含 slideHooks 注册区（骨架，待填充）
├── slides/
│   └── S01-cover.html        # L5 封面（系列时间轴 + 三机制 callout）
└── _reference/               # ⭐ L4 参考样本（不参与运行，仅查阅用）
    ├── slide_cover.html         # 类型 1：封面（L4 S01 原样）
    ├── slide_chapter-intro.html # 类型 2：章节过渡页（L4 S06）
    ├── slide_heavy-interact.html# 类型 3：重交互页（L4 S07 三柱架构）
    ├── slide_takeaways.html     # 类型 4：总结页（L4 S31）
    └── hook_examples.js         # 2 个 hook 模板：step-reveal + tab-switch
```

---

## 快速启动

```bash
cd hermes-html-pptL5
python3 -m http.server 8000
```

打开 <http://localhost:8000>，应看到 L5 封面（系列时间轴 L5 高亮）。

工具栏五件套（M/T/D/色/F）+ 键盘导航（← → Space Esc Home End）+ 钢笔拖尾（FADE 1200ms）+ 画板（清后退语义）均已就绪。

---

## 下一步：slide 生成接入

骨架完成后，slide 内容生成走 **/html-courseware-team** Agent Team 流水线。建议另起会话：

```
/html-courseware-team --resume /Users/mac/PycharmProjects/JupyterProject/HarnessEngineering/HermesAgentL5/hermes-html-pptL5/
```

或新建项目从 `lesson.md` + `plan.md` 重新走流水线（更稳）。

生成器需要做的事：
1. **扩展 `js/main.js`** 的 `slideFiles[]` / `slideTitles[]` / `chapters[]` 三数组（L5 6 章对应）
2. **生成 `slides/S02 - SXX.html`** 内容 fragment（参照 `_reference/slide_*.html`）
3. **填充 `js/interactive.js`** 的 `window.slideHooks[...]` 注册（参照 `_reference/hook_examples.js`）

---

## 维护说明

- **修改单页**：直接编辑 `slides/S{XX}-*.html`
- **修改总页码或目录**：编辑 `js/main.js` 顶部的 `slideFiles` / `slideTitles` / `chapters` 三个数组
- **修改全局视觉变量**：编辑 `css/main.css` 顶部 `:root` 的 CSS 变量
- **新增交互**：在 `js/interactive.js` 添加 `window.slideHooks[file] = function () { ... }`

---

## 技术栈

- 纯静态：HTML + CSS + 原生 JS，无构建工具
- 外部 CDN：GSAP 3.12.5（动画）、Google Fonts（Inter / Sora / Noto Sans SC / JetBrains Mono）
- 浏览器要求：Chrome / Edge / Safari 最近 2 个主版本
