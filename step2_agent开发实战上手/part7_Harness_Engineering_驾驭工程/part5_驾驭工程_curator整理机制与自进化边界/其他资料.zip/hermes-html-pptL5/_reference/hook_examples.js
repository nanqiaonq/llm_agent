/**
 * Harness Engineering L4 hermes-html-ppt · interactive.js · 2 个代表 hook 完整范例
 * 用途：L5 slide-writer / interactive-eng 填充 ../js/interactive.js 时对照参考
 *
 * 不参与运行（仅 _reference/，不被 index.html 加载）
 *
 * ─────────────────────────────────────────────────
 * 模板 A：tab-switch（4-tab navigator + 演示动画）
 *   原 hook：window.slideHooks['slides/S18-fork-4-constraints.html']
 *   适用：内容分类 / 多角度对比 / Tab 切换 + 各 Tab 内嵌演示动画
 *   关键技巧：
 *     - timerIds[] 统一收集所有 setTimeout/setInterval
 *     - 事件委托：addEventListener 绑在 tablist 而非每个 tab
 *     - cleanup 三件套：clearTimeout + removeEventListener + reset state
 *
 * 模板 B：step-reveal + click-to-detail（三柱架构 + 联动详情面板）
 *   原 hook：window.slideHooks['slides/S07-memory-architecture.html']
 *   适用：复杂结构图 + 点击组件展示详情 + 时序节点高亮联动
 *   关键技巧：
 *     - gsap timeline 控制入场动画（paused 后 play）
 *     - querySelectorAll 后转 Array（forEach 兼容）
 *     - 详情面板用 innerHTML + 模板字符串渲染
 *     - active class 切换（不重写 DOM）
 * ─────────────────────────────────────────────────
 */

/* =====================================================
   模板 A：tab-switch + 演示动画（S18 完整范例）
   ===================================================== */
window.slideHooks['slides/S18-fork-4-constraints.html'] = function () {
  var slide = document.querySelector('.slide');
  if (!slide) return;  // ←FM-2: querySelector 防 null

  var tabs   = Array.prototype.slice.call(slide.querySelectorAll('[role="tab"]'));
  var panels = Array.prototype.slice.call(slide.querySelectorAll('[role="tabpanel"]'));
  var tablist = slide.querySelector('[role="tablist"]');

  if (!tabs.length || !panels.length || !tablist) return;  // ←FM-2: DOM 不完整时安全退出

  var state = { activeIndex: 0 };
  var timerIds = [];  // ←FM-NEW: 演示动画定时器统一收集

  // ── 切换到指定 tab ─────────────────────────────────────────────────
  function activateTab(newIndex) {  // ←FM-1: 具名函数固定逻辑，便于复用与 removeEventListener
    var prev = state.activeIndex;
    if (newIndex === prev) return;

    // 停用旧 tab
    tabs[prev].setAttribute('aria-selected', 'false');
    tabs[prev].setAttribute('tabindex', '-1');
    tabs[prev].classList.remove('active');
    panels[prev].style.display = 'none';  // ←FM-2: display 切换不重写 DOM，直接操作 style

    // 激活新 tab
    tabs[newIndex].setAttribute('aria-selected', 'true');
    tabs[newIndex].setAttribute('tabindex', '0');
    tabs[newIndex].classList.add('active');
    panels[newIndex].style.display = 'block';
    tabs[newIndex].focus();

    state.activeIndex = newIndex;
  }

  // ── 确保初始状态正确（tab-0 激活，其余 none）─────────────────────
  tabs.forEach(function (tab, i) {
    tab.setAttribute('aria-selected', i === 0 ? 'true' : 'false');
    tab.setAttribute('tabindex', i === 0 ? '0' : '-1');
    if (i === 0) tab.classList.add('active');
    else tab.classList.remove('active');
    panels[i].style.display = i === 0 ? 'block' : 'none';
  });

  // ── click 切换（事件委托）────────────────────────────────────────
  function handleClick(e) {
    var btn = e.target.closest('[role="tab"]');
    if (!btn) return;
    var idx = parseInt(btn.getAttribute('data-tab-index'), 10);
    if (!isNaN(idx)) activateTab(idx);
  }
  tablist.addEventListener('click', handleClick);  // ←FM-1: 事件委托绑在 tablist

  // ── 键盘 ArrowLeft / ArrowRight 循环切换 ─────────────────────────
  function handleKeydown(e) {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    var len = tabs.length;
    var next = e.key === 'ArrowRight'
      ? (state.activeIndex + 1) % len
      : (state.activeIndex + len - 1) % len;
    activateTab(next);
  }
  tablist.addEventListener('keydown', handleKeydown);

  // ── 在某个 tab 内嵌的演示动画（示例：fork 裂变模拟）──────────────
  // 这一段展示如何在 tab 内放可重复触发的动画 demo，
  // 关键：所有 setTimeout 进 timerIds[]，方便 cleanup 一次性 clear
  var leakBtn = slide.querySelector('[data-mode="leak"]');
  var canvas  = slide.querySelector('#fork-canvas');

  function clearCanvas() {
    if (canvas) canvas.innerHTML = '';
    timerIds.forEach(function (id) { clearTimeout(id); });
    timerIds = [];
  }

  function leakHandler() {
    clearCanvas();
    // 时序：t=0 / t=500 / t=1000 / t=1500 渐次生成 fork 节点
    timerIds.push(setTimeout(function () { /* spawn gen0 */ }, 0));
    timerIds.push(setTimeout(function () { /* spawn gen1 */ }, 500));
    timerIds.push(setTimeout(function () { /* spawn gen2 */ }, 1000));
    timerIds.push(setTimeout(function () { /* spawn gen3 + warning */ }, 1500));
    timerIds.push(setTimeout(clearCanvas, 5000));  // 自动重置
  }

  if (leakBtn) leakBtn.addEventListener('click', leakHandler);

  // ── cleanup（关键：必须 return 一个 cleanup 函数）─────────────────
  return function cleanup() {  // ←FM-3: cleanup removeEventListener 防事件泄漏
    tablist.removeEventListener('click', handleClick);
    tablist.removeEventListener('keydown', handleKeydown);
    if (leakBtn) leakBtn.removeEventListener('click', leakHandler);

    timerIds.forEach(function (id) { clearTimeout(id); });
    timerIds = [];
    if (canvas) canvas.innerHTML = '';

    // 重置到第一个 tab
    tabs.forEach(function (tab, i) {
      tab.setAttribute('aria-selected', i === 0 ? 'true' : 'false');
      tab.setAttribute('tabindex', i === 0 ? '0' : '-1');
      if (i === 0) tab.classList.add('active');
      else tab.classList.remove('active');
      panels[i].style.display = i === 0 ? 'block' : 'none';
    });
    state = {};
  };
};


/* =====================================================
   模板 B：step-reveal + click-to-detail（S07 完整范例）
   ===================================================== */
window.slideHooks['slides/S07-memory-architecture.html'] = function () {
  var slide = document.querySelector('[data-slide-id="S07"]');
  if (!slide) return function noop() {};  // ←FM-1: noop cleanup 防 DOM 缺失早退

  // 1. 组件元数据（含详情 + 参与的时序节点 + 所属段）
  var COMPONENTS = {
    'memory-md': {
      title: 'MEMORY.md',
      segment: 'hot',
      summary: 'Agent 自维护的"长期事实"快照 — ...',
      meta: { '所在层': '段 1 · 热双层', '更新时机': 'Nudge 后台 review' },
      tnodes: [1, 6]
    },
    'sqlite': {
      title: 'SQLite',
      segment: 'cold',
      summary: 'messages 真表 14 字段 — ...',
      meta: { '所在层': '段 2 · 冷三件套', '源码': 'hermes_state.py:103-156' },
      tnodes: [3, 4]
    }
    // ... 更多组件
  };

  // 2. DOM 引用
  var titleEl    = slide.querySelector('#s07-title');
  var subtitleEl = slide.querySelector('.s07-subtitle');
  var pillars    = slide.querySelectorAll('.s07-pillar');
  var components = slide.querySelectorAll('.s07-component');
  var tnodes     = slide.querySelectorAll('.s07-tnode');
  var detailEl   = slide.querySelector('#s07-detail');

  // 3. 入场动画（gsap timeline，paused 后 play）
  var tl = gsap.timeline({ paused: true });
  tl.fromTo(titleEl, { opacity: 0, y: -10 }, { opacity: 1, y: 0, duration: 0.4 });
  tl.fromTo(subtitleEl, { opacity: 0 }, { opacity: 1, duration: 0.3 }, '-=0.1');
  tl.fromTo(pillars, { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.45, stagger: 0.13 });

  var entranceTimer = setTimeout(function () { tl.play(); }, 120);

  // 4. 详情面板渲染（innerHTML + 模板字符串）
  var SEG_LABEL = { hot: '段 1 · 热记忆', cold: '段 2 · 冷记忆', ext: '段 3 · 扩展层' };

  function renderDetail(compKey) {
    var data = COMPONENTS[compKey];
    if (!data) {
      detailEl.innerHTML = '<div class="s07-detail-empty">点击上方任一组件查看详情</div>';
      return;
    }
    var metaHtml = Object.keys(data.meta).map(function (k) {
      return '<span><b>' + k + ':</b> ' + data.meta[k] + '</span>';
    }).join('');
    detailEl.innerHTML =
      '<div class="s07-detail-header">' +
        '<span>' + data.title + '</span>' +
        '<span>' + SEG_LABEL[data.segment] + '</span>' +
      '</div>' +
      '<div>' + data.summary + '</div>' +
      '<div>' + metaHtml + '</div>';
  }

  // 5. 时序节点 pulse 联动
  function clearTnodePulse() {
    tnodes.forEach(function (n) { n.classList.remove('pulse-active'); });    // ←FM-3
  }

  function activateTnodes(idxArr) {
    clearTnodePulse();
    if (!idxArr || !idxArr.length) return;
    idxArr.forEach(function (idx) {
      var n = slide.querySelector('.s07-tnode[data-tnode="' + idx + '"]');
      if (n) n.classList.add('pulse-active');
    });
  }

  // 6. 组件点击交互
  function setActiveComponent(compKey, srcEl) {
    components.forEach(function (c) { c.classList.remove('active'); });   // ←FM-2: 全清后激活
    if (srcEl) srcEl.classList.add('active');
    renderDetail(compKey);
    var tnodesArr = (COMPONENTS[compKey] && COMPONENTS[compKey].tnodes) || [];
    activateTnodes(tnodesArr);
  }

  // 7. 事件绑定（保存 handler 引用，便于 cleanup removeEventListener）
  var compClickHandlers = [];
  components.forEach(function (compEl) {
    var key = compEl.getAttribute('data-component');
    var clickH = function () { setActiveComponent(key, compEl); };
    compClickHandlers.push(clickH);
    compEl.addEventListener('click', clickH);
  });

  // 8. cleanup
  return function cleanup() {
    clearTimeout(entranceTimer);
    if (tl) { tl.kill(); tl = null; }
    gsap.killTweensOf(slide.querySelectorAll('*'));

    components.forEach(function (compEl, idx) {
      compEl.removeEventListener('click', compClickHandlers[idx]);
      compEl.classList.remove('active');
    });
    clearTnodePulse();
    if (detailEl) detailEl.innerHTML = '';
  };
};

/* =====================================================
   完整 hook 源码参考：
   - L4 hermes-html-ppt/js/interactive.js（共 16+ 个完整 hook）
   - 关键模式覆盖：
     * 三柱架构 + 时序联动     → S07 (L803-971)
     * 4-tab navigator         → S18 (L24-208)
     * dual slogan toggle      → S05 (L226-)
     * particle flow animation → S08 (L983-)
     * SQLite schema viz       → S09 (L1461-)
     * FTS5 dual-index demo    → S10 (L1641-)
     * full-cycle dialog flow  → S12 (L1906-)
     * step-reveal lifecycle   → S17/S22
   ===================================================== */
