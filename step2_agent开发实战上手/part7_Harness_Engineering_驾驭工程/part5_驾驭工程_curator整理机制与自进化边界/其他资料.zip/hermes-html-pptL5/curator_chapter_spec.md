# L5 第 1 章 + 开篇衔接区 HTML Slide 设计规格

> **用途**：作为 `/html-courseware-team --resume` 时 slide-writer / interactive-eng 的输入约束。
> **生成日期**：2026-05-11（v1）/ 2026-05-12（v2 升级）
> **当前版本**：v2（开篇衔接 3 页 + C2 重做 + C4 含 Umbrella mini）
> **L5 章节定位**：开篇衔接区（lesson 第 0 章压缩）+ 第 1 章 Curator 定期整理机制
> **总 slide 数**：10（封面 1 + 开篇 3 + 第 1 章 6）
> **当前进度**：v1 已交付 6 页 IDC A 级，v2 待执行（3 新页 + S06 重做 + S08 微调）

---

## 0. v2 改动概要（2026-05-12）

**问题诊断（基于 lesson.md 第 1 章梳理）**：
1. v1 缺"贯穿 L4→L5"开篇衔接区，学员上来直接进 Curator 缺认知锚点
2. v1 第 1 章 6 页顺序错位（C2 Umbrella 终态前置 + lesson 1.1 三大问题动机缺失 + C4 Phase 2 Umbrella 重复）

**v2 调整**：
- 新增开篇 3 页（S02/S03/S04）承接 lesson 第 0 章（精简版，0.4 环境准备不进 HTML）
- 第 1 章 C2 完全重做为"为什么需要 Curator"（lesson 1.1），Umbrella 4 步动画视觉资产搬入 C4 Phase 2 tab 内嵌 mini
- S09 (C5) 暂不动（snapshot/血统补充留待后续）

**改名映射（执行时按表操作）**：

| 旧位置 | 新位置 | 操作 | 备注 |
|---|---|---|---|
| S01-cover.html | S01-cover.html | 保留 | 不动 |
| — | S02-series-finale-position.html | **新建** | 🟢 时间轴 |
| — | S03-intuition-shattering.html | **新建** | 🟡 灵魂 step-reveal |
| — | S04-three-lines-and-failures.html | **新建** | 🟡 三柱+底部 chip |
| S02-curator-chapter-intro.html | S05-curator-chapter-intro.html | **改名** | C1 内容不动 |
| S03-curator-umbrella-consolidation.html | **删除** | 视觉资产搬入 S08 | 原 C2 废弃 |
| — | S06-curator-why-needed.html | **新建** | C2 重做 lesson 1.1 |
| S04-curator-four-gates.html | S07-curator-four-gates.html | **改名** | C3 内容不动 |
| S05-curator-two-phases.html | S08-curator-two-phases.html | **改名+微调** | C4 加 Umbrella mini |
| S06-curator-rules-and-myths.html | S09-curator-rules-and-myths.html | **改名** | C5 内容不动 |
| S07-curator-full-run.html | S10-curator-full-run.html | **改名** | C6 内容不动 |

---

## 1. 整体节奏（v2 · 10 页）

```
[S01 封面]                                          保留
   ↓ ────────── 开篇衔接区（lesson 第 0 章压缩）──────────
[S02 系列终章定位]    5 节时间轴+前 4 节带走         🟢 静态
   ↓
[S03 直觉打碎表]      5 行逐行揭示+源码 L 行号       🟡 step-reveal 灵魂
   ↓
[S04 三主线+四维尺+失败模式] 上半三柱 + 底部 chip    🟡 三柱
   ↓ ────────── 第 1 章 Curator 定期整理机制 ──────────
[S05 = C1 章过渡]     引言+5 节小目录                🟢 纯 CSS 入场
   ↓
[S06 = C2 为什么需要] 3 大问题 step-reveal           🟡 step-reveal
   ↓                 ①虚假产出 ②patch 腐蚀 ③token 爆炸
[S07 = C3 4 闸门]     4 道纵向 checklist+L 行号      🟡 step-reveal
   ↓                 first-run 重点展开
[S08 = C4 两段执行]   tab P1/P2 + 时序条 + P2 内嵌    🔴🔴 复合
   ↓                 Umbrella 4 步 mini 动画
[S09 = C5 规则+误解]  左 5 规则 click 展开            🔴 click-detail
   ↓                 右 3 误解 toggle 揭晓
[S10 = C6 完整运行]   沉浸式终端模拟器                🔴🔴 灵魂页
                     hermes gateway start 全链路
```

**重交互页占比**：2/10 = 20%（C4 + C6，恰好红线）✓
**新页 IDC 目标**：S03/S04 灵魂 + 全部 A 级

---

## 2. 每页详细规格

> **🔴 写每页内容前必读** `~/.claude/skills/html-courseware-team/references/content-density-constitution.md`
>
> **IDC 4 问硬约束**：每个 step / card / column 必须答完：
> - **[W] What 是什么**：一句话定义
> - **[Y] Why 为什么**：机制/原理（不只是结论）
> - **[E] Example 例子**：具体场景/数据/类比
> - **[A] Anchor 锚点**：源码 L 行号/docstring
>
> **整页交付硬门控**：所有 step ≥ B 级（3 项有）且 ≥ 1 个 A 级（W/Y/E/A 全有，灵魂 step）。任一 C 级整页不通过。
>
> **机制可见性**：safety 类 ≥ 3 条护栏 / philosophy 类 ≥ 2 维度 / mechanism 类 时序+对比+源码 三选二。
>
> **跨 step 均衡**：字数差 / DOM 节点数差 ≤ 2 倍。
>
> **字号层级铁律**：L1 中文核心 > L2 中文机制 > L3 英文 chip > L4 行号。


### S02 系列终章定位（🟢 静态 · 时间轴）· v2 新增

**对应 lesson**：开篇 ¶3 + § 0.1 § 0.2 时间轴部分

**结构**：

- 标题：`L5 · 系列终章 5/5`（顶部 amber badge "5/5"）
- 5 节横向时间轴节点：

  ```
  L1 认知地图 ─→ L2 mini-Harness ─→ L3 DeepAgents ─→ L4 Hermes 记忆+Nudge ─→ L5【终章】
  三支柱八故障   11 机制+token 压缩   4 大组件+8 步      三层记忆+四维评价尺      7 件产物
                                                                              ⓟ pulse
  ```

- 每节点下方一句话产物 chip（小字）
- L5 节点 amber pulse + 装饰光环
- 底部"今天三块拼图收口"：Curator 整理机制 / ContextVar 血统隔离 / 自进化诚实边界（三个琥珀边框 chip）

**交互**：纯 CSS 入场序列（badge → 5 节点依次浮入 → L5 pulse → 三块拼图 chip 浮现），无 JS hook

**IDC 自检目标**：
- W: ✓ L5 是终章
- Y: ✓ 三块拼图收口 + 四家四维横评
- E: ✓ 5 节横向时间轴
- A: ✓ 5 节产物 chip + 三块拼图 chip
- → **A 级**

**对照 L4 模板**：`_reference/slide_chapter-intro.html`（章过渡同构 + 时间轴入场）

**实现注意**：
- 时间轴箭头用 SVG path，不用纯 CSS triangle（避免响应式变形）
- L5 pulse 用 `s02-pulse-amber` keyframes（参考 S01 cover）
- 三块拼图 chip 颜色：amber `#d4a574` / teal `#7dd3c0` / 警示红 `#e57373`

---

### S03 直觉打碎表（🟡 灵魂 step-reveal 5 行）· v2 新增

**对应 lesson**：表 0-1 全文（5 行核心错觉）

**结构**：

- 标题：`心里的直觉 vs 源码的实际`（副标题 `5 个高频错觉，今天逐一打碎`）
- 表格 5 行 × 3 列（直觉假设 | 源码实际 | 锚点章节）：

  | 心里的直觉假设 | 源码实际 | 锚点 |
  |---|---|---|
  | GEPA 装上 hermes 就能跑，默认链路 | 独立子项目 `hermes-agent-self-evolution`，`Phase 1 [√]` ≠ 端到端可跑 | 第 3.4.3 节 |
  | Curator 是 cron daemon，按时间自动跑 | `idle-triggered` + `should_run_now()` 4 道闸门 | 第 1.2 节（S07） |
  | Curator 跑起来会删旧 skill | **永远不删**，最大 archive（移 `.archive/` 可恢复）| 第 1.3 + 1.5 节（S08/S09）|
  | 用户手写的 skill 也被 Curator 整理 | 只动 `created_by="agent"`，手写隔离 | 第 2 章全章 |
  | "越用越强" = 模型参数变聪明 | 是 **prompt 注入质量**提升，模型本身不变 | 第 3.2.1 节 |

- 进度指示 `Step 1/5 → 5/5`
- 底部铁律句（5 行揭完后浮现）：
  ```
  ❝ Phase 1 [√] 不等于端到端可跑，README 的"已实现"标记需要亲手 grep 验证 ❞
  ```

**交互**：
- 点击 / →（方向键）推进，每按一次揭示一行"源码实际"列（amber 高亮浮入）
- 已揭示的行保留（不消失），未揭示的"源码实际"列显示为 `?`
- 锚点列每行有 chip（hover 显示更多 L 行号）
- 5 行揭完后底部铁律句 fade-up

**IDC 自检目标**：
- W: ✓ 5 个直觉错觉
- Y: ✓ 每行源码实际给原因
- E: ✓ 每行有具体反例
- A: ✓ 每行锚点章节 + 部分 L 行号
- → **A 级灵魂 step**（5 行全 A 级，整页灵魂页）

**对照 L4 模板**：`_reference/hook_examples.js` 模板 B step-reveal

**实现注意**：
- 5 行用 `data-step="1-5"` 标识
- `data-revealed` 类标记已揭示行（CSS 切换 `?` ↔ 实际内容）
- timerIds[] 收拢推进动画的 setTimeout
- cleanup 必须 reset 所有行到 step=0 状态

---

### S04 三主线 + 四维尺 + 业界失败模式（🟡 三柱 + 底部 chip）· v2 新增

**对应 lesson**：§ 0.2（三条主线 + 四维评价尺）+ § 0.3（业界失败模式）合并

**结构**：

#### 上半：三柱布局

```
┌─ 主线 1 ──┐  ┌─ 主线 2 ──┐  ┌─ 主线 3 ──┐
Curator 怎么管  血统是否会覆盖   越用越强 真假？
（第 1 章）     （第 2 章）       （第 3 章）

idle-triggered  ContextVar 78 行  Phase 1 √ ≠ 跑通
永远不删 archive  fork agent 隔离  prompt 提升 ≠ 模型
Phase 1 + 2     5 月修复            分层诚实告知
```

**中部隔条**：四维评价尺 4 chip（与三柱垂直分隔，单行）

```
─── 四维评价尺（系列产出）───────────────────
[GC 动态化]  [AC 架构约束]  [CE 上下文工程]  [入口治理]
─────────────────────────────────────────────
```

#### 下半：业界失败模式 4 chip 横排

```
🔴 ① 自评估过度自信     ⚪ ② 手动编辑被覆盖
   "It always thinks      （5 月已修复 →
    it did a good job"     第 2 章 ContextVar）
    107 票 Reddit

🟡 ③ 配置迁移灾难       🟡 ④ 小模型工具调用频出错
   多版本 hermes          mini/haiku 类小模型
   配置不兼容             tool_use 解析失败
```

- 顶部来源 chip：`r/openclaw on Reddit · 半年累计`
- 底部一行：`今天的目的不是揭穿哪家不诚实，而是教你怎么读任何 agent 产品的 marketing`

**交互**：
- 三柱可点击展开各自详情卡片（独立 state，互斥展开）
- 四维尺 4 chip hover 显示动机一句话
- 4 失败模式 chip 点击展开"根因+是否已修复"小卡

**IDC 自检目标**：
- W: ✓ 三主线 + 四维尺 + 4 失败模式
- Y: ✓ 三主线对应章节 + 失败模式根因
- E: ✓ Reddit 107 票引用 + ContextVar 78 行
- A: ✓ 各章节回引 + r/openclaw 来源
- → **A 级**（虽然信息量大，但三段式分区清晰）

**对照 L4 模板**：S05 hermes-vs-openclaw（三柱+对比）

**实现注意（R3 防御）**：
- 三柱独立 BEM 命名空间：`.s04-line-1/2/3 / .s04-line-detail`
- 4 失败模式独立 state 对象，不共享 DOM
- 状态对象：`var linesState = {expanded: null}` + `var failuresState = {revealed: Set()}`
- 注意页内信息量大，必须分上下两区视觉切割（中部"四维尺"作为分隔带）

---

### C1 章过渡 · Curator 出场（🟢 静态）

**展示风格**：A 文字驱动（与 L4 S06 同构）

**结构**：

- 章节标签 `Chapter 1`
- 章标题 `Curator 定期整理机制`
- 破直觉引言（核心句）：

  ```
  ❝整合 ≠ 去重 ≠ 删除❞
  —— 图书管理员 ——
     不是清洁工
  ```

- 5 节小目录：
  - 1.1 它是什么
  - 1.2 什么时候跑
  - 1.3 两段执行
  - 1.4 5 条硬规则
  - 1.5 完整运行
- 进度条 5 节点 `●━━━━━━━━━━○○○○`

**交互**：无 JS，纯 CSS 入场序列（label → title → 装饰线 → 引言 → 目录 → 进度条）

**对照 L4 模板**：`_reference/slide_chapter-intro.html`（S06 章过渡）

**实现注意**：

- 引言一句话破直觉，不解释（解释留到 C2）
- 进度条 5 节点对应 C2-C5 + C6（C1 自己不算节点）

---

### C2 (S06) 为什么需要 Curator（🟡 3 问题 step-reveal）· v2 完全重做

**对应 lesson**：§ 1.1（Nudge 生产端缺什么 + 三大问题）

**展示风格**：A 3 问题卡片 step-reveal

**结构**：

#### 顶部引入（Step 0）

```
Nudge 是 skill 库的"生产端"——
每完成 N 个 turn 自动 fork 一个 agent 写新 skill 落盘
                ↓
              （问题来了）
跑 1000 次 task 可能产 1000 条 skill，没有质检会发生什么？
```

#### Step 1 · 虚假产出（红色卡片）

```
❝ It always thinks it did a good job. ALWAYS. ❞
                                        —— Reddit r/openclaw · 107 票
─────────────────────────────────────
self-evaluation 过度自信
→ Nudge fork 的 agent 经常觉得"这次写得很好"
→ 实际只是把同一常识用不同措辞重写 N 次
```

- 锚点 chip：`r/openclaw · 107 votes · 第 0.3 节失败模式 #1`

#### Step 2 · patch 腐蚀（橙色卡片）

```
skill 写完 → 后续 agent 反复 patch（遇新边界 case 就改一改）
                              ↓
content 越来越长 · 结构越来越乱 · 偏离初始设计意图
                              ↓
30 天后看 ~/.hermes/skills/ → 50% 看不出区别
```

- 锚点 chip：`lesson 1.1 § 自我验证的判断方法`

#### Step 3 · token 爆炸（青色卡片）

```
agent 每次做 task → prompt 注入相关 skill 元数据列表
                              ↓
skill 库 > 200 条 → 元数据扫描吃掉数千 token
                              ↓
其中一半同质 → prompt 浪费严重，主缓存被冲
```

- 锚点 chip：`第 1.4 节 fork agent 不污染主缓存（curator.py:21）`

#### Step 4 · 引出 Curator（amber 总结卡）

```
所以需要一个"质检员"——
按 idle 周扫一遍 agent 写的 skill 库
做状态管理（Phase 1）+ LLM 合并（Phase 2）
                ↓
            ⬇ next: 它怎么被叫醒？（C3 4 闸门）
```

**交互**：
- 点击 / 方向键推进 Step 0 → 1 → 2 → 3 → 4
- 上一步卡片保留，下一步 fade-up
- 三个问题卡片颜色递进：红 → 橙 → 青（视觉张力递增）

**IDC 自检目标**：
- W: ✓ 3 大问题分别命名
- Y: ✓ 每问题根因解释（self-evaluation 过度自信 / patch 累积 / 元数据扫描成本）
- E: ✓ Reddit 107 票 / 50% 看不出区别 / 200 条数千 token
- A: ✓ 每问题源码 / lesson 章节 / Reddit 引用 chip
- → **A 级**（3 卡片各自 A 级）

**对照 L4 模板**：step-reveal lifecycle + 卡片入场 fade-up

**实现注意**：
- 5 个 step 用 `data-step="0/1/2/3/4"` 标识
- 三问题卡片颜色用 CSS 变量切换（不写硬 hex）：`--problem-red / --problem-orange / --problem-teal`
- 末尾引出 C3 的箭头用 amber 描边 + pulse 动画
- 与原 S03 Umbrella 视觉资产**完全不重叠**——Umbrella 已搬入 S08 Phase 2 tab

---

### C3 4 道闸门（🟡 step-reveal）

**展示风格**：B 垂直 checklist + L 行号

**结构**：

```
Curator should_run_now()
─────────────────────────
✓ G1: enabled        (L219)
✓ G2: not paused     (L221)
✓ G3: not first run  (L226)  ⚠ 最反直觉
   ├─ seed last_run_at = now
   ├─ defer 1 interval (默认 7 天)
   └─ 想绕过：hermes curator run --dry-run

   ⚠ dry-run 不仅绕过 G3，还跳过 Phase 1
      (L1295) —— 纯 report-only

✓ G4: past interval  (L247)
            ↓
        ✅ trigger run

  ──────────────────────────
  idle-triggered · NOT cron daemon
```

> ⚠ **教学修正 M3（必须）**：G3 footnote 注明 `--dry-run` 跳过 Phase 1（L1295）

**交互**：

- 4 道闸门顺序点亮（点击 / 方向键推进）
- hover G3 详情卡片浮出（first-run 三行重点展开）

**对照 L4 模板**：step-reveal 轻量版（无详情面板，仅闸门状态切换）

**实现注意**：

- 4 道闸门用 `<div class="c3-gate" data-gate-index="N">` 结构
- 已亮 = `.is-lit`，未亮 = `.is-pending`
- G3 高亮用 `⚠` 配琥珀色边框区别于 G1/G2/G4

---

### C4 两段执行（🔴🔴 上下分区）

**展示风格**：A 上下分区（tab 顶 + 时序条底）

**结构**：

#### 上方：Tab 切换

```
[Phase 1 ✓] [Phase 2]
──────────────────────
```

**Phase 1 tab 内容**：

- `apply_automatic_transitions()` (L255)
- 纯函数 / **不调 LLM**
- 时间戳决定状态：
  - `stale_after_days` (默认 30 天) → mark stale
  - `archive_after_days` (默认 90 天) → archive
  - 之前 stale，最近又用 → reactivate
- pinned skill **完全跳过**
- ⚠ **永不合并**（合并是 Phase 2 的活）

**Phase 2 tab 内容**：

- `run_curator_review` (L1278) → `_run_llm_review` (L1515)
- **fork AIAgent**（独立 agent）
- **auxiliary model**（不污染主缓存）

> ⚠ **教学修正 M2（必须）**：底部 footnote：
> "auxiliary model 是默认；未配置时会 fallback 到 main model (L1492) —— 诚实边界"

- 加载 `CURATOR_REVIEW_PROMPT` (L329-444)
- 5 条 hard rules 约束 LLM 决策（见 C5）

**v2 新增：Phase 2 tab 内嵌 Umbrella 4 步 mini 动画**（吸收原 C2 视觉资产）：

```
                    Umbrella 合并 4 步演示
─────────────────────────────────────────
Step 1 散乱:    ▢ debug-1024  ▢ port-conflict  ▢ restart-flow
                        ↓ （都属 hermes gateway 故障域）
Step 2 收伞:    🗂️ hermes-troubleshooting/
                  ├── debug-1024.md      （references/）
                  ├── port-conflict.md   （references/）
                  └── restart-flow.md    （references/）
Step 3 铁律:    ❝ Never auto-deletes — only archives ❞ · L17
Step 4 反偷懒:  ❝ <10 archives = stopped too early ❞ · L420-422
                              ↑（hermes 团队把"少做"当 bug 在管）
─────────────────────────────────────────
```

- Phase 2 tab 内独立 mini 区块（位置在 5 条 hard rules 之下、footnote 之上）
- 触发：Phase 2 tab 激活时自动播放 mini 动画（4 步 fade-up 序列）
- 切回 Phase 1 时 mini 动画 reset 到 Step 1 等待重播

#### 下方：时序条 7 节点（联动）

```
①open hermes → ②4 gates ✓ → ③Phase 1 ✨ → ④Phase 2 ✨ → ⑤REPORT.md
                                          ↑              ↑
                                  P1 tab 时该节点 pulse  P2 tab 时该节点 pulse
```

**交互**：

- Tab click 切换内容
- Tab 切换时对应时序节点 pulse（联动）
- 默认显示 Phase 1，节点 ③ pulse

**对照 L4 模板**：`_reference/slide_heavy-interact.html`（S07 三柱 + 时序条联动）

**实现注意（R1 防御）**：

- timerIds[] 统一收拢 tab 切换的 pulse 定时器
- cleanup 必须 removeEventListener tab click + clearTimeout pulse + reset tab state
- 单个 cleanup 函数处理两套交互，不要分离

---

### C5 5 规则 + 3 误解（🔴 click-detail）

**展示风格**：A 左右双列

**结构**：

#### 左侧：5 条硬规则（click 展开，同时只一条展开）

```
▶ R1 不动 bundled / hub-installed skill
▶ R2 不 delete，最大 archive（可恢复）
▶ R3 pinned 完全跳过
▶ R4 ⚡ 不许用 use_count==0 当借口拒绝合并
▶ R5 ⚡ 不许用 trigger 不同当借口拒绝合并
```

**R4 / R5 展开时**：

- 展示 "hermes 团队**反 LLM 偷懒**设计哲学" 的解释
- 与 C2 Step 4 反偷懒暗线 ⚡ 首尾呼应

#### 右侧：3 误解 toggle 揭晓（独立 state）

```
❌ Curator 是去重器
[▽ 揭晓]
─────────────
✅ 不是，是 umbrella 合并器
   （把窄 skill 收进伞 skill 的子段）

────────────────────────
❌ Curator 会删 skill
[▽ 揭晓]
─────────────
✅ 不会，最大破坏是 archive
   archive 移到 ~/.hermes/skills/.archive/
   可恢复

────────────────────────
❌ Curator 是后台 cron 进程
[▽ 揭晓]
─────────────
✅ 不是，idle-triggered
   用户不用 hermes 就不跑
```

**交互**：

- 左点击规则切换展开（active class 切换）
- 右点击 `[▽ 揭晓]` toggle 显示答案

**对照 L4 模板**：S07 详情面板渲染 + S31 总结自测

**实现注意（R2 + R3 防御）**：

- **R2**：规则展开区 `max-height: 280px` + `overflow-y: auto`，防小视口溢出
- **R3**：左右独立 BEM 命名空间：
  - 左：`.c5-rules-list / .c5-rule-item / .c5-rule-detail`
  - 右：`.c5-quiz-list / .c5-quiz-card / .c5-quiz-answer`
- state 对象独立维护：`var rulesState = {expandedRule: null}` / `var quizState = {revealed: Set()}`

---

### C6 完整运行 🔴🔴 灵魂页（沉浸式终端模拟器）

**展示风格**：A 沉浸式终端模拟器（最贴近 hermes 真实场景）

**结构**：

#### 顶部

```
$ hermes gateway start
[▶ 启动 Curator 模拟]      [⏸ 暂停] [↻ 重播]
```

#### 终端 stdout 5 段输出（打字机效果）

```
─────────────────────────────────────
> maybe_run_curator() invoked
> Gate 1: enabled ✓
> Gate 2: not paused ✓
> Gate 3: not first run ✓
> Gate 4: 8d > 7d interval ✓
─────────────────────────────────────
> Phase 1 starts...
  📁 skill-A (last 100d) → archive ✓
  📁 skill-B (last 45d)  → mark stale ✓
  📁 skill-C (active)    → no change
> Phase 1 done: 1 archived, 1 stale
─────────────────────────────────────
> Phase 2 forking aux agent...
  🤖 reviewing 12 agent-created skills
  🗂️  proposed merge: A+B+C → hermes-troubleshooting (umbrella)
  ✓ skill_manage executed
> Phase 2 done: 3 consolidations
─────────────────────────────────────
> REPORT.md written ✓
$ cat ~/.hermes/logs/curator/2026-05-11_03:00/REPORT.md

  ## Structured summary
  consolidations:
    - from: hermes-gateway-debug-1024
      into: hermes-troubleshooting
      reason: 同一故障域窄 skill
    ...
─────────────────────────────────────
```

**总时长**：30-45s（可调速）

**交互**：

- `[▶ 启动]` 触发整套动画
- 关键行 hover 显示源码 L 行号 tooltip：
  - `maybe_run_curator()` → L1656
  - `Phase 1 starts...` → L255
  - `Phase 2 forking aux agent` → L1515
  - `REPORT.md written` → L? (查源码)
- `[⏸ 暂停]` 中止打字机
- `[↻ 重播]` 重置 stdout 后重启

**对照 L4 模板**：S12 沉浸式对话框（章节灵魂页，977 行 hook 实现）

**实现注意（R1 防御）**：

- 打字机效果 = JS setInterval 逐字符插入，**所有 setInterval/setTimeout 必须 push 到 timerIds[]**
- cleanup 必须：
  ```js
  timerIds.forEach(clearTimeout);
  timerIds.forEach(clearInterval);
  stdoutEl.innerHTML = '';  // 重置内容
  startBtn.disabled = false;
  ```
- ⚡ 重播按钮：先调一次 cleanup-style reset，再重新启动动画
- 至少 3 处 `// ←FM1/FM2/FM3` 注释（quality-guard 验证）

---

## 3. 教学修正点（基于 trio 验证 · 必须落地）

> **trio 验证结论**：Opus + Codex 双视角验证用户给的 6 段内容 **95% 准确**，但 Codex 捞到 3 处需要修正/补充的事实。

| # | 位置 | 修正内容 | 来源 |
|---|---|---|---|
| **M1** | C2 Step 2 | "Phase 1 维护生命周期 + Phase 2 做伞合并，两件事并行"——纠正"只合并不维护"误解 | Codex PARTIAL ①：用户原文把 Phase 1 的维护性质弱化了 |
| **M2** | C4 P2 tab 底部 footnote | "auxiliary model 是默认，未配置时会 fallback 到 main model (L1492) —— 诚实边界" | Codex PARTIAL ④：aux 有 main fallback |
| **M3** | C3 G3 footnote + C6 演示 | `hermes curator run --dry-run` 绕过 G3 **同时跳过 Phase 1 自动转移**（L1295），纯 report-only | Codex 捞到 Opus 漏的事实 |

---

## 4. 实现风险（必须预防）

| # | 风险 | 防御策略 |
|---|---|---|
| **R1** | C4 / C6 复合交互 cleanup 泄漏 | timerIds[] 统一收拢 + removeEventListener 配对 + 单个 cleanup 函数；至少 3 处 `// ←FM` 注释 |
| **R2** | C5 双列在小视口（max-height: 740px）下溢出 | 规则展开区 `max-height: 280px + overflow-y: auto`；参照 L4 S07 响应式降级（max-height: 740px / 600px / 500px 三档断点） |
| **R3** | C5 左右 z-index 层叠混乱 | 独立 BEM 命名空间（`.c5-rules-*` vs `.c5-quiz-*`），独立 state 对象不共享 DOM 状态 |

---

## 5. 元约束（沿用 L4 视觉系统）

- ✅ CSS 变量 `:root` **不改**（颜色 / 字体 / 动效）
- ✅ 配色：琥珀 `#d4a574` + 冷青 `#7dd3c0` + 警示红 `#e57373`
- ✅ 蓝图网格背景保留
- ✅ 字体：Sora (display) / Inter (body) / Noto Sans SC / JetBrains Mono
- ✅ 所有 slideHook 必须 `return cleanup` 函数（FM-1）
- ✅ slide fragment 格式：`<style>...</style><div class="slide">...</div>`
- ✅ 所有 setTimeout / setInterval push 到 timerIds[]
- ✅ 所有 addEventListener 在 cleanup 中 removeEventListener
- ✅ 重交互页（C4 / C6）每页至少 3 处 `// ←FM1/FM2/FM3` 注释
- ✅ 响应式断点：`max-height: 740px / 600px / 500px` 三档
- ✅ `prefers-reduced-motion` 关闭所有动画

---

## 6. slideFiles / slideTitles / chapters · v2 · 10 页

修改 `js/main.js` 顶部三数组：

```js
var slideFiles = [
  'slides/S01-cover.html',
  // 开篇衔接区（v2 新增）
  'slides/S02-series-finale-position.html',         // 🟢 时间轴
  'slides/S03-intuition-shattering.html',           // 🟡 灵魂 step-reveal
  'slides/S04-three-lines-and-failures.html',       // 🟡 三柱+底部 chip
  // 第 1 章 Curator
  'slides/S05-curator-chapter-intro.html',          // C1 章过渡 🟢
  'slides/S06-curator-why-needed.html',             // C2 v2 重做 🟡
  'slides/S07-curator-four-gates.html',             // C3 4 闸门 🟡
  'slides/S08-curator-two-phases.html',             // C4 两段+Umbrella mini 🔴🔴
  'slides/S09-curator-rules-and-myths.html',        // C5 规则+误解 🔴
  'slides/S10-curator-full-run.html'                // C6 完整运行 🔴🔴
];

var slideTitles = [
  '课程封面 · L5 系列终章定位',
  '系列终章 · L1-L5 时间轴 + 三块拼图收口',
  '直觉打碎 · 5 个高频错觉逐一揭示',
  '三主线 + 四维评价尺 + 业界失败模式',
  '第 1 章 · Curator 定期整理机制（章过渡）',
  '为什么需要 Curator · Nudge 生产端的三大问题',
  'Curator 什么时候跑 · 4 道闸门 + idle-triggered',
  'Curator 两段执行 · Phase 1 纯函数 + Phase 2 Umbrella',
  'Curator 5 条硬规则 + 3 个常见误解',
  'Curator 完整运行 · hermes gateway 全链路演示'
];

var chapters = [
  { title: '系列终章 · L5 开场',           start: 0, end: 0 },
  { title: '开篇衔接 · 贯穿 L4→L5',         start: 1, end: 3 },
  { title: '第 1 章 · Curator 定期整理机制', start: 4, end: 9 }
  /* 第 2-5 章待规划 */
];
```

---

## 7. interactive.js hook 注册（v2 · 10 页路径）

需要的 hook（按新文件名）：

```js
// 开篇衔接区
// S02 系列终章定位（🟢）：纯 CSS 入场，无 hook
window.slideHooks['slides/S03-intuition-shattering.html']    = function () { /* 5 行 step-reveal */ };
window.slideHooks['slides/S04-three-lines-and-failures.html'] = function () { /* 三柱+底部 chip */ };

// 第 1 章
// S05 C1 章过渡（🟢）：纯 CSS 入场，无 hook
window.slideHooks['slides/S06-curator-why-needed.html']     = function () { /* C2 v2 重做 step-reveal */ };
window.slideHooks['slides/S07-curator-four-gates.html']     = function () { /* C3 4 闸门 step-reveal */ };
window.slideHooks['slides/S08-curator-two-phases.html']     = function () { /* C4 复合 + Umbrella mini */ };
window.slideHooks['slides/S09-curator-rules-and-myths.html'] = function () { /* C5 双列 click-detail */ };
window.slideHooks['slides/S10-curator-full-run.html']       = function () { /* C6 终端模拟器 */ };
```

🟢 静态页（S02 / S05）无 hook。
🟡 step-reveal 页（S03 / S04 / S06 / S07）：JS 控制 step + cleanup。
🔴 click-detail 页（S09）：左规则展开 + 右误解 toggle。
🔴🔴 复合页（S08 / S10）：tab + 时序条 / 终端模拟器。

```js
window.slideHooks['slides/S06-curator-rules-and-myths.html'] = function () { /* C5 */ };
```

总计新增 hook：**3-4 个**（C5 + C4 + C6 必需，C2/C3 可选）

参考模板：`_reference/hook_examples.js`（模板 A tab-switch + 模板 B step-reveal）

---

## 8. trio 源码验证留存（slide-writer 可对照核实）

| 用户断言 | Opus 验证 | Codex 验证 | 关键行号 |
|---|---|---|---|
| Umbrella consolidation 是本质 | ✓ | ⚠ PARTIAL（Phase 1 也做维护） | L329 (PROMPT) + L255 (P1) |
| idle-triggered，不污染主缓存 | ✓ | ✓ + 还发现 `skip_context_files/skip_memory` | L3 docstring + L1584 |
| should_run_now 4 道 gate | ✓ | ✓ | L198-248 (L219/L221/L226/L247) |
| Phase 1 纯函数 + Phase 2 LLM | ✓ | ⚠ PARTIAL（aux 有 main fallback） | L255 (P1) + L1278/L1515 (P2) + L1492 (fallback) |
| 5 条 hard rules | ✓ | ✓ | L329-444（rules 344-358） |
| "<10 archives = bug" | ✓ | ✓ | L420-422 |

**新增事实（Codex 捞到 Opus 漏的）**：`dry-run 跳过 Phase 1 自动转移` — L1295

**docstring 元事实**：
- "auxiliary-model task that periodically reviews agent-created skills" (L3)
- "Never auto-deletes — only archives" (L17 invariants)
- "Only touches agent-created skills" (L18)
- "Pinned skills bypass all auto-transitions" (L20)
- "Uses the auxiliary client; never touches the main session's prompt cache" (L21)

---

## 9. 下一步行动

### 在新会话中触发 slide 生成

```
/html-courseware-team --resume /Users/mac/PycharmProjects/JupyterProject/HarnessEngineering/HermesAgentL5/hermes-html-pptL5/

# 在 prompt 中包含：
# - 本 spec 路径：./curator_chapter_spec.md
# - 仅生成第 1 章 6 页（C1-C6）
# - 沿用本 spec 的所有设计决策（不重新讨论）
# - L5 课件仍在调整，仅产 Curator 章节，其他章节后续再做
```

### 生成完成验收

1. 启动 `python3 -m http.server 8000`
2. 浏览器打开 `http://localhost:8000`
3. 跳到第 2 页（C1 章过渡）开始顺序验收 6 页
4. 重点验收：
   - **C4**：tab 切换 + 时序条联动（pulse 是否同步）
   - **C5**：小视口下规则展开是否溢出
   - **C6**：终端打字机动画 30-45s 完整播放 + 暂停/重播
5. 钢笔（T） / 画板（D） / 全屏（F） / 目录（M） 五件套全功能验证

---

## 10. 修订记录

| 版本 | 日期 | 变更 |
|---|---|---|
| v1 | 2026-05-11 | 初版（trio 验证 + VOE 6 页拍板）|
| v2 | 2026-05-12 | 加开篇 3 页 + C2 重做 + C4 内嵌 Umbrella mini + 10 页改名映射 |

**拍板决策快照**：

- D1: ❶ C3 保持 🟡 step-reveal（不升级 🔴）
- D2: ❶ C5 合并 5 规则 + 3 误解（不拆 6 页）
- D3: ❷ C2 补"hermes 团队反 LLM 偷懒"暗线
- 新增 C6: 沉浸式终端模拟器（类 L4 S12 灵魂页）
- 6 页风格选择：C1:A / C2:A / C3:B / C4:A / C5:A / C6:A
