# OpenClaw 核心架构 · 第二节课（HTML 互动课件）

配合《OpenClaw 专题课第二节课：多智能体协作 × 上下文工程 × 记忆系统》（Jupyter 课件 `../lesson.md`）使用的课堂演示 HTML 课件。共 **25 页**，沿一根 context 主轴展开：当下组装（上下文工程）→ 分治隔离（多智能体）→ 持久来源（记忆系统）→ 收口成「三脑一轴」框架。

骨架/背景/风格完全继承第一节课（L3 浅珊瑚雾 Coral-Mist Molting 主题，`style_manifest.json` token 逐字段一致）。

## 运行方式

课件通过 `fetch` 动态加载 slide 页面，**不能直接双击 `index.html` 打开**（`file://` 协议下浏览器会拦截 fetch），必须起一个本地 HTTP 服务：

```bash
cd openclaw-html-ppt2
python3 -m http.server 8000
# 然后浏览器访问 http://localhost:8000
```

或使用 Node：

```bash
npx serve .
```

设计基准视口 **1440×810**（16:9 投影）；更大视口（如 2K 全屏）已做居中与连线自适应，可放心全屏讲。

## 操作说明

| 操作 | 按键 / 方式 |
| --- | --- |
| 翻页 | `←` / `→` 方向键，或底部导航按钮 |
| 直达某页 | 地址栏 hash，如 `http://localhost:8000/#15`（1 起始页码） |
| 目录面板（分章跳页） | `M` 键或工具栏目录按钮 |
| 钢笔（拖尾笔迹，1.2s 自动消隐） | `T` 键或工具栏钢笔按钮 |
| 画板（持久涂画） | `D` 键或工具栏画板按钮 |
| 全屏 | `F` 键或工具栏全屏按钮 |
| 笔迹颜色 | 工具栏颜色选择器 |

### 课堂演示要点（交互页）

| 页 | 怎么用 |
| --- | --- |
| S007 四层冰山 | 点「掀开水面」逐层揭示，最后一步「摊开算账 💰」切出成分账单（tool_result 72% 的反转时刻） |
| S008 五阶段管线 | 💣 给阶段注错 → 看安全网/熔断区接住谁（fail-closed 只有 compact/prepare 两个） |
| S010b 四道防线 | 进页自动投放 8 万字符灾难输出，按钮逐闸推进（L0 保尾 → L1 封顶 → L2 平行世界 → L3 路由） |
| S014 spawn 时序图 | 进页即全图（同一水平高度=同一时刻）；▶ 重播逐 stage 走，stage 3 是核心：main 虚线等待 vs sub 实心执行同高并排 |
| S015 四维实验台 | 四个维度按钮切换（再点同维度=收起）；lane 维度内有「演示填满+排队」按钮 |
| S016 多智能体谱系 | 四形态 tab 切换点亮通路（父子分治为默认主角）；地基横带常亮 |
| S018 记忆文件树 | 点左侧文件树任意项看职责卡；注意纯日期 vs 带时分两种文件名 = 两条来路 |
| S019 hybrid RAG | 进页自动跑一轮检索；可拖权重滑杆实时重算，体感"为什么偏向量" |
| S020 dreaming | 「快进到凌晨 3 点」启动管线，▶/⏸/⏭ 单步走 light→rem→deep |

## 内容结构（5 Part × 25 页）

| Part | 页 | 内容 |
| --- | --- | --- |
| Part 0 — 开场承上 | S001–S004 | 封面 / 上节五章产物回顾 / 单 agent 三堵墙 / 三脑一轴全景地图 |
| Part 1 — 上下文工程（重心） | S005–S011 | 章过渡 / proxy 旁路录音机四步观测链 / 四层 context 冰山+成分账单两幕剧 / **五阶段故障注入实验台**🔴🔴 / compact 压缩前后对比 / 进阶·四路路由判断树 / 进阶·四道防线流水线+prompt cache 暗线（S010b） / 章收口对账表+一扇门 |
| Part 2 — 多智能体 | S012–S016 | 章过渡 / 子 agent ≠ 线程认知重塑 / **spawn 垂直双泳道时序图**🔴🔴 / **两隔离两共享四维边界实验台**🔴🔴 / 多智能体谱系「一个地基+七种形态」互动拓扑 |
| Part 3 — 记忆系统（重心） | S017–S021 | 章过渡 / 记忆文件树探索器（3 文件 + dreaming 三处 + 三条自动来路） / **hybrid RAG 检索模拟器+权重滑杆**🔴🔴 / **dreaming 昼夜循环模拟器**🔴🔴 / 记忆后端全景（三档开放程度） |
| Part 4 — 收口 | S022–S024 | 三脑一轴回归+可迁移三问常驻 / 诚实边界+7 件产物自查 / 下节预告·跨渠道骨架 |

🔴🔴 标记为重交互模拟器页（S008 / S014 / S015 / S019 / S020），由 `js/interactive.js` 的 slideHooks 驱动；其余交互页（S007/S010b/S016/S018 等）交互逻辑内联在各自 slide 片段内。

## 目录结构

```
html-courseware/
├── index.html              # 主入口（导航骨架 + 工具栏）
├── css/main.css            # 全局样式（设计 token + 布局，继承第一节课零改动）
├── js/main.js              # 翻页引擎：slideFiles/slideTitles/chapters + 钢笔/画板/目录
├── js/interactive.js       # 重交互页 slideHooks（5 个模拟器的状态机）
├── slides/                 # 25 个独立 slide 页面（S001–S024，S010b 为插页）
├── confirmed_design.md     # 逐页设计契约 + 全部用户拍板记录（单一权威源，改页前必读）
├── style_manifest.json     # 视觉风格清单（L3 浅珊瑚雾 token，第三节课续作沿用）
└── README.md               # 本文件
```

## 维护注意

- **改任何页之前先读 `confirmed_design.md`**——它记录了每页的设计意图、用户拍板与历次重构原因；改完同步追加记录。
- 新增 / 删除 slide 时，`js/main.js` 里 **`slideFiles`、`slideTitles`、`chapters` 三个数组必须同步修改**（slideFiles 与 slideTitles 必须等长，chapters 区间须覆盖 0 到 length-1），并同步 `index.html` 的 `page-total` 初始值与 `style_manifest.json` 的 `total_slides`。
- 颜色禁止硬编码：一律用 `css/main.css` 的 `var()` token；页内局部色须在该页 wrap 上定义局部变量并注释用途。注意幽灵 token（引用不存在的 token 会静默 fallback 透明）。
- 重交互页 hook 注册键 = `'slides/SXXX-*.html'` 全路径；hook 必须 return cleanup（清 timer + 解绑监听 + `gsap.killTweensOf`）。**用了 `tl.tweenTo()` 的 timeline，kill 前必须先 `gsap.killTweensOf(tl)`**——漏杀会在切页后报 null 错误风暴（本课实战教训）。
- **SVG 运行时连线页（S011/S016）三重重画铁律**：连线是绝对坐标快照，①每次交互入口先重画 ②`document.fonts.ready` 后重画 ③`ResizeObserver` 跟随容器——缺一处就会在不同视口下断线。
- 视觉验收双口径：grep/DOM 探针过 ≠ 视觉过——改完跑一遍 `polish_audit.py`（`~/.claude/skills/html-courseware-team/scripts/`）再肉眼看截图；探针须含至少一档非 810 视口。
- 第三节课等续作请沿用 `style_manifest.json` 的设计 token，保持系列视觉一致。
