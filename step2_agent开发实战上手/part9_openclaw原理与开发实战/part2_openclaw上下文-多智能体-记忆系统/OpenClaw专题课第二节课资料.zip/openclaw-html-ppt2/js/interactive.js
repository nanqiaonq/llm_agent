/**
 * OpenClaw 核心架构 · 第二节课 — 重交互页 Hooks（骨架空壳，待内容生成填充）
 *
 * html-courseware-interactive-eng 将填充此文件。
 *
 * 键名格式：'slides/SXX-filename.html'（与 main.js slideFiles 数组完整路径一致）
 * 值格式：function() { ...; return function cleanup() { ... }; }
 *
 * cleanup 函数铁律（REF_golden_patterns.md §9 GSAP 安全模板）：
 *   - clearInterval / clearTimeout
 *   - gsap.killTweensOf() 或 timeline.kill()
 *   - removeEventListener（pointer/mouse 事件）
 *   - 防 null 早退也必须 return noop（FM-1）
 */
window.slideHooks = window.slideHooks || {};

/* ================= S008 hook（安全网剧场 · 2026-06-05 重构，方案 A） ================= */
/**
 * S008: ContextEngine 五阶段 · 安全网剧场
 * 交互：💣 注错开关（assemble/compact/prepare 可独立叠加）+ ▶ 发消息小球走管线
 *   - 无注错：小球流经五节点，assemble 处四层依次点亮 → 完成
 *   - assemble 注错：坠落 → 网1 fallback engine（注错持续，再试也失败）→ 坠落
 *     → 网2 catch 降级（log.warn 沿用已有消息）→ 回管线 compact 继续 →「turn 不崩」
 *   - compact / prepare 注错：坠落 → 熔断区 flash → 管线熄火 → TURN ABORTED
 *
 * FM 清单:
 *   FM-1 noop — DOM 缺失早退必须 return noop
 *   FM-2 GSAP cleanup — gsap.killTweensOf(tl) 前置 + tl.kill()（不使用 tweenTo/paused-fromTo，规避陷阱⑦⑧）
 *   FM-3 listener 全解绑 — btnSend + 3 个 bomb
 */
(function () {
  'use strict';
  window.slideHooks = window.slideHooks || {};

  window.slideHooks['slides/S008-engine-five-stages.html'] = function () {
    var root = document.querySelector('[data-slide-id="S008"]');
    if (!root) return function noop() {};  // ←FM-1

    var stage    = root.querySelector('#s008-stage');
    var ball     = root.querySelector('#s008-ball');
    var btnSend  = root.querySelector('#s008-btn-send');
    var statusEl = root.querySelector('#s008-status');
    var pipeline = root.querySelector('#s008-pipeline');
    var net1     = root.querySelector('#s008-net1');
    var net2     = root.querySelector('#s008-net2');
    var survive  = root.querySelector('#s008-survive');
    var melt     = root.querySelector('#s008-melt');
    var abortEl  = root.querySelector('#s008-abort');
    var nodes = {};
    ['bootstrap', 'ingest', 'assemble', 'compact', 'prepare'].forEach(function (k) {
      nodes[k] = root.querySelector('.s008-node[data-stage="' + k + '"]');
    });
    var layers = Array.prototype.slice.call(root.querySelectorAll('.s008-layer'));
    var bombs = {
      assemble: root.querySelector('#s008-bomb-assemble'),
      compact:  root.querySelector('#s008-bomb-compact'),
      prepare:  root.querySelector('#s008-bomb-prepare')
    };
    if (!stage || !ball || !btnSend || !nodes.bootstrap || !net1 || !melt) {
      return function noop() {};  // ←FM-1
    }

    var armed = { assemble: false, compact: false, prepare: false };
    var tl = null;

    function setStatus(text, fail) {
      if (!statusEl) return;
      statusEl.textContent = text;
      statusEl.classList.toggle('s008-status-fail', !!fail);
    }

    function pulse(key) {
      Object.keys(nodes).forEach(function (k) { nodes[k].classList.remove('passing'); });
      if (key && nodes[key]) nodes[key].classList.add('passing');
    }

    function killTl() {
      if (tl) {
        gsap.killTweensOf(tl);  // ←FM-2 防驱动 tween 残留（教训⑧同款防御）
        tl.kill();
        tl = null;
      }
    }

    function resetVisuals() {
      killTl();
      gsap.killTweensOf([ball, net1, net2]);
      pipeline.classList.remove('dead');
      Object.keys(nodes).forEach(function (k) { nodes[k].classList.remove('passing', 'exploding'); });
      layers.forEach(function (l) { l.classList.remove('lit'); });
      net1.classList.remove('s008-net-broken');
      net2.classList.remove('s008-net-broken');
      survive.classList.remove('shown');
      abortEl.classList.remove('shown');
      melt.classList.remove('flash');
      gsap.set([net1, net2], { y: 0 });
      gsap.set(ball, { opacity: 0, x: 0, y: 0 });
    }

    function run() {
      resetVisuals();
      btnSend.disabled = true;

      /* 运行时实时取坐标（相对 stage），避免 resize 后错位 */
      var sRect = stage.getBoundingClientRect();
      var bw = ball.offsetWidth;
      var pRect = pipeline.getBoundingClientRect();
      var lineY = pRect.top + pRect.height / 2 - sRect.top - bw / 2;  // 小球沿管线主线走
      function nodeX(key) {
        var r = nodes[key].getBoundingClientRect();
        return r.left + r.width / 2 - sRect.left - bw / 2;
      }
      function landY(el) {  // 落在元素顶沿
        var r = el.getBoundingClientRect();
        return r.top - sRect.top - bw + 3;
      }

      tl = gsap.timeline({
        onComplete: function () { btnSend.disabled = false; }
      });

      /* —— 入场：bootstrap → ingest —— */
      tl.set(ball, { x: nodeX('bootstrap') - 80, y: lineY, opacity: 0 });
      tl.to(ball, { opacity: 1, x: nodeX('bootstrap'), duration: 0.4, ease: 'power1.out' });
      tl.call(function () { pulse('bootstrap'); setStatus('bootstrap：初始化引擎，备好系统指令'); });
      tl.to(ball, { x: nodeX('ingest'), duration: 0.5, ease: 'power1.inOut' }, '+=0.45');
      tl.call(function () { pulse('ingest'); setStatus('ingest：把这条消息吃进消息列表'); });

      /* —— assemble：四层点亮 —— */
      tl.to(ball, { x: nodeX('assemble'), duration: 0.5, ease: 'power1.inOut' }, '+=0.45');
      tl.call(function () { pulse('assemble'); setStatus('assemble：四层组装中…'); });
      layers.forEach(function (layer, i) {
        tl.call(function () { layer.classList.add('lit'); }, null, '+=0.28');
      });

      if (armed.assemble) {
        /* 爆点 → 网1 → 网2 → 回管线 */
        tl.call(function () {
          nodes.assemble.classList.add('exploding');
          layers.forEach(function (l) { l.classList.remove('lit'); });
          setStatus('assemble 注错 💥 组装失败——坠落！', true);
        }, null, '+=0.3');
        tl.to(ball, { y: landY(net1), duration: 0.55, ease: 'power2.in' }, '+=0.45');
        tl.to(net1, { y: 7, duration: 0.12, ease: 'power1.out' });
        tl.to(net1, { y: 0, duration: 0.32, ease: 'back.out(2.5)' });
        tl.call(function () {
          nodes.assemble.classList.remove('exploding');
          setStatus('安全网 1：换备用引擎再试一次……注错持续，仍然失败', true);
        });
        tl.call(function () { net1.classList.add('s008-net-broken'); }, null, '+=0.7');
        tl.to(ball, { y: landY(net2), duration: 0.5, ease: 'power2.in' }, '+=0.1');
        tl.to(net2, { y: 7, duration: 0.12, ease: 'power1.out' });
        tl.to(net2, { y: 0, duration: 0.32, ease: 'back.out(2.5)' });
        tl.call(function () {
          setStatus('安全网 2：catch 接住 → log.warn，放弃本次组装，沿用已有消息');
        });
        tl.call(function () { survive.classList.add('shown'); }, null, '+=0.5');
        tl.to(ball, { x: nodeX('compact'), y: lineY, duration: 0.85, ease: 'power1.inOut' }, '+=0.55');
        tl.call(function () { pulse('compact'); setStatus('降级续跑 → compact'); });
      } else {
        tl.call(function () { setStatus('context_assembled ✓ —— 这就是 proxy blob 里那个请求体'); }, null, '+=0.3');
        tl.to(ball, { x: nodeX('compact'), duration: 0.5, ease: 'power1.inOut' }, '+=0.5');
        tl.call(function () { pulse('compact'); setStatus('compact：历史没逼上限，本轮直接通过'); });
      }

      /* —— compact —— */
      if (armed.compact) {
        addDeath('compact', 'compact 注错 💥 fail-closed——rethrow！');
        return;
      }

      /* —— prepare —— */
      tl.to(ball, { x: nodeX('prepare'), duration: 0.5, ease: 'power1.inOut' }, '+=0.45');
      if (armed.prepare) {
        tl.call(function () { pulse('prepare'); });
        addDeath('prepare', 'prepareSubagentSpawn 注错 💥 fail-closed——rethrow！');
        return;
      }
      tl.call(function () { pulse('prepare'); setStatus('prepareSubagentSpawn：本轮不派生子 agent，通过'); });
      tl.to(ball, { x: nodeX('prepare') + 90, opacity: 0, duration: 0.5, ease: 'power1.in' }, '+=0.45');
      tl.call(function () {
        pulse(null);
        setStatus('✓ 完成：context 已发给模型，turn 正常结束');
      });

      function addDeath(key, msg) {
        tl.call(function () {
          nodes[key].classList.add('exploding');
          setStatus(msg, true);
        }, null, '+=0.35');
        tl.to(ball, { y: landY(melt), duration: 0.7, ease: 'power2.in' }, '+=0.5');
        tl.call(function () {
          melt.classList.add('flash');
          abortEl.classList.add('shown');
          pipeline.classList.add('dead');
          pulse(null);
          setStatus('✗ TURN ABORTED：当场中止——半成品比失败更危险', true);
        });
        tl.to(ball, { opacity: 0, duration: 0.6, ease: 'power1.out' }, '+=0.8');
      }
    }

    /* —— 事件绑定（FM-3：全部具名，cleanup 解绑） —— */
    function onSend() { run(); }
    btnSend.addEventListener('click', onSend);

    var bombHandlers = {};
    Object.keys(bombs).forEach(function (key) {
      if (!bombs[key]) return;
      bombHandlers[key] = function (ev) {
        ev.stopPropagation();
        armed[key] = !armed[key];
        bombs[key].classList.toggle('armed', armed[key]);
      };
      bombs[key].addEventListener('click', bombHandlers[key]);
    });

    /* —— cleanup（FM-2 + FM-3） —— */
    return function cleanup() {
      killTl();
      gsap.killTweensOf([ball, net1, net2]);
      btnSend.removeEventListener('click', onSend);
      Object.keys(bombHandlers).forEach(function (key) {
        if (bombs[key]) bombs[key].removeEventListener('click', bombHandlers[key]);
      });
    };
  };
})();

/* ================= S014 hook（垂直双泳道时序图 · 2026-06-05 重构，方案 A） ================= */
/* ============================================================
 * S014 spawn 生命周期：非阻塞与 announce — 垂直双泳道时序图
 * hookFn key: window.slideHooks['slides/S014-spawn-lifecycle.html']
 *
 * 5 stage 步进：1=spawn+accepted(非阻塞) 2=yield 让台 3=等待vs执行并行(核心)
 *               4=announce 回报 5=新turn。纯 DOM class 切换 + setTimeout 自动播放，
 *               无 GSAP（彻底规避陷阱⑦ paused-fromTo / 陷阱⑧ tweenTo 孤儿）。
 * 初始态 = stage 5 全图点亮（首屏即见完整时序，重播再逐段走）。
 *
 * FM 清单:
 *   FM-1 noop — DOM 缺失早退必须 return noop，禁 return undefined
 *   FM-3 事件解绑 — removeEventListener 全部具名 handler + clearTimeout
 * ============================================================ */
(function () {
  window.slideHooks = window.slideHooks || {};

  window.slideHooks['slides/S014-spawn-lifecycle.html'] = function () {
    /* FM 清单: FM-1 noop / FM-3 handler 全解绑 + clearTimeout */

    var slide = document.querySelector('[data-slide-id="S014"]');
    if (!slide) return function noop() {};  // ←FM-1

    var btnPlay  = slide.querySelector('#s014-play');
    var btnPause = slide.querySelector('#s014-pause');
    var btnStep  = slide.querySelector('#s014-step');
    var dots     = slide.querySelectorAll('#s014-dots .s014-dot');
    var label    = slide.querySelector('#s014-stage-label');
    var caption  = slide.querySelector('#s014-caption');
    var rows     = slide.querySelectorAll('.s014-row');
    if (!btnPlay || !btnPause || !btnStep || !rows.length) return function noop() {};  // ←FM-1

    /* 行 → 所属 stage（data-row 1..8） */
    var ROW_STAGE = { 1: 1, 2: 1, 3: 2, 4: 3, 5: 3, 6: 3, 7: 4, 8: 5 };

    var STAGES = [
      { name: '非阻塞派生',
        text: '<b>⚡ 非阻塞铁证</b>：spawn 发出与 <code>{accepted, runId, childSessionKey}</code> 返回几乎同时——main 一毫秒都没等；同一高度右边，子 agent 才刚进队列。' },
      { name: 'yield 让台',
        text: '<b>正确等待姿势</b>：<code>sessions_yield</code> 主动结束 turn——不是阻塞等待，是把舞台让出来（"results arrive as next message"）。' },
      { name: '并行时段（核心）',
        text: '<b>本页核心</b>：左边 main 已退场（虚线等待段 · 不占资源），<b>同一高度</b>右边 sub 正在干活——这就是"非阻塞分治"的样子。' },
      { name: 'announce 回报',
        text: '<b>announce</b> 把结果包装成完成事件推回——平台层主动推送、best-effort（gateway 重启会丢），不是工具调用的返回值。' },
      { name: '新 turn 收结果',
        text: 'main 以<b>新 turn</b> 回场处理结果。回看全图：main 全程没有一秒在空转轮询。' }
    ];

    var stage = 0;        // 0=待命, 1..5
    var timer = null;     // ←FM-3 清理对象
    var playing = false;

    function render() {
      rows.forEach(function (row) {
        var rs = ROW_STAGE[parseInt(row.getAttribute('data-row'), 10)] || 99;
        row.classList.toggle('done', rs < stage);
        row.classList.toggle('now', rs === stage);
      });
      dots.forEach(function (d, i) { d.classList.toggle('on', i < stage); });
      if (label) {
        label.textContent = stage === 0 ? 'stage 0/5 · 待命'
          : 'stage ' + stage + '/5 · ' + STAGES[stage - 1].name;
      }
      if (caption && stage > 0) caption.innerHTML = STAGES[stage - 1].text;
    }

    function setStage(n) {
      stage = Math.max(0, Math.min(5, n));
      render();
    }

    function stopTimer() {
      playing = false;
      if (timer) { clearTimeout(timer); timer = null; }
    }

    function tick() {
      if (!playing) return;
      if (stage >= 5) { playing = false; return; }
      setStage(stage + 1);
      timer = setTimeout(tick, 1700);
    }

    function handlePlay() {
      stopTimer();
      setStage(0);
      playing = true;
      timer = setTimeout(tick, 350);
    }
    function handlePause() { stopTimer(); }
    function handleStep() {
      stopTimer();
      setStage(stage >= 5 ? 1 : stage + 1);
    }

    btnPlay.addEventListener('click', handlePlay);
    btnPause.addEventListener('click', handlePause);
    btnStep.addEventListener('click', handleStep);

    /* 初始态：全图点亮（首屏即见完整时序），caption 保持引导文案 */
    setStage(5);
    if (caption) caption.innerHTML = '完整时序已展示——本图的几何约束：<b>同一水平高度 = 同一时刻</b>。点 <b>▶ 重播</b> 逐段走一遍。';
    if (label) label.textContent = 'stage 5/5 · 完整时序';

    return function cleanup() {
      stopTimer();  // ←FM-3
      btnPlay.removeEventListener('click', handlePlay);    // ←FM-3
      btnPause.removeEventListener('click', handlePause);  // ←FM-3
      btnStep.removeEventListener('click', handleStep);    // ←FM-3
    };
  };
})();

/* ================= S015 hook（合并自 js/hooks/S015.hook.js） ================= */
/* S015 两隔离两共享：四维边界实验台 · 独立 IIFE hook
 * FM 清单: FM-1 lane setInterval / FM-2 GSAP killTweensOf + tl.kill / FM-3 click handler removeEventListener
 */
(function () {
  'use strict';

  window.slideHooks = window.slideHooks || {};

  window.slideHooks['slides/S015-isolation-share-lab.html'] = function () {
    /* FM 清单: FM-1 lane setInterval clearInterval /
                FM-2 GSAP killTweensOf + tl.kill /
                FM-3 所有 click handler via listeners 数组解绑 */

    var root = document.querySelector('[data-slide="s015"]');
    if (!root) return function noop() {}; // ←FM-2 防 null 早退

    // ─── 闭包状态 ───────────────────────────────────────────
    var state = {
      activeDim: null,       // null | 'session' | 'context' | 'lane' | 'auth'
      contextMode: 'isolated' // 'isolated' | 'fork'
    };
    var laneTimer = null;    // setInterval handle ←FM-1
    var laneCount = 0;       // 当前已填槽数
    var tl = null;           // 入场 timeline ←FM-2
    var entranceTimer = null; // setTimeout ←FM-1（也需要清）
    var listeners = [];       // [[el, evt, fn], ...] ←FM-3

    // ─── 具名注册（便于 removeEventListener）───────────────
    function on(el, evt, fn) {
      if (!el) return;
      el.addEventListener(evt, fn);
      listeners.push([el, evt, fn]);
    }

    // ─── DOM 引用 ─────────────────────────────────────────
    var line       = root.querySelector('[data-s015-line]');
    var badge      = root.querySelector('[data-s015-badge]');
    var dimBtns    = Array.prototype.slice.call(root.querySelectorAll('[data-s015-dim]'));
    var detailPanels = Array.prototype.slice.call(root.querySelectorAll('[data-s015-detail]'));
    var ctxBtns    = Array.prototype.slice.call(root.querySelectorAll('[data-s015-ctx]'));
    var ctxPanels  = Array.prototype.slice.call(root.querySelectorAll('[data-s015-ctx-panel]'));
    var laneRunBtn = root.querySelector('[data-s015-lane-run]');
    var slots      = Array.prototype.slice.call(root.querySelectorAll('[data-s015-slot]'));
    var pendingSlot  = root.querySelector('[data-s015-pending]');
    var pendingLabel = root.querySelector('[data-s015-pending-label]');

    // ─── 连线更新 ─────────────────────────────────────────
    function updateConnector(dim, ctxMode) {
      if (!line || !badge) return;

      // 重置
      line.className = 's015-connector-line';
      badge.className = 's015-connector-badge';
      badge.textContent = '';

      if (!dim) return;

      line.classList.add('show');

      if (dim === 'session') {
        line.classList.add('isolated');
        badge.classList.add('show', 'iso');
        badge.textContent = '✂ 独立 session';
      } else if (dim === 'context') {
        if (ctxMode === 'fork') {
          line.classList.add('fork');
          badge.classList.add('show', 'shr');
          badge.textContent = '⤵ fork 复制';
        } else {
          line.classList.add('isolated');
          badge.classList.add('show', 'iso');
          badge.textContent = '✂ isolated';
        }
      } else if (dim === 'lane') {
        line.classList.add('shared');
        badge.classList.add('show', 'shr');
        badge.textContent = '⟶ 共享 lane';
      } else if (dim === 'auth') {
        line.classList.add('shared');
        badge.classList.add('show', 'shr');
        badge.textContent = '⟶ 共享 auth';
      }
    }

    // ─── 详情区切换 ──────────────────────────────────────
    function showDetail(key) {
      detailPanels.forEach(function (panel) {
        var k = panel.getAttribute('data-s015-detail');
        if (k === key) {
          panel.classList.add('active');
        } else {
          panel.classList.remove('active');
        }
      });
    }

    // ─── 维度切换主逻辑 ───────────────────────────────────
    function setDim(dim) {
      // 若再次点击同维度 → 关闭
      if (state.activeDim === dim) {
        state.activeDim = null;
      } else {
        state.activeDim = dim;
      }

      // 按钮激活态
      dimBtns.forEach(function (btn) {
        var d = btn.getAttribute('data-s015-dim');
        if (d === state.activeDim) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });

      // 连线
      updateConnector(state.activeDim, state.contextMode);

      // 详情区
      if (!state.activeDim) {
        showDetail('empty');
      } else {
        showDetail(state.activeDim);
      }

      // lane 切出时停止演示
      if (state.activeDim !== 'lane') {
        stopLaneDemo();
      }
    }

    // ─── context 子开关 ───────────────────────────────────
    function setContextMode(mode) {
      state.contextMode = mode;

      ctxBtns.forEach(function (btn) {
        if (btn.getAttribute('data-s015-ctx') === mode) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });

      ctxPanels.forEach(function (panel) {
        if (panel.getAttribute('data-s015-ctx-panel') === mode) {
          panel.classList.add('active');
        } else {
          panel.classList.remove('active');
        }
      });

      // 同步连线（若 context 维度当前激活）
      if (state.activeDim === 'context') {
        updateConnector('context', state.contextMode);
      }
    }

    // ─── lane 演示 ────────────────────────────────────────
    function resetSlots() {
      laneCount = 0;
      slots.forEach(function (slot) {
        slot.classList.remove('occupied', 'pending');
        // 第 9 个槽（pending）隐藏
        if (slot.getAttribute('data-s015-slot') === '8') {
          slot.style.display = 'none';
        }
      });
      if (pendingSlot) { pendingSlot.style.display = 'none'; }
      if (pendingLabel) { pendingLabel.style.display = 'none'; }
    }

    function stopLaneDemo() {
      if (laneTimer) {
        clearInterval(laneTimer); // ←FM-1
        laneTimer = null;
      }
    }

    function runLaneDemo() {
      stopLaneDemo(); // 先清已有计时器 ←FM-1
      resetSlots();

      laneTimer = setInterval(function () { // ←FM-1 setInterval
        if (laneCount < 8) {
          // 填入第 laneCount+1 个槽
          var slot = root.querySelector(`[data-s015-slot="${laneCount}"]`);
          if (slot) {
            slot.classList.add('occupied');
            // GSAP 小动画
            gsap.fromTo(slot,
              { scale: 0.4, opacity: 0 },
              { scale: 1, opacity: 1, duration: 0.25, ease: 'back.out(1.4)' }
            );
          }
          laneCount++;
        } else if (laneCount === 8) {
          // 第 9 个 → 排队 pending
          if (pendingSlot) {
            pendingSlot.style.display = 'flex';
            pendingSlot.classList.add('pending');
            gsap.fromTo(pendingSlot,
              { scale: 0.4, opacity: 0 },
              { scale: 1, opacity: 1, duration: 0.25, ease: 'back.out(1.4)' }
            );
          }
          if (pendingLabel) {
            pendingLabel.style.display = 'inline';
            gsap.fromTo(pendingLabel,
              { opacity: 0, x: -6 },
              { opacity: 1, x: 0, duration: 0.3, ease: 'power2.out' }
            );
          }
          laneCount++;
          stopLaneDemo(); // 演示完毕，停止 ←FM-1
        }
      }, 280);
    }

    // ─── 入场动画（GSAP fromTo，防 display:none 时序问题）────
    var lab = root.querySelector('.s015-lab');
    tl = gsap.timeline({ paused: true }); // ←FM-2

    if (lab) {
      var animTargets = [];
      var hdr = lab.querySelector('.s015-header');
      var stg = lab.querySelector('.s015-stage');
      var btns = lab.querySelector('.s015-dim-btns');
      var ev   = lab.querySelector('.s015-evidence');
      if (hdr) animTargets.push(hdr);
      if (stg) animTargets.push(stg);
      if (btns) animTargets.push(btns);
      if (ev) animTargets.push(ev);

      if (animTargets.length > 0) {
        tl.fromTo(
          animTargets,
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.45, stagger: 0.08, ease: 'power2.out' }
        );
      }
    }

    entranceTimer = setTimeout(function () { // ←FM-1（setTimeout 也需清）
      if (tl) tl.play();
    }, 120);

    // ─── 事件绑定 ──────────────────────────────────────────

    // 四维按钮
    dimBtns.forEach(function (btn) {
      on(btn, 'click', function () {
        var dim = btn.getAttribute('data-s015-dim');
        setDim(dim);
      });
    });

    // context 子开关
    ctxBtns.forEach(function (btn) {
      on(btn, 'click', function () {
        var mode = btn.getAttribute('data-s015-ctx');
        setContextMode(mode);
      });
    });

    // lane 演示按钮
    on(laneRunBtn, 'click', function () {
      runLaneDemo();
    });

    // ─── 默认初始化：进入页面时选中 session 维（需要事件绑定完成后执行）
    setDim('session');

    // ─── cleanup ────────────────────────────────────────────
    return function cleanup() {
      clearTimeout(entranceTimer);                       // ←FM-1 timer 清理
      stopLaneDemo();                                    // ←FM-1 interval 清理
      if (tl) { tl.kill(); tl = null; }                 // ←FM-2 GSAP timeline 清理
      gsap.killTweensOf(root.querySelectorAll('*'));     // ←FM-2 killTweensOf
      listeners.forEach(function (item) {               // ←FM-3 handler 解绑
        if (item[0]) item[0].removeEventListener(item[1], item[2]);
      });
      listeners = [];
      state = {};
    };
  };
})();

/* ================= S019 hook（合并自 js/hooks/S019.hook.js） ================= */
/**
 * S019 — hybrid RAG 检索模拟器 hookFn
 * 文件：js/hooks/S019.hook.js
 * 注册 key：'slides/S019-hybrid-rag-sim.html'
 *
 * FM 清单:
 *   FM-1: querySelector 防 null 早退 → return noop
 *   FM-2: GSAP fromTo + paused + setTimeout(120ms)，禁裸 gsap.from()
 *   FM-3: 所有事件监听器用具名函数 + cleanup 全解绑 + clearTimeout
 *
 * 状态机:
 *   IDLE → SEARCHING（点击「检索 ▶」）
 *   SEARCHING → RESULT（GSAP timeline onComplete）
 *   RESULT → IDLE（点击「重播」）
 *   任意态 + 滑杆 input → 实时重算融合分（纯计算，不改主状态）
 */
(function () {
  'use strict';

  /* ---- 钉死数据（来源：lesson.md §3.2） ---- */
  var MEM_DATA = {
    m1: { label: 'm1', vecSim: 0.94, ftsHits: 2, ftsTotal: 2 },
    m2: { label: 'm2', vecSim: 0.05, ftsHits: 0, ftsTotal: 2 },
    m3: { label: 'm3', vecSim: 0.70, ftsHits: 0, ftsTotal: 2 }
  };
  var MEM_ORDER = ['m1', 'm2', 'm3']; // DOM 顺序

  /* ---- 融合分计算 ---- */
  function calcFusion(vecWeight) {
    var txtWeight = 1 - vecWeight;
    return MEM_ORDER.map(function (key) {
      var d = MEM_DATA[key];
      var ftsScore = d.ftsTotal > 0 ? d.ftsHits / d.ftsTotal : 0;
      var finalScore = d.vecSim * vecWeight + ftsScore * txtWeight;
      return {
        key: key,
        vecScore: d.vecSim,
        ftsScore: ftsScore,
        finalScore: finalScore,
        breakdown: key + ': ' + d.vecSim.toFixed(2) + '×' + vecWeight.toFixed(2)
          + ' + ' + ftsScore.toFixed(2) + '×' + txtWeight.toFixed(2)
          + ' = ' + finalScore.toFixed(3)
      };
    }).sort(function (a, b) { return b.finalScore - a.finalScore; });
  }

  /* ---- hookFn 注册 ---- */
  window.slideHooks = window.slideHooks || {};
  window.slideHooks['slides/S019-hybrid-rag-sim.html'] = function () {

    /* FM-1: DOM 防 null 早退 */
    var slide = document.querySelector('[data-slide-id="S019"]');
    if (!slide) return function noop() {};  // ←FM-1

    /* ---- DOM 引用 ---- */
    var btnSearch  = slide.querySelector('[data-s019-btn-search]');
    var btnReplay  = slide.querySelector('[data-s019-btn-replay]');
    var slider     = slide.querySelector('#s019-weight-slider');

    var vecRows    = ['m1', 'm2', 'm3'].map(function (k) { return slide.querySelector('[data-vec-row="' + k + '"]'); });
    var ftsRows    = ['m1', 'm2', 'm3'].map(function (k) { return slide.querySelector('[data-fts-row="' + k + '"]'); });
    var vecBars    = { m1: slide.querySelector('[data-vec-bar="m1"]'), m2: slide.querySelector('[data-vec-bar="m2"]'), m3: slide.querySelector('[data-vec-bar="m3"]') };
    var ftsBars    = { m1: slide.querySelector('[data-fts-bar="m1"]'), m2: slide.querySelector('[data-fts-bar="m2"]'), m3: slide.querySelector('[data-fts-bar="m3"]') };
    var fusionCards = [0, 1, 2].map(function (i) { return slide.querySelector('[data-fusion-card="' + i + '"]'); });
    var fusionRanks = [0, 1, 2].map(function (i) { return slide.querySelector('[data-fusion-rank="' + i + '"]'); });
    var fusionMems  = [0, 1, 2].map(function (i) { return slide.querySelector('[data-fusion-mem="' + i + '"]'); });
    var fusionScores = [0, 1, 2].map(function (i) { return slide.querySelector('[data-fusion-score="' + i + '"]'); });
    var fusionBreaks = [0, 1, 2].map(function (i) { return slide.querySelector('[data-fusion-break="' + i + '"]'); });
    var fusionFormula = slide.querySelector('[data-fusion-formula]');
    var weightVecEl   = slide.querySelector('[data-weight-vec]');
    var weightFtsEl   = slide.querySelector('[data-weight-fts]');
    var vecWeightLabel = slide.querySelector('[data-vec-weight-label]');
    var ftsWeightLabel = slide.querySelector('[data-fts-weight-label]');
    var kwSpans = slide.querySelectorAll('.s019-kw');

    /* ---- 闭包状态 ---- */
    var state = { phase: 'IDLE' };  // IDLE | SEARCHING | RESULT
    var tl = null;
    var entranceTimer = null;

    /* ---- 读滑杆值 ---- */
    function getVecWeight() {
      return (slider ? parseInt(slider.value, 10) : 70) / 100;
    }

    /* ---- 更新权重显示 ---- */
    function updateWeightLabels(vecW) {
      var txtW = 1 - vecW;
      if (weightVecEl) weightVecEl.textContent = vecW.toFixed(2);
      if (weightFtsEl) weightFtsEl.textContent = txtW.toFixed(2);
      if (vecWeightLabel) vecWeightLabel.textContent = '× ' + vecW.toFixed(1);
      if (ftsWeightLabel) ftsWeightLabel.textContent = '× ' + txtW.toFixed(1);
      /* 更新滑杆渐变背景 */
      if (slider) slider.style.setProperty('--slider-pct', (vecW * 100) + '%');
      /* 更新 formula 标注 */
      if (fusionFormula) {
        fusionFormula.textContent = 'finalScore = vecScore × ' + vecW.toFixed(1) + ' + ftsScore × ' + txtW.toFixed(1);
      }
    }

    /* ---- 重新渲染融合排序台（无动画，用于滑杆联动） ---- */
    function renderFusionCards(sorted, animate) {
      sorted.forEach(function (item, i) {
        var card = fusionCards[i];
        var rankBadge = fusionRanks[i];
        var memEl = fusionMems[i];
        var scoreEl = fusionScores[i];
        var breakEl = fusionBreaks[i];
        if (!card) return;

        /* 排名样式 */
        card.classList.remove('s019-rank-1');
        if (rankBadge) {
          rankBadge.classList.remove('s019-first');
          rankBadge.textContent = '#' + (i + 1);
          if (i === 0) {
            rankBadge.classList.add('s019-first');
            card.classList.add('s019-rank-1');
          }
        }
        if (memEl) memEl.textContent = item.key;
        if (scoreEl) {
          scoreEl.textContent = item.finalScore.toFixed(3);
          /* 短暂 opacity 脉冲表示数字变化 */
          if (!animate) {
            scoreEl.style.opacity = '0.4';
            setTimeout(function () { scoreEl.style.opacity = '1'; }, 60);
          }
        }
        if (breakEl) breakEl.textContent = item.breakdown;

        if (animate) {
          card.classList.remove('s019-visible');
          /* stagger 展开 */
          setTimeout(function () { card.classList.add('s019-visible'); }, i * 120);
        }
      });
    }

    /* ---- 重置 DOM 到初始态 ---- */
    function resetDOM() {
      /* 清除分数条 */
      MEM_ORDER.forEach(function (key) {
        if (vecBars[key]) vecBars[key].style.width = '0%';
        if (ftsBars[key]) ftsBars[key].style.width = '0%';
      });
      /* 隐藏分数行 */
      vecRows.concat(ftsRows).forEach(function (row) {
        if (row) { row.classList.remove('s019-visible'); }
      });
      /* 隐藏融合卡 */
      fusionCards.forEach(function (card) {
        if (card) card.classList.remove('s019-visible');
      });
      /* 重置融合台文字 */
      if (fusionRanks[0]) fusionRanks[0].textContent = '— 等待检索 —';
      [1, 2].forEach(function (i) { if (fusionRanks[i]) fusionRanks[i].textContent = ''; });
      fusionMems.forEach(function (el) { if (el) el.textContent = ''; });
      fusionScores.forEach(function (el) { if (el) el.textContent = ''; });
      fusionBreaks.forEach(function (el) { if (el) el.textContent = ''; });
      /* 清除关键词高亮 */
      kwSpans.forEach(function (kw) { kw.classList.remove('s019-kw-hit'); });
      /* 记忆卡样式 */
      slide.querySelectorAll('.s019-mem-card').forEach(function (c) {
        c.classList.remove('s019-dim', 's019-active');
      });
    }

    /* ---- 主检索动画 ---- */
    function runSearch() {
      if (state.phase !== 'IDLE') return;
      state.phase = 'SEARCHING';

      if (btnSearch) btnSearch.disabled = true;
      if (btnReplay) btnReplay.disabled = true;

      resetDOM();

      var vecW = getVecWeight();
      updateWeightLabels(vecW);

      /* GSAP timeline — FM-2: fromTo + paused + setTimeout ← FM-2 */
      if (tl) { tl.kill(); tl = null; }

      tl = gsap.timeline({
        paused: true,
        onComplete: function () {
          state.phase = 'RESULT';
          if (btnSearch) btnSearch.disabled = false;
          if (btnReplay) btnReplay.disabled = false;

          /* 渲染融合排序台 */
          var sorted = calcFusion(vecW);
          renderFusionCards(sorted, true);
        }
      });

      /* Stage 0: 记忆卡 dim → m1 active */
      tl.call(function () {
        slide.querySelectorAll('.s019-mem-card').forEach(function (c) {
          c.classList.add('s019-dim');
        });
      }, [], 0);

      /* Stage 1 (t=0.2): 向量路分数行依次出现 */
      vecRows.forEach(function (row, i) {
        if (!row) return;
        tl.call(function () {
          row.classList.add('s019-visible');
        }, [], 0.2 + i * 0.18);
      });

      /* Stage 2 (t=0.25): 向量分数条展开 */
      var vecSimMap = { m1: 0.94, m2: 0.05, m3: 0.70 };
      MEM_ORDER.forEach(function (key, i) {
        tl.call(function () {
          if (vecBars[key]) vecBars[key].style.width = (vecSimMap[key] * 100) + '%';
        }, [], 0.25 + i * 0.18);
      });

      /* Stage 3 (t=0.65): 全文路分数行依次出现 */
      ftsRows.forEach(function (row, i) {
        if (!row) return;
        tl.call(function () {
          row.classList.add('s019-visible');
        }, [], 0.65 + i * 0.18);
      });

      /* Stage 4 (t=0.7): 全文分数条展开 + m1 关键词高亮 */
      var ftsScoreMap = { m1: 1.0, m2: 0.0, m3: 0.0 };
      MEM_ORDER.forEach(function (key, i) {
        tl.call(function () {
          if (ftsBars[key]) ftsBars[key].style.width = (ftsScoreMap[key] * 100) + '%';
        }, [], 0.7 + i * 0.18);
      });

      /* Stage 5 (t=0.9): m1 关键词高亮 + 记忆卡 active */
      tl.call(function () {
        kwSpans.forEach(function (kw) { kw.classList.add('s019-kw-hit'); });
        var m1Card = slide.querySelector('[data-mem="m1"]');
        if (m1Card) { m1Card.classList.remove('s019-dim'); m1Card.classList.add('s019-active'); }
      }, [], 1.1);

      /* 总时长约 1.5s，onComplete 渲染融合卡 */
      tl.to({}, { duration: 0.4 }, 1.1);  // 拉伸 timeline 到 ~1.5s

      entranceTimer = setTimeout(function () { tl.play(); }, 120);  // ←FM-2: paused+delay
    }

    /* ---- 重播 ---- */
    function handleReplay() {
      if (state.phase !== 'RESULT') return;
      if (tl) { tl.kill(); tl = null; }  // ←FM-3 GSAP 清理
      state.phase = 'IDLE';
      resetDOM();
      var vecW = getVecWeight();
      updateWeightLabels(vecW);
      if (btnSearch) btnSearch.disabled = false;
      if (btnReplay) btnReplay.disabled = true;
    }

    /* ---- 滑杆联动（实时重算，无 GSAP） ---- */
    function handleSlider() {
      var vecW = getVecWeight();
      updateWeightLabels(vecW);
      if (state.phase === 'RESULT') {
        /* 实时重算并重渲染排序台 */
        var sorted = calcFusion(vecW);
        renderFusionCards(sorted, false);
      }
    }

    /* ---- 绑定事件（FM-3: 具名函数 + cleanup 解绑） ---- */
    if (btnSearch) btnSearch.addEventListener('click', runSearch);        // ←FM-3
    if (btnReplay) btnReplay.addEventListener('click', handleReplay);     // ←FM-3
    if (slider)    slider.addEventListener('input', handleSlider);        // ←FM-3

    /* ---- 初始化权重显示 ---- */
    updateWeightLabels(getVecWeight());

    /* ---- 入场动画（header + query 区） ---- */
    var entranceItems = slide.querySelectorAll('.s019-header, .s019-query-area, .s019-retrieval-grid, .s019-fusion-area, .s019-weight-area, .s019-ctrl-bar, .s019-paradigm, .s019-footnotes');
    var entranceTl = gsap.timeline({ paused: true });
    entranceTl.fromTo(
      entranceItems,
      { opacity: 0, y: 14 },
      { opacity: 1, y: 0, duration: 0.45, stagger: 0.06, ease: 'power2.out' }
    );
    var entranceDelay = setTimeout(function () { entranceTl.play(); }, 120);  // ←FM-2
    /* 首屏即见完整态（S010b/S014 同先例）：入场动画后自动跑一轮检索，payoff 不等点击 */
    var autoRunTimer = setTimeout(function () { runSearch(); }, 750);  // ←FM-3 配套 clearTimeout

    /* ---- cleanup（FM-1 FM-2 FM-3 全覆盖）---- */
    return function cleanup() {
      clearTimeout(entranceTimer);    // ←FM-3
      clearTimeout(entranceDelay);    // ←FM-3
      clearTimeout(autoRunTimer);     // ←FM-3
      if (tl) { tl.kill(); tl = null; }  // ←FM-2 GSAP kill
      if (entranceTl) { entranceTl.kill(); }
      gsap.killTweensOf(slide.querySelectorAll('*'));  // ←FM-2 killTweensOf
      if (btnSearch) btnSearch.removeEventListener('click', runSearch);   // ←FM-3
      if (btnReplay) btnReplay.removeEventListener('click', handleReplay); // ←FM-3
      if (slider)    slider.removeEventListener('input', handleSlider);    // ←FM-3
      state = {};
    };
  };
})();

/* ================= S020 hook（合并自 js/hooks/S020.hook.js） ================= */
/**
 * S020 昼夜循环模拟器 · hookFn
 * 键名：'slides/S020-dreaming-cycle.html'
 *
 * FM 清单: FM-1 noop 早退 / FM-2 setInterval 计数器 clearInterval / FM-3 GSAP tl.kill + killTweensOf
 *
 * 状态机（6 stage）：
 *   0 DAY → 1 CRON → 2 LIGHT → 3 REM → 4 DEEP → 5 OUTPUT
 * cleanup 复位：夜间 class 移除 + 白天区恢复展开 + 计数器停止
 */
(function () {
  'use strict';

  window.slideHooks = window.slideHooks || {};

  window.slideHooks['slides/S020-dreaming-cycle.html'] = function () {
    /* FM 清单: FM-1 noop 早退 / FM-2 setInterval 计数器 clearInterval / FM-3 GSAP tl.kill + killTweensOf */

    // ── FM-1: 早退保护 ──────────────────────────────────────────
    var slide = document.querySelector('.slide[data-slide-id="S020"]');
    if (!slide) return function noop() {};  // ←FM-1

    // ── DOM 引用 ─────────────────────────────────────────────────
    var wrap          = slide.querySelector('.s020-wrap');
    var dayBand       = slide.querySelector('[data-s020-day-band]');
    var advanceBtn    = slide.querySelector('[data-s020-advance-btn]');
    var nightStage    = slide.querySelector('[data-s020-night-stage]');
    var cronBar       = slide.querySelector('[data-s020-cron-bar]');
    var recallCount   = slide.querySelector('[data-s020-recall-count]');
    var outputRow     = slide.querySelector('[data-s020-output-row]');
    var loopArrow     = slide.querySelector('[data-s020-loop-arrow]');
    var weightArrow   = slide.querySelector('[data-s020-weight-arrow]');
    var memoryBox     = slide.querySelector('[data-s020-memory-box]');
    var eggPanel      = slide.querySelector('[data-s020-egg]');
    var eggClose      = slide.querySelector('[data-s020-egg-close]');
    var stageIndicator = slide.querySelector('[data-s020-stage-indicator]');
    var ctrlStageText = slide.querySelector('[data-s020-ctrl-stage]');
    var btnPlay       = slide.querySelector('[data-s020-play]');
    var btnPause      = slide.querySelector('[data-s020-pause]');
    var btnStep       = slide.querySelector('[data-s020-step]');
    var stageDots     = slide.querySelectorAll('[data-s020-stage-dots] .s020-dot');

    var phaseLightEl  = slide.querySelector('[data-s020-phase="light"]');
    var phaseRemEl    = slide.querySelector('[data-s020-phase="rem"]');
    var phaseDeepEl   = slide.querySelector('[data-s020-phase="deep"]');
    var funnelGates   = slide.querySelectorAll('[data-funnel-gate]');
    var funnelLimit   = slide.querySelector('[data-s020-funnel-limit]');
    var stagedPills   = slide.querySelectorAll('[data-pill]');
    var themeRows     = slide.querySelectorAll('[data-theme]');

    // ── 局部状态 ─────────────────────────────────────────────────
    var currentStageIdx = 0;
    var recallVal = 0;
    var recallTimer = null;  // ←FM-2 setInterval handle
    var tl = null;

    // stageEnds[i] = timeline 中第 i 阶段结束时间（秒）
    // 6 stages: 0=DAY(静态), 1=CRON, 2=LIGHT, 3=REM, 4=DEEP, 5=OUTPUT
    var stageEnds = [0.05, 1.8, 4.0, 6.2, 8.5, 11.0];

    var stageNames = [
      'stage 1/6 · 白天：对话积累',
      'stage 2/6 · cron 触发',
      'stage 3/6 · light 浅睡扫描',
      'stage 4/6 · rem 归纳主题',
      'stage 5/6 · deep 深度晋升',
      'stage 6/6 · 产出完成'
    ];

    var ctrlNames = [
      'stage 1/6 · 白天',
      'stage 2/6 · cron',
      'stage 3/6 · light',
      'stage 4/6 · rem',
      'stage 5/6 · deep',
      'stage 6/6 · 产出'
    ];

    // ── 工具函数 ──────────────────────────────────────────────────
    function setStageUI(i) {
      currentStageIdx = i;
      if (stageIndicator) stageIndicator.innerHTML = stageNames[i] || '';
      if (ctrlStageText)  ctrlStageText.textContent = ctrlNames[i] || '';
      stageDots.forEach(function (dot, idx) {
        dot.classList.toggle('active', idx <= i);
      });
    }

    function startRecallCounter() {
      // ←FM-2: setInterval handle 存入 recallTimer，cleanup 时清除
      recallVal = 0;
      if (recallCount) recallCount.textContent = '0';
      recallTimer = setInterval(function () {  // ←FM-2
        recallVal += Math.floor(Math.random() * 3) + 1;
        if (recallCount) recallCount.textContent = String(recallVal);
      }, 800);
    }

    function stopRecallCounter() {
      clearInterval(recallTimer);  // ←FM-2
      recallTimer = null;
    }

    // ── 构建 GSAP timeline ────────────────────────────────────────
    function buildTimeline() {
      // ←FM-3: 先 kill 旧 timeline
      if (tl) { tl.kill(); tl = null; }  // ←FM-3

      var hasGsap = (typeof gsap !== 'undefined');

      if (!hasGsap) {
        // 无 GSAP 时降级：CSS class 切换
        return buildCssFallback();
      }

      var timeline = gsap.timeline({
        paused: true,
        onComplete: function () {
          if (btnPause) btnPause.textContent = '▶ 继续';
        }
      });

      // stage 0 → 1: 切夜间（0 ~ 1.8s）
      timeline.add(function () { setStageUI(1); }, stageEnds[0]);

      // 白天区折叠
      timeline.to(dayBand, {
        maxHeight: '2.5rem',
        duration: 0.5,
        ease: 'power2.inOut',
        onStart: function () { dayBand.classList.add('collapsed'); }
      }, stageEnds[0] + 0.1);

      // 夜间舞台淡入
      timeline.fromTo(nightStage,
        { opacity: 0.22 },  /* 起始=CSS 压暗占位态，禁 0（paused 构建即写内联，会盖掉占位） */
        {
          opacity: 1,
          duration: 0.6,
          ease: 'power1.out',
          onStart: function () { nightStage.classList.add('active'); }
        },
        stageEnds[0] + 0.2
      );

      // cron 条淡入
      timeline.to(cronBar, {
        opacity: 1,
        duration: 0.45,
        ease: 'power1.out',
        onStart: function () { cronBar.classList.add('lit'); }
      }, stageEnds[0] + 0.7);

      // stage 1 → 2: light 阶段（1.8 ~ 4.0s）
      timeline.add(function () { setStageUI(2); }, stageEnds[1]);

      timeline.to(phaseLightEl, {
        opacity: 1,
        duration: 0.45,
        ease: 'power1.out',
        onStart: function () { phaseLightEl.classList.add('lit'); }
      }, stageEnds[1] + 0.1);

      // staged pills 逐个显示
      var pillArr = Array.from(stagedPills);
      pillArr.forEach(function (pill, idx) {
        timeline.to(pill, {
          opacity: 1,
          duration: 0.3,
          ease: 'power1.out',
          onStart: function () { pill.classList.add('show'); }
        }, stageEnds[1] + 0.35 + idx * 0.18);
      });

      // stage 2 → 3: rem 阶段（4.0 ~ 6.2s）
      timeline.add(function () { setStageUI(3); }, stageEnds[2]);

      timeline.to(phaseRemEl, {
        opacity: 1,
        duration: 0.45,
        ease: 'power1.out',
        onStart: function () { phaseRemEl.classList.add('lit'); }
      }, stageEnds[2] + 0.1);

      // theme rows 逐个滑入
      var themeArr = Array.from(themeRows);
      themeArr.forEach(function (row, idx) {
        timeline.fromTo(row,
          { opacity: 0, x: -8 },
          {
            opacity: 1,
            x: 0,
            duration: 0.35,
            ease: 'power1.out',
            onStart: function () { row.classList.add('show'); }
          },
          stageEnds[2] + 0.3 + idx * 0.22
        );
      });

      // 加权箭头（rem→deep）
      timeline.to(weightArrow, {
        opacity: 1,
        duration: 0.4,
        ease: 'power1.out',
        onStart: function () { weightArrow.classList.add('show'); }
      }, stageEnds[2] + 1.0);

      // stage 3 → 4: deep 阶段（6.2 ~ 8.5s）
      timeline.add(function () { setStageUI(4); }, stageEnds[3]);

      timeline.to(phaseDeepEl, {
        opacity: 1,
        duration: 0.45,
        ease: 'power1.out',
        onStart: function () { phaseDeepEl.classList.add('lit'); }
      }, stageEnds[3] + 0.1);

      // 漏斗三门槛逐行出现（严格顺序 light→rem→deep，漏斗属于 deep）
      var gateArr = Array.from(funnelGates);
      gateArr.forEach(function (gate, idx) {
        timeline.fromTo(gate,
          { opacity: 0, y: 8 },
          {
            opacity: 1,
            y: 0,
            duration: 0.35,
            ease: 'power1.out',
            onStart: function () { gate.classList.add('show'); }
          },
          stageEnds[3] + 0.35 + idx * 0.3
        );
      });

      // 每晚最多 10 条
      timeline.to(funnelLimit, {
        opacity: 1,
        duration: 0.4,
        ease: 'power1.out',
        onStart: function () { funnelLimit.classList.add('show'); }
      }, stageEnds[3] + 1.4);

      // stage 4 → 5: 产出（8.5 ~ 11.0s）
      timeline.add(function () { setStageUI(5); }, stageEnds[4]);

      timeline.fromTo(outputRow,
        { opacity: 0, y: 12 },
        {
          opacity: 1,
          y: 0,
          duration: 0.55,
          ease: 'power2.out',
          onStart: function () { outputRow.classList.add('show'); }
        },
        stageEnds[4] + 0.2
      );

      // 回灌箭头
      timeline.to(loopArrow, {
        opacity: 1,
        duration: 0.45,
        ease: 'power1.out',
        onStart: function () { loopArrow.classList.add('show'); }
      }, stageEnds[4] + 0.75);

      return timeline;
    }

    // ── CSS 降级实现（无 GSAP 时）─────────────────────────────────
    function buildCssFallback() {
      var stageTimers = [];
      var obj = {
        _paused: true,
        _timeouts: stageTimers,
        play: function () {
          obj._paused = false;
          obj._run();
        },
        pause: function () { obj._paused = true; },
        paused: function () { return obj._paused; },
        kill: function () {
          stageTimers.forEach(function (id) { clearTimeout(id); });
          stageTimers.length = 0;
          obj._paused = true;
        },
        tweenTo: function (targetTime, opts) {
          // 简单跳到 targetTime 对应 stage
          var targetStage = 0;
          for (var k = 0; k < stageEnds.length; k++) {
            if (targetTime >= stageEnds[k]) targetStage = k;
          }
          obj._runStage(targetStage, opts && opts.onComplete);
        },
        _runStage: function (idx, cb) {
          setStageUI(idx);
          obj._applyStageVisual(idx);
          if (cb) cb();
        },
        _applyStageVisual: function (idx) {
          if (idx >= 1) {
            dayBand.classList.add('collapsed');
            nightStage.classList.add('active');
            cronBar.classList.add('lit');
          }
          if (idx >= 2) phaseLightEl.classList.add('lit');
          if (idx >= 3) { phaseRemEl.classList.add('lit'); weightArrow.classList.add('show'); }
          if (idx >= 4) phaseDeepEl.classList.add('lit');
          if (idx >= 5) { outputRow.classList.add('show'); loopArrow.classList.add('show'); }
        },
        _run: function () {
          var delays = [0, 1800, 4000, 6200, 8500, 11000];
          delays.forEach(function (delay, idx) {
            var id = setTimeout(function () {
              if (!obj._paused) {
                setStageUI(idx);
                obj._applyStageVisual(idx);
              }
            }, delay);
            stageTimers.push(id);
          });
        }
      };
      return obj;
    }

    // ── 重播 ──────────────────────────────────────────────────────
    function buildAndPlay() {
      resetVisuals();
      tl = buildTimeline();
      if (tl && tl.play) {
        tl.play(0);
        if (btnPause) btnPause.textContent = '⏸ 暂停';
      } else if (tl && tl._run) {
        tl._paused = false;
        tl._run();
      }
    }

    function resetVisuals() {
      // 复位夜间
      dayBand.classList.remove('collapsed');
      nightStage.classList.remove('active');
      nightStage.style.opacity = '';  /* 清内联值，回落到 CSS 压暗占位 0.22 */
      cronBar.classList.remove('lit');
      phaseLightEl.classList.remove('lit');
      phaseRemEl.classList.remove('lit');
      phaseDeepEl.classList.remove('lit');
      weightArrow.classList.remove('show');
      outputRow.classList.remove('show');
      loopArrow.classList.remove('show');
      funnelLimit.classList.remove('show');
      Array.from(funnelGates).forEach(function (g) { g.classList.remove('show'); });
      Array.from(stagedPills).forEach(function (p) { p.classList.remove('show'); });
      Array.from(themeRows).forEach(function (r) { r.classList.remove('show'); });
      eggPanel.classList.remove('open');
      setStageUI(0);

      // 计数器重启
      stopRecallCounter();
      startRecallCounter();
    }

    // ── 快进按钮（白天 → 直接触发 CRON stage）──────────────────────
    function handleAdvance() {
      if (currentStageIdx === 0) {
        stopRecallCounter();
        if (!tl) tl = buildTimeline();
        if (tl && tl.play) {
          tl.play(stageEnds[0]);
          if (btnPause) btnPause.textContent = '⏸ 暂停';
        } else if (tl && tl._run) {
          tl._paused = false;
          tl._applyStageVisual(1);
          setStageUI(1);
        }
      }
    }

    // ── 控制按钮 ─────────────────────────────────────────────────
    function handlePlay() {
      buildAndPlay();
    }

    function handlePause() {
      if (!tl) return;
      if (tl.paused && tl.paused()) {
        tl.play();
        if (btnPause) btnPause.textContent = '⏸ 暂停';
      } else if (tl.pause) {
        tl.pause();
        if (btnPause) btnPause.textContent = '▶ 继续';
      }
    }

    function handleStep() {
      if (!tl) {
        tl = buildTimeline();
      }
      if (currentStageIdx >= stageEnds.length - 1) {
        // 末尾回起点
        buildAndPlay();
        if (tl && tl.pause) { tl.pause(0); }
        setStageUI(0);
        return;
      }
      var nextStage = currentStageIdx + 1;
      var targetTime = stageEnds[nextStage] - 0.05;
      if (tl.tweenTo) {
        tl.tweenTo(targetTime, {
          onComplete: function () {
            if (tl && tl.pause) tl.pause();
            if (btnPause) btnPause.textContent = '▶ 继续';
          }
        });
      }
    }

    // ── 彩蛋 ─────────────────────────────────────────────────────
    function handleMemoryBoxClick() {
      if (currentStageIdx >= 5) {
        eggPanel.classList.toggle('open');
      }
    }

    function handleEggClose() {
      eggPanel.classList.remove('open');
    }

    // ── 绑定事件 ─────────────────────────────────────────────────
    if (advanceBtn) advanceBtn.addEventListener('click', handleAdvance);
    if (btnPlay)    btnPlay.addEventListener('click', handlePlay);
    if (btnPause)   btnPause.addEventListener('click', handlePause);
    if (btnStep)    btnStep.addEventListener('click', handleStep);
    if (memoryBox)  memoryBox.addEventListener('click', handleMemoryBoxClick);
    if (eggClose)   eggClose.addEventListener('click', handleEggClose);

    // ── 入场初始化 ───────────────────────────────────────────────
    // 白天计数器启动，延迟等 slide 可见
    var entranceTimer = setTimeout(function () {
      startRecallCounter();  // ←FM-2
      // 预构建 timeline（paused），等待用户操作
      tl = buildTimeline();
    }, 150);

    // ── cleanup ─────────────────────────────────────────────────
    return function cleanup() {
      // ←FM-2: 清除计数器 setInterval
      stopRecallCounter();  // ←FM-2

      // ←FM-3: kill GSAP timeline
      clearTimeout(entranceTimer);
      if (tl) {
        if (tl.kill) { if (window.gsap) gsap.killTweensOf(tl); tl.kill(); }  // ←FM-3 含 tweenTo 驱动 tween
        tl = null;
      }
      if (typeof gsap !== 'undefined') {
        gsap.killTweensOf(slide.querySelectorAll('*'));  // ←FM-3
      }

      // 昼夜状态复位为白天（切页残留防护）
      dayBand.classList.remove('collapsed');
      nightStage.classList.remove('active');
      cronBar.classList.remove('lit');
      phaseLightEl.classList.remove('lit');
      phaseRemEl.classList.remove('lit');
      phaseDeepEl.classList.remove('lit');
      weightArrow.classList.remove('show');
      outputRow.classList.remove('show');
      loopArrow.classList.remove('show');
      funnelLimit.classList.remove('show');
      Array.from(funnelGates).forEach(function (g) { g.classList.remove('show'); });
      Array.from(stagedPills).forEach(function (p) { p.classList.remove('show'); });
      Array.from(themeRows).forEach(function (r) { r.classList.remove('show'); });
      eggPanel.classList.remove('open');
      if (btnPause) btnPause.textContent = '⏸ 暂停';
      setStageUI(0);

      // 解绑事件
      if (advanceBtn) advanceBtn.removeEventListener('click', handleAdvance);
      if (btnPlay)    btnPlay.removeEventListener('click', handlePlay);
      if (btnPause)   btnPause.removeEventListener('click', handlePause);
      if (btnStep)    btnStep.removeEventListener('click', handleStep);
      if (memoryBox)  memoryBox.removeEventListener('click', handleMemoryBoxClick);
      if (eggClose)   eggClose.removeEventListener('click', handleEggClose);

      // 计数器归零显示
      recallVal = 0;
      if (recallCount) recallCount.textContent = '0';
    };
  };

}());
