# 第二节课 HTML 课件 · 确认设计表

> 本文件是「主对话逐页第一性原理分析 + AskUserQuestion 用户拍板」的产物（2026-06-04 全部确认），
> 作为 html-courseware-team 执行生成的输入规格。角色等同第一节课的 confirmed_redesign.md。

## 基线决策（已确认）

| 维度 | 决策 |
|------|------|
| 内容源 | `../lesson.md`（1219 行，已审定稿）+ `../metadata.json` + `../plan.md` |
| 总页数 | **24 页**（Part 0 开场承上 4 / Part 1 上下文工程 7 / Part 2 多智能体 5 / Part 3 记忆系统 5 / Part 4 收口 3） |
| 重交互预算 | **5 个 🔴🔴**：S008 / S014 / S015 / S019 / S020（用户确认全保留） |
| 审美基线 | **完全继承第一节课 L3「浅珊瑚雾 Coral-Mist Molting」**——本目录骨架已就绪：css/main.css 零改动继承、style_manifest.json token 逐字段继承、index.html/js 引擎已迁移。**designer 风格访谈与 builder 骨架生成阶段可跳过**，禁止改动 css token |
| 骨架性页面 | S001 封面 / S005·S012·S017 章过渡 / S024 预告 沿用第一节课成熟范式。章过渡范式 2026-06-05 用户修订：大背景章号 + 徽章只留「第 N 章」+ **章名作主标题** + 钩子问句降为副标题（display 字体 ~1.4rem 橙红）+ 小节标签对称排布（4 节=2×2 网格 / 3 节=单行三胶囊，去分隔点） |
| 三数组铁律 | js/main.js 的 slideFiles/slideTitles/chapters 三数组必须同步（chapters 5 章规划注释已预埋在 main.js 内） |

## 课程信息

- 标题：OpenClaw 核心架构 · 第二节课（多智能体协作 × 上下文工程 × 记忆系统）
- 副标题：智能体的「分治脑 + 当下脑 + 长期脑」
- 主轴：context 的当下组装（第1章）→ 分治隔离（第2章）→ 持久来源（第3章）→ 收口成框架（第4章）
- 重要约束：「三脑一轴」是教学比喻非官方术语，出现处必须带声明（lesson.md L68/L1178 原话）

## 逐页确认结果

### Part 0 — 开场承上（S001–S004）

**S001 封面 🟢**
- 沿用第一节课封面范式。占位版已存在于 slides/S001-cover.html（标题+副标题+主轴一句话），可在此基础上精修。
- 2026-06-05 用户修订：主标题改为「OpenClaw 专题课 · 第二节课」；「分治脑+当下脑+长期脑」比喻撤出封面（学员尚无认知锚点，首次出现延后到 S004）；三大模块「上下文工程 / 多智能体协作 / 记忆系统」作为三张章节卡片标题（去掉脑前缀），第 1/2/3 章徽章即讲解顺序。

**S002 上节回顾 🟡 ｜ 确认方案：A·时间线握手**
- 左侧竖向五章节点（上节课五章产物），点击每个节点右侧亮出「本节怎么用上」连线
- 第 2 章（心脏→compact/subagent 是事件流延伸）、第 3 章（工具→subagents/memory_search 走策略管线）两行重点高亮 ★
- 内容源：lesson.md §0.1 五章产物回顾表（L40-46）

**S003 三堵墙 🟡 ｜ 确认方案：A·砸墙隐喻**
- 三面墙体卡片立在 agent 面前：① context 组装黑盒 ② 复杂任务无法分治 ③ 跨会话记忆是谜
- 点击每堵墙出现裂缝动画 + 对应章节「锤子」标签（第1章 proxy 砸开 / 第2章 subagent 拆 / 第3章 记忆系统拆）
- 三堵都点完后底部浮现「都围着 context 这根轴」
- 内容源：lesson.md §0.2（L52-62）

**S004 三脑一轴全景 🟡 ｜ 确认方案：A·主轴横贯 + hover**
- 中央粗轴线标 context，三个脑模块从上方接入（当下脑蓝/分治脑橙/长期脑绿——色相沿用 lesson 插图约定，落地时取 style_manifest 最近似 token：蓝→--color-accent、橙→--color-primary、绿需在卡内局部定义）
- hover 每个脑显示职责+对应章号；底部小字「本课教学比喻，非 OpenClaw 官方术语」（硬约束，不可省）
- S022 将同构回归此图（生成时两页布局骨架保持一致以兑现首尾呼应）
- 内容源：lesson.md L64-68

### Part 1 — 上下文工程 ★（S005–S011）

**S005 章过渡 🟢**：第 1 章「你发一句话，模型这一轮到底收到了什么？」+ 1.1-1.4 小节预览。

**S006 proxy 观测链 🔴 ｜ 2026-06-05 用户二次拍板重构：A·取证链+战利品揭幕**（替代下述初版方案，初版保留备查）
- 左 37%：常驻迷你架构（学员→agent[内嵌🎙录音机+开关芯片]═HTTP═LLM，虚线抄送→档案库 capture.sqlite|blobs/），随步进点亮对应元素
- 右 63%：四步证据卡步进（点卡片或「下一步」），当前步展开命令+输出要点，走过的步打 ✓
- 底部战利品面板：初始 🔒 锁定文案；第④步揭幕——三条比例条动画（system 30,000+字符 / 历史 20+条 / 你打的那句 ← 冰山一角），数字冲击 = 页面 payoff，并注明实测环境免责
- 两踩坑 = 底部两块警示牌胶囊，点击向上弹出详情（互斥开合，absolute 定位）

**S006 初版（已被替代）｜A·四步步进观测链**
- 上区常驻架构示意：学员→[agent 内嵌橙色录音机]══HTTP══[LLM]，录音机虚线抄送→档案库（capture.sqlite + blobs/）；标注开关 OPENCLAW_DEBUG_PROXY_ENABLED=1「开了才录」、通道标注「直连，不经过任何代理」
- 下区四步步进：①开关跑一轮（agent --local）②proxy sessions 确认 eventCount>0 ③sqlite3 查 capture_events 拿 blob id（CLI 没有列事件命令）④proxy blob --id 读出请求体；点击步进高亮架构图对应路径+显示该步命令与输出摘要
- 2 个踩坑做成可展开警示折叠条：⚠ --preset 是网络诊断枚举与 context 无关 / ⚠ proxy run 中间人路被 SSRF 拦（Blocked hostname...）+ TUI 无 TTY 即退，两坑叠加无明确报错
- 内容源：lesson.md §1.1（L78-135）

**S007 四层冰山 🔴 ｜ 确认方案：A·冰山揭示**
- 初始只见水面上橙色小块「你好，简单介绍下自己」；点击「掀开水面」水下三层依次展开：历史消息 20+ 条（浅黄）→ 记忆注入 MEMORY.md（绿）→ 系统指令 30,000+ 字符（灰蓝，最大）
- 右侧真实比例条：字符量对比（你发的 12 字符 vs system 3 万+）
- 收口标注「你打的那句只是冰山一角」+ 数字注明「我们的测试环境实测，你机器上数字会不同，结构是一样的」（lesson L135 诚实口径）
- 内容源：lesson.md L135-141 四层定义

**S008 ContextEngine 五阶段 🔴🔴 ｜ 2026-06-05 用户二次拍板重构：A·安全网剧场**（替代下述初版方案，初版保留备查）
- 上 1/3 五阶段管线（5 等分栅格，与坠落区同栅格保证纵向对齐），assemble 主角节点内嵌四层色条；assemble/compact/prepare 节点右上角挂 💣 注错开关（可独立叠加）
- 下 2/3 坠落舞台：assemble 列正下方挂两道安全网（网1 fallback engine / 网2 catch 降级），compact+spawn 列下方红色 fail-closed 熔断区；左 1-2 列放 🟢vs🔴 结论对照卡
- ▶ 发消息：小球沿管线主线流动+节点脉冲；assemble 注错→坠落→网1 接住回弹（注错持续仍失败标 broken）→坠网2 接住→「turn 不崩」徽章→弧线回管线续跑；compact/prepare 注错→坠穿到熔断区 flash→管线整体熄火→TURN ABORTED
- 状态栏（控制行右侧）逐阶段叙事；hook 不用 tweenTo/paused-fromTo（规避陷阱⑦⑧），每次 run 现场重建 timeline

**S008 初版（已被替代）｜A·故障注入实验台**
- 五阶段横向管线 bootstrap→ingest→assemble（最大，蓝高亮）→compact→prepareSubagentSpawn；点「发一条消息」小球流经管线，assemble 处展开四层组装动画
- 故障注入开关（本页核心交互）：
  - 给 assemble 注错 → 🟢 两道防线动画：备用引擎重试 → 仍败 catch 降级（log.warn 沿用已有消息），turn 不崩
  - 给 compact 或 prepareSubagentSpawn 注错 → 🔴 fail-closed：当场中止 rethrow，红色终止动画
- 配注「为什么 fail-closed：压缩重写消息列表/派生建初始上下文是结构性操作，半成品比失败更危险」
- 边界小字：本课聚焦五个核心环节，接口另有 maintain/ingestBatch/afterTurn/onSubagentEnded 等方法
- 内容源：lesson.md §1.2（L143-160）；slideHook 必须 return cleanup（timer + gsap）

**S009 compact 压缩 🔴 ｜ 确认方案：A·触发式前后对比**
- 左栏 7 条消息堆叠逼近上限红色警示带；点「触发压缩」：旧消息折叠收拢成一条绿色 [摘要] 块 + 保留最近 2 条原文，事件徽章 compaction_start→compaction_end 依次亮起；腾出空间用留白+绿框强调
- 触发条件标注 len(history) > max_messages；底部一句「用空间换延续」+ 提示手动 /compact 命令可稳定逼出
- 内容源：lesson.md §1.3（L307-398）

**S010 四路路由（进阶）🔴 ｜ 2026-06-05 最终版 v3：对照课件插图 context_overflow_precheck 流程图 1:1 重建**（用户指定；替代 v2 级联与初版判断树）
- 中轴纵向串联：入口框 → 菱形1（overflowTokens>0?）→ 菱形2（toolResultReducibleChars≤0?）→ 菱形3（可截空间≥覆盖阈值?）；菱形用 clip-path 双层画形（描边层+白底填充层），**文字保持水平**——初版旋转 45° 文字不可读是主败因
- 分支对照插图：fits 左出(绿 #1a7f4e) / compact_only 右出(红=primary) / truncate_tool_results_only 右出(蓝=accent) / compact_then_truncate 左出(橙 #b45309 实底最贵徽章)；分支标签只用 是/否
- 交互：顶部 4 个白话场景按钮（①装得下②溢出没东西可截③截一截就够④截了还不够）或点终点卡 → 路径逐段点亮（230ms/段）→ 底部 [context-overflow-precheck] 日志指纹带真实字段数值；setTimeout 链带 isConnected 守卫
- 教训沉淀：var(--color-bg-light) 是幽灵 token（真名 --color-bg-surface），静默 fallback 透明导致菱形填充失效——新 slide 用 token 前须对照 css/main.css 实名

**S010 初版（已被替代）｜A·可点击判断树**
- 真实判断树复刻（本页菱形判断框合法——lesson 配图注明是真实判断逻辑）：overflowTokens>0? → 可截空间≤0? → 可截空间≥覆盖阈值? → 四终点 fits（绿·零成本）/compact_only（红·贵）/truncate_tool_results_only（蓝·便宜）/compact_then_truncate（橙·贵）
- 点击判断节点选走向，到达终点亮成本标签；「一键演示四条路径」按钮依次走完
- 底部常驻：「先走便宜的路，不够才动用 LLM——成本分级」+ 运行时指纹「debug 日志 [context-overflow-precheck] 行打出 route= 判定」
- 头部标注「进阶加餐：零基础可跳过，不影响主线」
- 内容源：lesson.md 进阶盒子（L400-432）

**S011 第 1 章收口 🟡 ｜ 2026-06-05 用户二次拍板重构：A·两柱对账连线图 + 一扇门**（替代下述初版对账表，初版保留备查）
- 左柱五阶段卡（过程视角，失败徽章挂卡上：—/—/✓可降级/✗fail-closed/✗fail-closed），右柱四层 context 堆叠在「完整 context」框内（结果视角，配色对齐 S007：灰蓝/绿/琥珀/橙），框下注「= proxy blob 里那个请求体」
- 中间 SVG 真连线（运行时按元素坐标画贝塞尔曲线）：boot→system / ingest→history+当前 / assemble→四层全部 / compact→history / prepare→整框打包；点击阶段 → 连线+目标层点亮 + 底部动态一句话；默认激活 assemble
- 最右发光门（呼吸光晕动画）挂在 prepare 连线的延长线上——快照→门的常驻连线让空间即叙事；点门 → 预告浮层「快照是 fork 还是 isolated？第 2 章揭晓」（S012/S014 从这扇门进）
- 旧版色标图例卡删除（失败语义已编码进徽章），fail-closed 原因降为底部小字

**S011 初版（已被替代）｜A·对账表 + 一扇门**
- 主体：五阶段↔四层对账表（过程 vs 结果两套视角同一件事），失败行为色标列（assemble 绿可降级 / compact·prepare 红 fail-closed）
- 右下角发光的「门」元素标 prepareSubagentSpawn，点击开门缝透出第 2 章预告一句话（子 agent 拿到的快照是 fork 还是 isolated？）——S014 叙事从这扇门进来
- 内容源：lesson.md 对账表（L295-301）+ §1.4

### Part 2 — 多智能体（S012–S016）

**S012 章过渡 🟢**：第 2 章「子 agent 到底隔离了什么、又共享了什么？」+ 2.1-2.3 预览。

**S013 认知重塑 🟡 ｜ 2026-06-05 用户二次拍板重构：A·误解打叉三幕剧**（替代下述初版拓扑对比，初版保留备查）
- 左幕「❌ 你以为的：线程模型」：main 进程框内三个 thread 芯片 + 四条直觉清单；点击整卡 → 红章扣下「✕ 这个类比是错的」+ 内容灰化——错误直觉必须先出场再被打掉
- 右幕「✅ 真相：平级同事」：main agent 卡与 sub-agent 卡**同尺寸同内部结构**并排（↻ 自己的 loop / 🛡 自己的权限评估·同一套管线 / 🔑 session key 常显对比 / 📦 独立状态+isolated|fork chip）——结构同构 = 平级的视觉证据，消除旧版"main 大 sub 小"的主从暗示
- spawn 通道：sessions_spawn 非阻塞箭头（注 subagents 工具管查看）+「⊕ 再 spawn 一个」按钮现场派生 sub-B（入场动画，display:none→keyframes）
- 底部两条：⚠ 不是提权后门·约束只严不松（永久禁用名单）/ 📌 单 agent 独木桥困境 + 钩子「隔离了什么共享了什么？下两页拆开」
- 旧版 lane 轨道删除（S015 四维边界实验台已深度覆盖 lane）；hover 细节全部改常显

**S013 初版（已被替代）｜A·左右拓扑对比**
- 顶部大字「子 agent 不是线程，是平级的独立 agent session」
- 左：单 agent 独木桥（双层 while 心脏，任务串一条线）；右：agent 团队（main 橙 spawn 两个子 agent 绿，底部共享 subagent lane 橙色虚线轨道，标 maxConcurrent 默认 8）
- hover 子 agent 显示 isolated/fork 细节与独立 session key 格式 agent:<id>:subagent:<uuid>
- 内容源：lesson.md §2.1（L499-507）

**S014 spawn 生命周期 🔴🔴 ｜ 确认方案：A·双泳道时序模拟器**
- 主/子 agent 双泳道时序图，点「spawn」逐步播放：
  ① sessions_spawn 立即返回 {accepted, runId, childSessionKey}——非阻塞高亮（主泳道不停顿，文档原话 always non-blocking）
  ② 子 agent 在 subagent lane 排队执行工具调用
  ③ 完成后 announce 虚线推送回父（标 best-effort：gateway 重启会丢）
  ④ 父下一轮收到内部消息
- 「错误 vs 正确等待姿势」对照按钮：轮询 subagents（红✖）vs sessions_yield 主动结束 turn（绿✔，工具描述原话 "results arrive as next message"）
- 附注：子 agent 禁横向私聊（sessions_send 在永久禁用名单，"communicate through announce chain"）
- 内容源：lesson.md §2.1（L509-515）；cleanup 铁律适用

**S015 两隔离两共享 🔴🔴 ｜ 确认方案：A·四维边界实验台**
- 中央 main/sub 两实体，四维按钮 [session][context][lane][auth] 点击逐维点亮两实体间连线状态：隔离=断开（墨蓝✂）/共享=连通（橙实线）
- context 维附 isolated|fork 子开关：isolated 不继承父对话历史（标注：仍有自身 bootstrap 注入，白名单仅 AGENTS.md/TOOLS.md，非空白）/ fork 复制父快照
- lane 维点击演示：8 槽位满后第 9 个子 agent 被挡排队动画（maxConcurrent=8 安全阀；对照主 agent main lane 默认 4）
- auth 维：{openai:父key} + {anthropic:子key} 合并展示，附文档原话 "Fully isolated auth per agent is not supported yet."
- 角标诚实边界：四维中仅 session 隔离有运行时实证，其余三维=源码+文档证（PARTIAL）
- 内容源：lesson.md §2.2（L519-555）+ 对账表（L716-722）

**S016 多智能体模式全景 🟡 ｜ 确认方案：A·谱系卡片墙**
- 6 种模式按通信形态分组卡片墙：父子分治（subagent spawn·ACP spawn）/ fan-out 广播（Broadcast Groups，experimental，互相看不到对方回应）/ 点对点（sessions_send，A2A 约束）/ 编排（Task Flow+Lobster、cron 定时）
- hover 显示隔离与通信特征；底部诚实边界条：「有 fan-out 式多 agent，没有对等 mesh / 共享黑板 / 多 agent 协商运行时（截至 2026-05-29 主分支）」
- 附 subagent 嵌套谱系小字：maxChildrenPerAgent=5 / maxSpawnDepth=1，角色 main→orchestrator→leaf
- 内容源：lesson.md 模式全景表+两层回答（L773-787）

### Part 3 — 记忆系统 ★（S017–S021）

**S017 章过渡 🟢**：第 3 章「上周说的花生过敏，这周它还记得吗？」+ 3.1-3.3 预览。

**S018 记忆文件全景 🔴 ｜ 确认方案：A·文件树探索器**
- 模拟 ~/.openclaw/workspace/ 文件树（等宽字体拟终端 ls 风格），点击每项右侧亮职责卡：
  MEMORY.md→核心长期记忆，注入 context 第②层，10K 字符预算超出截断 / memory/YYYY-MM-DD.md→daily-note / DREAMS.md→用户日记（默认没有：dreaming 未开就不存在，不是装坏了）
- dreaming 三处三色防混淆标签：dreaming/=产出 dream-report（橙）/ .dreams/=内部状态 events.jsonl·short-term-recall·phase-signals（紫）/ DREAMS.md=用户日记（蓝）
- 顶部警示带「三处长得像，职责完全不同——最高频误解」
- 附注：compact 前静默 memory flush 抢救（软阈值 4000 tokens）+ sessionMemory 默认关闭
- 内容源：lesson.md §3.1（L799-887）

**S019 hybrid RAG 检索 🔴🔴 ｜ 确认方案：A·检索模拟器 + 权重滑杆**
- 预设 query「回忆零食偏好」+ lesson 同款 3 条 mock 记忆（m1 花生过敏零食 / m2 美式咖啡 / m3 坚果礼盒）
- 点「检索」两路并行动画：左向量路（语义距离可视化，×0.7）右全文路（关键词命中高亮，×0.3），分数条汇入融合排序台 → m1 第一 m2 垫底
- 权重滑杆拖动 vectorWeight 看排序实时变化——体感「为什么 0.7 偏向量」+「可配置」（agents.defaults.memorySearch.query.hybrid.vectorWeight/textWeight）
- 诚实标注：真实全文路用 BM25 非命中比例；权重会先归一化；无 embedding provider 时优雅降级 FTS-only
- 附 search→get 两步范式一句话（memory_get 按行精读核实）
- 内容源：lesson.md §3.2（L889-1029）；cleanup 铁律适用

**S020 dreaming 管线 🔴🔴 ｜ 确认方案：A·昼夜循环模拟器**
- 上区白天带（浅色）：对话积累→每日记忆 + memory_search 记账计数器跳动（short-term-recall.json）
- 点「快进到凌晨 3 点」页面切深蓝夜间主题（注意：夜间区深色仅限本页舞台区局部，不改全局浅珊瑚雾主题）：cron 闹钟（Memory Dreaming Promotion，0 3 * * *；机制默认关闭需 dreaming.enabled:true）触发三阶段依次点亮
- **顺序硬约束 light→rem→deep**（严禁 light→deep→rem）；rem→deep 加权细箭头（主题信号给晋升加权）
- deep 漏斗过滤动画：评分≥0.8 / 被召回≥3次 / 来自≥3个不同查询，每晚最多 10 条
- 产出三盒：三阶段报告（light/deep/rem 子目录）/ DREAMS.md（汇报文学日记）/ MEMORY.md；MEMORY.md 绿色回灌箭头闭环到「下一轮 context 第②层」
- 首晚彩蛋提示：「Promoted 0 不是故障是设计——召回记账还没攒够」+ recovery 自愈一句话
- 内容源：lesson.md §3.3（L1033-1103）；cleanup 铁律适用

**S021 记忆后端全景 🟡 ｜ 确认方案：A·插件插槽可视化**
- 中央 OpenClaw 主体留一个 memory 插槽（memory-core 默认在槽内），4 张候选后端卡（memory-lancedb/memory-wiki/active-memory/外部系统 mem0·Zep）环绕，hover 显示存储/检索/定位
- mem0 接入三层阶梯：✅ 只读检索增强开放（包 search/get 即可）/ ⚠️ 插件槽位半开放（plugins.slots.memory）/ ❌ 原生后端枚举封闭（memory.backend 仅 builtin|qmd）
- 呼应第一节课 plugin 边界：「换后端就像换插件」
- 内容源：lesson.md 后端全景表+三层答案（L1152-1167）

### Part 4 — 收口（S022–S024）

**S022 三脑一轴回归 🟡 ｜ 确认方案：A·同构升级图**
- 与 S004 同一张主轴图回归（布局骨架一致，首尾呼应），每个脑升级标注源码真名+主轴连接点：当下脑=ContextEngine（轴本身的组装者）/ 分治脑=subagent 系统（经 prepareSubagentSpawn 门备独立 context）/ 长期脑=记忆系统（经 assemble 记忆注入层回灌）
- 点击任意脑弹出「可迁移三问」：看任何 agent 系统都问——当下脑怎么组装 context？有没有分治脑怎么分？长期脑怎么存怎么取？
- 比喻声明小字保留
- 内容源：lesson.md §4.1（L1176-1203）

**S023 诚实边界 + 能力回顾 🟡 ｜ 确认方案：A·双栏盘点**
- 左栏 4 条诚实边界墨蓝描边卡：① subagent 运行时实证 PARTIAL（仅 session 实证）② sessionMemory 默认关 ③ dreaming 现场难触发（降级翻产物）④ fail-closed 仅 compact/prepare 两阶段特例
- 右栏 7 件产物清单逐条点击点亮勾选（学员自评）：proxy 三命令看四层 / 五阶段+fail-closed 范围 / context MVP / 两隔离两共享 / 隔离语义 MVP / 3文件+dreaming三处 / 0.7/0.3 出处
- 底部一句「区分『我有证据』和『我亲眼跑通』是 agent 工程师的核心素养」
- 内容源：lesson.md §4.2（L1205-1213）

**S024 下节预告 🟢**
- 沿用第一节课预告页范式：下节主题「跨渠道骨架——Gateway / channel / node 三层如何分摊决策权」+ 钩子（接微信接 Telegram 跑多台机器，谁集中调度谁分散执行）+「集中 vs 分治」张力回扣
- 内容源：lesson.md L1215

## 生成阶段硬约束（沿用第一节课验证过的教训）

1. slide 片段只用 css/main.css 已有 token 与组件类（.glass-card/.slide-title/.animate-ready 等），**禁止硬编码颜色**（含 3 位 #fff、rgba 数值、var() fallback 三盲区）
2. 居中铁律：wrapper 走 .slide 基类，禁自造全屏定位
3. 🔴🔴 页 slideHooks：键名为 'slides/SXXX-*.html' 全路径；必须 return cleanup（clearInterval + gsap.killTweensOf + removeEventListener；防 null 早退也 return noop）
4. CSS Grid 防撑爆：列用 minmax(0,1fr) 不用裸 1fr
5. Sonnet 生成 JS 多行字符串必须用反引号模板字面量
6. 每页生成后真浏览器（HTTP 服务）验证，不只静态 grep；hash 导航 1-based
7. 数字一律以 lesson.md 为准（0.7/0.3、maxConcurrent=8、main lane 4、10K 预算、900s、0 3 * * *、≥0.8/≥3次/≥3查询/10条、5/1 嵌套上限）；图中不出现源码行号
8. 完成后回填 js/main.js 三数组、style_manifest.json total_slides、README.md 状态表（页数以 slideFiles 数组为准，当前 25）

## 2026-06-05 第一章内容增量（lesson.md 新增块同步）

**S007 四层冰山 🔴 ｜ 重构：两幕剧（冰山 → 成分账单）**
- 背景：lesson §1.1 新增成分账单（总量 ≈34 万字符：tool_result 72% / tools 16% / system 11% / 对话 <1%），推翻旧版「system 92% 是主体」口径
- 幕1 保留原「掀开水面」三层揭示交互（system 层措辞改为"先别下结论"伏笔）；幕2 新增「把整个请求体摊开算账 💰」：tools 第五块（虚线边框=四层之外随行块）现形 + 右侧比例条切换为账单四行 + footer 换红色灵魂句「真实 agent 的 context 是被工具吃掉的，不是被聊天吃掉的」
- tools 块未揭示时 display:none + keyframes 入场（防幕1布局空洞，沿用 S013 教训）
- 初版（单幕 system 92%）保留于 git 历史备查；soul_line 取 lesson 原文

**S010b 四道防线 🔴（新增页，插于 S010/S011 之间）｜ 方案：流水线四闸 + 灾难输出闯关**
- 背景：lesson §1.3 进阶新增「四道防线」（L0 源头限流/L1 落盘封顶/L2 组装瘦身/L3 压力触发）+ prompt cache 暗线
- 上半：四闸卡横排（配色对照 lesson 插图 L0绿/L1蓝/L2琥珀/L3橙红），各带时机副标+要点+成本 chip（前三道"规则动作·零 LLM"，L3"compact 调 LLM·最贵"）
- 下半演示舞台：80,000 字符灾难 bash 输出**加载即投放**（首屏即见 visual hero），按钮步进过四闸——L0 保尾（Error 标记全程幸存）→ L1 封顶 16,078+修复指引后缀蓝段 → L2 平行世界双 chip（cache 热零动作/过期软裁硬清）→ L3 点亮"上一页那棵判断树"并点亮底部紫线
- 底部紫色暗线带：「prompt cache 按前缀命中——宁可追加、不要重写」（L3 时发光强调）
- 联动已同步：main.js 三数组（25 页/章区间 Part1 end=11 起顺延）+ index.html page-total + style_manifest total_slides=25 + README 页数与 Part1 行
- 验收：全 25 页 polish_audit 🟢（S007 blank=0.20 / S010b blank=0.30），S007 三态 + S010b 五态探针 maxBottom=778<810 零 pageerror，截图肉眼过

## 2026-06-05 第二章内容增量（lesson.md §2.3 八行谱系同步）

**S016 多智能体全景 🔴 ｜ 重构：6 卡片墙 → 「一个地基 + 七种形态」互动拓扑**
- 背景：lesson §2.3 谱系升级为八行（新增 agents.list 地基行 + Codex Supervisor 行）；旧版 ACP 卡存在事实错误（Agent Communication Protocol → 正名 **Agent Client Protocol**，定位从"跨机器分布式"纠正为"接外部 AI 编码代理当 agent 使"）
- 左侧 visual hero：以 main 为中心的互动拓扑——agents.list 蓝色地基横带（常亮，main/work/coding 三人格立其上，"默认只有一块砖"）+ subagent 块置于地基**之下**（标注"运行时派生的执行体，不是配置的人格"）+ SVG 运行时连线（S011 范式）
- 四形态 tab 切换（方向语义可视化）：🌿父子分治（橙实线下行 spawn + 虚线上行 announce，默认态）/ 💬1:1 有界（绿色双向箭头，ping-pong 5 轮/硬上限 20/默认关死）/ 📡fan-out 广播（紫色扇形，互不可见对方回应；文档 WhatsApp only vs 飞书源码超前）/ 🔌ACP 外接（蓝虚线连外部进程区，13 种 harness；默认关，runtime 枚举动态收缩"agent 压根看不见"）
- 右列辅助三形态卡：cron 定时 / Task Flow+Lobster / Codex Supervisor（experimental 默认不启用，监督对象是外部 Codex 会话非本章 subagent）+ 嵌套谱系 chip（5/1 + main→orchestrator→leaf 保留）
- 底部诚实边界条升级：否定声明限定在「运行时原语」层 + OpenProse SQLite 白板=用法层拼装非新原语
- 未上画面（lesson 自评"了解即可"）：delegationMode 旋钮 / 60 分钟归档 / 禁发五工具枚举 / 三观测路径——留讲稿
- 验收：四形态探针 maxBottom=778<810 零 pageerror，polish_audit 🟢 blank=0.20（旧版 LOW_DENSITY 36% 顺带治愈），截图肉眼过

**2026-06-05 连线断裂 bug 修复（S016 + S011 同款隐患）**
- 现象：用户大视口（~2000×1290）下 S016 spawn/fanout 连线全部断开悬空；810 探针自测假绿
- 根因：SVG 运行时连线是**绝对坐标快照**（加载时画一次），DOM 块百分比定位随视口移动，线不跟随；字体异步加载同样会让首屏坐标失效
- 修复：S016/S011 统一加三重重画——①每次交互（setMode/activate）先 drawAll ②document.fonts.ready 后重画 ③ResizeObserver 监听容器（isConnected 守卫防泄漏）；S016 spawn/announce 线改左右配对锚点消除交叉
- 验收：2000×1290 大视口 + 810→1290 resize 跟随，spawn/fanout 线终点距目标块顶边 gap=2px 量化断言，四形态截图肉眼过

## 2026-06-05 第三章内容增量（lesson.md §3.2 三条来路 + §3.3/3.4 细节同步）

**S018 记忆文件树 🔴 ｜ 修事实错误 + 吸收「三条自动来路」**
- 修错①：原每日笔记卡「sessionMemory 默认关闭：需启用才会自动写入每日笔记」混淆了两个机制——更正为：写入默认就开（flush+hook），`experimental.sessionMemory`（默认关）只管"会话转录建索引供检索"
- 修错②：flush 说明原错挂在 MEMORY.md 卡（flush 写的是每日记忆）——移到 daily 卡；MEMORY.md 卡 meta 改为"主动提炼 + dreaming deep 晋升"两来路
- 修错③：dreaming/ 卡泄漏插图 prompt 元语言（"严禁……加权细箭头"）——改为面向学员的真实顺序解释
- 新增：文件树补 `2026-06-03-1500.md` 快照节点 + 新详情卡「会话快照（带时分形态）」——桥② session-memory hook（/new、/reset 摘最近 15 条；default-on，文档表述滞后案例）；daily 卡改为桥①（flush 4000 tokens/2MB 强制 + 主动写）；footnote 升级为三条自动来路总览（①flush 默认开 ②hook 默认开 ③dreaming 默认关）
- "两种文件名形态 = 两条来路"通过 daily/快照两卡对照呈现

**S019 hybrid RAG 🔴 ｜ 细节注 +1**
- 诚实边界区补第 4 条：minScore 0.35 静默过滤（"搜不到先想 minScore"红字排查项）+ corpus 参数四域（memory/wiki/all/sessions）

**S021 记忆后端 🟡 ｜ 增强（顺带治 LOW_DENSITY 61%→🟢）**
- memory-wiki 卡改"叠加层"定位 + 两层开关活案例（manifest onStartup:true ≠ enabled；bundled 默认不上膛）+ corpus=wiki 呼应 S019
- 阶梯第二级补 mem0 官方插件实例 + 全局性约束（槽位全局、不支持按 agent 指定）
- callback 补通用教训：manifest 声明 ≠ 运行时状态，以 plugins list 实跑为准
- 未上画面（lesson 自评"了解即可"或纯配置操作）：短期 vs 长期分界四维表 / recovery 预留未消费 / 手动 promote CLI / mem0 配置 JSON——留讲稿
- 验收：三页双视口（1440×810 + 2000×1290）探针零溢出零 pageerror，S018 快照卡交互态截图过，polish_audit 四页全绿

## 2026-06-05 S014 重构（用户指出非阻塞效果不清 + 左右水平位置未对应）

**S014 spawn 生命周期 🔴🔴 ｜ 重构：两盒子结构图 → 垂直双泳道时序图（方案 A·用户拍板）**
- 失败根因：旧版用"两个盒子+箭头"的结构图表达时序并发——盒内卡片堆叠无时间语义，"非阻塞""等待期间子在跑"全靠文字
- 新范式几何约束：**同一水平高度 = 同一时刻**。8 时间行 × [main 泳道 | 中列箭头 | sub 泳道] grid，背景中轴生命线
- 三个关键视觉证据：①行1-2 spawn/accepted 双箭头紧贴 + ⚡chip「与 spawn 几乎同时=非阻塞」②行4-6 main 虚线等待段（"turn 已结束·不占资源"+ ··· 动画）与 sub 实心执行段同高并排，中列括注「main 空着 sub 在干活」③行7 announce 绿箭头唤醒 + 行8 新 turn
- 交互保留 5 stage（重播/暂停/单步 + dots）：1 非阻塞派生 / 2 yield 让台 / 3 并行时段(核心) / 4 announce / 5 新 turn；初始态=stage5 全图点亮（首屏即见完整时序）
- hook 重写（interactive.js 300 行→112 行）：纯 DOM class 切换 + setTimeout，无 GSAP——彻底退出陷阱⑦⑧风险区
- 底部对照升级：错误姿势注释指回泳道（"等待段仍实心烧 CPU"）、正确姿势指回虚线段
- 验收：五状态探针 + 大视口 2000×1290 + 切页静置 3s 零 pageerror（陷阱⑧验收项），polish_audit 🟢

## 2026-06-05 S015 比例精修（用户指出字体与容器比例失衡）

**S015 四维边界实验台 🔴🔴 ｜ 字号等比放大 27 处 + session 详情区充实**
- 全局字号放大 ~25-35%（实体卡名/key、维度按钮、连线徽章、四面板正文、lane 槽位、证据 chips），slot 尺寸 1.9-2.6rem→2.5-3.3rem
- session 详情区重做：原"一句话+三行小字撑大虚线框"→ 左右两张 key 卡（橙边 main / 蓝边 sub，与上方实体卡左右对齐呼应）+ 中缝 ✂ 隔离分隔 + 每卡三行"不共享清单"（session 状态/历史 turn/tool 队列）+ 底部 runtime 实证 pill（呼应 PARTIAL 证据链）
- hook 未动（验证过 hook 不引用被改元素；setDim 有 toggle 语义——同维度再点=收起，探针偶现"空态"是该设计行为非 bug）
- 验收：四维度态 + 默认态双视口（810/1290）零溢出零 pageerror，截图肉眼过

**2026-06-05 S014 字号等比放大（用户二次反馈）**
- 时序图重构后用户要求字体再大一档：20 处 clamp 放大 ~15-20%（标题/控制条/泳道头/段名/段副标/中列标注/caption/底部对照/footnote），行高 44→50px
- 验收：810 视口 maxBottom=783（余量 27px，FM 注释已标"再加内容须先减行高"），1290 视口过，零 pageerror

**2026-06-05 S019 布局修正（用户指出标题与内容贴顶）**
- 根因：`.slide:has(.s019-sim)` 写死 align-items/justify-content: flex-start——大视口下内容贴顶、底部大片空白
- 修复①：改垂直水平居中（内容 max-height 85vh 恒小于视口，无 flex-center+overflow 裁顶风险），上下留白差实测 0px
- 修复②（顺手，S010b/S014 同先例）：hook 入场动画后 750ms 自动跑一轮检索——首屏即见两路分数条+融合排序结果，payoff 不等点击；autoRunTimer 已入 cleanup
- 验收：双视口（810/1290）居中对称、自动检索动画完成态截图过、零 pageerror

## 2026-06-05 S021/S022 收口页字号与布局调整（用户要求）

**S021 记忆后端 🟡 ｜ 字号放大 17 处 + detail 改常显**
- 全局字号 +20-28%（headline/插槽标签/后端卡名/阶梯三级标签与正文/底部 callback）
- 后端卡 detail 从 hover 展开（max-height 80px 会裁长文案、课堂投影 hover 不可靠）改为常显——memory-wiki 两层开关案例完整可见，audit blank 0.31→0.14

**S022 三脑一轴回归 🟢 ｜ 重构：弹层三问 → 常驻三列（LOW_DENSITY 44% 根治）**
- 失败根因：「可迁移三问」（第 4 章框架可迁移的灵魂）藏在点击弹层里，初始态只剩三张名牌卡漂在窄带
- 新布局：三列 = 脑卡（emoji+比喻名+源码真名 pill+机制链）+ 对应迁移问卡常驻（Q1 组装四问/Q2 分治四问/Q3 存取四问），配色锚点当下脑橙/分治脑绿/长期脑墨蓝；底部 context 轴条 +「命名陷阱」祛魅条升格；标题改为"以后看任何 agent 系统，都问这三问"（lesson 可迁移价值前置）；弹层与页内 script 删除（🔴→🟢 纯静态）
- 两轮放大后 audit 🟢 blank=0.21（44%→79% 占比）
- 验收：两页双视口（810/1290）零溢出零 pageerror，截图肉眼过
