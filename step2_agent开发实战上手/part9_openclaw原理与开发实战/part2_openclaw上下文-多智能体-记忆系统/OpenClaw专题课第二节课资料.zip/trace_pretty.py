#!/usr/bin/env python3
"""
trace_pretty.py — OpenClaw 教学日志降噪高亮器（诚实版）

用法：
    openclaw --log-level debug tui --local 2>&1 | python3 trace_pretty.py
    openclaw --log-level debug tui --local 2>&1 | VERBOSE=1 python3 trace_pretty.py  # 灰显其余行

⚠️ 能力边界（基于 OpenClaw commit 0b24f47465 源码核实，作者未在真机实测）：
  · OpenClaw logger = tslog，输出【文本格式】到 stderr，无 --json / ndjson 结构化事件流。
  · agent 生命周期事件 (agent_start / turn_start / … / agent_end) 被订阅消费，
    **不逐条进 debug 文本日志**（embedded-agent-subscribe.handlers.ts:35 仅在
    handler 失败时才 log evt.type）。
  => 本脚本【无法】重建完整 ①→⑨ loop 序列。完整序列的"体感"主力是：
       - TUI 原生逐步展示（startTool/updateToolResult，chat-log.ts:333）
       - proxy blob 看真实 context（openclaw proxy blob --id <id>）
       - 源码精读对照 agent-loop.ts:122-326 的 emit 行
     完整结构化序列若必须脚本化 → 走 diagnostic-events transport
     (attempt.ts:988 emitTrustedDiagnosticEvent + logger.ts:455)，需真机实测 + 多半用 TS。

  · 本脚本只做【降噪 + 高亮已确认进 stderr 文本日志的教学行】。
  · 下面 PATTERNS 已于 2026-06-04 按真机 debug 日志校准（openclaw agent --local 无头跑法）。
    校准记录：① 旧"上下文压缩"正则匹配的是 hook 失败行，正常路径 0 命中——真实可观测行
    是 [context-diag] pre-prompt（roleCounts 含 compactionSummary）和 [context-overflow-precheck]
    （route=fits/compact_only/... 四路路由判定）；② 旧"子agent"正则裸匹配 "subagent" 会被
    skills 路径警告行（subagent-driven-development）误命中，已收紧到 tool=sessions_spawn /
    session key / lifecycle 事件；③ 工具调用真实指纹是 "embedded run tool start/end: ... tool=<名>"。
"""
import sys
import re
import os

# (中文标签, 正则)。顺序即匹配优先级：specific 在前，generic 在后。
PATTERNS = [
    # [context-diag] pre-prompt: ... messages=39 roleCounts=assistant:19,compactionSummary:1,... systemPromptChars=37636
    #   每轮发模型前的"上下文体检"——roleCounts 里的 compactionSummary 就是压缩摘要存在的活证据
    ("🧩 上下文体检", re.compile(r"\[context-diag\] pre-prompt:")),
    # [context-overflow-precheck] ... route=fits estimatedPromptTokens=... overflowTokens=0 ...
    #   compact 四路路由（fits/compact_only/truncate_tool_results_only/compact_then_truncate）的判定现场
    ("🗜 压缩路由判定", re.compile(r"\[context-overflow-precheck\]|route=(fits|compact_only|truncate_tool_results_only|compact_then_truncate)")),
    # 压缩真正执行期的日志（含 safeguard 与 hook 失败行）
    ("🗜 压缩执行", re.compile(r"\[compaction(-safeguard)?\]|embedded run compaction|session:compact:(before|after)|(before|after)_compaction")),
    # 子 agent：spawn 工具调用 / 子会话 session key / 生命周期事件（不再裸匹配 "subagent"，避免 skills 路径误报）
    ("👥 子agent", re.compile(r"tool=sessions_spawn|agent:[\w-]+:subagent:[a-f0-9-]+|lifecycle-(ok|blocked)-event")),
    # 记忆检索工具调用与记忆文件
    ("🧠 记忆", re.compile(r"tool=memory_search|memory sync|MEMORY\.md")),
    # 通用工具调用起止（embedded-agent-runner 的 debug 行）
    ("🔧 工具调用", re.compile(r"embedded run tool (start|end):.*tool=(\S+)")),
    # src/agents/agent-tool-definition-adapter.ts  logDebug("tools: <name> blocked by before_tool_call: <reason>")
    ("🔒 工具拦截", re.compile(r"tools:\s+(\S+)\s+blocked by before_tool_call:\s*(.+)")),
    # hook 失败兜底
    ("⚠ hook失败", re.compile(r"(before|after)_tool_call hook failed:\s*tool=(\S+)")),
]

CYAN = "\033[1;36m"
DIM = "\033[2m"
RESET = "\033[0m"


def classify(line):
    for label, pat in PATTERNS:
        if pat.search(line):
            return label
    return None


def main():
    verbose = bool(os.environ.get("VERBOSE"))
    hits = 0
    for raw in sys.stdin:
        line = raw.rstrip("\n")
        label = classify(line)
        if label:
            hits += 1
            print(f"{CYAN}[{hits:02d}] {label}{RESET}  {line}", flush=True)
        elif verbose:
            print(f"{DIM}{line}{RESET}", flush=True)
    if hits == 0:
        print(
            f"{DIM}(未匹配到教学关注行 —— 确认已加 --log-level debug，"
            f"或日志格式与 PATTERNS 不符，按真机输出微调正则){RESET}",
            file=sys.stderr,
        )


if __name__ == "__main__":
    main()
