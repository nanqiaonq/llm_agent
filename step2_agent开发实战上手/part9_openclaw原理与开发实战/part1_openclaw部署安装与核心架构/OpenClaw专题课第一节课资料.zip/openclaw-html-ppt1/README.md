# OpenClaw 核心架构 · 第一节课（HTML 互动课件）

配合《OpenClaw 专题课第一节课：部署安装与核心架构》（Jupyter 课件）使用的课堂演示 HTML 课件。共 **22 页**，覆盖 OpenClaw 的定位与演进、agent 运行时心脏（双层 while × EventStream × steering）、工具系统（plugin / capability / tool × 8 步策略管线）、安全纵深（exec 三档 × Docker sandbox）四大主题。

## 运行方式

课件通过 `fetch` 动态加载 slide 页面，**不能直接双击 `index.html` 打开**（`file://` 协议下浏览器会拦截 fetch），必须起一个本地 HTTP 服务：

```bash
cd html-courseware
python3 -m http.server 8000
# 然后浏览器访问 http://localhost:8000
```

或使用 Node：

```bash
npx serve .
```

## 操作说明

| 操作 | 按键 / 方式 |
| --- | --- |
| 翻页 | `←` / `→` 方向键，或底部导航按钮 |
| 目录面板（分章跳页） | `M` 键或工具栏目录按钮 |
| 钢笔（拖尾笔迹，1.2s 自动消隐） | `T` 键或工具栏钢笔按钮 |
| 画板（持久涂画） | `D` 键或工具栏画板按钮 |
| 全屏 | `F` 键或工具栏全屏按钮 |
| 笔迹颜色 | 工具栏颜色选择器 |

## 内容结构（4 Part × 22 页）

| Part | 页 | 内容 |
| --- | --- | --- |
| Part 0 — 开场铺垫 | S001–S006 | 封面 / OpenClaw 是什么有多火 / 三维定位 / 四款工具横向对比 / 四代演进蜕壳之路 / 不是什么四条边界 |
| Part 1 — 全局地图 | S007 | 一条消息的生命周期：全课路线图 |
| Part 2 — 核心架构（重心） | S008–S015 | 第 2 章过渡 / chatbot vs agent / **双层 while + steering 模拟器**🔴 / **EventStream 10 事件**🔴 / 第 3 章过渡 / plugin·capability·tool 层级 / 拖拽归位练习 / **8 步策略管线小球闯关**🔴 / exec 默认 full·off 非漏洞 |
| Part 3 — 哲学收口 | S016–S021 | 第 4 章过渡 / **exec 三档×三态双轴旋钮**🔴 / Docker sandbox 分层 / 信任 vs 约束张力光谱 / 全课能力回顾 / 下节预告 |

🔴 标记为重交互模拟器页（S010 / S011 / S014 / S017），由 `js/interactive.js` 的 slideHooks 驱动，可课堂现场操作演示。

## 目录结构

```
html-courseware/
├── index.html                  # 主入口（导航骨架 + 工具栏）
├── css/main.css                # 全局样式（设计 token + 布局）
├── js/main.js                  # 翻页引擎：slideFiles/slideTitles/chapters + 钢笔/画板/目录
├── js/interactive.js           # 重交互页 slideHooks（4 个模拟器的状态机）
├── slides/                     # 22 个独立 slide 页面（S001–S021 + S013b 练习页）
├── images/                     # 课件图片（四代演进时间轴）
├── courseware-brief.md         # 设计简报（页面规划与交互级别）
├── interaction_architecture.md # 交互架构设计（每页交互模式选型依据）
├── slide_structure.json        # 页面结构定义
├── style_manifest.json         # 视觉风格清单（L3 浅珊瑚雾 Coral-Mist 主题，续作保持一致用）
├── confirmed_redesign.md       # 重设计确认记录
└── .progress.json              # 生成 pipeline 状态（断点续传用）
```

## 维护注意

- 新增 / 删除 slide 时，`js/main.js` 里 **`slideFiles`、`slideTitles`、`chapters` 三个数组必须同步修改**（slideFiles 与 slideTitles 必须等长，chapters 区间须覆盖 0 到 length-1）。
- 第二节课等续作请沿用 `style_manifest.json` 的设计 token，保持系列视觉一致。
