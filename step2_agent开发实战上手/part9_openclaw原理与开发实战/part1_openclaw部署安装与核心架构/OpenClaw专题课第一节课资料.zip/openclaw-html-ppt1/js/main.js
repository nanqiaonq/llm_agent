/**
 * OpenClaw 核心架构 · 第一节课 — HTML 课件主控制器
 * 负责：slide 导航、侧边菜单(M)、画笔拖尾(T)、画板(D)、颜色选择器、键盘/触摸快捷键
 *
 * §一 骨架契约实现位置索引（REF_golden_patterns.md §一）：
 *   §一.1 双 canvas              → pen-trail-canvas / draw-board-canvas（index.html + initPenTrail / initDrawBoard）
 *   §一.2 进度条                 → updateProgressBar()
 *   §一.3 GSAP + Google Fonts    → index.html CDN 引用
 *   §一.4 目录分组铁律           → buildMenu()（4章分组，无 menu-item-dot）
 *   §一.5 工具栏五件套           → index.html DOM + 此文件 window.__ 暴露
 *   §一.6 CSS 变量注入           → css/main.css :root（≥12 个）
 *   §一.7 字体全正体             → css/main.css font-style:normal
 */

(function () {
  'use strict';

  /* ===== §一.5 三数组同步硬约束（T6b）===== */
  /* slideFiles.length === slideTitles.length && chapters[last].end === slideFiles.length-1 */

  var slideFiles = [
    'slides/S001-cover.html',
    'slides/S002-what-and-why.html',
    'slides/S003-three-dimensions.html',
    'slides/S004-comparison-table.html',
    'slides/S005-four-gen-molting.html',
    'slides/S006-not-what.html',
    'slides/S007-message-lifecycle-map.html',
    'slides/S008-chapter2-transition.html',
    'slides/S009-chatbot-vs-agent.html',
    'slides/S010-dual-while-steering.html',
    'slides/S011-eventstream-10events.html',
    'slides/S012-chapter3-transition.html',
    'slides/S013-plugin-capability-tool.html',
    'slides/S013b-plugin-drag-practice.html',
    'slides/S014-8step-pipeline-gauntlet.html',
    'slides/S015-exec-full-off-not-vuln.html',
    'slides/S016-chapter4-transition.html',
    'slides/S017-exec-dual-axis-knob.html',
    'slides/S018-docker-sandbox-layers.html',
    'slides/S019-trust-constraint-spectrum.html',
    'slides/S020-capability-review.html',
    'slides/S021-next-preview.html'
  ];

  var slideTitles = [
    'OpenClaw 核心架构 · 第一节课',
    'OpenClaw 是什么，它有多火',
    'OpenClaw 的三维定位',
    '四款工具横向对比',
    '四代演进：OpenClaw 的蜕壳之路',
    'OpenClaw 不是什么：四条边界',
    '一条消息的生命周期：全课路线图',
    '第 2 章：agent 的心脏',
    '认知重塑：chatbot 与 agent 的本质区别',
    '双层 while 循环与 steering 注入模拟器',
    'EventStream：10 个事件的生命周期',
    '第 3 章：心脏的手',
    'plugin / capability / tool：三者层级纠错',
    '动手验证：只有 tool ⊂ plugin',
    '8 步工具策略管线：小球闯关',
    'exec 默认 full/off：这不是漏洞',
    '第 4 章：安全纵深',
    'exec 三档×三态：双轴信任旋钮',
    'Docker sandbox 分层：policy vs sandbox',
    '信任与约束的张力光谱',
    '你现在能做什么：全课能力回顾',
    '下节预告：多智能体、上下文工程与记忆系统'
  ];

  /* §一.4 目录分组铁律：4 章 C0-C3 */
  var chapters = [
    { title: 'Part 0 — 开场铺垫',       start: 0,  end: 5  },
    { title: 'Part 1 — 全局地图',       start: 6,  end: 6  },
    { title: 'Part 2 — 核心架构（重心）', start: 7,  end: 18 },
    { title: 'Part 3 — 哲学收口',       start: 19, end: 21 }
  ];

  /* T6b 自验：slideFiles.length=22, slideTitles.length=22, chapters[3].end=21 = 22-1=21 ✓（含 S013b 练习页） */

  var totalSlides   = slideFiles.length;  /* 22 */
  var currentIndex  = 0;
  var slideCache    = {};
  var currentCleanup = null;
  var menuOpen      = false;
  var colorPickerOpen = false;

  /* ===== 画笔拖尾状态（§一.1 + REF §1 _pen.trails[] + FADE_MS=1200）===== */
  var _pen = {
    active:    false,
    canvas:    null,
    ctx:       null,
    drawing:   false,
    points:    [],
    trails:    [],
    rafId:     null,
    FADE_MS:   1200,   /* ←§一.1 时间衰减模式，严禁永久保留 */
    LINE_WIDTH: 3
  };

  /* ===== 画板状态 ===== */
  var _draw = {
    enabled: false,
    canvas:  null,
    ctx:     null,
    drawing: false
  };

  /* ===== currentDrawColor：颜色选择器共享（REF §3）===== */
  var currentDrawColor = '#ef4444';

  /* ─────────────────────────────────────────
   *  loadSlide：fetch + 缓存 + script 重执行
   * ───────────────────────────────────────── */
  async function loadSlide(n) {
    if (n < 0 || n >= totalSlides) return;

    /* 上页 cleanup（🔴🔴 页 timer/state 清理）*/
    if (typeof currentCleanup === 'function') {
      try { currentCleanup(); } catch (e) { /* ignore */ }
    }
    currentCleanup = null;

    currentIndex = n;
    updateProgressBar();
    updatePageIndicator();
    updateMenuActiveState();
    updateHash();

    var file = slideFiles[n];
    var html;

    if (slideCache[file]) {
      html = slideCache[file];
    } else {
      try {
        var resp = await fetch(file);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        html = await resp.text();
        slideCache[file] = html;
      } catch (e) {
        html = '<div style="text-align:center;padding:4rem;color:var(--color-text-dim);">无法加载 ' + file + '</div>';
        slideCache[file] = html;
      }
    }

    var viewport = document.getElementById('slide-viewport');
    viewport.innerHTML = '<div class="slide">' + html + '</div>';

    /* innerHTML 注入的 script 不会自动执行，必须手动重建 */
    var scripts = viewport.querySelectorAll('script');
    scripts.forEach(function(old) {
      var ns = document.createElement('script');
      if (old.src) {
        ns.src = old.src;
        ns.async = false;
      } else {
        ns.textContent = old.textContent;
      }
      old.parentNode.replaceChild(ns, old);
    });

    /* slideHook：interactive-eng 填充的 🔴🔴 cleanup 钩子（延迟 ≤10ms）*/
    setTimeout(function() {
      var hook = window.slideHooks && window.slideHooks[file];
      if (typeof hook === 'function') {
        try {
          var cleanup = hook();
          if (typeof cleanup === 'function') currentCleanup = cleanup;
        } catch (e) { console.warn('[slideHook error]', file, e); }
      }

      /* animate-ready 入场动画 */
      var els = document.querySelectorAll('.animate-ready');
      els.forEach(function(el) {
        var delay = parseFloat(el.getAttribute('data-delay') || '0');
        setTimeout(function() { el.classList.add('animated'); }, delay * 1000);
      });
    }, 8);

    /* 预载相邻页 */
    [n - 1, n + 1].forEach(function(i) {
      if (i >= 0 && i < totalSlides && !slideCache[slideFiles[i]]) {
        fetch(slideFiles[i])
          .then(function(r) { return r.ok ? r.text() : ''; })
          .then(function(t) { if (t) slideCache[slideFiles[i]] = t; })
          .catch(function() {});
      }
    });

    /* 导航按钮可用性 */
    var prev = document.getElementById('nav-prev');
    var next = document.getElementById('nav-next');
    if (prev) prev.disabled = n === 0;
    if (next) next.disabled = n === totalSlides - 1;
  }

  /* ===== §一.2 进度条 ===== */
  function updateProgressBar() {
    var pct = totalSlides > 1 ? (currentIndex / (totalSlides - 1)) * 100 : 100;
    var bar = document.getElementById('progress-bar');
    if (bar) bar.style.width = Math.max(4, pct) + '%';
  }

  function updatePageIndicator() {
    var cur = document.getElementById('page-current');
    var tot = document.getElementById('page-total');
    if (cur) cur.textContent = currentIndex + 1;
    if (tot) tot.textContent = totalSlides;
  }

  function updateHash() {
    history.replaceState(null, '', '#' + (currentIndex + 1));
  }

  function readHash() {
    var hash = location.hash.replace('#', '');
    var num = parseInt(hash, 10);
    if (num >= 1 && num <= totalSlides) return num - 1;
    return 0;
  }

  /* ===== 翻页 ===== */
  function prevSlide() { if (currentIndex > 0) loadSlide(currentIndex - 1); }
  function nextSlide() { if (currentIndex < totalSlides - 1) loadSlide(currentIndex + 1); }
  function goToSlide(n) { if (n >= 0 && n < totalSlides) loadSlide(n); }

  /* ===== 全屏 ===== */
  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen && document.exitFullscreen();
    }
  }

  /* ===== §一.4 侧边菜单（目录分组铁律，无 menu-item-dot）===== */
  function buildMenu() {
    var list = document.getElementById('menu-list');
    if (!list) return;
    list.innerHTML = '';

    chapters.forEach(function(ch) {
      /* 分组标题（不可点击，蓝色粗体）*/
      var chEl = document.createElement('div');
      chEl.className = 'menu-chapter';
      chEl.textContent = ch.title;
      list.appendChild(chEl);

      for (var i = ch.start; i <= ch.end; i++) {
        (function(idx) {
          var item = document.createElement('div');
          item.className = 'menu-item';
          item.setAttribute('data-index', idx);
          /* 学员可见：序号 + 标题，无 ia_ref / dot / 交互级别 */
          item.innerHTML =
            '<span class="menu-item-num">' + String(idx + 1).padStart(2, '0') + '</span>' +
            '<span>' + slideTitles[idx] + '</span>';
          item.onclick = function() { goToSlide(idx); closeMenu(); };
          list.appendChild(item);
        })(i);
      }
    });
  }

  function updateMenuActiveState() {
    var items = document.querySelectorAll('.menu-item');
    items.forEach(function(item) {
      var idx = parseInt(item.getAttribute('data-index'), 10);
      item.classList.toggle('active', idx === currentIndex);
    });
  }

  function toggleMenu() { menuOpen ? closeMenu() : openMenu(); }

  function openMenu() {
    menuOpen = true;
    document.getElementById('side-menu') && document.getElementById('side-menu').classList.add('open');
    document.getElementById('menu-overlay') && document.getElementById('menu-overlay').classList.add('visible');
    updateMenuActiveState();
  }

  function closeMenu() {
    menuOpen = false;
    document.getElementById('side-menu') && document.getElementById('side-menu').classList.remove('open');
    document.getElementById('menu-overlay') && document.getElementById('menu-overlay').classList.remove('visible');
  }

  /* ─────────────────────────────────────────
   *  §一.1 画笔拖尾  REF §1
   *  _pen.trails[] + animatePenTrail() + FADE_MS=1200
   *  时间衰减模式：抬起后笔迹 FADE_MS ms 淡出，严禁永久保留
   * ───────────────────────────────────────── */
  function initPenTrail() {
    var canvas = document.getElementById('pen-trail-canvas');
    if (!canvas) return;
    _pen.canvas = canvas;
    _pen.ctx = canvas.getContext('2d');

    function resize() {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    canvas.addEventListener('mousedown', function(e) {
      _pen.drawing = true;
      _pen.points  = [{ x: e.clientX, y: e.clientY, t: Date.now() }];
    });
    canvas.addEventListener('mousemove', function(e) {
      if (!_pen.drawing) return;
      _pen.points.push({ x: e.clientX, y: e.clientY, t: Date.now() });
      penRender();
    });
    canvas.addEventListener('mouseup',    penUp);
    canvas.addEventListener('mouseleave', penUp);

    canvas.addEventListener('touchstart', function(e) {
      e.preventDefault();
      var t = e.touches[0];
      _pen.drawing = true;
      _pen.points  = [{ x: t.clientX, y: t.clientY, t: Date.now() }];
    }, { passive: false });
    canvas.addEventListener('touchmove', function(e) {
      e.preventDefault();
      if (!_pen.drawing) return;
      var t = e.touches[0];
      _pen.points.push({ x: t.clientX, y: t.clientY, t: Date.now() });
      penRender();
    }, { passive: false });
    canvas.addEventListener('touchend', function(e) {
      e.preventDefault();
      penUp();
    }, { passive: false });
  }

  function penUp() {
    if (!_pen.drawing) return;
    _pen.drawing = false;
    if (_pen.points.length > 1) {
      _pen.trails.push({ points: _pen.points.slice(), startTime: Date.now() });
    }
    _pen.points = [];
    if (_pen.active) animatePenTrail();
  }

  function penRender() {
    var ctx    = _pen.ctx;
    var canvas = _pen.canvas;
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    var now = Date.now();
    /* 淡出：超过 FADE_MS 的 trail 自动丢弃 */
    _pen.trails = _pen.trails.filter(function(trail) {
      return now - trail.startTime < _pen.FADE_MS;
    });
    _pen.trails.forEach(function(trail) {
      var alpha = Math.max(0, 1 - (now - trail.startTime) / _pen.FADE_MS);
      penDrawPath(ctx, trail.points, alpha * 0.72);
    });
    if (_pen.points.length > 1) penDrawPath(ctx, _pen.points, 1);
  }

  function penDrawPath(ctx, points, alpha) {
    if (points.length < 2) return;
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (var i = 1; i < points.length; i++) {
      var prev = points[i - 1], curr = points[i];
      var mx = (prev.x + curr.x) / 2, my = (prev.y + curr.y) / 2;
      ctx.quadraticCurveTo(prev.x, prev.y, mx, my);
    }
    ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
    ctx.strokeStyle  = hexToRgba(currentDrawColor, alpha);
    ctx.lineWidth    = _pen.LINE_WIDTH;
    ctx.lineCap      = 'round';
    ctx.lineJoin     = 'round';
    ctx.stroke();
  }

  function hexToRgba(hex, alpha) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    var r = parseInt(hex.substring(0, 2), 16);
    var g = parseInt(hex.substring(2, 4), 16);
    var b = parseInt(hex.substring(4, 6), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
  }

  function togglePenTrail() {
    _pen.active = !_pen.active;
    var canvas = document.getElementById('pen-trail-canvas');
    var btn    = document.getElementById('btn-pen');
    if (_pen.active) {
      if (canvas) canvas.classList.add('pen-active');
      if (btn)    btn.classList.add('active');
      animatePenTrail();
    } else {
      if (canvas) canvas.classList.remove('pen-active');
      if (btn)    btn.classList.remove('active');
      if (_pen.rafId) { cancelAnimationFrame(_pen.rafId); _pen.rafId = null; }
      if (_pen.ctx && canvas) _pen.ctx.clearRect(0, 0, canvas.width, canvas.height);
      _pen.trails = [];
      _pen.points = [];
    }
  }

  function animatePenTrail() {
    if (!_pen.active) return;
    penRender();
    if (_pen.trails.length > 0 || _pen.drawing) {
      _pen.rafId = requestAnimationFrame(animatePenTrail);
    } else {
      _pen.rafId = null;
    }
  }

  /* ─────────────────────────────────────────
   *  §一.1 画板 (D)  REF §2
   *  toggle 语义：再按 D 先 clearDrawBoard() 再 enabled=false（清后退）
   *  ESC 键同样走清后退路径
   * ───────────────────────────────────────── */
  function initDrawBoard() {
    var canvas = document.getElementById('draw-board-canvas');
    if (!canvas) return;
    _draw.canvas = canvas;
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    _draw.ctx     = canvas.getContext('2d');

    window.addEventListener('resize', function() {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
    });

    canvas.addEventListener('mousedown', function(e) {
      if (!_draw.enabled) return;
      _draw.drawing = true;
      _draw.ctx.beginPath();
      _draw.ctx.moveTo(e.clientX, e.clientY);
    });
    canvas.addEventListener('mousemove', function(e) {
      if (!_draw.drawing || !_draw.enabled) return;
      _draw.ctx.lineTo(e.clientX, e.clientY);
      _draw.ctx.strokeStyle = currentDrawColor;
      _draw.ctx.lineWidth   = 3;
      _draw.ctx.lineCap     = 'round';
      _draw.ctx.lineJoin    = 'round';
      _draw.ctx.stroke();
    });
    canvas.addEventListener('mouseup',    function() { _draw.drawing = false; });
    canvas.addEventListener('mouseleave', function() { _draw.drawing = false; });
  }

  function toggleDrawBoard() {
    if (_draw.enabled) {
      /* 再按：先清后退（REF §2 toggle 语义）*/
      clearDrawBoard();
    } else {
      _draw.enabled = true;
      var canvas = document.getElementById('draw-board-canvas');
      if (canvas) {
        canvas.style.pointerEvents = 'all';
        canvas.style.cursor = 'crosshair';
      }
      document.body.classList.add('draw-mode');
      var btn = document.getElementById('btn-draw');
      if (btn) btn.classList.add('active');
    }
  }

  function clearDrawBoard() {
    _draw.enabled = false;
    _draw.drawing = false;
    var canvas = document.getElementById('draw-board-canvas');
    if (canvas && _draw.ctx) {
      _draw.ctx.clearRect(0, 0, canvas.width, canvas.height);
      canvas.style.pointerEvents = 'none';
      canvas.style.cursor = 'default';
    }
    document.body.classList.remove('draw-mode');
    var btn = document.getElementById('btn-draw');
    if (btn) btn.classList.remove('active');
  }

  /* ─────────────────────────────────────────
   *  §一.5 颜色选择器  REF §3
   *  4色共享 currentDrawColor
   * ───────────────────────────────────────── */
  function setDrawColor(hex) {
    currentDrawColor = hex;
    var dot = document.getElementById('color-dot-indicator');
    if (dot) dot.style.background = hex;
    document.querySelectorAll('#color-picker-popup .color-dot').forEach(function(btn) {
      btn.classList.toggle('selected', btn.dataset.color === hex);
    });
    closeColorPicker();
  }

  function toggleColorPicker() {
    colorPickerOpen = !colorPickerOpen;
    var popup = document.getElementById('color-picker-popup');
    if (popup) popup.classList.toggle('open', colorPickerOpen);
  }

  function closeColorPicker() {
    colorPickerOpen = false;
    var popup = document.getElementById('color-picker-popup');
    if (popup) popup.classList.remove('open');
  }

  /* ===== 键盘事件（← → F M T D Esc）===== */
  document.addEventListener('keydown', function(e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    switch (e.key) {
      case 'ArrowLeft':
      case 'ArrowUp':
        e.preventDefault(); prevSlide(); break;
      case 'ArrowRight':
      case 'ArrowDown':
      case ' ':
        e.preventDefault(); nextSlide(); break;
      case 'Home': e.preventDefault(); goToSlide(0); break;
      case 'End':  e.preventDefault(); goToSlide(totalSlides - 1); break;
      case 'Escape':
        if (_draw.enabled)  { clearDrawBoard(); break; }
        if (_pen.active)    { togglePenTrail(); break; }
        if (menuOpen)       { closeMenu(); break; }
        goToSlide(0);
        break;
      case 'f': case 'F':
        if (!e.metaKey && !e.ctrlKey) { e.preventDefault(); toggleFullscreen(); }
        break;
      case 'm': case 'M':
        if (!e.metaKey && !e.ctrlKey) { e.preventDefault(); toggleMenu(); }
        break;
      case 't': case 'T': togglePenTrail();  break;
      case 'd': case 'D': toggleDrawBoard(); break;
    }
  });

  /* ===== 触摸滑动 ===== */
  var touchStartX = 0, touchStartY = 0;
  document.addEventListener('touchstart', function(e) {
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
  }, { passive: true });
  document.addEventListener('touchend', function(e) {
    var dx = e.changedTouches[0].clientX - touchStartX;
    var dy = e.changedTouches[0].clientY - touchStartY;
    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 50) {
      if (dx < 0) nextSlide(); else prevSlide();
    }
  }, { passive: true });

  /* ===== 全局 API 暴露（onClick + slideHook 均依赖此）===== */
  window.__nextSlide         = nextSlide;
  window.__prevSlide         = prevSlide;
  window.__goSlide           = function(i) { closeMenu(); goToSlide(i); };
  window.__toggleMenu        = toggleMenu;
  window.__closeMenu         = closeMenu;
  window.__toggleFullscreen  = toggleFullscreen;
  window.__togglePenTrail    = togglePenTrail;
  window.__toggleDrawBoard   = toggleDrawBoard;
  window.__toggleColorPicker = toggleColorPicker;
  window.__setDrawColor      = setDrawColor;

  /* ===== 初始化 ===== */
  document.addEventListener('DOMContentLoaded', function() {
    buildMenu();
    initPenTrail();
    initDrawBoard();

    /* 颜色指示器初始化 */
    var dot = document.getElementById('color-dot-indicator');
    if (dot) dot.style.background = currentDrawColor;

    /* 点击外部关闭颜色面板 */
    document.addEventListener('click', function(e) {
      if (colorPickerOpen && !e.target.closest('#color-picker-wrap')) closeColorPicker();
    });

    var startSlide = readHash();
    loadSlide(startSlide);
  });

})();
