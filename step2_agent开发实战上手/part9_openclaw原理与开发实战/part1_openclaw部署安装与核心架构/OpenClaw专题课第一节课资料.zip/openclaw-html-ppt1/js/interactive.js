/**
 * OpenClaw 核心架构 · 第一节课 — 重交互页 Hooks
 *
 * html-courseware-interactive-eng 将填充此文件。
 *
 * 键名格式：'slides/SXX-filename.html'（与 main.js slideFiles 数组完整路径一致）
 * 值格式：function() { ...; return function cleanup() { ... }; }
 *
 * 已知 🔴🔴 页（interactive-eng 负责）：
 *   slides/S012-dual-while-steering.html      — 双层 while 循环 + steering 注入模拟器
 *   slides/S013-eventstream-10events.html     — EventStream 10 事件泳道日志对账
 *   slides/S016-8step-pipeline-gauntlet.html  — 8步工具策略管线小球闯关
 *   slides/S019-exec-dual-axis-knob.html      — exec 三档×三态双轴信任旋钮
 *
 * cleanup 函数铁律（REF_golden_patterns.md §9 GSAP 安全模板）：
 *   - clearInterval / clearTimeout
 *   - gsap.killTweensOf() 或 timeline.kill()
 *   - removeEventListener（pointer/mouse 事件）
 */
window.slideHooks = window.slideHooks || {};

window.slideHooks['slides/S005-four-gen-molting.html'] = function() {
  /* FM 清单: FM-1 timer 清理(moltingTimer/entranceTimer) / FM-2 GSAP killTweensOf / FM-3 click+input handler 解绑 */
  var root = document.querySelector('[data-slide="s005"]');
  if (!root) return function noop() {};  // ←FM-1: 防 null 早退也 return noop

  var generations = [
    {
      name: 'Warelay',
      kicker: '01 / 04 shell',
      copy: '一个朴素的 WhatsApp 转发网关，先把消息转起来。',
      note: '早期外壳很薄：重点是 gateway（网关）转发消息。'
    },
    {
      name: 'Clawdbot',
      kicker: '02 / 04 shell',
      copy: '龙虾 Clawd 入住后的 bot，名字开始承载项目角色。',
      note: '壳换了：从转发网关，长出更明确的 agent（智能体）身份。'
    },
    {
      name: 'Moltbot',
      kicker: '03 / 04 shell',
      copy: '2026-01 Anthropic 商标邮件后蜕壳改名，Molty 住进新壳。',
      note: '商标邮件梗：Anthropic 的礼貌邮件意外成了蜕壳时机。'
    },
    {
      name: 'OpenClaw',
      kicker: '04 / 04 final shell',
      copy: '2026-01-30 最终定名：外壳变了，能在真实电脑上干活的 agent 运行时灵魂不变。',
      note: '最终壳显现：珊瑚旧壳退场，橙红新壳在同一个 agent 灵魂上点亮。'
    }
  ];

  var shell = root.querySelector('.s005-shell-view');
  var oldShell = shell && shell.querySelector('.s005-old-shell');
  var newShell = shell && shell.querySelector('.s005-new-shell');
  var slider = root.querySelector('[data-s005-slider]');
  var nodes = Array.prototype.slice.call(root.querySelectorAll('[data-s005-node]'));
  var replay = root.querySelector('[data-s005-replay]');
  var kickerEl = root.querySelector('[data-s005-kicker]');
  var nameEl = root.querySelector('[data-s005-name]');
  var copyEl = root.querySelector('[data-s005-copy]');
  var noteEl = root.querySelector('[data-s005-note]');

  var listeners = [];
  var moltingTimer = null;  // ←FM-1: 蜕壳动效 class 清除 timer
  var entranceTimer = null; // ←FM-1: GSAP 入场延迟 timer
  var moltTl = null;        // ←FM-2: 蜕壳 GSAP timeline
  var entranceTl = null;    // ←FM-2: 入场 GSAP timeline
  var current = 0;

  function on(el, event, handler) {  // ←FM-3: 统一注册，cleanup 统一解绑
    if (!el) return;
    el.addEventListener(event, handler);
    listeners.push([el, event, handler]);
  }

  // 入场动画：GSAP fromTo + paused + 延迟播放（防 display:none 时序问题）
  if (window.gsap) {
    var headerEls = root.querySelectorAll('.s005-header > *');
    var stageEls = root.querySelectorAll('.s005-stage > *');
    var ctrlEls = root.querySelectorAll('.s005-controls > *');
    entranceTl = window.gsap.timeline({ paused: true });
    entranceTl
      .fromTo(headerEls,
        { opacity: 0, y: -14 },
        { opacity: 1, y: 0, duration: 0.4, stagger: 0.08, ease: 'power2.out' }
      )
      .fromTo(stageEls,
        { opacity: 0, y: 18 },
        { opacity: 1, y: 0, duration: 0.42, stagger: 0.1, ease: 'power2.out' },
        '-=0.25'
      )
      .fromTo(ctrlEls,
        { opacity: 0, y: 10 },
        { opacity: 1, y: 0, duration: 0.35, stagger: 0.07, ease: 'power2.out' },
        '-=0.28'
      );
    entranceTimer = setTimeout(function() {  // ←FM-1: 延迟 120ms 确保 slide 可见
      if (entranceTl) entranceTl.play();
    }, 120);
  }

  function killMoltTween() {
    if (moltTl) {
      moltTl.kill();  // ←FM-2: 切代时杀掉正在运行的蜕壳 timeline
      moltTl = null;
    }
    if (window.gsap && oldShell && newShell) {
      window.gsap.killTweensOf([oldShell, newShell]);  // ←FM-2
    }
    clearTimeout(moltingTimer);  // ←FM-1
  }

  function triggerMolting() {
    if (!shell || !window.gsap || !oldShell || !newShell) {
      // 无 GSAP 降级：CSS animation 方案
      if (!shell) return;
      shell.classList.remove('is-molting');
      void shell.offsetWidth;
      shell.classList.add('is-molting');
      clearTimeout(moltingTimer);
      moltingTimer = setTimeout(function() {  // ←FM-1
        if (shell) shell.classList.remove('is-molting');
      }, 1050);
      return;
    }
    killMoltTween();
    // GSAP fromTo 蜕壳动效：旧壳淡出 + 新壳淡入同时运行
    moltTl = window.gsap.timeline({ onComplete: function() { moltTl = null; } });
    moltTl
      .fromTo(oldShell,
        { opacity: 0.88, x: 0, scale: 1, rotate: -1 },
        { opacity: 0.16, x: -35, scale: 0.9, rotate: -10, duration: 0.85, ease: 'power2.inOut' },
        0
      )
      .fromTo(newShell,
        { opacity: 0, x: 26, scale: 0.84 },
        { opacity: 1, x: 0, scale: 1.05, duration: 0.9, ease: 'power2.out' },
        0.05
      );
  }

  function setGeneration(index, shouldAnimate) {
    current = Math.max(0, Math.min(3, Number(index) || 0));
    var data = generations[current];
    if (shell) shell.setAttribute('data-generation', String(current));
    if (slider) slider.value = String(current);
    if (kickerEl) kickerEl.textContent = data.kicker;
    if (nameEl) nameEl.textContent = data.name;
    if (copyEl) copyEl.textContent = data.copy;
    if (noteEl) noteEl.textContent = data.note;

    nodes.forEach(function(node, idx) {
      var active = idx === current;
      node.classList.toggle('is-active', active);
      node.setAttribute('aria-selected', active ? 'true' : 'false');
    });

    // 非 OpenClaw 代：重置蜕壳状态
    if (current !== 3) killMoltTween();
    if (current === 3 && shouldAnimate) triggerMolting();
  }

  function handleSliderInput(event) {
    setGeneration(event.target.value, Number(event.target.value) === 3);
  }

  on(slider, 'input', handleSliderInput);  // ←FM-3: 具名函数绑定

  nodes.forEach(function(node) {
    function handleNodeClick() {
      var index = Number(node.getAttribute('data-s005-node'));
      setGeneration(index, index === 3);
    }
    on(node, 'click', handleNodeClick);  // ←FM-3
  });

  function handleReplayClick() {
    setGeneration(3, true);
  }
  on(replay, 'click', handleReplayClick);  // ←FM-3: 具名函数

  setGeneration(0, false);

  return function cleanupS005() {
    clearTimeout(moltingTimer);   // ←FM-1
    clearTimeout(entranceTimer);  // ←FM-1
    if (entranceTl) { entranceTl.kill(); entranceTl = null; }  // ←FM-2
    killMoltTween();              // ←FM-2: 含 killTweensOf
    if (window.gsap && root) {
      window.gsap.killTweensOf(root.querySelectorAll('*'));  // ←FM-2: 兜底 kill 所有子元素
    }
    listeners.forEach(function(item) {
      item[0].removeEventListener(item[1], item[2]);  // ←FM-3
    });
    listeners.length = 0;
  };
};

window.slideHooks['slides/S013b-plugin-drag-practice.html'] = function() {
  /* FM 清单: FM-1 entranceTimer 清理 / FM-2 GSAP killTweensOf / FM-3 pointer handler 解绑 */
  /* 拖拽练习页（原 S013，拆分后概念讲解留在 S013，拖拽迁至本页 S013b） */

  var slide = document.querySelector('.s013-boundary');
  if (!slide) return function noop() {};  // ←FM-1

  // ── 状态 ──
  var drag = null;  // { el, kind, startX, startY, originLeft, originTop, width }
  var listeners = [];

  // ── DOM refs ──
  var plugin    = slide.querySelector('[data-s013-plugin]');
  var pluginDrop= slide.querySelector('[data-s013-plugin-drop]');
  var capDrop   = slide.querySelector('[data-s013-capability-drop]');
  var capDock   = slide.querySelector('[data-s013-cap-dock]');
  var status    = slide.querySelector('[data-s013-status]');
  var hostInput = slide.querySelector('[data-s013-host]');
  var hostValue = slide.querySelector('[data-s013-host-value]');
  var loadBadge = slide.querySelector('[data-s013-load-badge]');

  var hostVersions = ['2026.3.24', '2026.4.1', '2026.4.20', '2026.4.25', '2026.5.30'];
  var requiredIndex = 3;  // 2026.4.25 对应 index=3

  // ── GSAP 入场 timeline ──
  var entranceTl = gsap.timeline({ paused: true });
  entranceTl.fromTo(
    slide.querySelectorAll('.s013-panel, .s013-center, .s013-capability-bin, .s013-status'),
    { opacity: 0, y: 18 },
    // clearProps:'transform' 清除入场残留的 translate(0,0)——否则 .s013-panel 会成为
    // 拖拽 tool（position:fixed）的包含块，导致抓取后坐标相对 panel 而非视口、元素下移错位
    { opacity: 1, y: 0, duration: 0.42, stagger: 0.09, ease: 'power2.out', clearProps: 'transform' }
  );
  var entranceTimer = setTimeout(function() { entranceTl.play(); }, 120);  // ←FM-1

  // ── 工具函数 ──
  function on(el, evt, fn) {
    if (!el) return;
    el.addEventListener(evt, fn);
    listeners.push([el, evt, fn]);
  }

  function setStatus(msg, isErr) {
    if (!status) return;
    status.textContent = msg;
    status.classList.toggle('is-error', Boolean(isErr));
  }

  function rectContains(el, x, y) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
  }

  // 把拖拽元素从 body 还原回原始 DOM 位置，并清除 fixed 定位样式
  function returnHome(el) {
    el.style.left = '';
    el.style.top = '';
    el.style.width = '';
    el.classList.remove('is-dragging');
    var h = el._s013home;
    if (h && h.parent) {
      if (h.next && h.next.parentNode === h.parent) h.parent.insertBefore(el, h.next);
      else h.parent.appendChild(el);
    }
    el._s013home = null;
  }

  // 误拖到 capability 区：还原原位 + 抖动闪红
  function rejectAndReturn(el) {
    returnHome(el);
    // CSS class reject 闪红边
    el.classList.remove('is-rejected');
    void el.offsetWidth;
    el.classList.add('is-rejected');
    if (capDrop) {
      capDrop.classList.remove('is-wrong');
      void capDrop.offsetWidth;
      capDrop.classList.add('is-wrong');
    }
    setStatus('REJECTED：tool 不是一种 capability——capability 共 15 种，tool 不在其中。', true);
  }

  function acceptTool(el) {
    var isSkip = plugin && plugin.classList.contains('is-skip');
    el.style.left = '';
    el.style.top = '';
    el.style.width = '';
    el.classList.remove('is-dragging');
    if (isSkip) {
      // host 版本不足，不可注册
      el.classList.remove('is-rejected'); void el.offsetWidth; el.classList.add('is-rejected');
      setStatus('skip：host 版本不足，plugin 跳过加载，tool 不能注册。', true);
      return;
    }
    el.classList.add('is-locked');
    el.disabled = true;
    if (pluginDrop) pluginDrop.appendChild(el);
    var hint = pluginDrop && pluginDrop.querySelector('.s013-bay-hint');
    if (hint) hint.textContent = 'ACCEPTED：tool ⊂ plugin（唯一包含关系）。';
    setStatus('ACCEPTED：' + el.textContent.trim() + ' 已注册进 plugin（tool ⊂ plugin 唯一包含关系）。', false);
    // 入场小弹动
    gsap.fromTo(el, { scale: 1.18, opacity: 0.7 }, { scale: 1, opacity: 1, duration: 0.32, ease: 'back.out(2)' });  // ←FM-2
  }

  function acceptCapability(el) {
    el.style.left = '';
    el.style.top = '';
    el.style.width = '';
    el.classList.remove('is-dragging');
    if (capDock) {
      capDock.classList.add('has-cap');
      capDock.appendChild(el);
    }
    gsap.fromTo(el, { scale: 1.18, opacity: 0.7 }, { scale: 1, opacity: 1, duration: 0.28, ease: 'back.out(2)' });  // ←FM-2
    setStatus('ACCEPTED：capability 是贴在 plugin 外侧的分类标签，不是容器。', false);
  }

  // ── 拖拽事件（pointer events + setPointerCapture）──
  function onPointerDown(e) {  // ←FM-3
    var el = e.currentTarget;
    if (el.disabled) return;
    var r = el.getBoundingClientRect();
    drag = {
      el: el,
      kind: el.getAttribute('data-kind'),
      pointerId: e.pointerId,
      dx: e.clientX - r.left,
      dy: e.clientY - r.top
    };
    // 记录原始 DOM 位置，拖拽结束后据此还原
    el._s013home = { parent: el.parentNode, next: el.nextSibling };
    el.style.width = r.width + 'px';
    el.style.left  = r.left + 'px';
    el.style.top   = r.top  + 'px';
    el.classList.add('is-dragging');
    // 关键修复：把元素挂到 body，脱离任何 transform 祖先，
    // 否则 position:fixed 会相对 transform 祖先而非视口定位 → 抓取后坐标错位下移
    document.body.appendChild(el);
    el.setPointerCapture(e.pointerId);  // setPointerCapture 让 move/up 事件保持在该元素上
    if (pluginDrop) pluginDrop.classList.add('is-hot');
    setStatus('DRAG：把 tool 放进 plugin 容器，或把 capability 贴到 plugin 外侧。', false);
    e.preventDefault();
  }

  function onPointerMove(e) {  // ←FM-3
    if (!drag || drag.el !== e.currentTarget) return;
    drag.el.style.left = (e.clientX - drag.dx) + 'px';
    drag.el.style.top  = (e.clientY - drag.dy) + 'px';
  }

  function onPointerUp(e) {  // ←FM-3
    if (!drag || drag.el !== e.currentTarget) return;
    var el   = drag.el;
    var kind = drag.kind;
    var x    = e.clientX;
    var y    = e.clientY;
    drag = null;
    el.releasePointerCapture(e.pointerId);
    if (pluginDrop) pluginDrop.classList.remove('is-hot');

    if (kind === 'tool' && rectContains(pluginDrop, x, y)) {
      acceptTool(el);
    } else if (kind === 'tool' && rectContains(capDrop, x, y)) {
      rejectAndReturn(el);
    } else if (kind === 'capability' && (rectContains(capDock, x, y) || rectContains(plugin, x, y))) {
      acceptCapability(el);
    } else {
      // 未命中有效区域：还原原位
      returnHome(el);
      setStatus('RESET：没有命中有效区域，卡片已回原位。', false);
    }
  }

  function onPointerCancel(e) {  // ←FM-3
    if (!drag || drag.el !== e.currentTarget) return;
    var el = drag.el;
    drag = null;
    returnHome(el);
    if (pluginDrop) pluginDrop.classList.remove('is-hot');
  }

  // ── host version 滑块 ──
  function onHostInput() {  // ←FM-3
    var idx     = Number(hostInput.value) || 0;
    var version = hostVersions[idx];
    var ok      = idx >= requiredIndex;
    if (hostValue) hostValue.textContent = version;
    if (plugin) {
      plugin.classList.toggle('is-load', ok);
      plugin.classList.toggle('is-skip', !ok);
    }
    if (loadBadge) loadBadge.textContent = ok ? 'load' : 'skip';
    setStatus(ok
      ? 'load：host ≥ minHostVersion，plugin 可以加载。'
      : 'skip：host ' + version + ' < minHostVersion 2026.4.25，plugin 被跳过加载。',
      !ok);
  }

  // ── 绑定事件 ──
  var draggables = Array.prototype.slice.call(slide.querySelectorAll('[data-kind]'));
  draggables.forEach(function(el) {
    on(el, 'pointerdown',   onPointerDown);
    on(el, 'pointermove',   onPointerMove);
    on(el, 'pointerup',     onPointerUp);
    on(el, 'pointercancel', onPointerCancel);
  });
  on(hostInput, 'input', onHostInput);
  onHostInput();  // 初始化滑块状态

  // ── cleanup ──
  return function cleanupS013() {
    clearTimeout(entranceTimer);  // ←FM-1
    if (entranceTl) entranceTl.kill();  // ←FM-2
    gsap.killTweensOf(slide.querySelectorAll('*'));  // ←FM-2
    if (drag && drag.el) {
      returnHome(drag.el);
      drag = null;
    }
    listeners.forEach(function(item) {
      item[0].removeEventListener(item[1], item[2]);  // ←FM-3
    });
    listeners.length = 0;
  };
};

window.slideHooks['slides/S010-dual-while-steering.html'] = function() {
  /* S010 已重构为静态对话框（双层 while 嵌套框），无需 JS 驱动 */
  return function noop() {};
};


window.slideHooks['slides/S011-eventstream-10events.html'] = function() {
  /* FM 清单: FM-1 切场景 resetAllHighlights+clearAutoTimer / FM-2 pausedFlag 守卫 advanceStep / FM-3 日志 scrollTop 居中定位 */

  var root = document.querySelector('[data-slide="s011"]');
  if (!root) return function noop() {};  // ←FM-2: 早退必须返回具名 noop

  // ── 常量定义 ────────────────────────────────────────────────────
  var eventOrder = [
    'agent_start', 'turn_start', 'message_start', 'message_update', 'message_end',
    'tool_execution_start', 'tool_execution_update', 'tool_execution_end',
    'turn_end', 'agent_end'
  ];

  // 四场景事件子集（不同场景走不同事件路径）
  var scenarioSequences = {
    plain:    ['agent_start', 'turn_start', 'message_start', 'message_end', 'turn_end', 'agent_end'],
    tool:     ['agent_start', 'turn_start', 'message_start', 'message_end', 'tool_execution_start', 'tool_execution_update', 'tool_execution_end', 'turn_end', 'agent_end'],
    stream:   ['agent_start', 'turn_start', 'message_start', 'message_update', 'message_end', 'turn_end', 'agent_end'],
    steering: ['agent_start', 'turn_start', 'message_start', 'message_update', 'message_end', 'tool_execution_start', 'tool_execution_update', 'tool_execution_end', 'turn_end', 'agent_end']
  };

  var scenarioLabels = {
    plain:    '无工具 · 6 主骨架',
    tool:     '有工具 · 工具亮起/结果回填',
    stream:   '流式 · message_update 增量',
    steering: 'steering（插话） · 当前轮内继续对账'
  };

  var stageLabels = {
    agent_start:          'agent 生命周期打开',
    turn_start:           '进入本轮处理',
    message_start:        'assistant 消息开始',
    message_update:       'streaming（流式）增量更新',
    message_end:          'assistant 消息完成',
    tool_execution_start: 'TUI 工具亮起 → chat-log.ts:333',
    tool_execution_update:'工具执行中更新 partialResult',
    tool_execution_end:   '结果回填完成 {result, isError}',
    turn_end:             '轮次汇总 toolResults',
    agent_end:            '生命周期闭合'
  };

  // ── DOM 缓存 ─────────────────────────────────────────────────────
  var eventCards      = Array.prototype.slice.call(root.querySelectorAll('[data-s011-event]'));
  var groups          = Array.prototype.slice.call(root.querySelectorAll('[data-s011-group]'));
  var logLines        = Array.prototype.slice.call(root.querySelectorAll('[data-s011-line]'));
  var scenarioButtons = Array.prototype.slice.call(root.querySelectorAll('[data-s011-scenario]'));
  var playBtn         = root.querySelector('[data-s011-play]');
  var pauseBtn        = root.querySelector('[data-s011-pause]');
  var stepBtn         = root.querySelector('[data-s011-step]');
  var progressEl      = root.querySelector('[data-s011-progress]');
  var stageEl         = root.querySelector('[data-s011-stage]');
  var logContainer    = root.querySelector('[data-s011-log]');

  // ── 可变状态（闭包内，不污染全局）─────────────────────────────────
  var listeners       = [];
  var autoTimer       = null;
  var currentScenario = 'plain';
  var currentStepIdx  = -1;
  var pausedFlag      = true;   // ←FM-2: pausedFlag 守卫，防 advanceStep 重入
  var modeLabel       = '场景选择';

  // ── 工具函数 ─────────────────────────────────────────────────────
  function on(el, evt, handler) {
    if (!el) return;
    el.addEventListener(evt, handler);
    listeners.push([el, evt, handler]);
  }

  function byAttr(list, attr, val) {
    return list.filter(function(el) { return el.getAttribute(attr) === val; });
  }

  function eventNumber(name) {
    return Math.max(0, eventOrder.indexOf(name) + 1);
  }

  function setButtonState() {
    if (playBtn)  playBtn.classList.toggle('is-active', !pausedFlag && modeLabel === 'PLAY');
    if (pauseBtn) pauseBtn.classList.toggle('is-active', pausedFlag && modeLabel === 'PAUSE');
    if (stepBtn)  stepBtn.classList.toggle('is-active', modeLabel === 'STEP');
    scenarioButtons.forEach(function(btn) {
      var active = btn.getAttribute('data-s011-scenario') === currentScenario;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });
  }

  function setStage(eventName) {
    var num = eventName ? eventNumber(eventName) : 0;
    if (progressEl) progressEl.textContent = '事件 ' + num + '/10';
    if (stageEl) {
      stageEl.textContent = eventName
        ? modeLabel + ' · ' + scenarioLabels[currentScenario] + ' · ' + stageLabels[eventName]
        : modeLabel + ' · ' + scenarioLabels[currentScenario];
    }
    setButtonState();
  }

  // FM-3: 日志 scrollTop 居中定位（非 querySelector，确保当前行可见）
  function centerLogLine(line) {  // ←FM-3
    if (!logContainer || !line) return;
    var top    = line.offsetTop - logContainer.offsetTop;
    var target = top - (logContainer.clientHeight - line.offsetHeight) / 2;
    logContainer.scrollTop = Math.max(0, target);
  }

  // FM-1: 切场景时重置所有高亮（含 clearAutoTimer 防定时器泄漏）
  function resetAllHighlights() {  // ←FM-1
    eventCards.forEach(function(card) {
      card.classList.remove('is-reached', 'is-current');
      card.setAttribute('aria-pressed', 'false');
    });
    groups.forEach(function(group) {
      group.classList.remove('is-group-active');
    });
    logLines.forEach(function(line) {
      line.classList.remove('is-reached', 'is-current', 'is-tool-lit', 'is-result-filled');
    });
    if (logContainer) logContainer.scrollTop = 0;
  }

  function markToolSideEffects(sequence, idx) {
    var reached       = sequence.slice(0, idx + 1);
    var hasToolStart  = reached.indexOf('tool_execution_start') !== -1;
    var hasToolEnd    = reached.indexOf('tool_execution_end')   !== -1;
    byAttr(logLines, 'data-s011-line', 'tool_execution_start').forEach(function(line) {
      line.classList.toggle('is-tool-lit', hasToolStart);
    });
    byAttr(logLines, 'data-s011-line', 'tool_execution_end').forEach(function(line) {
      line.classList.toggle('is-result-filled', hasToolEnd);
    });
  }

  function highlightEvent(eventName, seqIdx) {
    var sequence    = scenarioSequences[currentScenario];
    var activeGroup = null;
    eventCards.forEach(function(card) {
      var name        = card.getAttribute('data-s011-event');
      var reachedIdx  = sequence.indexOf(name);
      var reached     = reachedIdx !== -1 && reachedIdx <= seqIdx;
      var isCurrent   = name === eventName;
      card.classList.toggle('is-reached', reached);
      card.classList.toggle('is-current', isCurrent);
      card.setAttribute('aria-pressed', isCurrent ? 'true' : 'false');
      if (isCurrent) activeGroup = card.getAttribute('data-s011-group-id');
    });
    groups.forEach(function(group) {
      group.classList.toggle('is-group-active', group.getAttribute('data-s011-group') === activeGroup);
    });
    logLines.forEach(function(line) {
      var name       = line.getAttribute('data-s011-line');
      var reachedIdx = sequence.indexOf(name);
      var reached    = reachedIdx !== -1 && reachedIdx <= seqIdx;
      var isCurrent  = name === eventName;
      line.classList.toggle('is-reached', reached);
      line.classList.toggle('is-current', isCurrent);
    });
    markToolSideEffects(sequence, seqIdx);
    centerLogLine(byAttr(logLines, 'data-s011-line', eventName)[0]);  // ←FM-3
    setStage(eventName);
  }

  function clearAutoTimer() {
    clearTimeout(autoTimer);
    autoTimer = null;
  }

  function pause() {
    pausedFlag = true;
    modeLabel  = 'PAUSE';
    clearAutoTimer();
    setButtonState();
    if (currentStepIdx >= 0) setStage(scenarioSequences[currentScenario][currentStepIdx]);
  }

  function advanceStep(isManual) {
    if (pausedFlag && !isManual) return;  // ←FM-2: pausedFlag 守卫防自动步进重入
    var sequence = scenarioSequences[currentScenario];
    if (currentStepIdx >= sequence.length - 1) {
      pausedFlag = true;
      modeLabel  = 'PAUSE';
      clearAutoTimer();
      setButtonState();
      return;
    }
    currentStepIdx++;
    highlightEvent(sequence[currentStepIdx], currentStepIdx);
    if (!pausedFlag && modeLabel === 'PLAY') {
      clearAutoTimer();
      autoTimer = window.setTimeout(function() { advanceStep(false); }, 900);
    }
  }

  function play() {
    if (currentStepIdx >= scenarioSequences[currentScenario].length - 1) {
      resetAllHighlights();   // ←FM-1: 重播先重置高亮
      currentStepIdx = -1;
    }
    pausedFlag = false;
    modeLabel  = 'PLAY';
    clearAutoTimer();
    setButtonState();
    advanceStep(false);
  }

  function step() {
    pausedFlag = true;
    modeLabel  = 'STEP';
    clearAutoTimer();
    advanceStep(true);
  }

  function selectScenario(nextScenario) {
    currentScenario = nextScenario;
    currentStepIdx  = -1;
    pausedFlag      = true;
    modeLabel       = '场景选择';
    clearAutoTimer();     // ←FM-1: 切场景先 clearAutoTimer 防定时器泄漏
    resetAllHighlights(); // ←FM-1
    setStage(null);
  }

  // ── 事件绑定（具名函数，便于 removeEventListener）────────────────
  function handleScenarioBtn() {
    selectScenario(this.getAttribute('data-s011-scenario'));
  }

  function handleEventCardClick() {
    var eventName = this.getAttribute('data-s011-event');
    var sequence  = scenarioSequences[currentScenario];
    var idx       = sequence.indexOf(eventName);
    pause();
    modeLabel = 'STEP';
    if (idx === -1) {
      // 事件不在当前场景——切换到 steering 场景找到它
      resetAllHighlights();
      currentStepIdx  = -1;
      currentScenario = 'steering';
      sequence = scenarioSequences[currentScenario];
      idx      = sequence.indexOf(eventName);
    }
    currentStepIdx = idx;
    highlightEvent(eventName, currentStepIdx);
  }

  scenarioButtons.forEach(function(btn) { on(btn, 'click', handleScenarioBtn.bind(btn)); });
  eventCards.forEach(function(card) { on(card, 'click', handleEventCardClick.bind(card)); });
  on(playBtn,  'click', play);
  on(pauseBtn, 'click', pause);
  on(stepBtn,  'click', step);

  // 入场动画（GSAP fromTo，防 display:none 时序问题）
  var entranceTimer = setTimeout(function() {
    gsap.fromTo(eventCards,
      { opacity: 0, y: 10 },
      { opacity: 1, y: 0, duration: 0.36, stagger: 0.04, ease: 'power2.out' }
    );
  }, 120);

  // 初始化场景
  selectScenario('plain');

  // ── Cleanup（tl.kill / killTweensOf / clearTimeout / removeEventListener）
  return function cleanupS011() {
    clearTimeout(entranceTimer);
    clearAutoTimer();
    gsap.killTweensOf(eventCards);       // ←FM-2: GSAP 入场动画清理
    gsap.killTweensOf(logLines);
    listeners.forEach(function(item) { item[0].removeEventListener(item[1], item[2]); });
    listeners.length = 0;
  };
};

window.slideHooks['slides/S014-8step-pipeline-gauntlet.html'] = function() {
  /* FM 清单: FM-1 切 profile 先 stopBall+resetTrack / FM-2 popup fixed 视口定位 / FM-3 cleanup killTweensOf */

  // ←FM-1: 防止 querySelector 失败时直接 return noop
  var root = document.querySelector('[data-slide="s014"]');
  if (!root) return function noop() {};

  // ── DOM refs ──
  var track      = root.querySelector('[data-s014-track]');
  var ball       = root.querySelector('[data-s014-ball]');
  var pathBase   = root.querySelector('[data-s014-path-base]');
  var pathActive = root.querySelector('[data-s014-path-active]');
  var popup      = root.querySelector('[data-s014-popup]');
  var stageEl    = root.querySelector('[data-s014-stage]');
  var progressEl = root.querySelector('[data-s014-progress]');
  var outcomeEl  = root.querySelector('[data-s014-outcome]');
  var gates      = Array.prototype.slice.call(root.querySelectorAll('[data-s014-gate]'));
  var statusCells= Array.prototype.slice.call(root.querySelectorAll('[data-s014-status]'));
  var profileBtns= Array.prototype.slice.call(root.querySelectorAll('[data-s014-profile]'));
  var playBtn    = root.querySelector('[data-s014-play]');
  var pauseBtn   = root.querySelector('[data-s014-pause]');
  var stepBtn    = root.querySelector('[data-s014-step]');
  var resetBtn   = root.querySelector('[data-s014-reset]');

  // ── State ──
  var currentProfile = 'full';
  var currentGate    = 0;  // 已完成的关卡数（0=未开始）
  var activeGate     = 0;  // 当前飞行目标关卡
  var machineState   = 'IDLE';
  var tween          = null;
  var entranceTimer  = null;
  var resizeTimer    = null;
  var pathReady      = false;
  var listeners      = [];

  // ── Listener registry ──
  function on(el, evt, fn) {
    if (!el) return;
    el.addEventListener(evt, fn);
    listeners.push([el, evt, fn]);
  }

  // ── Gate helpers ──
  function gateByNum(n) {
    return gates.filter(function(g) { return Number(g.getAttribute('data-s014-gate')) === n; })[0];
  }
  function orderedGates() {
    return gates.slice().sort(function(a, b) {
      return Number(a.getAttribute('data-s014-gate')) - Number(b.getAttribute('data-s014-gate'));
    });
  }

  // ── Stage indicator ──
  function setStage(state, gateNum) {
    machineState = state;
    var n = Math.max(0, Math.min(8, Number(gateNum) || 0));
    var label = {
      IDLE:        '等待调用',
      FLYING:      '调用穿行中',
      GATE_PASS:   '本步放行',
      GATE_BLOCK:  '本步拦截',
      DONE:        '放行执行'
    }[state] || state;
    if (stageEl)    stageEl.textContent = label + ' · 第 ' + n + '/8 步 · profile=' + currentProfile;
    if (progressEl) progressEl.textContent = '第 ' + n + '/8 步';
  }

  function setOutcome() {
    if (!outcomeEl) return;
    outcomeEl.textContent = currentProfile === 'full'
      ? 'full：exec 穿过全部 8 步，最终放行执行。'
      : 'minimal：exec 不在第 1 步白名单，调用被挡下——blocked by before_tool_call。';
  }

  function setProfileBtns() {
    profileBtns.forEach(function(btn) {
      var active = btn.getAttribute('data-s014-profile') === currentProfile;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-selected', String(active));
    });
  }

  // ── Path progress indicator ──
  function updatePathProgress() {
    if (!pathActive || !pathBase || !pathBase.getTotalLength) return;
    var total    = pathBase.getTotalLength();
    var fraction = machineState === 'DONE' ? 1 : currentGate / 9;
    var offset   = total * (1 - Math.max(0, Math.min(1, fraction)));
    pathActive.style.strokeDasharray  = String(total);
    pathActive.style.strokeDashoffset = String(offset);
  }

  // ── Gate visual state ──
  function renderTrack() {
    gates.forEach(function(gate) {
      var n = Number(gate.getAttribute('data-s014-gate'));
      gate.classList.toggle('is-pass',    n <= currentGate && machineState !== 'GATE_BLOCK');
      gate.classList.toggle('is-current', n === activeGate && machineState === 'FLYING');
      gate.classList.toggle('is-block',   n === currentGate && machineState === 'GATE_BLOCK');
    });
    statusCells.forEach(function(cell) {
      var n = Number(cell.getAttribute('data-s014-status'));
      cell.classList.toggle('is-pass',  n <= currentGate && machineState !== 'GATE_BLOCK');
      cell.classList.toggle('is-block', n === currentGate && machineState === 'GATE_BLOCK');
    });
    if (ball) {
      ball.classList.toggle('is-block', machineState === 'GATE_BLOCK');
      ball.classList.toggle('is-done',  machineState === 'DONE');
    }
    updatePathProgress();
  }

  // ── Popup（position:fixed — FM-2）──
  function hidePopup() {
    if (!popup) return;
    popup.classList.remove('is-visible');
    popup.style.left = '';
    popup.style.top  = '';
  }

  function positionPopup() {  // ←FM-2: popup is position:fixed, coords are viewport-relative
    if (!popup) return;
    var gate = gateByNum(1);
    if (!gate) return;
    var r    = gate.getBoundingClientRect();
    var vw   = window.innerWidth;
    var pw   = Math.min(288, vw * 0.72);       // 18rem≈288px
    var left = Math.min(vw - pw - 12, Math.max(12, r.left + r.width * 0.5 - pw * 0.5));
    var top  = Math.min(window.innerHeight - 160, r.top + r.height + 10);
    popup.style.left  = left + 'px';
    popup.style.top   = top + 'px';
    popup.style.width = pw + 'px';
  }

  function showBlocked() {
    currentGate = 1;
    activeGate  = 0;
    setStage('GATE_BLOCK', 1);
    renderTrack();
    if (popup) {
      popup.classList.add('is-visible');
      positionPopup();
    }
  }

  // ── Path rebuild (dynamic layout) ──
  function pathPointForEl(el) {
    var tr = track.getBoundingClientRect();
    var r  = el.getBoundingClientRect();
    return {
      x: r.left - tr.left + r.width  * 0.5,
      y: r.top  - tr.top  + r.height * 0.5
    };
  }

  function rebuildPath() {
    if (!track || !pathBase || !pathActive) return;
    var pts    = orderedGates().map(pathPointForEl);
    if (pts.length < 8) return;
    var startX = Math.max(18, pts[0].x - 88);
    var doneX  = Math.min(track.clientWidth - 18, pts[7].x + 80);
    var doneY  = pts[7].y;
    var d = 'M ' + startX + ' ' + pts[0].y +
      pts.map(function(p) { return ' L ' + p.x + ' ' + p.y; }).join('') +
      ' L ' + doneX + ' ' + doneY;
    pathBase.setAttribute('d', d);
    pathActive.setAttribute('d', d);
    pathReady = true;
    if (window.gsap && window.MotionPathPlugin) {
      window.gsap.registerPlugin(window.MotionPathPlugin);
    }
    resetTrack();
  }

  // ── Ball position helpers ──
  function placeBallAtStart() {
    if (!window.gsap || !window.MotionPathPlugin || !ball || !pathBase || !pathReady) return;
    window.gsap.set(ball, {
      motionPath: {
        path: pathBase, align: pathBase,
        alignOrigin: [0.5, 0.5], start: 0, end: 0
      }
    });
  }

  // ── Reset ──
  function stopBall() {  // ←FM-1: called before any profile switch
    if (tween) { tween.kill(); tween = null; }
    activeGate = 0;
    if (window.gsap && ball) window.gsap.killTweensOf(ball);  // ←FM-3
  }

  function resetTrack() {
    currentGate = 0;
    hidePopup();
    if (ball) ball.classList.remove('is-block', 'is-done');
    setStage('IDLE', 0);
    placeBallAtStart();
    renderTrack();
  }

  // ── Move ball to done endpoint ──
  function moveToDone() {
    if (!window.gsap || !window.MotionPathPlugin || !ball || !pathBase || !pathReady) return;
    if (tween) tween.kill();
    tween = window.gsap.to(ball, {
      duration: 0.32, ease: 'power1.out',
      motionPath: {
        path: pathBase, align: pathBase,
        alignOrigin: [0.5, 0.5], start: 8 / 9, end: 1
      },
      onComplete: function() { tween = null; }
    });
  }

  // ── Arrive at a gate ──
  function arriveAtGate(gateNum, keepGoing) {
    currentGate = gateNum;
    activeGate  = 0;
    if (currentProfile === 'minimal' && gateNum === 1) {
      showBlocked();
      return;
    }
    hidePopup();
    if (gateNum >= 8) {
      setStage('DONE', 8);
      renderTrack();
      moveToDone();
      return;
    }
    setStage('GATE_PASS', gateNum);
    renderTrack();
    if (keepGoing) animateToGate(gateNum + 1, true);
  }

  // ── Fallback (no GSAP MotionPath) ──
  function fallbackMove(targetGate, keepGoing) {
    currentGate = targetGate;
    arriveAtGate(targetGate, keepGoing);
  }

  // ── Animate ball to next gate ──
  function animateToGate(targetGate, keepGoing) {
    if (!pathReady || targetGate < 1 || targetGate > 8) return;
    hidePopup();
    if (tween) tween.kill();
    activeGate = targetGate;
    setStage('FLYING', targetGate);
    renderTrack();
    if (!window.gsap || !window.MotionPathPlugin || !ball || !pathBase) {
      window.setTimeout(function() { fallbackMove(targetGate, keepGoing); }, 220);
      return;
    }
    var startFrac = currentGate / 9;
    var endFrac   = targetGate  / 9;
    tween = window.gsap.to(ball, {
      duration: keepGoing ? 0.55 : 0.40,
      ease: 'power1.inOut',
      motionPath: {
        path: pathBase, align: pathBase,
        alignOrigin: [0.5, 0.5],
        start: startFrac, end: endFrac
      },
      onComplete: function() { tween = null; arriveAtGate(targetGate, keepGoing); }
    });
  }

  // ── Controls ──
  function handlePlay() {
    if (tween && typeof tween.paused === 'function' && tween.paused()) {
      tween.resume();
      setStage('FLYING', activeGate || currentGate + 1);
      renderTrack();
      return;
    }
    var wasBlocked = machineState === 'GATE_BLOCK';
    stopBall();
    hidePopup();
    if (currentGate >= 8 || wasBlocked) resetTrack();
    animateToGate(currentGate + 1, true);
  }

  function handlePause() {
    if (tween) tween.pause();
    setStage('IDLE', currentGate);
    renderTrack();
  }

  function handleStep() {
    var wasBlocked = machineState === 'GATE_BLOCK';
    stopBall();
    if (wasBlocked || currentGate >= 8) resetTrack();
    animateToGate(currentGate + 1, false);
  }

  function handleReset() { stopBall(); resetTrack(); }

  function handleProfileSwitch() {
    var profile = this.getAttribute('data-s014-profile');
    stopBall();    // ←FM-1: stop ball before profile switch
    resetTrack();  // ←FM-1: reset track state
    currentProfile = profile;
    setProfileBtns();
    setOutcome();
    setStage('IDLE', 0);
  }

  function handleResize() {
    clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(rebuildPath, 120);
  }

  // ── Bind events ──
  profileBtns.forEach(function(btn) { on(btn, 'click', handleProfileSwitch); });
  on(playBtn,   'click', handlePlay);
  on(pauseBtn,  'click', handlePause);
  on(stepBtn,   'click', handleStep);
  on(resetBtn,  'click', handleReset);
  on(window,    'resize', handleResize);

  // ── Entrance animation (GSAP fromTo, paused + delay) ──
  var entranceTl = null;
  entranceTimer = window.setTimeout(function() {
    if (!window.gsap) {
      setProfileBtns(); setOutcome();
      window.setTimeout(rebuildPath, 0);
      return;
    }
    entranceTl = window.gsap.timeline({ paused: true });
    var allGates = root.querySelectorAll('.s014-gate');
    entranceTl.fromTo(
      [root.querySelector('.s014-header'), root.querySelector('.s014-side-panel'),
       root.querySelector('.s014-control-panel')],
      { opacity: 0, y: 18 },
      { opacity: 1, y: 0, duration: 0.4, stagger: 0.08, ease: 'power2.out' }
    ).fromTo(
      allGates,
      { opacity: 0, scale: 0.85 },
      { opacity: 1, scale: 1, duration: 0.35, stagger: 0.04, ease: 'back.out(1.3)' },
      '-=0.2'
    );
    entranceTl.play();
    setProfileBtns();
    setOutcome();
    window.setTimeout(rebuildPath, 80);
  }, 120);

  // ── Cleanup ──
  return function cleanupS014() {  // ←FM-3: full cleanup
    clearTimeout(entranceTimer);
    clearTimeout(resizeTimer);
    if (tween)      { tween.kill();      tween      = null; }
    if (entranceTl) { entranceTl.kill(); entranceTl = null; }
    if (window.gsap && root) {
      window.gsap.killTweensOf(root.querySelectorAll('*'));  // ←FM-3
    }
    hidePopup();
    listeners.forEach(function(item) { item[0].removeEventListener(item[1], item[2]); });
    listeners = [];
  };
};

window.slideHooks['slides/S017-exec-dual-axis-knob.html'] = function() {
  /* FM 清单: FM-1 cleanup removeEventListener(document pointermove/up/cancel) /
              FM-2 统一 pointer events + setPointerCapture 防双触发 /
              FM-3 落点 clamp 到 [0,2]x[0,2] 防旋钮飞出九宫格 */

  var root = document.querySelector('[data-slide="s017"]');
  if (!root) return function noop() {};  // ←FM-2 防 null

  var securityLevels = ['deny', 'allowlist', 'full'];
  var askLevels = ['off', 'on-miss', 'always'];

  // 场景预设：开发机/共享机/CI（confirmed_redesign S017）
  var presets = {
    dev:    { security: 'full',      ask: 'off'     },
    shared: { security: 'allowlist', ask: 'on-miss' },
    ci:     { security: 'deny',      ask: 'off'     }
  };

  // 9 种组合的反馈文案（红线#4：不暗示漏洞；full/off = trusted-operator 有意 UX）
  var feedback = {
    silent: {
      title: '静默执行',
      detail: 'trusted-operator 有意 UX：单一可信操作者信任自己的机器和意图，exec 直接执行不弹审批。这是 full/off 的默认设计，不是漏洞（exec-approvals.ts:205/206）。'
    },
    approval: {
      title: '弹审批',
      detail: '执行前停在 operator intent 确认点：用户须显式确认后 exec 才继续。适合多用户或共享环境，让每次命令执行留下有意识的确认动作。'
    },
    reject: {
      title: '直接拒绝',
      detail: 'security=deny 时所有 exec 直接被拒绝，无论 ask 配置如何。这是积极收紧的护栏，用于多租户/不信任场景，不是默认值的异常。'
    }
  };

  // 9 格场景描述（正确枚举：deny/allowlist/full × off/on-miss/always）
  var scenarios = {
    'full:off':        '开发机默认配置：full/off 是 exec-approvals.ts:205/206 写死的默认值，面向 trusted-operator 流畅 UX，减少摩擦让个人工作台高效。',
    'full:on-miss':    'full 档没有白名单 miss 分支，on-miss 不产生额外弹窗效果；这组合等同 full/off 体验，适合保持统一配置界面的个人环境。',
    'full:always':     '高信任+每次确认：每次 exec 弹审批，让操作者多看一眼。适合演示、教学，或处理高风险命令时增加一道有意识的确认。',
    'allowlist:off':   '精确白名单静默：命中白名单的命令静默执行，白名单外直接拒绝，不弹窗。适合自动化链路，行为确定无需人工介入。',
    'allowlist:on-miss': '共享机推荐：白名单命中静默放行，未命中弹审批由人决定。在精确管控与可恢复性之间找折中，是多用户共享环境的实用组合。',
    'allowlist:always':  '生产变更窗口：即使命中白名单也每次确认，用更重的 operator intent 换取更强审计感，适合风险敏感操作窗口。',
    'deny:off':        'CI 流水线/不信任环境：deny 禁止一切 exec，ask=off 不改变 deny 的最高优先级。适合多租户 SaaS 或纯代码分析场景。',
    'deny:on-miss':    '不信任环境：deny 先于审批生效，所有 exec 直接拒绝，不进入审批流程。on-miss 在此无实质效果。',
    'deny:always':     '严格多租户：即使 ask=always，deny 仍直接拒绝，不把拒绝伪装成可审批项。最高安全档位。'
  };

  // DOM 引用
  var plane      = root.querySelector('[data-s017-plane]');
  var knob       = root.querySelector('[data-s017-knob]');
  var indicator  = root.querySelector('[data-s017-indicator]');
  var securityText  = root.querySelector('[data-s017-knob-security]');
  var askText       = root.querySelector('[data-s017-knob-ask]');
  var securityValue = root.querySelector('[data-s017-security-value]');
  var askValue      = root.querySelector('[data-s017-ask-value]');
  var stateValue    = root.querySelector('[data-s017-state-value]');
  var outcomeCard   = root.querySelector('[data-s017-outcome-card]');
  var outcomeTitle  = root.querySelector('[data-s017-outcome-title]');
  var outcomeDetail = root.querySelector('[data-s017-outcome-detail]');
  var scenarioEl    = root.querySelector('[data-s017-scenario] span');
  var securityChips = Array.prototype.slice.call(root.querySelectorAll('[data-s017-security-chip]'));
  var askChips      = Array.prototype.slice.call(root.querySelectorAll('[data-s017-ask-chip]'));
  var cells         = Array.prototype.slice.call(root.querySelectorAll('[data-s017-cell]'));
  var presetButtons = Array.prototype.slice.call(root.querySelectorAll('[data-s017-preset]'));
  var resetButton   = root.querySelector('[data-s017-reset]');

  // 状态（闭包内，不污染全局）
  var current = { x: 2, y: 0 };  // 默认 full/off（exec-approvals.ts:205/206）
  var dragging = false;
  var activePointerId = null;
  var entranceTl = null;
  var entranceTimer = null;
  var listeners = [];

  // 具名事件注册（便于 removeEventListener）
  function on(el, evt, fn) {
    if (!el) return;
    el.addEventListener(evt, fn);
    listeners.push([el, evt, fn]);
  }

  function clampGrid(v) {
    return Math.max(0, Math.min(2, Math.round(v)));  // ←FM-3 clamp 防越界
  }

  function securityVal(x) { return securityLevels[Math.max(0, Math.min(2, x))]; }
  function askVal(y)       { return askLevels[Math.max(0, Math.min(2, y))]; }
  function xFromSec(s)  { var i = securityLevels.indexOf(s); return i < 0 ? 2 : i; }
  function yFromAsk(a)  { var i = askLevels.indexOf(a);      return i < 0 ? 0 : i; }

  function outcomeFor(sec, ask) {
    if (sec === 'deny') return 'reject';
    if (sec === 'full' && ask !== 'always') return 'silent';
    if (sec === 'full' && ask === 'always') return 'approval';
    // allowlist
    if (ask === 'off') return 'reject';  // allowlist+off: 白名单外拒绝，白名单内静默（合并为 reject 简化教学）
    return 'approval';
  }

  function renderFeedback(sec, ask) {
    var outcome = outcomeFor(sec, ask);
    var data = feedback[outcome];
    var key = sec + ':' + ask;
    if (outcomeCard)   outcomeCard.setAttribute('data-outcome', outcome);
    if (outcomeTitle)  outcomeTitle.textContent = data.title;
    if (outcomeDetail) outcomeDetail.textContent = data.detail;
    if (indicator)     indicator.textContent = sec + ' / ' + ask + ' · ' + data.title;
    if (securityValue) securityValue.textContent = sec;
    if (askValue)      askValue.textContent = ask;
    if (securityText)  securityText.textContent = sec;
    if (askText)       askText.textContent = ask;
    if (stateValue)    stateValue.textContent = 'IDLE';
    if (scenarioEl)    scenarioEl.textContent = scenarios[key] || '';

    securityChips.forEach(function(chip) {
      chip.classList.toggle('is-active', chip.getAttribute('data-s017-security-chip') === sec);
    });
    askChips.forEach(function(chip) {
      chip.classList.toggle('is-active', chip.getAttribute('data-s017-ask-chip') === ask);
    });
    cells.forEach(function(cell) {
      cell.classList.toggle('is-active', cell.getAttribute('data-s017-cell') === key);
    });
    presetButtons.forEach(function(btn) {
      var p = presets[btn.getAttribute('data-s017-preset')];
      btn.classList.toggle('is-active', Boolean(p && p.security === sec && p.ask === ask));
    });
  }

  function renderPosition() {
    if (!knob) return;
    knob.style.left = ((current.x + 0.5) / 3 * 100) + '%';
    knob.style.top  = ((2 - current.y + 0.5) / 3 * 100) + '%';
  }

  function commitPosition(x, y) {
    current.x = clampGrid(x);  // ←FM-3
    current.y = clampGrid(y);  // ←FM-3
    renderPosition();
    renderFeedback(securityVal(current.x), askVal(current.y));
  }

  function pointToGrid(clientX, clientY) {
    if (!plane) return { x: current.x, y: current.y };
    var rect = plane.getBoundingClientRect();
    var lx = Math.max(0, Math.min(rect.width,  clientX - rect.left));
    var ly = Math.max(0, Math.min(rect.height, clientY - rect.top));
    return {
      x: clampGrid(Math.floor(lx / rect.width  * 3)),  // ←FM-3
      y: clampGrid(2 - Math.floor(ly / rect.height * 3))  // ←FM-3
    };
  }

  // 拖拽处理：统一 pointer events + setPointerCapture 防双触发
  function handlePointerDown(event) {
    if (!knob) return;
    dragging = true;
    activePointerId = event.pointerId;
    knob.setPointerCapture(event.pointerId);  // ←FM-2
    knob.classList.add('is-dragging');
    if (plane) plane.classList.add('is-dragging');
    var grid = pointToGrid(event.clientX, event.clientY);
    current.x = grid.x; current.y = grid.y;
    renderPosition();
    renderFeedback(securityVal(current.x), askVal(current.y));
    event.preventDefault();
  }

  function handlePointerMove(event) {
    if (!dragging || event.pointerId !== activePointerId) return;  // ←FM-2
    var grid = pointToGrid(event.clientX, event.clientY);
    current.x = grid.x; current.y = grid.y;
    renderPosition();
    renderFeedback(securityVal(current.x), askVal(current.y));
  }

  function handlePointerUp(event) {
    if (!dragging || event.pointerId !== activePointerId) return;
    dragging = false;
    activePointerId = null;
    try { if (knob) knob.releasePointerCapture(event.pointerId); } catch (e) {}
    if (knob)  knob.classList.remove('is-dragging');
    if (plane) plane.classList.remove('is-dragging');
    commitPosition(pointToGrid(event.clientX, event.clientY).x,
                   pointToGrid(event.clientX, event.clientY).y);
  }

  // 绑定事件
  on(knob,     'pointerdown', handlePointerDown);
  on(document, 'pointermove', handlePointerMove);  // ←FM-1 绑在 document
  on(document, 'pointerup',   handlePointerUp);    // ←FM-1 绑在 document
  on(document, 'pointercancel', handlePointerUp);  // ←FM-1 绑在 document

  presetButtons.forEach(function(btn) {
    on(btn, 'click', function handlePreset() {
      var key = btn.getAttribute('data-s017-preset');
      var p = presets[key];
      if (p) commitPosition(xFromSec(p.security), yFromAsk(p.ask));
    });
  });

  on(resetButton, 'click', function handleReset() {
    commitPosition(xFromSec('full'), yFromAsk('off'));
  });

  // GSAP 入场动画（fromTo + paused + delay 120ms，防 display:none 时序问题）
  // ⚠️ 禁用 gsap.from()——S017 历史反例：from() 在 display:none 元素上无法推断目标值
  if (window.gsap) {
    var targets = root.querySelectorAll('.s017-header > *, .s017-grid-panel, .s017-result-panel');
    entranceTl = gsap.timeline({ paused: true });
    entranceTl.fromTo(targets,
      { opacity: 0, y: 16 },
      { opacity: 1, y: 0, duration: 0.42, stagger: 0.08, ease: 'power2.out' }
    );
    entranceTimer = setTimeout(function() {
      if (entranceTl) entranceTl.play();
    }, 120);  // 等 slide 从 display:none 变可见
  }

  // 初始渲染（默认 full/off）
  renderPosition();
  renderFeedback('full', 'off');

  // cleanup 函数（必须返回）
  return function cleanup() {
    clearTimeout(entranceTimer);  // ←FM-1（timer 清理）
    if (entranceTl) { entranceTl.kill(); entranceTl = null; }  // ←FM-2（GSAP killTweensOf）
    if (window.gsap && root) {
      gsap.killTweensOf(root.querySelectorAll('*'));  // ←FM-2
    }
    listeners.forEach(function(item) {
      item[0].removeEventListener(item[1], item[2]);  // ←FM-1（removeEventListener）
    });
    listeners = [];
    dragging = false;
    activePointerId = null;
    if (knob)  knob.classList.remove('is-dragging');
    if (plane) plane.classList.remove('is-dragging');
  };
};
