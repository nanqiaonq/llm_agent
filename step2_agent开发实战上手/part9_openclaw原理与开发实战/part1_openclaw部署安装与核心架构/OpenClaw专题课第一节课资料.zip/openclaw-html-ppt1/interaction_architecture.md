## Interaction Architecture
生成时间：2026-06-01
课程：OpenClaw 核心架构 · 第一节课
主题：light（浅珊瑚雾 Coral-Mist Molting，L3）｜motion_level：high｜creativity_level：medium

### Lesson Thesis
- **核心命题**：让开发者从"以为 agent 就是带工具的 chatbot"，到理解 agent 的真实运行机制——一条消息进入后，由「外层 while(true) 心跳循环 + 内层 while 工具循环」自驱推进，运行中可被 steering 注入**当前轮**干预，工具调用须过 8 步策略管线，安全由双轴信任旋钮分层把控。
- **必须可见的机制**（不可视化就无法真正理解）：
  1. 双层 while 循环 + steering 注入当前轮（圆环不重置、不另起会话）— P12 灵魂页
  2. EventStream 10 事件分 4 组生命周期，每个动作都对应一个事件 — P13
  3. 8 步工具策略管线门控（"模型想调工具不是想调就能调"）— P16
  4. exec 三档×三态双轴信任模型（security×ask 交叉的 9 种组合）— P19
- **目标学员误解 Top 3**：
  1. 「agent = chatbot + 工具」→ P11/P12 打破：agent 是自驱心跳循环，chatbot 是被动一次性应答
  2. 「steering 插话会打断/重启对话」→ P12 打破：steering 注入当前轮上下文，循环不重启、不新建会话
  3. 「exec 默认 full/off 是安全漏洞」→ P17/P19 打破：trusted-operator 有意 UX，是护栏不是隔离漏洞
- **成功判据**：学员能口述一条消息从进入到干完活经过哪些循环层 / 哪些事件 / 哪些策略关卡；能解释 steering 为何不另起会话；能说出 exec 三档分别适合什么场景。

---

### 逐页交互决策

| page_id | title | teaching_role | interaction_strength | chosen_pattern | four_axis_score | justification | anti_pattern_check |
|---------|-------|--------------|---------------------|----------------|-----------------|---------------|-------------------|
| P1 | 封面 | hook | 🟢 | static-cover | EP:3 MV:1 IC:3 OL:3=10 | 封面只需龙虾视觉聚焦+副标题"跟着一条消息走完 agent 的一生"，交互会分散 hook 注意力 | true |
| P2 | OpenClaw 是什么+多火 | concept | 🟡 | milestone-step-reveal | EP:2 MV:2 IC:3 OL:3=10 | 里程碑数字逐条揭示（90 天超 React/VS Code）让"火爆"有节奏感；静态一次给出冲击力弱。须标注"数据快照 2026-03-02 GitHub API" | true |
| P3 | 三维定位 | concept | 🟡 | hover-card-expand | EP:2 MV:1 IC:3 OL:3=9 | 三卡片（跨渠道 20+平台 logo 墙×跨设备×跨 provider）悬停展开，hover 让每维细节按需呈现不挤屏 | true |
| P4 | 同类对比 | compare | 🟡 | four-column-table | EP:2 MV:0 IC:3 OL:3=8 | 四者（OpenClaw/Claude Code/Codex/Hermes）多维对比表，扫描式阅读优于动画；Hermes 仅标"本地/小众 CLI"形态对比 | true |
| P5 | 四代演进·molting | 交互组件5 | 🔴 | timeline-slider-molting | EP:2 MV:2 IC:2 OL:3=9 | 滑块驱动四代（Warelay→Clawdbot→Moltbot→OpenClaw）演进，点 OpenClaw 触发蜕壳渐变动效，让"3 次 rebrand/换壳成长"隐喻可感；静态时间线传不出"蜕壳"动势 | true |
| P6 | 不是什么·四条边界 | concept | 🟡 | flip-card-misconception | EP:2 MV:1 IC:3 OL:3=9 | 翻转卡误解面→正确面，让"边界澄清"有"先入为主再纠正"的认知冲击；翻转是边界教学的轻量强化 | true |
| P7 | 过渡·消息生命周期 | section-transition | 🟡 | arc-roadmap | EP:2 MV:1 IC:3 OL:3=9 | 主轴弧线图+5 章路线图（标重心章 2/3），让学员看到自己在整条生命周期叙事的位置 | true |
| P8 | 在你机器上跑起来 | flow | 🟢 | terminal-step-static | EP:2 MV:1 IC:3 OL:3=9 | 三步命令（clone→pnpm install→tui --local）终端风静态展示即清晰，命令是"复制即用"不需交互 | true |
| P9 | Gateway 中枢 vs --local 旁路 | concept | 🟡 | topology-toggle | EP:3 MV:2 IC:2 OL:3=10 | 拓扑对照点击切换两种模式，连线随模式变化让"中枢 vs 旁路"路径差异可见；新机制对照须有视觉连线 | true |
| P10 | 过渡·第2章 心脏 | section-transition | 🟢 | suspense-text | EP:1 MV:1 IC:3 OL:3=8 | 悬念文字"跑到一半你能插话"，过渡页靠文案钩子不靠交互 | true |
| P11 | 认知重塑 chatbot vs agent | compare | 🟡 | scenario-table | EP:2 MV:1 IC:3 OL:3=9 | 慢任务场景代入+4 维对照表，为 P12 灵魂页铺认知地基；对照表扫描优于动画 | true |
| **P12** | **⭐双层 while+steering 模拟器** | **交互组件1·灵魂页** | **🔴🔴** | **nested-loop-heartbeat-injection** | EP:3 MV:3 IC:1 OL:2=9 | 双层嵌套循环+steering 注入当前轮，是全课唯一无法被静态替代的机制——"圆环不重置、不另起会话"这个最反直觉的点，全靠飞入当前轮的动画揭示。9 样本中无此 pattern，是本课 diversity break | true |
| **P13** | **EventStream 10 事件流** | **交互组件2** | **🔴🔴** | **phase-lane-log-reconcile** | EP:3 MV:3 IC:1 OL:2=9 | 10 事件分 4 组泳道点亮 + 右侧 TUI 日志同步高亮对账，让"每个动作都对应一个事件"可见；静态序列图无法表达事件↔日志的时序对账。新机制独立展示，事件↔日志有对账连线 | true |
| P14 | 过渡·第3章 心脏的手 | section-transition | 🟢 | suspense-text | EP:1 MV:1 IC:3 OL:3=8 | 悬念"模型想调工具不是想调就能调"，过渡页文案钩子 | true |
| **P15** | **plugin/capability/tool 纠错图谱** | **交互组件6** | **🔴** | **drag-drop-correction-gate** | EP:3 MV:2 IC:1 OL:2=8 | 拖拽纠错（tool 拖进 plugin/capability，拖错弹回不解锁）让"三者层级关系"通过试错内化，比静态图谱深刻；+minHostVersion 门控滑块。须体现"tool 不属于 capability 的 15 种" | true |
| **P16** | **8 步工具策略管线闯关** | **交互组件3** | **🔴🔴** | **ball-gauntlet-profile-branch** | EP:3 MV:3 IC:1 OL:2=9 | 小球穿 8 关蛇形管线 + 切 profile（full 全过/minimal 第 1 关拦截变红弹原因），让"策略门控"可感——"卡在第 1 关"静态绝无法表达。新机制独立展示，小球路径即视觉连线 | true |
| P17 | exec 默认 full/off 不是漏洞 | concept(强调) | 🟡 | emphasis-callout | EP:2 MV:1 IC:3 OL:3=9 | trusted-operator 护栏≠多租户隔离，强调框定（红线#4：不可讲反）；强调页靠排版层次不靠交互 | true |
| P18 | 过渡·第4章 安全纵深 | section-transition | 🟢 | suspense-text | EP:1 MV:1 IC:3 OL:3=8 | 悬念"既然 full 合理，另两档长啥样"，承接 P17 引出 P19 | true |
| **P19** | **exec 三档×三态信任旋钮** | **交互组件4** | **🔴🔴** | **dual-axis-knob-feedback** | EP:3 MV:2 IC:1 OL:2=8 | 双轴旋钮 security(deny↔full)×ask(off↔always) 拖动看静默/弹审批/拒绝的因果反馈+场景，让双轴安全模型的 9 种组合可探索；静态表格列得出组合但给不出"拖到 deny 看拒绝"的因果体验 | true |
| P20 | Docker sandbox 分层 | concept | 🟡 | layer-toggle | EP:3 MV:2 IC:2 OL:3=10 | 叠层开关：policy 管"能调什么"/sandbox 管"在哪里调"，两层独立开关让"策略层 vs 隔离层"正交关系可见 | true |
| P21 | 信任 vs 约束 张力光谱 | concept(轻交互) | 🟡 | spectrum-slider-linked | EP:2 MV:2 IC:2 OL:3=9 | 光谱滑块与 P19 联动+点名另两对张力，把哲学张力落到可拖的连续谱；轻交互即可，不必升 🔴 | true |
| P22 | 全课能力回顾 | summary | 🟢 | checklist-static | EP:2 MV:1 IC:3 OL:3=9 | 5 章×8 件产物勾选式回顾，成就感清单静态呈现即可，勾选动效非核心 | true |
| P23 | 下节预告+结尾 | ending | 🟢 | static-ending | EP:2 MV:1 IC:3 OL:3=9 | 多智能体×上下文工程×记忆系统预告+龙虾收尾，结尾页视觉收束不需交互 | true |

> **字段值锁定**：`interaction_strength` 纯 emoji（🟢/🟡/🔴/🔴🔴）；`anti_pattern_check` 为 boolean（true/false）。

---

### 🔴🔴 / 🔴 重交互页 state 设计要点

#### P12 ⭐双层 while+steering 模拟器（🔴🔴 灵魂页）
- **布局**：左侧大圆环=外层 `while(true)` 心跳（agent-loop.ts:213 入口），环上 4 个 stage 节点（① 取下一步·LLM 决策 → ② 是否要调工具？→ ③ 内层 while 执行工具循环 → ④ 回灌结果 → 回①）；内层 tool 循环用环内小循环箭头表示（agent-loop.ts:285/311）。右侧=steering 队列面板 + 当前轮上下文消息列表。
- **状态机（5 态，控认知负荷）**：
  ```
  IDLE
    → (点"发慢任务") → HEARTBEAT_TICK（外层转一圈，stage①②点亮）
    → TOOL_LOOP（内层 while，stage③ 小循环转 N 次）
    → REFLECT（stage④ 回灌）→ 回 HEARTBEAT_TICK（下一圈）→ … → DONE
  任意运行态 → (点"插话") → STEERING_INJECT：
    steering 消息从右侧队列「飞入」当前轮上下文列表
    【关键：飞入当前正在转的那一圈的 messages，圆环不重置 / 不回 IDLE / 不新建会话】
    → 继续当前循环
  ```
- **控件**：▶ 播放（自动转圈）/ ⏸ 暂停（停在当前 stage）/ ⏭ 单步（手动推进一个 stage）；进度条=「第 N 圈 · Stage X」可拖动单步回看；顶部 stage indicator 文字标注当前位置。
- **active 表现**（浅底）：当前 stage 节点橙红描边加粗+发光（--glow-active）；steering 飞入消息用墨蓝 accent 区分于原上下文。
- **教学锚点**：核心洞见 ≤3 步到达——发任务→插话→看飞入当前轮（而非另起会话）。

#### P13 EventStream 10 事件流（🔴🔴）
- **布局**：左侧 4 组生命周期泳道（① 会话/轮次组 → ② LLM 推理组 → ③ 工具调用组 → ④ 完成/错误组），10 个事件卡按组排布（红线：共 10 种事件分 4 组，6 主骨架，数字不可改）；右侧 TUI 终端日志（mono 字体）实时滚动高亮对账（chat-log.ts:333）。
- **状态机**：场景选择器（无工具/有工具/流式/steering 四场景）→ PLAY → 逐事件点亮：左泳道事件卡 active 橙红描边 + 右侧 TUI 对应日志行墨蓝高亮 → 形成事件↔日志对账线。不同场景走不同事件子集（无工具场景跳过工具组）。
- **控件**：▶播放 / ⏸暂停 / ⏭单步；进度="事件 N/10"。
- **三态对账配色**（沿用 manifest）：匹配=墨蓝 accent / 当前=橙红 primary / 未到=暖灰 dim。

#### P16 8 步工具策略管线闯关（🔴🔴）
- **布局**：复用 s025 蛇形 8 节点布局 + 三按钮控制栏骨架（creative_freedom 变体，非照抄：加 profile 分支 + 小球 motionPath）。8 关对应 tool-policy-pipeline.ts 各步（红线：共 8 步不可改）。
- **状态机**：选 profile（full/minimal）→ 释放小球 → 小球沿 8 关蛇形前进，每关播放源码 label → full：8 关全过绿色到达；minimal：第 1 关（白名单校验）拦截，小球停住变红+弹"被拦截原因"popup。悬停任意关看源码 label。
- **控件**：▶发射小球 / ⏸暂停 / ⏭单步过关；进度="第 N/8 关"。

#### P19 exec 三档×三态信任旋钮（🔴🔴）
- **布局**：中央双轴 2D 旋钮——X 轴 security(deny↔read-only↔full)，Y 轴 ask(off↔on-write↔always)，3×3=9 格落点；旋钮当前落点高亮。右侧结果反馈面板：当前 (security,ask) 组合下"跑 exec rm -rf"会发生什么（静默执行/弹审批/直接拒绝）+适用场景（exec-approvals.ts:24/25/205/206）。
- **状态机**：拖动 knob → 落到 9 格之一（clamp 边界）→ 实时计算 (security×ask) → 结果面板更新三态反馈（静默=橙红警示 / 弹审批=墨蓝 / 拒绝=暖灰）+场景描述。
- **控件**：双轴 knob 拖动（核心）+ "重置到默认 full/off" 按钮 + 3 个场景预设钮（开发机/共享机/CI）降低学习曲线。
- **红线**：exec 默认 full/off 框定为 trusted-operator 有意 UX（红线#4），结果面板文案不得暗示"漏洞"。

#### P15 plugin/capability/tool 纠错图谱（🔴）
- **布局**：上方 tool 卡片池，下方 plugin / capability 两个容器。拖拽纠错：tool 拖进正确容器贴标签锁定，拖错弹回不解锁。+minHostVersion 门控滑块（manifest-registry.ts:1026），版本不足时对应 plugin 灰显锁定。
- **状态机**：DRAG_START → (drop 正确) ACCEPTED（贴标签+锁定，AD-14 渐进点亮）/ (drop 错误) REJECTED（弹回原位+橙红抖动）。
- **红线**：capability 共 15 种、tool 不在其中——拖拽逻辑必须体现"tool 是 plugin 提供的执行单元，不属于 capability 的 15 种分类"，拖 tool 进 capability 容器须判错弹回。

---

### Pattern Selection Summary
**保留模式**：
- `nested-loop-heartbeat-injection`(P12)：全课唯一能表达"steering 注入当前轮不重置循环"的 pattern，9 样本无此模式，承担 diversity_constraint break。
- `phase-lane-log-reconcile`(P13)：泳道点亮+日志对账双栏，让事件流可对账。
- `ball-gauntlet-profile-branch`(P16)：复用 s025 蛇形骨架 + profile 分支变体，小球穿关让门控可感。
- `dual-axis-knob-feedback`(P19)：2D 决策矩阵旋钮，双轴交叉因果反馈，区别于 chartjs 滑块沙盒。
- `timeline-slider-molting`(P5) / `drag-drop-correction-gate`(P15)：滑块+拖拽纠错，🔴 级轻状态机。
- 轻交互复用（hover-expand / flip-card / toggle / slider）：P3/P6/P9/P20/P21，单控件低负荷。

**拒绝模式**：
- 过渡页（P10/P14/P18）拒绝任何交互（anti-pattern：交互仅因"看起来高级"而存在）→ 降为悬念文案静态页。
- P4/P11 对比页拒绝动画对比（anti-pattern：动画改变风格多于改变理解）→ 用扫描式对照表。
- P12/P13/P16 拒绝"左右对比"布局（反模式铁律：新机制用独立展示）→ 均独立展示单机制。
- 全课拒绝 >3 控件到达核心洞见的设计；P12/P19 控件数控制在 stage indicator/预设钮辅助下路径明确。

---

### 🔴🔴 重交互页列表（路由给 interactive-eng）
```json
["P12", "P13", "P16", "P19"]
```

---

### 🔴🔴 失败模式预防清单（强制，针对各页 pattern 推导）

#### P12 失败模式（FM）
- FM-1: 自动转圈的 setInterval/GSAP timeline 在快速翻页时仍在改 DOM（圆环还在转）→ 防御：cleanup 中 clearInterval + timeline.kill() + killTweensOf(环节点)  `// ←FM1`
- FM-2: 点"插话"时正处于 stage 切换动画中段，steering 注入与 stage 动画时序竞争导致消息飞入错误的轮 → 防御：注入前先读 currentRound 锁定 targetRound，动画 onComplete 才 append 到该轮 messages  `// ←FM2`
- FM-3: 拖进度条单步回看后点 ▶ 继续，currentStage 索引与圆环视觉态错位（进度条改了 state 但环 DOM 未同步）→ 防御：进度条 change 统一走 renderStage(idx) 单一渲染函数，禁双写  `// ←FM3`

#### P13 失败模式（FM）
- FM-1: 切换场景（无工具/流式/steering）时上一场景已点亮的事件卡与日志高亮未清 → 防御：切场景先 resetAllHighlights() 再走新场景子集  `// ←FM1`
- FM-2: 流式场景事件密集，连续高亮的 setTimeout 链未在 ⏸ 暂停时挂起 → 防御：每个 step 入口检查 pausedFlag 守卫，而非只 clearTimeout 链头  `// ←FM2`
- FM-3: TUI 日志 scrollIntoView 在 slide display:none 时算出 0 高度滚到顶 → 防御：用日志容器内 scrollTop 计算定位，禁用 scrollIntoView  `// ←FM3`

#### P16 失败模式（FM）
- FM-1: 切 profile（full↔minimal）时小球还在飞行 → 防御：切 profile 先 stopBall() + resetTrack() 再重新发射  `// ←FM1`
- FM-2: minimal 拦截 popup 用 fixed 定位，全屏切换后坐标错位 → 防御：popup 相对管线容器（position:relative 父）定位，非 viewport fixed  `// ←FM2`
- FM-3: GSAP motionPath 小球 tween 翻页未 kill → 防御：cleanup 中 gsap.killTweensOf(ball) + path tween 清理  `// ←FM3`

#### P19 失败模式（FM）
- FM-1: 拖拽 pointermove 未释放就翻页，绑在 document 上的 move/up 监听泄漏到下一页 → 防御：cleanup 中 removeEventListener(document, pointermove/pointerup)  `// ←FM1`
- FM-2: 触摸设备 pointer 与 mouse 双触发导致 knob 跳格 → 防御：统一用 pointer events + setPointerCapture，禁混用 mouse/touch 双监听  `// ←FM2`
- FM-3: 拖到轴外 knob 飞出 9 宫格 → 防御：落点 clamp 到 [0,2]×[0,2] 网格边界，越界吸附最近格  `// ←FM3`

**编号规则**：每页独立 FM-1/2/3，与 interactive-eng 的 `// ←FM{n}` 标记 1:1 对应，供 quality-guard 用 `grep -c '// ←FM'` 反查覆盖率。

---

### motion_level 约束应用
- 当前 motion_level：**high**
- high 模式：不触发任何降级，🔴🔴 与 🔴 全部保留原级。
- 已受影响的页面：**无**（high 模式无降级；若后续改为 low，则 P12/P13/P16/P19 降 🔴、P5/P15 降 🟡）。

---

### 质量自检
- [x] 所有页面 justification 非空且可证伪
- [x] 所有页面 anti_pattern_check 已填写（全 true）
- [x] 🔴🔴 页 4/23 = 17.4% ≤ 20%
- [x] 无 four_axis_score < 6 的页面（最低 P4/P10/P14/P18 = 8）
- [x] 🔴🔴 重交互页列表已单独 JSON 输出
- [x] motion_level=high，无降级要求；P12 满足 diversity_constraint（全新 pattern）
- [x] 红线核对：数据快照标注(P2)/Hermes 形态对比(P4)/10 事件 4 组(P13)/8 步管线(P16)/15 capability tool 不在内(P15)/full-off 非漏洞(P17/P19) 均在对应页 justification 或 state 要点中钉死
