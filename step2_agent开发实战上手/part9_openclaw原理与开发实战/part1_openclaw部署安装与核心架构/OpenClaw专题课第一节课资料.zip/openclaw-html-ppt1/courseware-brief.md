# OpenClaw 核心架构 · 第一节课 — HTML 课件 Brief

## creativity_level
medium

> 6 个重交互组件 + molting 蜕壳视觉母题，属"部分创新"档。methodology 18 条 + 反模式 D8 为硬约束；pattern 选用、independent-artistic 可借鉴启发。

## source_type
materials

## 元信息
- **course_title**：OpenClaw 核心架构 · 第一节课
- **源课件（权威内容来源）**：/Users/mac/PycharmProjects/JupyterProject/OpenClaw/第一节课/lesson.md（5 章约 120 分钟，已通读）
- **total_slides**：23
- **受众**：想真正搞懂 OpenClaw 架构怎么跑起来的开发者，零基础友好
- **叙事主轴**：跟随"一条真实消息的生命周期"——从发出到 agent 把活干完

## 视觉基调（designer 风格预览方向，仍生成 2-3 变体供选）
- 主色：龙虾橙红
- 背景：深海星空深色底
- 卡片：玻璃拟态（glassmorphism + backdrop-filter）
- 视觉母题：molting 蜕壳贯穿（演进/换壳/成长的隐喻）
- 动效适中、CSS-only 优先；一页一职责、视口铁律不溢出（总高 ≤ 85vh）

## 完整 23 页结构（4 段叙事弧线：被吸引 → 建立全局 → 拆解心脏与手 → 拔高哲学）

### Part 0 开场铺垫（6 页）
- P1 封面 | 封面 | 🟢 | 主标题+龙虾视觉+副标题"跟着一条消息走完 agent 的一生"+约120分钟
- P2 OpenClaw 是什么+它有多火 | 概念 | 🟡 | 一句话定义+GitHub 热度里程碑叙事+数据快照日期
- P3 三维定位 | 概念 | 🟡 | 跨渠道(20+平台 logo 墙)×跨设备×跨 model provider，三卡片悬停展开
- P4 同类对比 | 对比 | 🟡 | OpenClaw vs Claude Code vs Codex vs Hermes 四列；Hermes 标注"本地/小众 CLI"仅形态对比
- P5 四代演进·molting | 交互组件5 | 🔴 | 蜕壳时间线滑块+点 OpenClaw 触发蜕壳动效+商标邮件梗
- P6 不是什么·四条边界 | 概念 | 🟡 | 翻转卡片 误解面→正确面

### Part 1 全局地图+装机过渡（3 页）
- P7 过渡·一条消息的生命周期 | 章节过渡 | 🟡 | 主轴弧线图+5章路线图(标重心章2/3)
- P8 在你机器上跑起来 | 流程 | 🟢 | clone→pnpm install→tui --local；第一条消息触发 exec+write
- P9 Gateway 中枢 vs --local 旁路 | 概念 | 🟡 | 拓扑对照，点击切换两种模式

### Part 2 核心架构（11 页·重心）
- P10 过渡·第2章 agent 的心脏 | 章节过渡 | 🟢 | 悬念"跑到一半你能插话"
- P11 认知重塑 chatbot vs agent | 对比 | 🟡 | 慢任务场景代入+4维对照表
- P12 ⭐双层 while+steering 模拟器 | 交互组件1·灵魂页 | 🔴🔴 | 外层心跳大圈+内层 tool 循环，运行中插话飞入当前轮，可拖进度条
- P13 EventStream 10 事件流 | 交互组件2 | 🔴🔴 | 4组生命周期泳道点亮+场景切换+TUI 日志联动对账
- P14 过渡·第3章 心脏的手 | 章节过渡 | 🟢 | "模型想调工具不是想调就能调"
- P15 plugin/capability/tool 纠错图谱 | 交互组件6 | 🔴 | 可拖拽纠错+minHostVersion 门控滑块
- P16 8步工具策略管线闯关 | 交互组件3 | 🔴🔴 | 小球穿8关，切 profile 看放行/拦截
- P17 exec 默认 full/off 不是漏洞 | 概念(强调) | 🟡 | trusted-operator 护栏≠多租户隔离
- P18 过渡·第4章 安全纵深+哲学 | 章节过渡 | 🟢 | "既然 full 合理，另两档长啥样"
- P19 exec 三档×三态信任旋钮 | 交互组件4 | 🔴🔴 | 双轴旋钮 security×ask，拖动看结果反馈
- P20 Docker sandbox 分层 | 概念 | 🟡 | 叠层开关：policy 管"能调什么"/sandbox 管"在哪里调"

### Part 3 哲学收口（3 页）
- P21 信任 vs 约束 张力光谱 | 概念(轻交互) | 🟡 | 光谱滑块与 P19 联动+点名另两对张力
- P22 全课能力回顾 | 总结 | 🟢 | 5章×你现在能做什么(8件产物勾选式)
- P23 下节预告+结尾 | 结尾 | 🟢 | 多智能体×上下文工程×记忆系统，龙虾收尾

## 6 个核心交互组件
- 组件1(P12) 双层 while+steering 模拟器 = 全课灵魂页，最高优先，必须让"steering 插入当前轮而非另起会话"可视化（🔴🔴）
- 组件2(P13) EventStream 事件流时间线+TUI 联动（🔴🔴）
- 组件3(P16) 8步管线闯关（🔴🔴）
- 组件4(P19) exec 三档×三态旋钮（🔴🔴）
- 组件5(P5) molting 蜕壳时间线（🔴）
- 组件6(P15) plugin/capability/tool 纠错图谱（🔴）

## 真实事实数据（已双轨核实，必须用这些，不可编造/篡改）
- **创建者**：Peter Steinberger（PSPDFKit 创始人）；启动 2025 年 11 月；官网 openclaw.ai；仓库 github.com/openclaw/openclaw（标语 "Your own personal AI assistant. Any OS. Any Platform. The lobster way. 🦞"）
- **GitHub 热度里程碑**（数据快照 2026-03-02 GitHub API，须标注）：1/28 单日 +17,830 stars；90 天内超越 React/Linux/VS Code/TensorFlow 历史积累；2026-03-02 以 247K vs React 243K 登顶 GitHub 史上最多星项目。对比锚点：VS Code 用 10 年到 182K、React 用 13 年到 243K，OpenClaw 90 天达成
- **四代演进**：Warelay(WhatsApp 转发网关)→Clawdbot(龙虾 Clawd 入住)→Moltbot(2026-01 Anthropic 商标邮件后蜕壳改名 Molty)→OpenClaw(2026-01-30 最终定名)；正好"3 次 rebrand/4 个名字"
- **四者对比(P4)**：OpenClaw=个人 AI 助手+多渠道控制平面/常驻 Gateway 守护进程/50+ 聊天渠道入口/跨 provider/生活工作自动化(清收件箱·日历·订机票)；Claude Code=Anthropic 终端编码 agent CLI/会话式/写代码/Claude；Codex=OpenAI 终端编码 agent CLI/写代码；Hermes=本地/小众 CLI(默认 Kimi)仅作形态对比，标注"公网难验证"不给量化断言

## 事实红线（courseware 红线，违反即 BLOCK）
1. GitHub 星数用里程碑叙事+明确标注"数据快照 2026-03-02 GitHub API，实时数字更高"，禁单一不准数字
2. Hermes 仅形态对比+标注本地/小众，禁可量化能力断言
3. 所有 file:line 源码锚点直接复用 lesson.md（已核实）：agent-loop.ts:213/216/220/285/311、types.ts:410-437、tool-policy-pipeline.ts、exec-approvals.ts:24/25/205/206、inspect-shape.ts:4-19、manifest-registry.ts:1026、chat-log.ts:333
4. exec 默认 full/off "不是漏洞"框定不可讲反（trusted-operator 有意 UX）
5. EventStream 共 10 种事件分 4 组（6 主骨架）；capability 共 15 种（tool 不在其中）；管线共 8 步——这些数字不可改
6. 🔴🔴 页必过 architect + 真浏览器视觉验收
