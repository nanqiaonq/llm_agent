# HTML 课件逐页重构 · 确认设计表

> 本文件是「阶段 A 人在回路评审」的产物，作为「阶段 B html-courseware-team 执行重构」的输入规格。
> 生成方式：Opus 主对话逐页第一性原理分析 + AskUserQuestion 用户拍板。可断点续传。

## 基线决策（2026-06-02 已确认）

| 维度 | 决策 |
|------|------|
| 内容源 | lesson.md 为主（5 章），Opus 可提增删建议，用户拍板 |
| 结构基线 | 现有实际 21 页（S001-S021），最小结构变动 |
| 审美基线 | 保留 L3「浅珊瑚雾 Coral-Mist Molting」配色/字体/玻璃拟态，只改布局/交互/信息编排 |
| 推进节奏 | 一页一页：第一性原理分析 → AskUserQuestion 选交互 → 入账 → 下一页 |
| 范围 | 除封面 S001 外，S002-S021 共 20 页全部重构 |

## 逐页确认结果

### S002 ｜ OpenClaw 是什么·它有多火（🟡 hook）
- **教学 KPI**：动机转化（让学员觉得值得学），核心可视化「增速碾压」非绝对数字
- **确认方案**：D · 增长曲线赛跑（左·可播放）+ 关键里程碑逐条点亮（右）并置
- **内容要点**：一句话定义+龙虾；增长赛跑 OpenClaw 垂直 vs React/VSCode 缓爬；里程碑 启动→单日+17,830★→60天破React→376K登顶
- **硬约束**：标注「数据快照 2026-06-02 · GitHub API · 实时更高」，禁裸数字；创始人/启动日降为小字佐证
- **注意**：左右并置防 85vh 溢出

### S003 ｜ OpenClaw 三维定位（🟡 mechanism）
- **教学 KPI**：跨渠道×跨设备×跨provider 三维等权并列，防只记一维
- **确认方案**：A · 三卡等宽并列，hover 展开该维细节（跨渠道→logo墙/跨设备→OS列表/跨provider→模型列表）
- **硬约束（对齐 lesson 第0章）**：跨设备 device = 自己的多台电脑(Mac/Linux/WSL) 非 IoT；跨 provider 本节只起单 provider，不暗示多 provider 路由
- **内容要点**：三维配色权重对等，logo 墙克制别压过另两维

### S004 ｜ 四款工具横向对比（🟡 example）
- **教学 KPI**：定位切割——让学员认清 OpenClaw 不是又一个编码 CLI，而是助手+多渠道控制平面
- **确认方案**：D · 差异维度表，自动高亮「只有 OpenClaw 有」的格（多渠道/常驻GW/跨provider）
- **红线 #2（不可违反）**：Hermes 仅形态对比，标「本地/小众 CLI · 公网难验证」，难验证项标 ?，禁任何可量化能力断言
- **内容要点**：四款=OpenClaw/Claude Code/Codex/Hermes；凸显 OpenClaw 三项独有性

### S005 ｜ 四代演进·蜕壳之路（🔴 example · interactive-eng）
- **教学 KPI**：molting 隐喻「换壳但灵魂不变」可感，承载全课视觉母题
- **确认方案**：A · 横向时间线四节点+滑块拖动推进，点 OpenClaw 触发蜕壳渐变动效
- **视觉硬约束**：用 --molting-gradient（浅珊瑚→橙红）+ --molting-glow + --molting-core
- **内容要点**：四代名+各代一句话定位+Anthropic 商标邮件梗（Moltbot 蜕壳时机）+"灵魂不变"点题

### S006 ｜ OpenClaw 不是什么·四条边界（🟡 mechanism）
- **教学 KPI**：认知纠错，先承认误解再翻转，和 S003「是什么」正反呼应
- **确认方案**：D · 左误解（删除线）右正解+依据 静态两栏对照列
- **内容裁决**：采用 lesson 0.2 四条边界 —— ①不是 Skill 平台 ②不是只能连 Slack 的 bot ③device 不是 IoT ④ACP 不是自创协议（弃用旧 slide 的编码工具/SaaS/单provider/临时脚本那套）
- **内容要点**：每条正解配一句依据（README/官方包描述）

### S007 ｜ 一条消息的生命周期·全课路线图（🟡 mechanism）
- **教学 KPI**：先行组织者，建立全局视野+标重心，降低后续认知负荷
- **确认方案**：C · 地铁线路图，各章=站点，重心章(②心脏/③手)=换乘大站，当前站高亮
- **内容对齐（21页基线）**：站点按 HTML 实际覆盖：①是什么→②心脏→③手→④安全→⑤哲学，不含装机站
- **内容要点**：主轴"一条消息生命周期 发出→干完活"，"你在这里"指示器弱化

### 🔑 过渡页通则（S008/S012/S016 共用 · 用户确立）
- **主标题 = 专业技术章节主题词（忠于 lesson/源码），禁口语悬念腔**
- 副标题 = 本章脉络/要拆的核心机制预告
- 悬念/反直觉点降级为正文页内容，不占过渡页主标题
- 术语忠于源码：第2章循环准确名为 agent loop（agent-loop.ts，双层 while），无 QueryLoop

### S008 ｜ 第2章过渡·agent 运行时心脏（🟢 transition）
- **教学 KPI**：专业宣告本章主题+预告核心机制（按过渡页通则）
- **确认方案**：B · 专业主标题「第2章·agent 运行时心脏」+ 3 核心机制小标签横排（双层while循环→EventStream事件流→steering引导）
- **内容要点**：主标题忠于源码；一句"一条消息从进入到干完活的内核"

### S009 ｜ 认知重塑·chatbot vs agent（🟡 mechanism · overflow风险）
- **教学 KPI**：打破"agent=chatbot+工具"误解，为 S010 铺地基
- **确认方案**：B · 左右分屏动线对比（左 chatbot 锁死等待 / 右 agent 循环可插话），同一慢任务两边演示
- **内容裁决**：采用 lesson 4 维（交互模型/运行中插话/本质结构/插话归宿），慢任务对齐 lesson"逐行读千行文件"
- **注意**：控制 75vh 防溢出

### S010 ｜ 双层 while + steering 注入模拟器（🔴🔴 灵魂页 · interactive-eng）
- **教学 KPI（全课最高）**：steering 注入当前轮·圆环不重置·不另起会话 可见
- **确认方案**：A · 同心圆环——外层大圆环 while(true) 心跳(4 stage 节点)+内层小循环箭头(工具循环)，右侧 steering 队列，点插话消息飞入当前轮 messages，圆环不重置
- **铁律**：独立展示禁左右对比；核心洞见≤3步(发任务→插话→看飞入当前轮)
- **源码锚点**：agent-loop.ts:213/216/220/285/311
- **FM**：cleanup 清 interval/timeline；注入前锁 targetRound；进度条走单一 renderStage
- **验收**：必过 architect + 真浏览器视觉验收

### S011 ｜ EventStream·10 事件生命周期（🔴🔴 · interactive-eng）
- **教学 KPI**：每个动作↔一个事件可见；事件↔TUI 日志对账（同一数据两端）
- **确认方案**：C · 承接 S010 循环（缩小），循环每走一步从循环喷出对应事件到事件流面板，强调"事件=循环状态投影"
- **内容增强（必做）**：事件流面板保留对账维度——每个喷出事件标注「对应 TUI 渲染 chat-log.ts:333」，别丢 lesson 2.4 的事件↔日志对账
- **红线 #5**：共 10 种事件分 4 组（6 主骨架），数字不可改
- **场景**：保留 无工具/有工具/流式/steering 场景选择器走不同事件子集
- **FM**：切场景 resetAllHighlights；暂停 pausedFlag 守卫；定位用 scrollTop
- **验收**：必过 architect + 真浏览器视觉验收

### S012 ｜ 第3章过渡·工具系统（🟢 transition · 按过渡页通则）
- **确认方案**：B 形态（脉络预览）+ 主标题 A「第3章·工具系统与插件化外壳」（忠于 lesson 章名）
- **三机制标签**：plugin/capability/tool · 8步策略管线 · exec 信任边界
- **内容要点**：一句"模型发起的工具调用如何受控"

### S013 ｜ plugin/capability/tool 层级纠错（🔴 practice · molting 目标页）
- **教学 KPI**：试错内化 tool⊂plugin 唯一包含·capability 是标签非容器·破套娃误解
- **确认方案**：A · 拖拽纠错门——tool 卡池拖进 plugin/capability 容器，拖对锁定/拖错弹回抖动，+minHostVersion 滑块(版本不足灰显)
- **红线 #5**：capability 共 15 种 tool 不在其中——tool 拖进 capability 容器须判错弹回
- **视觉**：molting 渐变（本页是 molting_motif 目标页）
- **注意**：控溢出（池+容器+滑块）

### S014 ｜ 8 步工具策略管线·闯关（🔴🔴 · interactive-eng）
- **教学 KPI**：策略门控可感——8步顺序门控·纯过滤非UI审批·full全过vs minimal拦截
- **确认方案**：A · 小球沿蛇形 8 关前进，profile 切换器(full/minimal)，minimal 第1关拦截小球变红+弹原因，悬停看源码 label
- **红线 #5**：管线共 8 步不可改；纯过滤非 UI 审批(拦截=日志 blocked by before_tool_call)
- **铁律**：profile 用切换器非左右并排对比
- **源码锚点**：tool-policy-pipeline.ts 8 个 label 按序
- **FM**：切 profile 先 stopBall+resetTrack；popup 相对容器定位；cleanup killTweensOf
- **验收**：必过 architect + 真浏览器视觉验收

### S015 ｜ exec 默认 full/off 不是漏洞（🟡 mechanism·强调）
- **教学 KPI**：消除"exec 默认 full/off 是漏洞"误解，框定 trusted-operator 有意 UX
- **确认方案**：A · 强调大字 callout（"这不是漏洞"橙红描边框）+类比 sudo 本机默认可用+区分 trusted-operator UX≠多租户隔离
- **🔴 红线 #4**：不可讲反，文案禁暗示漏洞；引官方原文 docs/gateway/security/index.md:126「intentional UX, not a vulnerability」

### S016 ｜ 第4章过渡·安全纵深（🟢 transition·按过渡页通则）
- **确认方案**：B 形态（脉络预览）+ 主标题 A「第4章·安全纵深与设计哲学」（忠于 lesson 章名）
- **三机制标签**：exec 三档×三态 · Docker sandbox 分层 · 信任vs约束 张力
- **内容要点**：一句"从单个默认值到贯穿系统的取舍"

### S017 ｜ exec 三档×三态·双轴信任旋钮（🔴🔴 · interactive-eng）
- **教学 KPI**：security×ask 9 种组合的因果反馈(静默/弹审批/拒绝)可探索
- **确认方案**：A · 双轴 2D 旋钮 X=security Y=ask 3×3=9格，拖到某格右侧结果面板更新三态反馈+场景，场景预设钮(开发机/共享机/CI)
- **🔴 重大事实修正（必做）**：轴值用正确枚举 security=deny/allowlist/full（弃 read-only）、ask=off/on-miss/always（弃 on-write）
- **红线 #4**：结果面板文案不得暗示漏洞；full/off 框定 trusted-operator 有意 UX
- **源码锚点**：exec-approvals.ts:24/25(类型)/205/206(默认)
- **FM**：cleanup removeEventListener；统一 pointer events+setPointerCapture；落点 clamp
- **验收**：必过 architect + 真浏览器视觉验收

### S018 ｜ Docker sandbox 分层·policy vs sandbox（🟡 mechanism）
- **教学 KPI**：policy(能调什么) 与 sandbox(在哪调) 两层正交互补
- **确认方案**：A · 叠层开关——policy 层(上)+sandbox 层(下)各独立开关，切换看组合
- **内容要点**：两层正交；sandbox 默认非全开(main 直接宿主跑，sandbox 给非 main 会话需显式开启)
- **源码锚点**：zod-schema.agent-runtime.ts:175(capDrop)/202(seccomp)/173(network)/206(binds)；拒绝 seccomp unconfined(235)/network host(223)

### S019 ｜ 信任与约束的张力光谱（🟡 summary·轻交互）
- **教学 KPI**：把安全哲学落到可拖连续谱，升华为设计原则
- **确认方案**：C · 天平可视化——左信任右约束拖动看平衡点，各档(full/allowlist/deny/sandbox)落点标注，与 S017 旋钮联动
- **内容裁决**：另两对张力采用 lesson 4.3 的「集中vs分治(第三节课)」「静态vs动态(后续)」，弃 slide 旧的"自主性vs可控性/效率vs审计"
- **内容要点**：信任vs约束深讲；无绝对正确位置·只有匹配场景

### S020 ｜ 全课能力回顾·勾选式能力清单（🟢 summary·轻交互）
- **教学 KPI**：用勾选清单把抽象架构落到"我现在能做 X"的具体能力陈述，强化成就感
- **确认方案**：A · 勾选式能力清单（静态呈现为主，勾选动效可选）
- **🔴 诚实裁决（必做）**：能力清单只列 HTML 实际讲过的能力，剔除装机②/Gateway 路径③——HTML 21 页**未独立教学装机/Gateway**（grep 实证：装机/--local 仅出现在 S002-S006 的对比语境，非教学页）。slide_structure 的"5章×8件"是 IA 旧表述（IA 描述的是 23 页旧结构，已 STALE），红线 #5 在本次按-HTML-实际-覆盖重构后失效
- **重组分组**（按 HTML 实际五簇，替代旧的"5章×8件"）：
  1. **是什么** — 说清 OpenClaw 与 Claude Code/Codex/Hermes 的核心差异 + 三维定位 + 边界（不是什么）
  2. **心脏** — 口述双层 while 循环结构 + EventStream 10 事件分 4 组生命周期 + steering 注入当前轮机制
  3. **手** — 解释 plugin/capability/tool 三层关系（tool⊂plugin 唯一包含·capability 是标签）+ 8 步工具策略管线
  4. **安全** — 判断 exec full/off 的使用场景（不再误解为漏洞）+ 用 security×ask 双轴为场景选配置
  5. **哲学** — 用信任vs约束张力谱思考"没有绝对正确·只有匹配场景"
- **视觉**：静态清单卡片，每簇一组勾选项；成就感导向

### S021 ｜ 结尾页·蜕壳进度收尾（🟢 summary·轻交互·叙事闭环）
- **教学 KPI**：用 molting 蜕壳母题完成叙事闭环（呼应封面"agent 的一生"），激发对下节的期待
- **确认方案**：A · 蜕壳进度收尾——龙虾🦞 molting 母题贯穿，把课程进度具象成蜕壳生命周期
- **结构**：
  1. 顶部：🦞 + "你蜕了第一层壳"
  2. 蜕壳进度轴：第一壳✓「核心架构」（是什么·心脏·手·安全·哲学）已点亮 → 第二壳「下节」虚线待解锁
  3. 下一层壳三张待解锁卡片（虚线/灰态呼应"下节"）：① 多智能体协作（多 OpenClaw 实例协同）② 上下文工程（设计 agent 记忆窗口）③ 记忆系统（跨会话长期记忆）
  4. 底部：⭐ github.com/openclaw/openclaw ·🌐 openclaw.ai
- **叙事呼应**：封面 S001 龙虾视觉 + "跟着一条消息走完 agent 的一生" → 结尾"蜕了一层壳"形成闭环
- **视觉**：molting 渐变（--molting-gradient）；三卡虚线态区分"已学/待学"；静态无交互

---

## 阶段 A 完成（2026-06-02）
- S002–S021 共 20 页全部逐页第一性原理评审 + AskUserQuestion 拍板完成，封面 S001 保留不动
- 下一步：阶段 B 用 /html-courseware-team 按本规格执行重构
