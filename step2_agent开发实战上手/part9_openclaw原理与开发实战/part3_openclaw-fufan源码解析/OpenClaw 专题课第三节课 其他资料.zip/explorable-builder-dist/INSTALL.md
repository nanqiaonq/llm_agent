# Explorable Builder · 安装包

把"过程/系统/模型"类编程概念，一键生成为单页可交互 HTML Explorable（拖一下，自己试出结论）。

## 这个包里有什么

| 文件 | 说明 |
|---|---|
| `explorable-builder-v3.2.zip` | skill 主体（21 个文件，完全自包含，零外部硬依赖） |
| `install.sh` | 一键安装脚本 |
| `INSTALL.md` | 本说明 |

## 安装（任选一种）

**方式一：一键脚本（推荐）**

```bash
bash install.sh
```

**方式二：手动解压**

```bash
mkdir -p ~/.claude/skills
unzip -o explorable-builder-v3.2.zip -d ~/.claude/skills/
```

两种方式都会把 skill 装到 `~/.claude/skills/explorable-builder/`。

## 验证安装成功

```bash
ls ~/.claude/skills/explorable-builder/SKILL.md   # 能列出即成功
```

然后**重启 Claude Code**（或新开一个会话），在主对话输入 `/explorable-builder` 或 `/eb` 即可触发。

## 第一次用先看 5 个范例

```bash
# macOS
open ~/.claude/skills/explorable-builder/assets/starter-templates/01-segment-coloring.html
# Linux
xdg-open ~/.claude/skills/explorable-builder/assets/starter-templates/01-segment-coloring.html
```

拖一下这 5 个 demo，先建立"可交互教学"的直觉，再开始做自己的主题。

## 可选增强（不装也能用）

Phase 5 的自动验证依赖 Playwright，**不装会自动降级为软门控，不影响核心生成**：

```bash
npm i -g playwright && npx playwright install chromium
```

## 完整使用文档

装好后见 `~/.claude/skills/explorable-builder/QUICK-START.md`（8 阶段流程、进阶模式、常见问题全在里面）。

## 环境要求

- Claude Code（任意近期版本）
- 可选：Node.js + Playwright（仅自动验证用）
- 平台：macOS / Linux（Windows 用 WSL）
