#!/bin/bash
# Explorable Builder · 一键安装脚本
# 用法：bash install.sh
# 作用：把 explorable-builder skill 解压安装到 ~/.claude/skills/
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ZIP="$HERE/explorable-builder-v3.2.zip"
DEST="$HOME/.claude/skills"

if [ ! -f "$ZIP" ]; then
  echo "[ERROR] 找不到 $ZIP，请确认与 install.sh 在同一目录"
  exit 1
fi

if ! command -v unzip >/dev/null 2>&1; then
  echo "[ERROR] 系统缺少 unzip，请先安装（mac: brew install unzip / linux: apt install unzip）"
  exit 1
fi

mkdir -p "$DEST"
unzip -o "$ZIP" -d "$DEST" >/dev/null

if [ -f "$DEST/explorable-builder/SKILL.md" ]; then
  echo "[OK] 已安装到 $DEST/explorable-builder"
  echo "[NEXT] 在 Claude Code 主对话输入 /explorable-builder 或 /eb 即可使用"
  echo "[DEMO] 先看 5 个范例："
  echo "       open $DEST/explorable-builder/assets/starter-templates/01-segment-coloring.html"
else
  echo "[ERROR] 解压后未找到 SKILL.md，安装可能失败"
  exit 1
fi
