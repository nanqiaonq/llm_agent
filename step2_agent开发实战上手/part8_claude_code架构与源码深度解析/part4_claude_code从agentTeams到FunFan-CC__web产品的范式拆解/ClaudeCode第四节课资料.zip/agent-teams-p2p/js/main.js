/**
 * Agent Teams P2P -- HTML 课件主控制器
 * 复用第三节课 cc-multiagent-ppt 骨架
 * 负责：slide 导航、侧边菜单、画笔轨迹(T)、画板(D)、颜色选择器、快捷键
 */

(function () {
  'use strict';

  /* ===== 配置：8 页 ===== */
  var slideFiles = [
    'slides/S001-hub-spoke-to-p2p.html',
    'slides/S002-six-tools-overview.html',
    'slides/S003-sendmessage-vs-coordinator.html',
    'slides/S004-mailbox-filesystem.html',
    'slides/S005-tasklist-kanban.html',
    'slides/S006-backends-identity.html',
    'slides/S007-observable-p2p-simulation.html',
    'slides/S008-tension-upgrade-summary.html'
  ];

  var slideTitles = [
    '从 Hub-Spoke 到 P2P Mesh',
    '6 个工具全景',
    'SendMessage vs Coordinator 寻址',
    'Mailbox 文件系统邮箱',
    'TaskList 分布式协调',
    '三种后端 + 身份系统',
    'Observable P2P 完整运行模拟',
    '四对张力升级 + 总结'
  ];

  var chapters = [
    { title: '认知动力', start: 0, end: 0 },
    { title: '工具全景', start: 1, end: 1 },
    { title: '通信层', start: 2, end: 3 },
    { title: '协调层', start: 4, end: 4 },
    { title: '基础设施层', start: 5, end: 5 },
    { title: '综合运行', start: 6, end: 6 },
    { title: '认知升级', start: 7, end: 7 }
  ];

  var totalSlides = slideFiles.length;
  var currentIndex = 0;
  var slideCache = {};
  var currentCleanup = null;
  var menuOpen = false;
  var drawBoardEnabled = false;
  var drawCtx = null;
  var isDrawing = false;
  var currentDrawColor = '#5a8a8a';
  var colorPickerOpen = false;

  /* ===== loadSlide ===== */
  async function loadSlide(n) {
    if (n < 0 || n >= totalSlides) return;

    if (typeof currentCleanup === 'function') {
      try { currentCleanup(); } catch (e) { /* ignore */ }
    }
    currentCleanup = null;

    currentIndex = n;
    updateProgressBar();
    updatePageIndicator();
    updateMenuActiveState();
    updateHash();

    var file = slideFiles[n];
    var html;

    if (slideCache[file]) {
      html = slideCache[file];
    } else {
      try {
        var resp = await fetch(file);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        html = await resp.text();
        slideCache[file] = html;
      } catch (e) {
        html = '<div style="text-align:center;padding:4rem;color:var(--text-dim);">Loading ' + file + '</div>';
        slideCache[file] = html;
      }
    }

    var viewport = document.getElementById('slide-viewport');
    var slideId = file.replace('slides/', '').replace('.html', '').split('-')[0];
    viewport.innerHTML = '<div class="slide active" id="' + slideId + '">' + html + '</div>';

    var scripts = viewport.querySelectorAll('script');
    scripts.forEach(function(oldScript) {
      var newScript = document.createElement('script');
      if (oldScript.src) {
        newScript.src = oldScript.src;
        newScript.async = false;
      } else {
        newScript.textContent = oldScript.textContent;
      }
      oldScript.parentNode.replaceChild(newScript, oldScript);
    });

    if (window.slideHooks) {
      var hookFn = window.slideHooks[file];
      if (typeof hookFn === 'function') {
        setTimeout(function() {
          try {
            var cleanup = hookFn();
            if (typeof cleanup === 'function') currentCleanup = cleanup;
          } catch (e) { console.warn('slideHook error:', e); }
        }, 8);
      }
    }

    setTimeout(function() {
      var els = document.querySelectorAll('.animate-ready');
      els.forEach(function(el) {
        var delay = parseFloat(el.getAttribute('data-delay') || '0');
        setTimeout(function() { el.classList.add('animated'); }, delay * 1000);
      });
    }, 8);

    [n - 1, n + 1].forEach(function(i) {
      if (i >= 0 && i < totalSlides && !slideCache[slideFiles[i]]) {
        fetch(slideFiles[i]).then(function(r) { return r.ok ? r.text() : ''; }).then(function(t) {
          if (t) slideCache[slideFiles[i]] = t;
        }).catch(function() {});
      }
    });

    var prev = document.getElementById('nav-prev');
    var next = document.getElementById('nav-next');
    if (prev) prev.disabled = n === 0;
    if (next) next.disabled = n === totalSlides - 1;
  }

  /* ===== Progress & Page ===== */
  function updateProgressBar() {
    var pct = totalSlides > 1 ? (currentIndex / (totalSlides - 1)) * 100 : 100;
    var bar = document.getElementById('progressFill');
    if (bar) bar.style.width = Math.max(4, pct) + '%';
  }

  function updatePageIndicator() {
    var el = document.getElementById('pageIndicator');
    if (el) el.textContent = (currentIndex + 1) + ' / ' + totalSlides;
  }

  function updateHash() {
    history.replaceState(null, '', '#' + (currentIndex + 1));
  }

  function readHash() {
    var hash = location.hash.replace('#', '');
    var num = parseInt(hash, 10);
    if (num >= 1 && num <= totalSlides) return num - 1;
    return 0;
  }

  /* ===== Navigation ===== */
  function prevSlide() { if (currentIndex > 0) loadSlide(currentIndex - 1); }
  function nextSlide() { if (currentIndex < totalSlides - 1) loadSlide(currentIndex + 1); }
  function goToSlide(n) { if (n >= 0 && n < totalSlides) loadSlide(n); }

  /* ===== Fullscreen ===== */
  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen && document.exitFullscreen();
    }
  }

  /* ===== Sidebar Menu ===== */
  function buildMenu() {
    var list = document.getElementById('menuItems');
    if (!list) return;
    list.innerHTML = '';

    chapters.forEach(function(ch) {
      var chEl = document.createElement('div');
      chEl.className = 'menu-chapter';
      chEl.textContent = ch.title;
      list.appendChild(chEl);

      for (var i = ch.start; i <= ch.end; i++) {
        (function(idx) {
          var item = document.createElement('div');
          item.className = 'menu-item';
          item.setAttribute('data-index', idx);
          item.innerHTML = '<span class="menu-item-num">' + String(idx + 1).padStart(2, '0') + '</span>' +
            '<span>' + slideTitles[idx] + '</span>';
          item.onclick = function() { goToSlide(idx); closeMenu(); };
          list.appendChild(item);
        })(i);
      }
    });
  }

  function updateMenuActiveState() {
    var items = document.querySelectorAll('.menu-item');
    items.forEach(function(item) {
      var idx = parseInt(item.getAttribute('data-index'));
      item.classList.toggle('active', idx === currentIndex);
    });
  }

  function toggleMenu() { menuOpen ? closeMenu() : openMenu(); }

  function openMenu() {
    menuOpen = true;
    var menu = document.getElementById('sidebarMenu');
    var overlay = document.getElementById('menuOverlay');
    if (menu) menu.classList.add('open');
    if (overlay) overlay.classList.add('open');
    updateMenuActiveState();
  }

  function closeMenu() {
    menuOpen = false;
    var menu = document.getElementById('sidebarMenu');
    var overlay = document.getElementById('menuOverlay');
    if (menu) menu.classList.remove('open');
    if (overlay) overlay.classList.remove('open');
  }

  /* ===== Pen Trail (T) -- FADE_MS=1200 ===== */
  var _pen = {
    active: false, canvas: null, ctx: null, drawing: false,
    points: [], trails: [], rafId: null, FADE_MS: 1200, LINE_WIDTH: 3
  };

  function initPenTrail() {
    var canvas = document.getElementById('pen-trail-canvas');
    if (!canvas) return;
    _pen.canvas = canvas;
    _pen.ctx = canvas.getContext('2d');

    function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
    resize();
    window.addEventListener('resize', resize);

    canvas.addEventListener('mousedown', function(e) {
      _pen.drawing = true;
      _pen.points = [{x: e.clientX, y: e.clientY, t: Date.now()}];
    });
    canvas.addEventListener('mousemove', function(e) {
      if (!_pen.drawing) return;
      _pen.points.push({x: e.clientX, y: e.clientY, t: Date.now()});
      penRender();
    });
    canvas.addEventListener('mouseup', penUp);
    canvas.addEventListener('mouseleave', penUp);

    canvas.addEventListener('touchstart', function(e) {
      e.preventDefault();
      var t = e.touches[0];
      _pen.drawing = true;
      _pen.points = [{x: t.clientX, y: t.clientY, t: Date.now()}];
    }, {passive: false});
    canvas.addEventListener('touchmove', function(e) {
      e.preventDefault();
      if (!_pen.drawing) return;
      var t = e.touches[0];
      _pen.points.push({x: t.clientX, y: t.clientY, t: Date.now()});
      penRender();
    }, {passive: false});
    canvas.addEventListener('touchend', function(e) { e.preventDefault(); penUp(); }, {passive: false});
  }

  function penUp() {
    if (!_pen.drawing) return;
    _pen.drawing = false;
    if (_pen.points.length > 1) {
      _pen.trails.push({ points: _pen.points.slice(), startTime: Date.now() });
    }
    _pen.points = [];
    if (_pen.active) animatePenTrail();
  }

  function penRender() {
    var ctx = _pen.ctx, canvas = _pen.canvas;
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    var now = Date.now();
    _pen.trails = _pen.trails.filter(function(trail) { return now - trail.startTime < _pen.FADE_MS; });
    _pen.trails.forEach(function(trail) {
      var alpha = Math.max(0, 1 - (now - trail.startTime) / _pen.FADE_MS);
      penDrawPath(ctx, trail.points, alpha * 0.7);
    });
    if (_pen.points.length > 1) penDrawPath(ctx, _pen.points, 1);
  }

  function penDrawPath(ctx, points, alpha) {
    if (points.length < 2) return;
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (var i = 1; i < points.length; i++) {
      var prev = points[i-1], curr = points[i];
      var mx = (prev.x + curr.x) / 2, my = (prev.y + curr.y) / 2;
      ctx.quadraticCurveTo(prev.x, prev.y, mx, my);
    }
    ctx.lineTo(points[points.length-1].x, points[points.length-1].y);
    ctx.strokeStyle = hexToRgba(currentDrawColor, alpha);
    ctx.lineWidth = _pen.LINE_WIDTH;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  function hexToRgba(hex, alpha) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    var r = parseInt(hex.substring(0,2), 16);
    var g = parseInt(hex.substring(2,4), 16);
    var b = parseInt(hex.substring(4,6), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
  }

  function togglePenTrail() {
    _pen.active = !_pen.active;
    var canvas = document.getElementById('pen-trail-canvas');
    var btn = document.getElementById('btn-pen');
    if (_pen.active) {
      if (canvas) canvas.classList.add('pen-active');
      if (btn) btn.classList.add('active');
      animatePenTrail();
    } else {
      if (canvas) canvas.classList.remove('pen-active');
      if (btn) btn.classList.remove('active');
      if (_pen.rafId) cancelAnimationFrame(_pen.rafId);
      _pen.rafId = null;
      if (_pen.ctx && canvas) _pen.ctx.clearRect(0, 0, canvas.width, canvas.height);
      _pen.trails = [];
      _pen.points = [];
    }
  }

  function animatePenTrail() {
    if (!_pen.active) return;
    penRender();
    if (_pen.trails.length > 0 || _pen.drawing) {
      _pen.rafId = requestAnimationFrame(animatePenTrail);
    } else {
      _pen.rafId = null;
    }
  }

  /* ===== Draw Board (D) ===== */
  function initDrawBoard() {
    var canvas = document.getElementById('draw-board-canvas');
    if (!canvas) return;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    drawCtx = canvas.getContext('2d');
    window.addEventListener('resize', function() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    });

    canvas.addEventListener('mousedown', function(e) {
      if (!drawBoardEnabled) return;
      isDrawing = true;
      drawCtx.beginPath();
      drawCtx.moveTo(e.clientX, e.clientY);
    });
    canvas.addEventListener('mousemove', function(e) {
      if (!isDrawing) return;
      drawCtx.lineTo(e.clientX, e.clientY);
      drawCtx.strokeStyle = currentDrawColor;
      drawCtx.lineWidth = 3;
      drawCtx.lineCap = 'round';
      drawCtx.lineJoin = 'round';
      drawCtx.stroke();
    });
    canvas.addEventListener('mouseup', function() { isDrawing = false; });
    canvas.addEventListener('mouseleave', function() { isDrawing = false; });
  }

  function toggleDrawBoard() {
    drawBoardEnabled = !drawBoardEnabled;
    var canvas = document.getElementById('draw-board-canvas');
    var btn = document.getElementById('btn-draw');
    if (!canvas) return;
    if (drawBoardEnabled) {
      canvas.style.pointerEvents = 'all';
      canvas.style.cursor = 'crosshair';
      document.body.classList.add('draw-mode');
      if (btn) btn.classList.add('active');
    } else {
      clearDrawBoard();
    }
  }

  function clearDrawBoard() {
    drawBoardEnabled = false;
    isDrawing = false;
    var canvas = document.getElementById('draw-board-canvas');
    var btn = document.getElementById('btn-draw');
    if (canvas && drawCtx) {
      drawCtx.clearRect(0, 0, canvas.width, canvas.height);
      canvas.style.pointerEvents = 'none';
      canvas.style.cursor = 'default';
    }
    document.body.classList.remove('draw-mode');
    if (btn) btn.classList.remove('active');
  }

  /* ===== Color Picker ===== */
  function setDrawColor(hex) {
    currentDrawColor = hex;
    var dot = document.getElementById('color-dot-indicator');
    if (dot) dot.style.background = hex;
    document.querySelectorAll('#color-picker-popup .color-dot').forEach(function(btn) {
      btn.classList.toggle('selected', btn.dataset.color === hex);
    });
    closeColorPicker();
  }

  function toggleColorPicker() {
    colorPickerOpen = !colorPickerOpen;
    var popup = document.getElementById('color-picker-popup');
    if (popup) popup.classList.toggle('open', colorPickerOpen);
  }

  function closeColorPicker() {
    colorPickerOpen = false;
    var popup = document.getElementById('color-picker-popup');
    if (popup) popup.classList.remove('open');
  }

  /* ===== Keyboard ===== */
  document.addEventListener('keydown', function(e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    switch (e.key) {
      case 'ArrowLeft': case 'ArrowUp':
        e.preventDefault(); prevSlide(); break;
      case 'ArrowRight': case 'ArrowDown': case ' ':
        e.preventDefault(); nextSlide(); break;
      case 'Home': e.preventDefault(); goToSlide(0); break;
      case 'End': e.preventDefault(); goToSlide(totalSlides - 1); break;
      case 'Escape':
        if (drawBoardEnabled) { clearDrawBoard(); break; }
        if (_pen.active) { togglePenTrail(); break; }
        if (menuOpen) closeMenu();
        break;
      case 'f': case 'F':
        if (!e.metaKey && !e.ctrlKey) { e.preventDefault(); toggleFullscreen(); }
        break;
      case 'm': case 'M':
        if (!e.metaKey && !e.ctrlKey) { e.preventDefault(); toggleMenu(); }
        break;
      case 't': case 'T': togglePenTrail(); break;
      case 'd': case 'D': toggleDrawBoard(); break;
    }
  });

  /* ===== Touch Swipe ===== */
  var touchStartX = 0, touchStartY = 0;
  document.addEventListener('touchstart', function(e) {
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
  }, { passive: true });
  document.addEventListener('touchend', function(e) {
    var dx = e.changedTouches[0].clientX - touchStartX;
    var dy = e.changedTouches[0].clientY - touchStartY;
    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 50) {
      if (dx < 0) nextSlide(); else prevSlide();
    }
  }, { passive: true });

  /* ===== Stars ===== */
  function generateStars() {
    var bg = document.getElementById('starsBg');
    if (!bg) return;
    for (var i = 0; i < 80; i++) {
      var s = document.createElement('div');
      s.className = 'star';
      s.style.cssText = 'left:' + (Math.random()*100) + '%;top:' + (Math.random()*100) + '%;animation-delay:' + (Math.random()*3) + 's;animation-duration:' + (2+Math.random()*2) + 's;';
      bg.appendChild(s);
    }
  }

  /* ===== Global API ===== */
  window.__nextSlide = nextSlide;
  window.__prevSlide = prevSlide;
  window.__goSlide = function(i) { closeMenu(); goToSlide(i); };
  window.__toggleMenu = toggleMenu;
  window.__closeMenu = closeMenu;
  window.__toggleFullscreen = toggleFullscreen;
  window.__togglePenTrail = togglePenTrail;
  window.__toggleDrawBoard = toggleDrawBoard;
  window.__toggleColorPicker = toggleColorPicker;
  window.__setDrawColor = setDrawColor;

  /* CC namespace for programmatic navigation (SPA hash probe compatible) */
  window.CC = {
    goTo: function(n) { goToSlide(n); },
    getSlideCount: function() { return totalSlides; },
    getCurrentIndex: function() { return currentIndex; }
  };

  /* ===== Init ===== */
  document.addEventListener('DOMContentLoaded', function() {
    generateStars();
    buildMenu();
    initPenTrail();
    initDrawBoard();
    var dot = document.getElementById('color-dot-indicator');
    if (dot) dot.style.background = currentDrawColor;
    document.addEventListener('click', function(e) {
      if (colorPickerOpen && !e.target.closest('#color-picker-wrap')) closeColorPicker();
    });
    var startSlide = readHash();
    loadSlide(startSlide);
  });

})();
