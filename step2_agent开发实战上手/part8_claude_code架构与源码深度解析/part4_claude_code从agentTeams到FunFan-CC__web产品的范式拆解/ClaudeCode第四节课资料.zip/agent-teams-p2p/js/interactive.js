/**
 * Agent Teams P2P -- Interactive Hooks Registry
 * slideHooks: { 'slides/S00X-xxx.html': function() { ... return cleanup; } }
 * red-red pages (S005, S007) will register their hooks here
 */

window.slideHooks = window.slideHooks || {};
