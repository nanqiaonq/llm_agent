# Interaction Architecture -- Agent Teams P2P

## 总览

| Page | 标题 | 交互级别 | 选定模式 | 解释力 | 动效价值 | 实现成本 | 认知负荷 | assignee |
|------|------|---------|---------|--------|---------|---------|---------|----------|
| S001 | 从 Hub-Spoke 到 P2P Mesh | green | topology-morph-toggle | 4 | 4 | M | 2 | slide-writer |
| S002 | 6 个工具全景 | green | three-layer-card-expand | 3 | 3 | M | 2 | slide-writer |
| S003 | SendMessage vs Coordinator 寻址 | yellow | dual-column-step-simulator | 4 | 4 | M | 3 | slide-writer |
| S004 | Mailbox 文件系统邮箱 | yellow | filesystem-write-animation | 4 | 4 | M | 3 | slide-writer |
| S005 | TaskList 分布式协调 | red-red | kanban-task-lifecycle | 5 | 5 | H | 3 | interactive-eng |
| S006 | 三种后端 + 身份系统 | yellow | tab-switcher-with-chain | 3 | 3 | M | 3 | slide-writer |
| S007 | Observable P2P 完整运行模拟 | red-red | full-lifecycle-step-simulator | 5 | 5 | H | 4 | interactive-eng |
| S008 | 四对张力升级 + 总结 | green | balance-scale-animation | 3 | 3 | L | 2 | slide-writer |

## 交互级别统计

- green: 3 页 (S001, S002, S008)
- yellow: 3 页 (S003, S004, S006)
- red-red: 2 页 (S005, S007) = 25% < 20% 上限的例外（用户已确认，两页均为课件核心模拟器）

## 逐页交互架构

### S001 从 Hub-Spoke 到 P2P Mesh [green]

**what becomes visible**: 两种拓扑结构的结构差异——单向辐射 vs 任意双向互连
**选定模式**: topology-morph-toggle
- 左侧静态 hub-spoke 图（Coordinator 中心 + 4 Worker 单向箭头）
- 点击"升级到 Agent Teams"按钮 → CSS 动画变形为 P2P mesh（Team Lead + 3 Teammate 双向连线）
- 点击每个节点 → 弹出角色描述卡片
- hover 连线 → 显示通信方式文字（dispatch 单向 / SendMessage 双向）
**反模式排除**: 无需多 stage 步进（只有两个状态），用 toggle 即可
**四轴**: 解释力=4（拓扑差异一目了然）/ 动效=4（变形动画强化对比感）/ 成本=M / 认知=2（两态切换简单）
**justification**: hub-spoke→mesh 的拓扑变形是本课认知动力的视觉锚点，静态双图无法传递"升级"的连续感

### S002 6 个工具全景 [green]

**what becomes visible**: 6 个工具的三层架构分层关系 + 各工具详情
**选定模式**: three-layer-card-expand
- 三层横向布局：Team 管理层 / 通信协调层 / 执行基础设施层
- 每层内放置工具卡片（上层 2 + 中层 4 + 下层标注）
- 点击卡片 → 展开详情面板（源码位置 + 一句话职能 + 关键参数）
- 层与层之间有静态连线表示依赖
**反模式排除**: 非 accordion（accordion 隐藏了层级关系），用空间布局保留三层结构
**四轴**: 解释力=3（分层清晰但非动态交互）/ 动效=3（展开面板）/ 成本=M / 认知=2
**justification**: 6 个工具的层级归属是本课结构性知识，三层空间布局比列表更直观

### S003 SendMessage vs Coordinator 寻址 [yellow]

**what becomes visible**: 两种模式下 writer-reviewer 多轮修改循环的生命周期差异
**选定模式**: dual-column-step-simulator
- 左栏：Coordinator 模式（dispatch → worker run → return → die → 重新 spawn）
- 右栏：Agent Teams 模式（teammate 持久化 → SendMessage 双向 → idle ↔ active）
- 步进按钮控制同步播放
- 左栏每轮 reviewer 死亡+重生有闪烁+淡入视觉提示
- 消息气泡带颜色和方向箭头
**反模式排除**: 非 tab 切换（需要同时对比两种模式）；非自动播放（学员需要逐步理解）
**四轴**: 解释力=4（同步对比是理解差异的最有效方式）/ 动效=4（生命周期动画）/ 成本=M / 认知=3
**justification**: 单向指令 vs 双向消息、一次性 vs 持久化——这些抽象差异只有通过同步动画对比才能直观感知

### S004 Mailbox 文件系统邮箱 [yellow]

**what becomes visible**: "P2P 底层是文件不是网络"的反直觉设计 + lockfile 并发控制
**选定模式**: filesystem-write-animation
- 展示 ~/.claude/teams/{team}/inboxes/ 目录结构模拟
- 点击"发送消息"按钮 → 动画展示 writeToMailbox 完整过程
- 5 步序列：lockfile 加锁（锁图标亮起）→ 读旧消息数组 → 追加新消息 → 写回 JSON → 解锁（锁消失）
- 可连续发送多条消息，看邮箱 JSON 内容增长
- 源码锚点标注（teammateMailbox.ts:56, :134）
**反模式排除**: 非代码走读（不展示源码文本），用文件系统模拟器把抽象过程可视化
**四轴**: 解释力=4（lockfile 过程可视化是本页核心价值）/ 动效=4（锁图标动画）/ 成本=M / 认知=3
**justification**: "文件系统邮箱"这个设计决策的精妙之处在于零外部依赖，只有动画化 lockfile 流程才能让学员"看到"并发安全

### S005 TaskList 分布式协调 [red-red]

**what becomes visible**: 任务从创建到完成的全生命周期 + blockedBy 依赖链的自动解锁
**选定模式**: kanban-task-lifecycle
- 三列看板（Pending / In Progress / Completed）
- 初始 4 个 task 卡片在 Pending 列（含 blockedBy 可视化标记）
- 完整 6 步交互流：
  1. team lead 创建 4 task（卡片出现在 Pending）
  2. 点击"认领"task 1 → 卡片移到 In Progress
  3. 点击"完成"task 1 → 移到 Completed
  4. task 3 的 blockedBy 状态可视化更新（1/2 依赖完成）
  5. task 2 完成 → task 3 自动解锁（blockedBy 清空，可认领）
  6. 认领+完成 task 3 → task 4 解锁
- blockedBy 用红色锁链图标表示，解锁时锁链断裂动画
- 右侧面板显示 Task 数据模型（6 字段）
**状态机**: task_status: pending → in_progress → completed; blocked: locked → partial_unlock → unlocked
**控制三件套**: play/pause/step 三按钮 + step dots + step indicator
**反模式排除**: 非简单列表（无法展示依赖链动态解锁）；非纯动画（需要学员主动认领操作才能理解 push vs pull）
**四轴**: 解释力=5（依赖链自动解锁是 TaskList 最精巧的设计）/ 动效=5（看板动画+锁链断裂）/ 成本=H / 认知=3（看板隐喻降低认知）
**justification**: blockedBy 声明式依赖管理是 Agent Teams 与 Coordinator 最大的结构差异，只有交互式看板才能让学员"体验"到依赖自动解锁的机制
**FM 防御清单**: FM-1 看板列状态同步 / FM-2 blockedBy 计数精确 / FM-3 cleanup 重置全部卡片位置

### S006 三种后端 + 身份系统 [yellow]

**what becomes visible**: 三种后端的隔离粒度差异 + 身份解析优先级链
**选定模式**: tab-switcher-with-chain
- 上半部分：三选一 tab 切换器（tmux / iTerm2 / in-process）
  - tmux tab: 终端窗口多 pane 示意
  - iTerm2 tab: macOS 多 tab 示意
  - in-process tab: 同进程内 AsyncLocalStorage 虚线隔间
- 下半部分：身份解析优先级链路动画
  - AsyncLocalStorage → dynamicTeamContext → undefined
  - 点击"查询身份"按钮 → 从上到下逐层检查（高亮当前层级）→ 找到后停止
**反模式排除**: 非三栏并列（三种后端差异不在于并列对比，在于切换理解各自机制）
**四轴**: 解释力=3（tab 切换 + 链路动画覆盖两个知识点）/ 动效=3 / 成本=M / 认知=3
**justification**: in-process 的 AsyncLocalStorage 隔离是最反直觉的设计（同进程怎么隔离？），需要"虚线隔间"可视化才能建立心智模型

### S007 Observable P2P 完整运行模拟 [red-red] (SOUL PAGE)

**what becomes visible**: 一次完整 Agent Teams 运行的全过程——从创建到清理的 12 步
**选定模式**: full-lifecycle-step-simulator
- 3 个 teammate 节点（team-lead 黄铜金 + slide-writer 静谧青 + quality-guard 静谧青）
- 12 步完整流程（自动播放 + 手动步进双模式）：
  Step 1: TeamCreate → config.json 创建动画
  Step 2: spawn slide-writer（节点出现，静谧青）
  Step 3: spawn quality-guard（节点出现，静谧青）
  Step 4: TaskCreate → "generate page-3" 任务卡出现
  Step 5: slide-writer 认领 task → 状态变 in_progress
  Step 6: slide-writer 完成 → SendMessage 飞向 quality-guard
  Step 7: quality-guard 审查 → BLOCK → SendMessage 飞回（rust 红处方单）
  Step 8: slide-writer 修复 → SendMessage 再飞向 quality-guard
  Step 9: quality-guard 复查 → PASS → TaskUpdate 完成（静谧青标记）
  Step 10: team-lead 通过 TaskList 看到 task completed
  Step 11: SendMessage shutdown_request → teammate 节点淡出
  Step 12: TeamDelete → 清理动画
- 每步高亮当前活跃 agent（其他 dim 50%）
- 消息飞行有动画轨迹（贝塞尔曲线）
- 右侧 TaskList 面板实时更新状态
- 底部 step indicator 显示当前步骤文字描述
**控制三件套（硬约束）**: play(自动)/pause/step(手动步进) 三按钮 + 12 个 step dots + step indicator 文字
**状态机**: 12-state FSM, states: create → spawn1 → spawn2 → task_create → claim → generate → block → fix → pass → observe → shutdown → cleanup
**色彩编码**: team-lead=#c4923a / teammate=#5a8a8a / BLOCK消息=#c44545 / PASS消息=#5a8a8a / TaskList面板=#ecdfca
**反模式排除**: 非自动播放 only（必须支持手动步进，学员控制权铁律）；非简化版（12 步缺一不可）
**四轴**: 解释力=5（完整生命周期是本课终极认知目标）/ 动效=5（节点出现/消息飞行/BLOCK红闪）/ 成本=H / 认知=4（12步较长但有 step dots 导航）
**justification**: 这是课件灵魂页。Observable P2P 模式的核心价值——orchestrator 通过 TaskList 保持可见性——只有在完整 12 步模拟中才能被学员真正体验到。BLOCK→fix→PASS 循环是课程从理论到实感的跃迁点
**FM 防御清单**: FM-1 12 步状态严格单向递增 / FM-2 消息飞行动画 cleanup 必须在步骤切换时执行 / FM-3 TaskList 面板状态与当前 step 严格同步 / FM-4 step dots active 状态唯一 / FM-5 三按钮状态互斥（play 时 step 禁用等）

### S008 四对张力升级 + 总结 [green]

**what becomes visible**: 四对张力从 Coordinator 到 Agent Teams 的平衡点迁移
**选定模式**: balance-scale-animation
- 四组天平（能力/约束、信任/约束、静态/动态、集中/分治）
- 页面加载时天平从 Coordinator 平衡点自动倾斜到 Agent Teams 新平衡点
- 点击每组天平 → 展开详情面板：该张力在两种模式中的不同体现
- 最后一个总结卡片收束 5 件产物清单
**反模式排除**: 非 4 页分开（张力是一组整体框架，必须同屏展示对比关系）
**四轴**: 解释力=3（天平隐喻直观但深度有限）/ 动效=3（倾斜动画）/ 成本=L / 认知=2
**justification**: 四对张力是第三节课留下的认知框架，在这里做升级映射完成闭环。天平倾斜动画传递"新平衡点"的概念比文字更有效

## red-red 页面清单（供 orchestrator 路由给 interactive-eng）

| Page | 模式 | 状态机复杂度 | 预估工时 |
|------|------|------------|---------|
| S005 | kanban-task-lifecycle | 6 状态 | High |
| S007 | full-lifecycle-step-simulator | 12 状态 | Very High |
