# 课件需求简报

## 核心目标
让学员理解从 Coordinator hub-spoke 到 Agent Teams P2P mesh 的架构升级逻辑，掌握 6 个工具的职能分工、Mailbox 文件系统邮箱、共享 TaskList、三种后端与身份系统，并将四对张力框架映射到新机制

## 受众画像
已完成 Claude Code 第三节课的学员（熟悉子 Agent 隔离/Fork 缓存/Coordinator 编排/四对张力），有 TypeScript 阅读能力。主要场景：直播授课投屏 + 课后学员自主复习

## 视觉风格倾向
深色背景（深海蓝/深空灰）+ 毛玻璃卡片 + 蓝色/绿色/黄色高亮，与已有架构图风格一致。技术+视觉混合型

## 交互密度预期
中-高（8 页中 2 页为 🔴🔴 重交互模拟器，3 页为 🟡 中交互展开卡片，3 页为 🟢 轻交互）

## 硬性禁止项
- 所有技术描述必须与源码一致，不编造
- Page 5 和 Page 7 必须有状态机和多 stage 模拟器
- Page 7 必须配三按钮学员控制权（play/pause/step）+ stage dots + stage indicator

## 用户期望感受
"终于搞清楚了，之前一直没想明白" + "好想动手试试，感觉能做出来"

## creativity_level
medium

## source_type
material

## 源材料
- lesson.md: /Users/mac/PycharmProjects/JupyterProject/ClaudeCode/第三点五节课/lesson.md (617行, 5章)
- reference.md: /Users/mac/PycharmProjects/JupyterProject/ClaudeCode/fufan-cc/agent-teams-p2p-reference.md (392行, 源码索引)
- mixed-mode-analysis.md: /Users/mac/PycharmProjects/JupyterProject/ClaudeCode/fufan-cc/agent-teams-mixed-mode-analysis.md (222行, Observable P2P 分析)
- 架构图: /Users/mac/PycharmProjects/JupyterProject/ClaudeCode/fufan-cc/images/html-courseware-team-architecture.png, courseware-pipeline-team-architecture.png
