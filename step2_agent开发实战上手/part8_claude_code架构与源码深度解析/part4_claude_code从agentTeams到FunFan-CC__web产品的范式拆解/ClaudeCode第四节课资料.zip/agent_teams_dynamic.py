"""
Agent Teams P2P 动态版 —— 对话式创建 team，运行时 spawn teammate

核心区别（对比 agent_teams_demo.py 静态版）：
  静态版：代码编写时预定义 3 个 agent + StateGraph 编排
  动态版：用户对话 → 主 agent 调 team_create/spawn_teammate 工具 → 运行时动态创建 teammate
         更接近 Claude Code 的真实设计（一个主进程 + 动态 spawn 子进程 + 文件系统邮箱轮询）

映射关系：
  Claude Code                         →  本实现
  主 claude 进程 (team lead)           →  main_agent（create_agent 实例）
  Agent tool + team_name spawn        →  spawn_teammate tool → TEAMMATE_POOL 动态添加
  TeamCreate → config.json            →  team_create tool → TEAM_CONFIG 内存字典
  writeToMailbox / readUnreadMessages →  send_message / read_messages → MAILBOX 内存邮箱
  TaskCreate / TaskUpdate / TaskList  →  task_create / task_update / task_list → TASKS 列表
  tmux pane 事件循环                   →  while True 主循环检查 mailbox + tasks

运行环境：conda activate harness (LangChain 1.2.15 + LangGraph 1.1.10)
运行方式：python agent_teams_dynamic.py（自动运行预设场景，无需手动输入）
"""

import os
import time
from datetime import datetime
from typing import Any

from dotenv import load_dotenv
load_dotenv(os.path.expanduser("~/.claude/.env"))

# 禁用 LangSmith tracing
os.environ["LANGCHAIN_TRACING_V2"] = "false"
os.environ["LANGSMITH_TRACING"] = "false"

from langchain.tools import tool
from langchain.chat_models import init_chat_model
from langchain.agents import create_agent


# ============================================================
# 第一层：全局共享状态（模拟 Claude Code 的文件系统存储）
# ============================================================

# 模拟 ~/.claude/teams/{name}/config.json（运行时由 team_create 工具填充）
TEAM_CONFIG: dict[str, Any] = {}

# 模拟 ~/.claude/teams/{name}/inbox/（文件系统邮箱）
MAILBOX: dict[str, list[dict]] = {}

# 模拟 ~/.claude/tasks/{name}/（共享 TaskList）
TASKS: list[dict] = []
TASK_ID_COUNTER = [0]

# 动态 teammate 池（运行时由 spawn_teammate 工具填充）
TEAMMATE_POOL: dict[str, Any] = {}

# 当前正在执行的 agent 名称（模拟 Claude Code 的 dynamicTeamContext）
CURRENT_AGENT = ["team-lead"]

# LLM 实例（全局共享，降低初始化开销）
LLM = init_chat_model("deepseek:deepseek-chat", temperature=0)


# ============================================================
# 第二层：工具定义（team lead 和 teammate 各自的工具集不同）
# ============================================================

# ----- 通信工具（所有 agent 共用）-----

@tool
def send_message(to: str, content: str) -> str:
    """P2P 发送消息给指定 teammate。映射 Claude Code 的 SendMessageTool。

    Args:
        to: 接收者 name（如 "researcher"），或 "*" 广播给所有 teammate
        content: 消息内容
    """
    sender = CURRENT_AGENT[0]
    msg = {"from": sender, "content": content, "timestamp": datetime.now().isoformat(), "read": False}

    if to == "*":
        recipients = [name for name in MAILBOX if name != sender]
        for r in recipients:
            MAILBOX[r].append(msg.copy())
        return f"已广播给 {', '.join(recipients)}"

    if to not in MAILBOX:
        available = list(MAILBOX.keys())
        return f"错误：找不到 '{to}'。当前成员：{available}"

    MAILBOX[to].append(msg)
    return f"已发送消息给 {to}"


@tool
def read_messages() -> str:
    """读取当前 agent 的未读消息。映射 Claude Code 的 readUnreadMessages。"""
    name = CURRENT_AGENT[0]
    unread = [m for m in MAILBOX.get(name, []) if not m["read"]]
    if not unread:
        return "没有未读消息"
    for m in unread:
        m["read"] = True
    lines = [f"  来自 {m['from']}：{m['content']}" for m in unread]
    return f"📬 {len(unread)} 条未读：\n" + "\n".join(lines)


# ----- 任务管理工具 -----

@tool
def task_create(subject: str, description: str, blocked_by: str = "") -> str:
    """创建共享任务。映射 Claude Code 的 TaskCreateTool。

    Args:
        subject: 任务标题
        description: 详细描述
        blocked_by: 前置 task ID（逗号分隔，如 "1,2"），留空无依赖
    """
    TASK_ID_COUNTER[0] += 1
    tid = str(TASK_ID_COUNTER[0])
    bl = [b.strip() for b in blocked_by.split(",") if b.strip()] if blocked_by else []
    TASKS.append({"id": tid, "subject": subject, "description": description,
                  "status": "pending", "owner": None, "blocked_by": bl})
    info = f"，blocked_by=[{','.join(bl)}]" if bl else ""
    return f"✅ 已创建 Task {tid}：{subject}{info}"


@tool
def task_update(task_id: str, status: str = "", owner: str = "") -> str:
    """更新任务状态或认领任务。映射 Claude Code 的 TaskUpdateTool。

    Args:
        task_id: 任务 ID
        status: 新状态（pending / in_progress / completed）
        owner: 认领者（留空自动填当前 agent）
    """
    task = next((t for t in TASKS if t["id"] == task_id), None)
    if not task:
        return f"错误：找不到 Task {task_id}"

    # blockedBy 检查
    if status == "in_progress" and task["blocked_by"]:
        blockers = [t for t in TASKS if t["id"] in task["blocked_by"] and t["status"] != "completed"]
        if blockers:
            return f"❌ Task {task_id} 被 {[t['id'] for t in blockers]} 阻塞"

    if status:
        task["status"] = status
    if status == "in_progress" and not owner:
        owner = CURRENT_AGENT[0]
    if owner:
        task["owner"] = owner

    # 完成时解锁下游
    unlocked = ""
    if status == "completed":
        for t in TASKS:
            if task_id in t.get("blocked_by", []):
                t["blocked_by"].remove(task_id)
                if not t["blocked_by"]:
                    unlocked += f"\n  🔓 Task {t['id']}({t['subject']}) 已解锁"

    return f"✅ Task {task_id}: status={task['status']}, owner={task.get('owner', '无')}{unlocked}"


@tool
def task_list() -> str:
    """查看所有任务。映射 Claude Code 的 TaskListTool。"""
    if not TASKS:
        return "📋 TaskList 为空"
    lines = []
    for t in TASKS:
        bl = f" [blocked by {','.join(t['blocked_by'])}]" if t.get("blocked_by") else ""
        ow = f" → {t['owner']}" if t.get("owner") else ""
        lines.append(f"  Task {t['id']}: {t['subject']} | {t['status']}{ow}{bl}")
    return f"📋 {len(TASKS)} 个任务：\n" + "\n".join(lines)


# ----- Team 管理工具（仅 team lead 使用）-----

@tool
def team_create(team_name: str, description: str = "") -> str:
    """创建一个新 team。映射 Claude Code 的 TeamCreateTool。

    Args:
        team_name: 团队名称
        description: 团队描述
    """
    TEAM_CONFIG["name"] = team_name
    TEAM_CONFIG["description"] = description
    TEAM_CONFIG["lead_agent_id"] = f"team-lead@{team_name}"
    TEAM_CONFIG["members"] = [{"name": "team-lead", "role": "协调者"}]
    MAILBOX["team-lead"] = MAILBOX.get("team-lead", [])
    return f"✅ Team '{team_name}' 已创建。你是 team lead，现在可以用 spawn_teammate 添加成员。"


@tool
def spawn_teammate(name: str, role: str) -> str:
    """动态创建一个新 teammate 并加入 team。映射 Claude Code 的 Agent tool + team_name 参数。

    每个 teammate 是一个完整的 create_agent 实例（对应 Claude Code 中每个 teammate 是完整 claude 进程）。

    Args:
        name: teammate 名称（用于 SendMessage 寻址）
        role: 角色描述（如 "搜索调研"、"内容写作"）
    """
    if not TEAM_CONFIG.get("name"):
        return "错误：请先用 team_create 创建 team"

    if name in TEAMMATE_POOL:
        return f"错误：teammate '{name}' 已存在"

    # 动态创建 agent 实例（运行时生成，不是预编译的）
    teammate_agent = create_agent(
        model=LLM,
        tools=[send_message, read_messages, task_list, task_update],
        name=name,
        system_prompt=f"""你是 Agent Team "{TEAM_CONFIG['name']}" 中的 {name}（{role}）。

        你的职责：
        1. 用 read_messages 读取来自 team lead 或其他 teammate 的消息
        2. 用 task_list 查看可认领的任务
        3. 用 task_update 认领任务（status=in_progress）并在完成后标记 completed
        4. 用 send_message 把结果发给需要的 teammate 或 team lead
        5. 你负责的领域是：{role}

        你是 {name}@{TEAM_CONFIG['name']}。
        通信规则：跟任何人说话必须用 send_message 工具，光写文本对方看不到。
        完成任务后必须用 task_update 标记 completed，然后用 send_message 通知 team lead。""",
    )

    # 加入 teammate 池
    TEAMMATE_POOL[name] = teammate_agent

    # 注册邮箱
    MAILBOX[name] = []

    # 加入 team 配置
    TEAM_CONFIG["members"].append({"name": name, "role": role})

    return (f"✅ Teammate '{name}'（{role}）已创建并加入 team。\n"
            f"   当前成员：{[m['name'] for m in TEAM_CONFIG['members']]}\n"
            f"   你可以用 send_message(to='{name}', ...) 给它发消息。")


# ============================================================
# 第三层：主 Agent（team lead）—— 用户直接对话的入口
# ============================================================

# team lead 的工具集 = 通信 + 任务管理 + team 管理
lead_tools = [send_message, read_messages, task_create, task_update, task_list,
              team_create, spawn_teammate]

main_agent = create_agent(
    model=LLM,
    tools=lead_tools,
    name="team_lead",
    system_prompt="""你是一个 Agent Team 的 team lead。用户会直接跟你对话。

你的核心工作流（严格按顺序，每步都用工具）：
1. 用 team_create 创建团队
2. 用 spawn_teammate 创建所需的 teammate（名字和角色由你决定）
3. 用 task_create 把任务拆成子任务，用 blocked_by 设依赖关系
4. 用 send_message 通知对应 teammate 去 task_list 认领任务
5. 完成上述 4 步后立即停止，回复"已完成编排，等待 teammate 执行"

绝对禁止（红线）：
- 禁止自己执行调研、写作、搜索等具体任务——你是编排者不是执行者
- 禁止自己调用 task_update 把任务标记为 completed——只有实际执行任务的 teammate 才能标完成
- 禁止在 teammate 还没回复时就自己补位做完任务
- 你的工作到"通知 teammate 去认领"就结束了，剩下的交给事件循环驱动 teammate

注意：每个 teammate 是独立的 agent，你跟它们的唯一通信方式是 send_message 工具。""",
)


# ============================================================
# 第四层：事件循环（替代 StateGraph，更接近 Claude Code 的真实设计）
# ============================================================

def run_teammate(name: str) -> str:
    """激活一个 teammate 执行一轮（读消息 → 认领任务 → 执行 → 回报）

    Args:
        name: teammate 名称

    Returns:
        teammate 的最终回复文本
    """
    if name not in TEAMMATE_POOL:
        return f"错误：teammate '{name}' 不存在"

    CURRENT_AGENT[0] = name
    agent = TEAMMATE_POOL[name]

    # 构造输入：告诉 teammate 检查消息和任务
    unread_count = len([m for m in MAILBOX.get(name, []) if not m["read"]])
    if unread_count > 0:
        prompt = f"你有 {unread_count} 条未读消息。请先 read_messages 读取，然后 task_list 查看任务并认领执行。"
    else:
        prompt = "请 task_list 查看是否有可认领的任务。如无待办事项，回复'无待办'。"

    result = agent.invoke({"messages": [{"role": "user", "content": prompt}]})

    # 提取最终回复
    last_msg = result["messages"][-1]
    content = last_msg.content if hasattr(last_msg, "content") else str(last_msg)
    return content


def check_and_route() -> str | None:
    """检查 mailbox + tasks，返回应该被激活的 teammate 名称。

    路由优先级（映射 Claude Code 的 Mailbox 轮询逻辑）：
    1. 有未读消息的 teammate → 激活
    2. 有 pending 且未被阻塞的 task → 根据角色激活对应 teammate
    3. 都没有 → 返回 None（结束循环）
    """
    # 优先级 1：检查未读消息
    for name in TEAMMATE_POOL:
        unread = [m for m in MAILBOX.get(name, []) if not m["read"]]
        if unread:
            return name

    # 优先级 2：检查可认领的 pending task
    for t in TASKS:
        if t["status"] == "pending" and not t.get("blocked_by") and not t.get("owner"):
            # 在已有 teammate 中找匹配的（按角色关键词）
            for member in TEAM_CONFIG.get("members", []):
                if member["name"] in TEAMMATE_POOL:
                    return member["name"]

    return None


def event_loop(user_input: str, max_turns: int = 12):
    """主事件循环：team lead 处理用户输入 → 轮询 teammate 执行

    这个循环对应 Claude Code 中 tmux session 的事件循环：
    - 主循环检查每个 teammate 的 mailbox
    - 有未读消息就唤醒对应 teammate
    - teammate 执行完进入 idle，循环继续检查
    - 所有 task 完成则退出

    Args:
        user_input: 用户的任务描述
        max_turns: 最大轮次（防止无限循环）
    """
    import sys
    print("=" * 60, flush=True)
    print("🚀 Agent Teams 动态版启动", flush=True)
    print("=" * 60, flush=True)

    start_time = time.time()
    turn = 0

    # Step 1: team lead 处理用户输入（创建 team → spawn teammate → 创建 task → 通知）
    print(f"\n{'─' * 50}", flush=True)
    print(f"📍 Turn {turn} | 🎯 team-lead 处理用户指令", flush=True)
    sys.stdout.flush()
    CURRENT_AGENT[0] = "team-lead"

    result = main_agent.invoke({"messages": [{"role": "user", "content": user_input}]})
    lead_reply = result["messages"][-1].content if hasattr(result["messages"][-1], "content") else str(result["messages"][-1])

    # 截断显示
    display = lead_reply[:400] + "..." if len(lead_reply) > 400 else lead_reply
    print(f"   💬 {display}", flush=True)
    _print_status()
    turn += 1

    # Step 2: 事件循环——轮询 mailbox + tasks，激活 teammate
    while turn < max_turns:
        # 检查是否所有 task 都完成
        if TASKS and all(t["status"] == "completed" for t in TASKS):
            # 让 team lead 读取最终结果
            unread_lead = [m for m in MAILBOX.get("team-lead", []) if not m["read"]]
            if unread_lead:
                print(f"\n{'─' * 50}")
                print(f"📍 Turn {turn} | 🎯 team-lead 汇总最终结果")
                CURRENT_AGENT[0] = "team-lead"
                summary_result = main_agent.invoke({
                    "messages": [{"role": "user", "content": "所有任务已完成，请 read_messages 读取 teammate 的回报，然后汇总最终结果。"}]
                })
                summary = summary_result["messages"][-1].content
                display = summary[:500] + "..." if len(summary) > 500 else summary
                print(f"   💬 {display}")

            print(f"\n✅ 所有 {len(TASKS)} 个任务已完成！")
            break

        # 路由：谁应该被激活？
        next_agent = check_and_route()
        if not next_agent:
            print(f"\n⏸️ 无待处理事项，循环结束")
            break

        print(f"\n{'─' * 50}")
        print(f"📍 Turn {turn} | 🤖 {next_agent} 被激活")

        # 执行 teammate
        reply = run_teammate(next_agent)
        display = reply[:400] + "..." if len(reply) > 400 else reply
        print(f"   💬 {display}")
        _print_status()
        turn += 1

    elapsed = time.time() - start_time

    # 最终报告
    print(f"\n{'=' * 60}")
    print(f"🏁 执行完成 | 耗时: {elapsed:.1f}s | 轮次: {turn}")
    if TEAM_CONFIG:
        print(f"   Team: {TEAM_CONFIG.get('name', '未创建')}")
        print(f"   成员: {[m['name'] for m in TEAM_CONFIG.get('members', [])]}")
    print(f"   TaskList:")
    for t in TASKS:
        icon = {"pending": "⏳", "in_progress": "🔄", "completed": "✅"}.get(t["status"], "❓")
        print(f"   {icon} Task {t['id']}: {t['subject']} | {t['status']} | owner={t.get('owner', '无')}")
    print("=" * 60)


def _print_status():
    """打印当前 TaskList + Mailbox 状态"""
    if TASKS:
        print(f"   📋 TaskList:")
        for t in TASKS:
            icon = {"pending": "⏳", "in_progress": "🔄", "completed": "✅"}.get(t["status"], "❓")
            bl = f" [blocked by {','.join(t['blocked_by'])}]" if t.get("blocked_by") else ""
            ow = f" → {t['owner']}" if t.get("owner") else ""
            print(f"      {icon} Task {t['id']}: {t['subject']}{ow}{bl}")
    for name, inbox in MAILBOX.items():
        unread = len([m for m in inbox if not m["read"]])
        if unread > 0:
            print(f"   📬 {name} 有 {unread} 条未读")


def reset():
    """重置全局状态"""
    TEAM_CONFIG.clear()
    MAILBOX.clear()
    MAILBOX["team-lead"] = []
    TASKS.clear()
    TASK_ID_COUNTER[0] = 0
    TEAMMATE_POOL.clear()
    CURRENT_AGENT[0] = "team-lead"


# ============================================================
# 第五层：运行入口
# ============================================================

if __name__ == "__main__":
    reset()

    # 模拟用户在对话框中输入一条指令
    # team lead 需要自己决定：创建什么 team、spawn 哪些 teammate、怎么拆任务
    event_loop(
        user_input=(
            "帮我完成一个任务：调研 Python 3.13 的三个最重要新特性，然后写一段 100 字总结。\n"
            "请你自己决定创建什么 team、需要哪些 teammate，然后拆分任务并协调执行。"
        ),
        max_turns=12,
    )
