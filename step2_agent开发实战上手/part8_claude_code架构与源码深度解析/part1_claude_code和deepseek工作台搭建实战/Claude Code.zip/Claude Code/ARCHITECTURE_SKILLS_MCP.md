# Claude Code Skills & MCP 底层架构深度分析

> 基于 instructkr/claude-code 开源代码逆向分析，可用于复现实现。

---

## 一、整体架构概览

```
┌─────────────────────────────────────────────────────────────────┐
│                        Claude Code 运行时                        │
├──────────────────────┬──────────────────────────────────────────┤
│                      │                                          │
│   Skill 系统         │          MCP 系统                        │
│   ├─ 加载层          │          ├─ 配置层 (config.ts)           │
│   │  loadSkillsDir   │          ├─ 连接层 (client.ts)           │
│   ├─ 解析层          │          ├─ 传输层 (stdio/sse/http/ws)   │
│   │  frontmatterParser│         ├─ 工具桥接 (MCPTool.ts)       │
│   ├─ 执行层          │          ├─ 资源访问 (List/ReadResource) │
│   │  SkillTool       │          └─ 技能集成 (mcpSkillBuilders)  │
│   └─ 权限层          │                                          │
│      permissions     │      两者共享: AppState.mcp 状态管理      │
└──────────────────────┴──────────────────────────────────────────┘
```

核心设计理念：**Skill 是 Markdown 驱动的行为注入**，**MCP 是协议驱动的工具扩展**，两者通过统一的 `Command` 和 `Tool` 接口汇入同一个工具调度管道。

---

## 二、Skill 系统架构

### 2.1 Skill 来源与加载优先级

```typescript
// src/skills/loadSkillsDir.ts:67-73
export type LoadedFrom =
  | 'commands_DEPRECATED'  // 旧版 /commands/ 目录（兼容）
  | 'skills'               // 现代 /.claude/skills/ 目录
  | 'plugin'               // 插件 plugin/SKILL.md
  | 'managed'              // 企业策略托管
  | 'bundled'              // 编译内置
  | 'mcp'                  // MCP 服务器提供
```

**加载路径优先级**（高→低）：

| 优先级 | 来源 | 路径 |
|--------|------|------|
| 1 | 项目级 | `.claude/skills/<name>/SKILL.md` |
| 2 | 用户级 | `~/.claude/skills/<name>/SKILL.md` |
| 3 | 策略托管 | `~/.claude/managed/.claude/skills/` |
| 4 | 插件 | `plugin/SKILL.md` |
| 5 | 内置 | 编译到二进制 |
| 6 | MCP | MCP 服务器 prompts |

**关键约束**：Skill 必须是**目录+SKILL.md**格式，不支持单独 `.md` 文件直接放在 `/skills/` 下。

### 2.2 Skill 文件格式（Markdown + YAML Frontmatter）

```yaml
---
name: "显示名称"
description: "技能描述"
when_to_use: "触发条件描述"
allowed-tools: ["bash", "grep"]       # 执行期间免权限的工具
argument-hint: "<file-path>"          # 参数提示
arguments: ["filename", "pattern"]    # 支持 ${ARG_NAME} 替换
model: "opus"                         # 模型覆盖（或 'inherit'）
disable-model-invocation: false       # 禁止模型主动调用
user-invocable: true                  # 用户可通过 /name 调用
context: fork                         # 执行模式: inline(默认) | fork(子agent)
agent: "general-purpose"              # fork 时的 agent 类型
paths: "src/**/*.{ts,tsx}"            # 条件激活的文件 glob
effort: "high"                        # agent 思考力度
shell: bash                           # !`cmd` 块使用的 shell
hooks:                                # 调用时注册的钩子
  PreToolUse:
    - matcher: "command:bash"
      hooks:
        - command: "some-hook.sh"
version: "1.0.0"
---

# Skill 正文（Markdown）
这里是注入给模型的 prompt 内容...
```

### 2.3 Frontmatter 解析器

```
src/utils/frontmatterParser.ts
```

**解析流程**：

```
原始 Markdown
    ↓
正则提取 --- 之间的 YAML 块（FRONTMATTER_REGEX = /^---\s*\n([\s\S]*?)---\s*\n?/）
    ↓
第一次 YAML 解析（parseYaml）
    ↓ 失败？
对含特殊字符的值自动加引号（quoteProblematicValues）
    ↓
第二次 YAML 解析（重试）
    ↓
返回 { frontmatter: FrontmatterData, content: string }
```

**特殊处理**：glob 模式中的 `{}[]* ` 等 YAML 特殊字符会被自动引号包裹，确保 `src/**/*.{ts,tsx}` 这类 paths 能正确解析。

### 2.4 Skill 注册为 Command

```
src/skills/loadSkillsDir.ts → parseSkillFrontmatterFields() + createSkillCommand()
```

**核心数据结构**（简化）：

```typescript
interface Command {
  name: string                    // 技能名
  type: 'prompt'                  // 固定为 prompt
  description: string             // 描述
  whenToUse?: string              // 触发条件
  source: string                  // 来源标识
  loadedFrom: LoadedFrom          // 加载源类型
  allowedTools: string[]          // 免权限工具列表
  model?: ModelSpec               // 模型覆盖
  executionContext?: 'fork'       // 执行上下文
  agent?: string                  // fork agent 类型
  paths?: string[]                // 条件激活 glob
  effort?: EffortValue            // 思考力度
  hooks?: HooksSettings           // 钩子配置
  disableModelInvocation: boolean // 模型主动调用开关
  userInvocable: boolean          // 用户可调用开关
  getPromptForCommand: (args, context) => ContentBlockParam[] // 获取 prompt
}
```

### 2.5 Skill 触发与执行管道

```
                    ┌────────────────────────────┐
                    │  用户输入 /skill-name       │
                    │  或模型决定调用 Skill tool   │
                    └──────────┬─────────────────┘
                               ↓
                    ┌──────────────────────┐
                    │  SkillTool.validateInput()  │
                    │  - 检查技能是否存在          │
                    │  - 验证 disableModelInvocation│
                    │  - 确认类型为 prompt          │
                    └──────────┬─────────────────┘
                               ↓
                    ┌──────────────────────┐
                    │  SkillTool.checkPermissions()│
                    │  - 检查 deny 规则           │
                    │  - 检查 allow 规则          │
                    │  - 安全属性自动放行          │
                    └──────────┬─────────────────┘
                               ↓
                    ┌──────────────────────┐
                    │  执行路由决策                │
                    │  context === 'fork' ?        │
                    └──────┬──────────┬───────────┘
                     YES   ↓          ↓  NO (默认)
              ┌──────────────┐  ┌───────────────┐
              │ executeForked │  │ executeInline  │
              │ Skill()      │  │ Skill()        │
              └──────────────┘  └───────────────┘
```

#### Inline 执行（默认）

```
1. processPromptSlashCommand() 展开 skill 内容
2. substituteArguments() 替换 ${ARG_NAME} 参数
3. 注入环境变量: ${CLAUDE_SKILL_DIR}, ${CLAUDE_SESSION_ID}
4. executeShellCommandsInPrompt() 执行 !`...` 内嵌 shell 命令
   ⚠️ MCP 来源的 skill 跳过此步（安全限制）
5. allowed-tools 临时加入权限白名单
6. skill 内容作为 system/user message 注入模型
```

#### Fork 执行（子 Agent）

```typescript
// src/tools/SkillTool/SkillTool.ts:122-289
async function executeForkedSkill(...) {
  const agentId = createAgentId()

  // 1. 准备隔离上下文
  const { modifiedGetAppState, baseAgent, promptMessages, skillContent } =
    await prepareForkedCommandContext(command, args, context)

  // 2. 合并 effort 配置
  const agentDefinition = command.effort
    ? { ...baseAgent, effort: command.effort }
    : baseAgent

  // 3. 启动子 agent 独立对话循环
  for await (const message of runAgent({
    agentDefinition,
    promptMessages,
    model: command.model,
    availableTools: context.options.tools,
    override: { agentId },
  })) {
    agentMessages.push(message)
  }

  // 4. 提取结果，清理内存
  const resultText = extractResultText(agentMessages)
  clearInvokedSkillsForAgent(agentId)
  return { success: true, status: 'forked', agentId, result: resultText }
}
```

### 2.6 条件激活系统（paths）

```
src/skills/loadSkillsDir.ts:997-1058
```

**三层状态管理**：

```typescript
const conditionalSkills = new Map<string, Command>()       // 待激活池
const activatedConditionalSkillNames = new Set<string>()   // 已激活名称集
const dynamicSkills = new Map<string, Command>()            // 运行时激活的 skill
```

**触发流程**：

```
FileReadTool / FileWriteTool / FileEditTool
    ↓ 文件路径
activateConditionalSkillsForPaths(filePaths, cwd)
    ↓
遍历 conditionalSkills，用 ignore 库匹配 glob
    ↓ 匹配成功
将 skill 从 conditionalSkills → dynamicSkills
    ↓
触发 'tengu_dynamic_skills_changed' 信号
```

### 2.7 Skill 列表预算控制

```
src/tools/SkillTool/prompt.ts
```

Skill 列表注入模型时有**严格的 token 预算**：

- 占上下文窗口的 **1%**（`contextWindowTokens * 4 * 0.01` 字符）
- 回退默认 8000 字符
- 单个 skill 描述硬上限 **250 字符**
- 内置 skill 优先获得完整描述
- 超出预算时非内置 skill 描述被截断

### 2.8 内置 Skill 注册机制

```
src/skills/bundledSkills.ts
```

```typescript
type BundledSkillDefinition = {
  name: string
  description: string
  aliases?: string[]
  whenToUse?: string
  allowedTools?: string[]
  model?: string
  context?: 'inline' | 'fork'
  agent?: string
  files?: Record<string, string>      // 可附带文件资源
  getPromptForCommand: (args, context) => ContentBlockParam[]
}

// 附带文件会被解压到:
// ~/.claude/bundled-skills/<skill-name>/
```

---

## 三、MCP 系统架构

### 3.1 配置体系

```
src/services/mcp/config.ts + types.ts
```

**配置来源（合并顺序）**：

| 优先级 | 来源 | 路径 |
|--------|------|------|
| 1 | 项目级 | `.mcp.json`（项目根目录） |
| 2 | 项目设置 | `.claude/settings.json` → mcpServers |
| 3 | 用户级 | `~/.claude/settings.json` → mcpServers |
| 4 | 企业级 | `~/.claude/managed/managed-mcp.json` |
| 5 | claude.ai | `fetchClaudeAIMcpConfigsIfEligible()` |
| 6 | 插件 | `getPluginMcpServers()` |

**支持的传输类型**：

```typescript
// src/services/mcp/types.ts
type Transport = 'stdio' | 'sse' | 'sse-ide' | 'http' | 'ws' | 'sdk'

// Stdio（最常用）
{ command: "npx", args: ["server-package"], env: { KEY: "val" } }

// SSE（Server-Sent Events + OAuth）
{ type: "sse", url: "https://...", headers: {}, oauth: { clientId, callbackPort } }

// HTTP（StreamableHTTP）
{ type: "http", url: "https://...", headers: {}, oauth: {} }

// WebSocket
{ type: "ws", url: "wss://...", headers: {} }

// SDK（进程内）
{ type: "sdk", name: "server-name" }

// IDE 专用
{ type: "sse-ide", url: "...", ideName: "vscode" }
{ type: "ws-ide", url: "...", ideName: "jetbrains", authToken: "..." }

// claude.ai 代理
{ type: "claudeai-proxy", url: "...", id: "..." }
```

### 3.2 连接管理架构

```
src/services/mcp/client.ts（3300+ 行核心文件）
```

#### 连接建立流程

```
getAllMcpConfigs()                    ← 合并所有配置源
    ↓
getMcpToolsCommandsAndResources()    ← 入口函数（main.tsx 调用）
    ↓
对每个 server 调用 connectToServer()  ← memoized，相同配置不重连
    ↓
根据 type 创建 Transport:
  ├─ stdio  → StdioClientTransport（子进程 stdin/stdout）
  ├─ sse    → SSEClientTransport（HTTP SSE + OAuth）
  ├─ http   → StreamableHTTPClientTransport
  ├─ ws     → WebSocketTransport（自定义实现）
  ├─ sdk    → SdkControlClientTransport（进程内）
  └─ 特殊   → InProcessTransport（Chrome/ComputerUse 进程内）
    ↓
new Client("claude-code", { capabilities: { roots: {}, elicitation: {} } })
    ↓
client.connect(transport)            ← 带超时的 Promise.race
    ↓
MCPServerConnection { type: 'connected', client, capabilities, config }
```

#### Stdio 传输细节

```typescript
// src/services/mcp/client.ts:944-958
const finalCommand = process.env.CLAUDE_CODE_SHELL_PREFIX || serverRef.command
const finalArgs = process.env.CLAUDE_CODE_SHELL_PREFIX
  ? [[serverRef.command, ...serverRef.args].join(' ')]
  : serverRef.args

transport = new StdioClientTransport({
  command: finalCommand,
  args: finalArgs,
  env: { ...subprocessEnv(), ...serverRef.env },
  stderr: 'pipe',  // 防止 MCP 服务器的 stderr 污染 UI
})
```

#### 进程内服务器优化

对于体积大的 MCP 服务器，避免独立子进程：

```typescript
// Chrome MCP（~325MB）和 ComputerUse MCP 使用 InProcessTransport
const [clientTransport, serverTransport] = createLinkedTransportPair()
inProcessServer = createClaudeForChromeMcpServer(context)
await inProcessServer.connect(serverTransport)
transport = clientTransport  // 客户端使用链接的另一端
```

### 3.3 MCP Tool → Claude Code Tool 桥接

```
src/tools/MCPTool/MCPTool.ts + src/services/mcp/client.ts:1743-1998
```

这是 MCP 架构中最关键的设计——将 MCP 协议的工具映射为 Claude Code 内部的 `Tool` 接口：

```typescript
// client.ts:1766-1988（简化）
export const fetchToolsForClient = memoizeWithLRU(
  async (client: MCPServerConnection): Promise<Tool[]> => {
    // 1. 通过 MCP 协议获取工具列表
    const result = await client.client.request(
      { method: 'tools/list' },
      ListToolsResultSchema,
    )

    // 2. 清洗 Unicode
    const toolsToProcess = recursivelySanitizeUnicode(result.tools)

    // 3. 逐个转换为 Claude Code Tool
    return toolsToProcess.map((tool): Tool => {
      const fullyQualifiedName = buildMcpToolName(client.name, tool.name)
      // → "mcp__serverName__toolName"

      return {
        ...MCPTool,                    // 继承基础 MCPTool 模板
        name: fullyQualifiedName,      // 完全限定名
        mcpInfo: { serverName, toolName },  // 权限检查用
        isMcp: true,

        // 描述截断到 2048 字符
        async prompt() {
          return desc.length > MAX_MCP_DESCRIPTION_LENGTH
            ? desc.slice(0, MAX_MCP_DESCRIPTION_LENGTH) + '... [truncated]'
            : desc
        },

        // 利用 MCP tool annotations
        isConcurrencySafe: () => tool.annotations?.readOnlyHint ?? false,
        isReadOnly: () => tool.annotations?.readOnlyHint ?? false,
        isDestructive: () => tool.annotations?.destructiveHint ?? false,
        isOpenWorld: () => tool.annotations?.openWorldHint ?? false,

        // 输入 schema 直接透传
        inputJSONSchema: tool.inputSchema,

        // 核心：工具调用代理
        async call(args, context, _canUseTool, parentMessage, onProgress) {
          for (let attempt = 0; ; attempt++) {
            try {
              const connectedClient = await ensureConnectedClient(client)
              const mcpResult = await callMCPToolWithUrlElicitationRetry({
                client: connectedClient,
                tool: tool.name,
                args,
                meta: { 'claudecode/toolUseId': toolUseId },
                signal: context.abortController.signal,
              })
              return { data: mcpResult.content, mcpMeta: ... }
            } catch (error) {
              // Session 过期自动重试（最多 1 次）
              if (error instanceof McpSessionExpiredError && attempt < 1) continue
              throw error
            }
          }
        },
      }
    })
  },
  (client) => client.name,  // LRU 缓存键
  20,                         // 缓存容量
)
```

### 3.4 MCP 工具调用链

```
模型决定调用 mcp__server__tool
    ↓
Tool.call(args, context)
    ↓
ensureConnectedClient(client)        ← 确保连接存活
    ↓
callMCPToolWithUrlElicitationRetry() ← 带 OAuth elicitation 重试
    ↓
client.request({ method: 'tools/call', params: { name, arguments } })
    ↓
JSON-RPC over Transport (stdio/sse/http/ws)
    ↓
MCP 服务器执行并返回 CallToolResult
    ↓
{ content: ContentBlock[], isError: bool, structuredContent?: dict }
    ↓
truncateMcpContentIfNeeded()         ← 结果超 100KB 截断
    ↓
返回给模型
```

### 3.5 资源系统

```
src/tools/ListMcpResourcesTool/ + src/tools/ReadMcpResourceTool/
```

两个专用工具暴露 MCP 资源：

- **ListMcpResourcesTool**：`resources/list` → 返回 URI、名称、MIME、描述
- **ReadMcpResourceTool**：`resources/read` → 支持二进制 blob 解码、持久化到磁盘

### 3.6 MCP Prompts → Skills 集成

```
src/skills/mcpSkillBuilders.ts + src/skills/mcpSkills.ts
```

**Feature-gated**：仅 `MCP_SKILLS` feature flag 启用时生效。

```typescript
// client.ts:117-121
const fetchMcpSkillsForClient = feature('MCP_SKILLS')
  ? require('../../skills/mcpSkills.js').fetchMcpSkillsForClient
  : null
```

**转换流程**：

```
MCP server → prompts/list                    ← 获取 prompt 定义
    ↓
每个 prompt → createSkillCommand()            ← 注册为 Command
    ↓
Command {
  name: "server:promptName (MCP)",
  type: 'prompt',
  loadedFrom: 'mcp',
  getPromptForCommand: () => client.getPrompt(name, args)
}
    ↓
注入 AppState.mcp.commands                    ← 可被 SkillTool 调用
```

**安全限制**：MCP 来源的 skill **永远不执行内嵌 shell 命令**（`!`\`...\`` 块被跳过）。

### 3.7 连接健康管理

```
src/services/mcp/useManageMCPConnections.ts
```

**指数退避重连**：

```typescript
const MAX_RECONNECT_ATTEMPTS = 5
const INITIAL_BACKOFF_MS = 1000
const MAX_BACKOFF_MS = 30000
```

**终端错误检测**（触发重连）：

```
ECONNREFUSED, ENOTFOUND, ETIMEDOUT
Body Timeout Error, terminated
SSE stream disconnected
Failed to reconnect SSE stream
Maximum reconnection attempts
```

**Session 过期处理**：

```typescript
// HTTP 404 + JSON-RPC -32001 = session 不存在
function isMcpSessionExpiredError(error: Error): boolean {
  return error.code === 404 &&
    (error.message.includes('"code":-32001') ||
     error.message.includes('"code": -32001'))
}
// → 清除连接缓存 → 下次调用自动重建连接
```

**连续错误阈值**：3 次连续错误后触发重连（成功则重置计数）。

**缓存失效事件**：

| MCP 通知 | 失效缓存 |
|----------|---------|
| `tools/list_changed` | 工具缓存 |
| `resources/list_changed` | 资源缓存 |
| `prompts/list_changed` | Prompt/Command 缓存 |

### 3.8 延迟加载系统（Deferred Tools / ToolSearch）

当 MCP 工具描述超过上下文窗口 10% 时，工具标记为 `defer_loading: true`：

```
工具列表注入 system prompt 时
    ↓
超阈值？ → 仅发送工具名称（不含 schema）
    ↓
模型需要用时 → 调用 ToolSearchTool
    ↓
ToolSearchTool 返回完整 schema → 模型可以调用
```

MCP 工具默认标记 `shouldDefer: true`。

### 3.9 权限模型

**MCP 工具命名规范**：`mcp__serverName__toolName`

**权限规则匹配**：

```
mcp__myserver__tool1  ← 精确匹配单个工具
mcp_myserver          ← 前缀匹配，阻止该服务器所有工具
mcp__*                ← 通配所有 MCP 工具
```

**Skill 权限**：

```
/skill-name           ← 精确匹配
review:*              ← 前缀通配（review-pr, review-code 等）
```

**安全属性自动放行**：仅含 name/description/whenToUse 且无 allowedTools/hooks/model/agent 的 skill 自动允许，不弹权限确认。

---

## 四、AppState 中的 MCP 状态结构

```typescript
// src/state/AppStateStore.ts
mcp: {
  clients: MCPServerConnection[]              // 连接实例列表
  tools: Tool[]                               // 所有 MCP 代理工具
  commands: Command[]                         // MCP prompt 转换的 skill
  resources: Record<string, ServerResource[]>  // server → 资源映射
  pluginReconnectKey: number                   // 插件重连触发器
}
```

---

## 五、关键文件索引

| 模块 | 文件路径 | 核心函数 |
|------|---------|---------|
| **MCP 连接** | `src/services/mcp/client.ts` | `connectToServer()`, `fetchToolsForClient()`, `ensureConnectedClient()` |
| **MCP 配置** | `src/services/mcp/config.ts` | `getAllMcpConfigs()`, `writeMcpjsonFile()` |
| **MCP 类型** | `src/services/mcp/types.ts` | 所有配置 Schema（Stdio/SSE/HTTP/WS） |
| **MCP 生命周期** | `src/services/mcp/useManageMCPConnections.ts` | React Hook，重连、缓存失效 |
| **MCP 工具模板** | `src/tools/MCPTool/MCPTool.ts` | `buildTool()` 基础定义 |
| **MCP 资源** | `src/tools/ListMcpResourcesTool/` | `resources/list` 代理 |
| **MCP 资源读取** | `src/tools/ReadMcpResourceTool/` | `resources/read` 代理 |
| **Skill 加载** | `src/skills/loadSkillsDir.ts` | `getSkillDirCommands()`, `createSkillCommand()`, `activateConditionalSkillsForPaths()` |
| **Skill 工具** | `src/tools/SkillTool/SkillTool.ts` | `validateInput()`, `call()`, `executeForkedSkill()` |
| **Skill 列表** | `src/tools/SkillTool/prompt.ts` | `getPrompt()`, token 预算控制 |
| **内置 Skill** | `src/skills/bundledSkills.ts` | `registerBundledSkill()`, 文件提取 |
| **Frontmatter** | `src/utils/frontmatterParser.ts` | `parseFrontmatter()`, YAML 特殊字符处理 |
| **MCP Skill 桥** | `src/skills/mcpSkillBuilders.ts` | 写入式注册表，防循环依赖 |
| **权限检查** | `src/utils/permissions/permissions.ts` | MCP 工具权限匹配 |
| **工具名解析** | `src/services/mcp/mcpStringUtils.ts` | `buildMcpToolName()`, `mcpInfoFromString()` |
| **延迟加载** | `src/utils/toolSearch.ts` | 超阈值工具延迟注入 |

---

## 六、复现要点

### 6.1 最小 Skill 系统复现

1. **文件发现**：递归扫描 `~/.claude/skills/` 和 `.claude/skills/`，找 `*/SKILL.md`
2. **解析**：用正则提取 `---` frontmatter，YAML 解析，特殊字符自动引号
3. **注册**：构建 Command 对象，区分 inline/fork 执行模式
4. **触发**：SkillTool 作为内部 Tool 注册，模型通过 tool_use 调用
5. **执行**：inline 直接注入 prompt；fork 启动 runAgent 子循环
6. **条件激活**：维护 conditionalSkills Map，文件操作工具触发 glob 匹配

### 6.2 最小 MCP 系统复现

1. **配置**：解析 `.mcp.json` 的 `mcpServers` 字段，Zod schema 验证
2. **连接**：根据 type 创建 Transport，`new Client().connect(transport)`
3. **工具发现**：`tools/list` 获取工具列表
4. **工具桥接**：每个 MCP tool → 内部 Tool 对象，`name = mcp__server__tool`
5. **调用代理**：`Tool.call()` → `client.request('tools/call', { name, arguments })`
6. **结果处理**：截断超大结果，处理二进制 blob，映射错误
7. **生命周期**：memoized 连接、超时检测、指数退避重连、缓存失效

### 6.3 两者集成点

- MCP prompts 通过 `mcpSkillBuilders` 注册为 skill，`loadedFrom: 'mcp'`
- SkillTool 的 `getAllCommands()` 合并本地 commands + MCP skills
- AppState.mcp 统一管理 tools/commands/resources/clients 状态
- 权限系统统一处理 `mcp__` 前缀工具和 `/skill-name` 命令
