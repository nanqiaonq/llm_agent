# 附录二·选学篇 B：autoDream 生产闸门

> 📍 **配套主课件**：`./lesson.md` ·《Claude Code 源码课程·浓缩版第 3 节：多智能体与上下文工程》  
> 🔗 **主章对接点**：第 4 章 4.7 节末路标"详见独立文档..."指向本文档  
> 🎯 **本文档定位**：浓缩版主章外的选学深水篇——原属第 4 章 4.7 节内容外置  
> 📅 **生成日期**：2026-05-21  
> 🔗 **关联文档**：[appendix_A_cache_break_audit.md](./appendix_A_cache_break_audit.md)（选学篇 A 缓存断裂归因）

---

## <center>附录二：选学篇·autoDream 生产闸门</center>

&emsp;&emsp;**这一附录是浓缩版主章外的选学深水篇**，原属于第 4 章 4.7 节。当你已经掌握主章第 4 章「单文件 Session Memory + 10 节模板 + 12K 上限 + 记忆是提示不是真理」这套用户感知层的认知后，如果想下潜到「**什么时候触发抽取 / 怎么防多个抽取进程并发写同一份记忆 / 怎么不污染父 Prompt Cache**」这些工业级问题，这一篇会把 autoDream 的**三级 gate 短路优化、post-sampling hook 八步闭环、5 道闸完整版、PID 反核抢锁、死锁防御、4 Phase 提示词、extractMemories 三向回扣**整套机制拆给你。

> 💡 **如果你不打算抄走整套**：可以只读 B.1（设计动机）+ B.2（三级 gate 短路优化）抓住核心，B.3-B.8 的工程细节按兴趣展开。其余想深挖的，留给你和大模型对话时按需打开。本附录内子节采用 B.x 编号，与原讲义 4.7.x 一一对应。

### B.1 为什么「后台抽取」是长会话 Agent 的必修课

&emsp;&emsp;先还原这个设计背后的工程约束。你的 Agent 在跑一个长会话，用户在对话框里打字，主线程处理用户输入、调用工具、回复结果——这是主流程，不能停、不能慢、不能让「提取记忆」这件事给它加延迟。但记忆又必须及时更新：如果等会话结束再统一抽取，这段会话里的关键发现、踩过的坑、已经定下的决策就全都在「记忆真空」里跑了，下一次会话启动时我们拿到的是过期信息。所以正确的做法是**主线程不停、后台异步跑记忆抽取**——这就是 第 4.2 节 那段源码注释说的「in the background using a forked subagent without interrupting the main conversation flow」。

&emsp;&emsp;但后台异步带来三个新问题：**第一，什么时候触发？** 不能每次工具调用都触发，那太频繁、浪费 token；也不能太少触发，那记忆更新太滞后。**第二，怎么保证不污染父 cache？** forked subagent 跑的是一次独立的 API 调用，如果它用的是和主流程相同的上下文结构，就会让父会话的 Prompt Cache 失效。**第三，怎么防止并发？** 如果上一轮记忆抽取还没跑完，下一轮就触发了，两个进程都在写同一份记忆文件，结果就是覆盖或合并混乱。`Claude Code` 源码用三个机制分别解决这三个问题：三级 gate（解决「什么时候触发」）、`createSubagentContext` 隔离（解决「不污染父 cache」）、`markExtractionStarted` / `markExtractionCompleted`（解决「防并发」）。接下来我们逐层拆开，看每一层的设计意图和可迁移的模式。

### B.2 autoDream 的三级 gate

&emsp;&emsp;`autoDream` 是会话间（跨会话）的**记忆整合**入口，管的是「历史会话的整体记忆」什么时候该做一次全局整合。`services/autoDream/autoDream.ts` 的第 1 至 11 行有一段自带的设计注释，可以逐字直接引用，因为它把三级 gate 的原理说得比任何解释都清楚：

```text
// Background memory consolidation. Fires the /dream prompt as a forked
// subagent when time-gate passes AND enough sessions have accumulated.
//
// Gate order (cheapest first):
//   1. Time: hours since lastConsolidatedAt >= minHours (one stat)
//   2. Sessions: transcript count with mtime > lastConsolidatedAt >= minSessions
//   3. Lock: no other process mid-consolidation
```

&emsp;&emsp;这段注释里有一个细节值得特别注意：**「cheapest first」**。三个 gate 不是随机顺序，而是按计算代价从低到高排列。Time gate 只需要读一个时间戳（一次 stat 系统调用），是最廉价的检查——如果时间不够，后面两个 gate 连跑都不跑。Sessions gate 需要扫描 transcript 文件的 mtime，稍贵一点。Lock 检查在最后，它的代价取决于锁文件的状态，放最后是因为前两个 gate 都通过的情况才是「真正可能触发整合」的时机，这时才值得去争锁。这个设计模式叫做「短路优化」，是高频调用路径里的经典写法——我们在自己的 Agent 里加任何 gate 链，都可以照着这个顺序原则来排列。

&emsp;&emsp;光知道顺序还不够，你应该想知道这两道阈值**默认是多少**。`autoDream.ts:63-66` 定义了一个 `DEFAULTS` 常量：第 64 行 `minHours: 24,` / 第 65 行 `minSessions: 5,`——默认每隔至少 24 小时、且累积至少 5 个新会话才触发一次跨会话记忆整合。这两个数字本身是工业经验值：太频繁会浪费 token,太稀疏会让记忆滞后；24h + 5 会话这个组合大致对应「中度活跃用户每周触发一两次」的节奏（**这是讲师基于阈值的推导估算，非 Anthropic 官方分类**，引用时记得带这条口径）。你在自家 Agent 里抄走时可以以此为初值，再按真实使用频率微调。

&emsp;&emsp;还有一个工程细节值得单独点出来：紧接着的 `getConfig()` 函数（`autoDream.ts:73-93`，函数签名在第 73 行）会先从 **GrowthBook** 读远程配置（feature key `tengu_onyx_plover`），也就是说这两个阈值**可以被 Anthropic 服务端动态下发覆盖**，`DEFAULTS` 只是 GB 返回 `null` 或类型异常时的兜底；源码注释里专门写了「Defensive per-field validation since GB cache can return stale wrong-type values」，每个字段都做了 `typeof === 'number' && Number.isFinite && > 0` 三重校验才采用。这套「**远程开关 + 本地兜底 + 防御性字段校验**」的三件套，是任何需要远程下发参数的 Agent 都该照抄的模式——尤其当你想给团队上线一个新 Agent、又不想每改一个阈值就发一次版本时。

&emsp;&emsp;`autoDream.ts` 还有两个关键依赖值得关注：它从 `'../../utils/forkedAgent.js'` 导入 `runForkedAgent` 和 `createCacheSafeParams`——`createCacheSafeParams` 这个函数名本身就是「不污染父 cache」设计意图的体现；同时从 `'../extractMemories/extractMemories.js'` 导入 `createAutoMemCanUseTool`，这是限制 forked subagent 权限的工具集——记忆整合子 Agent 只被授予了读取记忆文件所需的最小工具集，防止它在后台做超出职责的操作。这两个设计决策合起来，给了我们一个可直接参考的「最小权限 forked subagent」模式。

&emsp;&emsp;下面这段静态验证脚本让你用 `grep` 把 `autoDream.ts` 的注释头和关键 import 打印出来，确认源码里真的有这四个文件组成的目录结构：

```python
"""
静态验证：autoDream 目录结构 + 三级 gate 注释确认

源码锚点：
  - services/autoDream/autoDream.ts:1-11  三级 gate 设计注释
  - services/autoDream/config.ts          阈值配置
  - services/autoDream/consolidationLock.ts  Lock gate 实现
  - services/autoDream/consolidationPrompt.ts  整合用 prompt
实测结果（备份）：
  autoDream.ts Line 1:  // Background memory consolidation. Fires the /dream prompt as a forked
  autoDream.ts Line 5:  // Gate order (cheapest first):
  autoDream.ts Line 6:  //   1. Time: hours since lastConsolidatedAt >= minHours (one stat)
"""

import subprocess
import os

BASE = "/Users/mac/Git/Claude Code/src/services/autoDream"
FILES = ["autoDream.ts", "config.ts", "consolidationLock.ts", "consolidationPrompt.ts"]


def check_files():
    print("=== autoDream 目录文件确认 ===")
    for f in FILES:
        path = os.path.join(BASE, f)
        exists = os.path.exists(path)
        print(f"  {'✓' if exists else '✗'} {f}")


def grep_gate_comments():
    src = os.path.join(BASE, "autoDream.ts")
    if not os.path.exists(src):
        print("[BACKUP] autoDream.ts:1-11 含三级 gate 注释（cheapest first 顺序）")
        return
    result = subprocess.run(
        ["grep", "-n", "Gate order\|cheapest first\|Time:\|Sessions:\|Lock:", src],
        capture_output=True, text=True
    )
    print("=== 三级 gate 注释关键行 ===")
    print(result.stdout.strip() or "(未找到，请检查路径)")


def grep_imports():
    src = os.path.join(BASE, "autoDream.ts")
    if not os.path.exists(src):
        print("[BACKUP] import runForkedAgent, createCacheSafeParams from forkedAgent.js")
        return
    result = subprocess.run(
        ["grep", "-n", "runForkedAgent\|createCacheSafeParams\|createAutoMemCanUseTool", src],
        capture_output=True, text=True
    )
    print("=== autoDream.ts 关键 import ===")
    print(result.stdout.strip() or "(未找到)")


if __name__ == "__main__":
    check_files()
    grep_gate_comments()
    grep_imports()
```

&emsp;&emsp;运行后你会看到四个文件全部存在，并且 `autoDream.ts` 里的三行 gate 注释完整打印出来。`consolidationLock.ts` 专门实现 Lock gate，把「是否有其他进程在整合中」这个状态做成一个独立的可查询模块——这个拆法告诉你，并发锁控制不该和业务逻辑混在一起。

### B.3 sessionMemory.ts 的 post-sampling hook 闭环

&emsp;&emsp;如果说 `autoDream` 管的是「跨会话的历史整合」，那 `sessionMemory.ts` 里的 `extractSessionMemory` 管的是**当前会话内的实时抽取**——每次模型采样结束后，检查要不要更新这次会话的记忆文件。它的实现形式是一个 **post-sampling hook**：`services/SessionMemory/sessionMemory.ts:374` 有一行 `registerPostSamplingHook(extractSessionMemory)`，把这个函数注册进 `utils/hooks/postSamplingHooks.js` 的 hook 队列里。每次主流程的模型采样完成，hook 队列就会被触发，`extractSessionMemory` 就有机会运行一次。这个 hook 注册机制本身是我们可以照搬的接口设计：把「后台异步检查要不要做 X」的逻辑封装成 hook，集中注册到一个队列里，主流程只负责在合适时机触发队列，不需要知道 hook 里具体做什么。

&emsp;&emsp;这个 hook 的主体是 `sessionMemory.ts:272` 定义的 `const extractSessionMemory = sequential(async function (context: REPLHookContext)`。`sequential` 这个包裹函数保证这个 hook 不会并发重入——即使 hook 被触发了两次，第二次也会等第一次跑完再跑，而不是同时跑两个抽取进程去写同一份记忆文件。这是防并发的第一层保障。

&emsp;&emsp;hook 内部是一个完整的八步闭环（对应源码第 277 至 353 行），我们逐步来看：

&emsp;&emsp;**第 1 步（:277）**：`querySource === 'repl_main_thread'` 守门。只有主线程的采样结果才触发记忆抽取，subagent 的采样不触发。这一步最重要：它直接堵死了「记忆抽取 subagent 又触发了下一轮记忆抽取」的递归场景。你在设计任何后台异步逻辑时，这个「只在主线程运行」的守门几乎是必须的。

&emsp;&emsp;**第 2 步（:283–291）**：`isSessionMemoryGateEnabled()` 检查用户是否开启了 Session Memory 功能，未开启直接 return，保证整个机制的开关可控。

&emsp;&emsp;**第 3 步（:297）**：`shouldExtractMemory(messages)` 阈值检查——这是三个真实阈值字段发挥作用的地方，下一节单独讲。

&emsp;&emsp;**第 4 步（:300）**：`markExtractionStarted()` 设置并发锁，防止同一个会话里两个 hook 触发同时跑两个抽取 subagent。

&emsp;&emsp;**第 5 步（:303–308）**：`createSubagentContext(toolUseContext)` 创建隔离上下文——这是「不污染父 cache」设计意图的落地点。隔离上下文和父会话共享工具集，但拥有**独立的消息历史和独立的 cache 状态**，forked subagent 的 API 调用不会复用父会话的 `cache_control` 锚点，不会让父会话下一次调用时「发现 cache 被一个后台 Agent 修改了」。

&emsp;&emsp;**第 6 步（:318–325）**：`await runForkedAgent({...})` 真正跑记忆抽取 subagent，配合 `cacheSafeParams` 保证 cache 友好。注意这一步是 `await`——hook 本身是在后台顺序执行的，但它会等 subagent 跑完再继续下一步，保证记账和解锁发生在抽取完成之后。

&emsp;&emsp;**第 7 步（:344）**：`recordExtractionTokenCount(...)` 记录本次抽取时的 context 大小，用于下一次阈值判断（`minimumTokensBetweenUpdate` 就是对比这里记录的值）。

&emsp;&emsp;**第 8 步（:349）**：`markExtractionCompleted()` 释放并发锁，允许下一轮 hook 触发新的抽取。

&emsp;&emsp;下面这段脚本把八步的行号锚点一次性打印出来，你可以直接对照源码校验：

```python
"""
静态验证：sessionMemory.ts post-sampling hook 闭环八步行号

源码锚点：
  :272  extractSessionMemory = sequential(async function...)   hook 主体定义
  :277  querySource === 'repl_main_thread' 守门
  :283  isSessionMemoryGateEnabled()
  :297  shouldExtractMemory(messages)
  :300  markExtractionStarted()
  :303  createSubagentContext(toolUseContext)
  :318  await runForkedAgent({...})
  :344  recordExtractionTokenCount(...)
  :349  markExtractionCompleted()
  :374  registerPostSamplingHook(extractSessionMemory)
实测结果（备份）：
  Line 272: const extractSessionMemory = sequential(async function (context: REPLHookContext)
  Line 374: registerPostSamplingHook(extractSessionMemory)
"""

import subprocess
import os

SRC = "/Users/mac/Git/Claude Code/src/services/SessionMemory/sessionMemory.ts"

PATTERNS = [
    (r"extractSessionMemory\s*=\s*sequential",   "l.272 hook 主体定义"),
    (r"repl_main_thread",                         "l.277 querySource 守门"),
    (r"isSessionMemoryGateEnabled",               "l.283-291 gate 检查"),
    (r"shouldExtractMemory",                      "l.297 阈值检查"),
    (r"markExtractionStarted",                    "l.300 防并发：开始标记"),
    (r"createSubagentContext",                    "l.303-308 隔离上下文"),
    (r"runForkedAgent",                           "l.318-325 forked subagent"),
    (r"recordExtractionTokenCount",               "l.348 记账"),
    (r"markExtractionCompleted",                  "l.353 防并发：释放"),
    (r"registerPostSamplingHook",                 "l.374 hook 注册"),
]


if __name__ == "__main__":
    if not os.path.exists(SRC):
        print("[BACKUP] 源码文件不在此路径，以下为实测结果备份：")
        for _, label in PATTERNS:
            print(f"  {label} ✓ 已在源码中确认")
    else:
        for pattern, label in PATTERNS:
            result = subprocess.run(
                ["grep", "-nE", pattern, SRC],
                capture_output=True, text=True
            )
            hit = result.stdout.strip()
            print(f"[{label}]")
            print(f"  {hit if hit else '(未找到，请检查行号漂移)'}")
```

&emsp;&emsp;运行后如果源码路径存在，你会看到十处关键行号依次打印出来，覆盖 hook 定义到注册的完整闭环。特别留意 `l.272` 的 `sequential` 包裹和 `l.374` 的 `registerPostSamplingHook`——这两行是整个后台抽取机制的入口点和注册点，是你在自己项目里落地这套设计时需要对应实现的两处核心接口。

### B.4 三个真实阈值字段：什么时候该抽

&emsp;&emsp;第 3 步的 `shouldExtractMemory(messages)` 里用到了三个真实的阈值字段，它们控制着「本次 hook 触发时，到底要不要真正跑 subagent 去抽记忆」。这三个字段来自 `services/SessionMemory/` 的配置层（fact-base 已确认字段名，行号未精确锁定，故只定性给出字段名和语义）：

<style>
.center {
width: auto;
display: table;
margin-left: auto;
margin-right: auto;
}
</style>
<p align="center"><font face="黑体" size=4>sessionMemory 三个抽取阈值字段及判断维度</font></p>
<div class="center">

| 字段名 | 控制维度 | 应用场景 |
|--------|---------|---------|
| `minimumMessageTokensToInit` | **初始化门槛**：会话消息总量达到这个 token 数才允许第一次抽记忆 | 避免会话刚开始就空跑抽取，内容太少抽不出有价值的记忆 |
| `minimumTokensBetweenUpdate` | **更新间隔**：上次抽取后，context 增长了这么多 token 才允许再次抽 | 控制更新频率，防止每次工具调用完都触发，浪费 token |
| `toolCallsBetweenUpdates` | **工具调用数间隔**：上次抽取后，发生了这么多次工具调用才允许再次抽 | 用事件密度而非 token 密度衡量「有没有足够多新内容值得记录」 |

</div>

&emsp;&emsp;这三个字段组合起来是一个「AND 逻辑」——三个条件都满足才触发。设计成三维而不是单维，是因为「值不值得抽」这件事的度量维度不唯一：一个只有 500 token 但包含 20 次工具调用的会话，比一个有 5,000 token 但只发生了 2 次工具调用的会话，在信息密度上可能更值得抽取。把 token 密度和事件密度都考虑进来，比只盯 token 数更能反映真实的「新信息量」。我们在自己的 Agent 里配这三个阈值时，有一个简单的启发式：把 `minimumMessageTokensToInit` 设置成约等于系统提示词的 1.5 倍（保证对话内容已经超过了系统提示词的体量）、把 `minimumTokensBetweenUpdate` 设置成约等于每轮工具调用平均产生的 token 量的 5 倍（大约每 5 轮有意义的工具调用更新一次记忆），`toolCallsBetweenUpdates` 设置成 3 到 5 之间——这三个默认值让记忆更新频率落在「不过频、不滞后」的合理区间。

### B.5 autoDream 引擎层：5 道闸完整版 + PID 反核抢锁 + 死锁防御

&emsp;&emsp;**先把 B.2 的"三级 gate"和这里的"5 道闸"对齐——不矛盾，是同一套门控的两个观察角度**：B.2 那个"三级 gate"出自 `autoDream.ts:1-11` 源码自带的头部设计注释，注释作者那里只列了 **Time / Sessions / Lock 这三道核心 gate**（cheapest first 排序），是设计意图层的摘要。但 `initAutoDream` 函数（`autoDream.ts:122` 开始的 80 多行闭包）真正实现时，在这 3 道核心 gate 的外侧再加了 **feature flag**（最外层关停开关）+ **scan throttle**（time 通过后的 10 分钟节流兜底），合起来是 5 道闸。**3 = 注释里的核心 gate（设计意图）/ 5 = 实测的完整闸（生产实现）**——这一节我们看实现，所以逐道拆开看 5 道在源码里的精确位置和它们各自抵御的失败场景。

<style>
.center {
width: auto;
display: table;
margin-left: auto;
margin-right: auto;
}
</style>
<p align="center"><font face="黑体" size=4>autoDream 5 道闸完整顺序（精确行号锚点）</font></p>
<div class="center">

| 闸序 | 闸名 | 源码位置 | 抵御的失败 |
|---|---|---|---|
| 1 | gate (feature flag) | `autoDream.ts:128` (`isGateOpen()`) + `config.ts:13` (`isAutoDreamEnabled()`) | 用户/组织级关停 autoDream 时不要白跑 |
| 2 | time-gate | `autoDream.ts:130` | 距上次整合不足 `cfg.minHours` 时跳过 |
| 3 | **scan throttle** | `autoDream.ts:143` 配合 `SESSION_SCAN_INTERVAL_MS = 10 * 60 * 1000`（:56） | 即使 time-gate 通过，最近 10 分钟刚扫过就跳过 |
| 4 | session-gate | `autoDream.ts:153` (`listSessionsTouchedSince` + `cfg.minSessions`) | 自上次整合后新会话数不足时跳过 |
| 5 | lock | `autoDream.ts:173-182` (`tryAcquireConsolidationLock`) | 其他进程正在整合时退出 |

</div>

&emsp;&emsp;第 3 道 **scan throttle** 是 B.2 那段「Gate order」注释里没写但源码实测存在的一道：它用一个**进程内的 `lastSessionScanAt` 时间戳**做防抖，即使外层 time-gate 通过、即使 hook 在短时间内被高频触发，10 分钟之内也不会重复扫描 transcript 目录。这道闸的设计意图是「**即使前面的 gate 设计有 bug，最坏情况也能保证 10 分钟内只跑一次**」——这是工程纪律里非常典型的「兜底防御」模式：永远在最贵的操作（这里是扫描整个 transcript 目录）前面加一道时间窗节流，不依赖上游 gate 的正确性。你给自家 Agent 加任何"周期性后台任务"时，这道节流是建议必备的兜底。

#### B.5.1 PID 反核抢锁：无原子操作下的多进程互斥

&emsp;&emsp;第 5 道闸的实现 `tryAcquireConsolidationLock`（`consolidationLock.ts:46`）是这一节最值得抄的工程模式——它在**没有原子操作的环境下**，靠一个文件 + 一次 PID 写入 + 一次读回比对实现了多进程互斥。锁文件名 `LOCK_FILE = '.consolidate-lock'`（`consolidationLock.ts:16`），心跳过期阈值 `HOLDER_STALE_MS = 60 * 60 * 1000`（`:19`，1 小时）。完整逻辑分四步：

&emsp;&emsp;**第 1 步**：读锁文件的 mtime 和 PID 字段。如果文件不存在，直接进第 4 步抢锁。**第 2 步（死锁防御）**：如果文件存在且 mtime 在 1 小时内，再核对 PID 字段所指的进程是否还活着——`if (holderPid !== undefined && isProcessRunning(holderPid))`（`consolidationLock.ts:61`）。如果还活着，说明真有人正在整合，**退出不抢**；如果旧 PID 已经死了（进程崩了忘释放锁），进第 4 步抢锁回收。**第 3 步**：如果文件 mtime 超过 1 小时（持锁者要么挂了要么忘了释放），也进第 4 步回收。**第 4 步（两步抢锁）**：先 `writeFile(path, String(process.pid))` 把自己的 PID 写进去；然后**立即再 `readFile(path)` 读回来**，比对里面的 PID 是不是自己——**如果两个进程同时进入第 4 步，谁后写谁的 PID 留在文件里，先写的那个读回来发现"不是我"就退出**。

&emsp;&emsp;这个 PID 反核机制最有意思的地方是，它不需要任何原子 CAS、不依赖 `flock` 系统调用、也不需要文件锁库——只靠文件系统的两个最朴素能力（写文件 + 读文件）加上"读回来比对"这一招，就在多进程之间做到了正确互斥。你写自家长会话 Agent 时，凡是要在多进程之间做"只让一个进程跑某个后台任务"的事，这个模式都可以直接抄，跨平台无依赖。

### B.6 forked 抽取的关键参数 + consolidationPrompt 4 Phase 提示词

&emsp;&emsp;5 道闸全部通过后，autoDream 会调 `runForkedAgent`（`autoDream.ts:222-230`）——这次调用里有三个关键参数值得记住：`querySource: 'auto_dream'`（标记调用来源，让前面讲的 `previousStateBySource Map` 把它的 cache 状态独立追踪）、`forkLabel: 'auto_dream'`（事件埋点用）、`skipTranscript: true`（**这次 forked 抽取不写进主会话的 transcript 文件**，避免后台日志污染用户能看到的会话历史）。这三个参数合起来，意思是：这次后台抽取既不让父会话的 Prompt Cache 失效、也不在用户的 transcript 里留下"我在后台读你的旧记忆"这种技术性日志噪音。

&emsp;&emsp;forked subagent 跑起来时用的提示词来自 `buildConsolidationPrompt`（`consolidationPrompt.ts:10`），里面是一个完整的 **4 Phase 工作流**（提示词原文锚点在 `consolidationPrompt.ts:24-58`）：

<style>
.center {
width: auto;
display: table;
margin-left: auto;
margin-right: auto;
}
</style>
<p align="center"><font face="黑体" size=4>consolidationPrompt 4 Phase 记忆整合工作流</font></p>
<div class="center">

| Phase | 名字 | 主要动作 |
|---|---|---|
| 1 | **Orient** | `ls` 记忆目录看现有结构 → 读入口文件 `ENTRYPOINT_NAME` → 浏览现有 topic 文件，避免重复创建 |
| 2 | **Gather recent signal** | 优先级：日志（`logs/YYYY/MM/`）→ 漂移的记忆 → transcript 窄字段 grep（**禁止 exhaustive read**）|
| 3 | **Consolidate** | 合并而非新建 / 相对日期转绝对日期 / 删除被反驳的旧事实 |
| 4 | **Prune and index** | 入口文件保持在 `MAX_ENTRYPOINT_LINES` 行内 + 总 ~25KB / 每条索引 ≤ ~150 字符 / 删除 stale 指针 |

</div>

&emsp;&emsp;这 4 个 Phase 自身就是一份你可以直接抄进自己 Agent 记忆维护流程的提示词模板。其中 Phase 2 的 **「禁止 exhaustive read」** 是一条容易忽略但很关键的纪律——长 transcript 是 JSONL 流式文件，整文件读会瞬间占满上下文；正确做法是带很窄的字段做 `grep -rn "<narrow term>" path/ --include="*.jsonl" | tail -50`——你想到什么就 grep 什么，不要漫无边际地通读。这个纪律抄到任何「读历史日志」类的 Agent 工作流里都好用。

### B.7 extractMemories 闭包 + 三向回扣 + drain 优雅关闭

&emsp;&emsp;B.2-B.6 我们看的是 `autoDream`（**跨会话**的全局记忆整合）+ `sessionMemory.ts` 的 post-sampling hook（**会话内**的实时抽取）这两条线。源码里还有第三个核心模块——`services/extractMemories/extractMemories.ts`（21684 字节，是这一片源码里最大的一份），它承载的是"实时抽取"实际跑起来时的引擎层闭包。这一节我们把这个引擎层打开，顺便引出整个第三节课最值得记住的 **三向回扣点**：前面 lesson1 第 5 章 5.5 节教过的 `useCanUseTool` / 第 5 章 5.1 节教过的 `isReadOnly` 是方法、以及本节课 第 7 章 即将看到的 `CacheSafeParams`，它们在 `createAutoMemCanUseTool` 这**一个函数**里同时落地，源码自己写出来了一次"三点一线"演示。

#### B.7.1 extractMemories 引擎的闭包 5 件套

&emsp;&emsp;`initExtractMemories`（`extractMemories.ts:296`）函数返回一个闭包，闭包里维护 5 个跨调用持久的状态变量：

<style>
.center {
width: auto;
display: table;
margin-left: auto;
margin-right: auto;
}
</style>
<p align="center"><font face="黑体" size=4>extractMemories 闭包 5 件套（跨调用持久状态）</font></p>
<div class="center">

| 变量名 | 行号 | 作用 |
|---|---|---|
| `inFlightExtractions: Set<Promise<void>>` | `:303` | 所有「在飞」的抽取 promise 集合，drain 时用 |
| `lastMemoryMessageUuid: string` | `:307` | 游标——每次只看这个 UUID 之后的新消息 |
| `inProgress: boolean` | `:313` | 互斥标志：跑期间下一次调用进来就 stash 不重入 |
| `turnsSinceLastExtraction: number` | `:316` | 计数：上次抽取后又跑了多少轮，配合三档阈值 |
| `pendingContext` | `:320` | 在跑期间又来新调用，把它的 context 暂存这里——本轮跑完后跑一次 trailing run |

</div>

&emsp;&emsp;最值得抄的是**互斥写守恒**那个细节。当 post-sampling hook 触发抽取时，`hasMemoryWritesSince`（`extractMemories.ts:121`）会先检查"主 Agent 在最近这段消息里有没有自己已经写过 memory 文件"。如果有，**直接跳过这次 forked 抽取，并把游标推进到最后一条消息**——意思是：用户/主 Agent 自己已经写过了，后台抽取就不要再跑一遍把刚写的盖掉。这个机制保证了后台机制不会和主线程抢写同一份文件。你在自己的长会话 Agent 里加任何"后台异步写文件"逻辑时，这道"主写检测"是必须的，否则后台跑得越欢，覆盖用户/主线程刚写入的概率就越大。

#### B.7.2 三向回扣点：createAutoMemCanUseTool 是源码自带的三点一线

&emsp;&emsp;`createAutoMemCanUseTool`（`extractMemories.ts:171`）是 forked subagent 跑起来时绑给它的**能力裁决函数**。它的实现里**同时存在**三个我们在前两节课/本节课早先各自学过的独立机制，源码用 50 多行篇幅把它们写在一个函数里：

> 🔗 **回扣点 1：CanUseToolFn 签名（第二节课第 5 章 5.5 节）**——`createAutoMemCanUseTool(memoryDir: string): CanUseToolFn`，返回的是一个 `async (tool, input) => PermissionDecision` 函数。这正是第二节课第 5.5 节那张「Tool 协议三层结构图」里"动态裁决层"在**非 UI 场景**的另一种落地形态——同一份 `CanUseToolFn` 签名，UI 场景里是 React hook，这里是一个普通的 async 函数。**回头看那张图，这次我们看到了"动态裁决层"的第二种实现入口**。

> 🔗 **回扣点 2：isReadOnly 是方法不是布尔（第二节课第 5 章 5.1 节）**——`createAutoMemCanUseTool` 处理 Bash 工具时（`extractMemories.ts:197`）的判断是 `if (parsed.success && tool.isReadOnly(parsed.data))`。注意是 `tool.isReadOnly(parsed.data)`——**调用了 `isReadOnly` 这个方法，把本次调用的实际 input 传进去**——也就是说，Bash 工具能不能在抽取期间被用，取决于这次 Bash 命令是 `ls` / `grep` / `cat` 这类只读命令还是 `rm` / `mv` 这类写命令。这正是第二节课 第 5.1 节 那张 Tool 契约表里说"`isConcurrencySafe` / `isReadOnly` 不是静态布尔而是吃 input 的方法"的实际工程价值——你**只看 input** 就能决定该工具该次调用能不能放行，颗粒度细到每一次调用。

> 🔗 **回扣点 3：CacheSafeParams 与 fork 的工具列表（本节课 第 7.1 节 即将讲到）**——`extractMemories.ts:178-179` 有一句源码原文注释直接讲清楚这个机制：「**giving the fork a different tool list would break prompt cache sharing (tools are part of the cache key — see `CacheSafeParams` in `forkedAgent.ts`)**」。意思是：forked subagent 用的工具列表必须跟主进程一致——因为工具定义是 Prompt Cache key 的一部分。所以 `createAutoMemCanUseTool` 限制 forked subagent 能力的做法**不是改工具列表**，**而是保留同样的工具列表但在 canUseTool 这层拦截**。下一章 第 7.1 节 我们会看到 `CacheSafeParams` 五字段的完整设计——你看到这一节再回头想这句话，会明白"为什么限能力不能走列表层、必须走裁决层"。

&emsp;&emsp;三个独立的概念，在同一个函数 50 多行篇幅里同时出现——这不是教学拼接，是源码自己写出来的「三点一线」演示。读这一段源码的回报，就是把前两节零散学到的三个知识点**在一个真实工程场景里看见它们配合工作**。后面你自己写"后台限权 forked subagent"时，这三点会同时出现在你脑海里。

#### B.7.3 drainPendingExtraction：主流程结束前的优雅关闭

&emsp;&emsp;最后一个值得记住的工程纪律是 `drainPendingExtraction`（`extractMemories.ts:611`）。它是主流程在退出前必须 `await` 的清理函数——意思是「等所有在飞的抽取都跑完再退出」。源码里这个函数被 `print.ts` 在 `gracefulShutdownSync` 之前调用，配合一个 5 秒的优雅关闭超时——**如果主进程立刻退出，forked subagent 会被父进程信号杀掉，刚抽到一半的记忆就丢了**。所以正确的关闭流程是三步：① 主回复 flush 完了 → ② 调 `drainPendingExtraction` 等抽取完成 → ③ 最后才 `gracefulShutdownSync` 真正退出。

&emsp;&emsp;你在自家长会话 Agent 里如果有任何「后台异步任务」，这个 drain 模式都是必须的——不是"我后台跑了就行了"，而是"我退出之前先等后台跑完，避免数据丢失"。这一点很容易被忽略，但它是把"实验玩具"和"生产能用"分开的关键一道工序。

### B.8 你能抄走什么：四件套设计模式

&emsp;&emsp;补完引擎层（B.5 autoDream 引擎、B.6 4 Phase 提示词、B.7 extractMemories 闭包与三向回扣）之后，我们把整套机制收成一个可平移的设计模式骨架。无论你用的是 `LangGraph`、自家的 loop 框架、还是从零搭的 Agent，只要有「长会话 + 需要跨会话记忆」的需求，这四件套都可以平移进去：

&emsp;&emsp;**第一件：post-sampling hook 接入点**。在每次主模型采样结束后触发一次轻量检查——这是「后台异步不打断主流程」的基础设施。关键点：hook 必须只在主线程触发（守门），hook 函数必须是 sequential / 串行的（防并发重入），hook 里的所有重操作（比如跑 subagent）都是 await 异步等待完成再释放锁。这一件套的核心价值是让「要不要记」的检查对主流程完全透明。

&emsp;&emsp;**第二件：forked subagent + 隔离上下文**。记忆抽取不是在主会话上下文里直接跑 LLM，而是 fork 出一个独立的子 Agent 实例，给它一个隔离的消息历史和独立的 cache 状态。这是「不污染父 cache」的根本保证，也是「记忆抽取失败不影响主流程」的故障隔离。在 LangGraph 里，这对应的是开一个新的 `invoke` 调用，不复用父 `checkpointer` 的状态。

&emsp;&emsp;**第三件：三档阈值门控**。用 token 初始化门槛 + token 增长间隔 + 事件数间隔三维度联合判断「要不要抽」，而不是靠定时器或者每次都跑。这套三档设计让记忆更新频率自适应会话的活跃程度——活跃会话高频更新、沉默会话少触发。

&emsp;&emsp;**第四件：markStarted / markCompleted 并发锁**。用两个标记函数把「抽取进行中」这个状态显式管理起来，任何新的抽取触发先查这个标记，已有进行中则跳过。这比用文件锁或 DB 锁轻量得多，适合单进程的 Agent loop。

&emsp;&emsp;下面这段代码是四件套的 Python 骨架，把整个闭环串起来，让你看清楚各层之间的调用关系：

```python
"""
记忆抽取四件套骨架：post-sampling hook + forked subagent + 三档阈值 + 并发锁

可迁移内核：
  - post-sampling hook 接入点（sequential 串行保证）
  - forked subagent + createSubagentContext 隔离（不污染父 cache）
  - 三档阈值联合判断（minimumMessageTokensToInit / minimumTokensBetweenUpdate / toolCallsBetweenUpdates）
  - markExtractionStarted / markExtractionCompleted 并发锁
源码锚点：
  sessionMemory.ts:272  extractSessionMemory = sequential(...)
  sessionMemory.ts:277  querySource === 'repl_main_thread' 守门
  sessionMemory.ts:297  shouldExtractMemory(messages) 阈值检查
  sessionMemory.ts:300  markExtractionStarted()
  sessionMemory.ts:303  createSubagentContext(toolUseContext)
  sessionMemory.ts:318  await runForkedAgent({...})
  sessionMemory.ts:344  recordExtractionTokenCount(...)
  sessionMemory.ts:349  markExtractionCompleted()
  sessionMemory.ts:374  registerPostSamplingHook(extractSessionMemory)
生产替换点：
  - run_forked_agent → 换成你的 LangGraph invoke / asyncio.create_task
  - estimate_tokens → 换成真实 tokenizer
  - memory_file → 换成你的持久化存储（文件 / Redis / DB）
本代码已在 conda 环境真跑验证。
"""

import asyncio
from dataclasses import dataclass, field


# === 三档阈值配置（对应 minimumMessageTokensToInit / minimumTokensBetweenUpdate / toolCallsBetweenUpdates）===
MINIMUM_MESSAGE_TOKENS_TO_INIT = 2000     # 初始化门槛：会话消息够长才首次抽取
MINIMUM_TOKENS_BETWEEN_UPDATE  = 1000     # 更新间隔：上次抽取后新增 token 够多才再抽
TOOL_CALLS_BETWEEN_UPDATES     = 3        # 工具调用数间隔：发生足够多工具调用才再抽


@dataclass
class ExtractionState:
    """并发锁 + 记账状态（对应 markExtractionStarted/Completed + recordExtractionTokenCount）。"""
    is_extracting: bool = False
    last_extraction_tokens: int = 0
    tool_calls_since_last: int = 0


def estimate_tokens(messages: list) -> int:
    """粗估 token 数（生产换真实 tokenizer）。"""
    return sum(len(str(m)) // 4 for m in messages)


def should_extract_memory(messages: list, state: ExtractionState) -> bool:
    """
    三档阈值联合判断（对应 sessionMemory.ts:297 shouldExtractMemory）。
    三个条件必须同时满足才触发抽取。
    """
    total_tokens = estimate_tokens(messages)
    # 条件①：会话消息总量超过初始化门槛
    if total_tokens < MINIMUM_MESSAGE_TOKENS_TO_INIT:
        return False
    # 条件②：上次抽取后新增 token 足够多
    new_tokens = total_tokens - state.last_extraction_tokens
    if new_tokens < MINIMUM_TOKENS_BETWEEN_UPDATE:
        return False
    # 条件③：上次抽取后工具调用数足够多
    if state.tool_calls_since_last < TOOL_CALLS_BETWEEN_UPDATES:
        return False
    return True


async def run_forked_agent(isolated_context: dict, memory_file: list) -> str:
    """
    模拟 forked subagent 跑记忆抽取（对应 sessionMemory.ts:318 runForkedAgent）。
    
    关键：isolated_context 是隔离的上下文，不复用父会话 cache 状态。
    生产替换点：换成你的 LLM 调用（LangGraph invoke / anthropic.messages.create）。
    """
    await asyncio.sleep(0)  # 模拟异步 IO
    extracted = f"[抽取记忆] 处理了 {len(isolated_context['messages'])} 条消息"
    memory_file.append(extracted)
    return extracted


def create_subagent_context(parent_context: dict) -> dict:
    """
    创建隔离的 subagent 上下文（对应 sessionMemory.ts:303 createSubagentContext）。
    
    关键：独立消息历史 + 独立 cache 状态，不污染父会话。
    """
    return {
        "messages": list(parent_context.get("messages", [])),  # 复制，不共享引用
        "cache_state": {},      # 全新 cache 状态，和父会话完全隔离
        "is_subagent": True,    # 标记为 subagent，让 should_extract_memory 的守门生效
    }


class SessionMemoryHook:
    """
    post-sampling hook 主体（对应 sessionMemory.ts:272 extractSessionMemory = sequential(...)）。
    sequential 语义通过 asyncio.Lock 实现：上一轮未完成时新触发等待，不并发重入。
    """

    def __init__(self):
        self._state = ExtractionState()
        self._lock = asyncio.Lock()          # sequential：串行不并发
        self._memory_file: list = []

    def register(self, hook_queue: list):
        """对应 sessionMemory.ts:374 registerPostSamplingHook(extractSessionMemory)。"""
        hook_queue.append(self.extract_session_memory)

    async def extract_session_memory(self, context: dict):
        """
        hook 主体，八步闭环（sessionMemory.ts:272-353）。
        """
        # Step 1 (l.277)：只在主线程运行，subagent 触发直接 return
        if context.get("query_source") != "repl_main_thread":
            return

        async with self._lock:              # sequential：保证不并发
            # Step 2 (l.283-291)：gate 开关检查（教学简化：默认开启）
            if not context.get("session_memory_enabled", True):
                return

            # Step 3 (l.297)：三档阈值检查
            if not should_extract_memory(context["messages"], self._state):
                return

            # Step 4 (l.300)：并发锁（此处由 asyncio.Lock 替代 markExtractionStarted）
            self._state.is_extracting = True

            try:
                # Step 5 (l.303-308)：创建隔离上下文
                isolated_ctx = create_subagent_context(context)

                # Step 6 (l.318-325)：forked subagent 跑抽取
                await run_forked_agent(isolated_ctx, self._memory_file)

                # Step 7 (l.348)：记账，用于下一次阈值判断
                self._state.last_extraction_tokens = estimate_tokens(context["messages"])
                self._state.tool_calls_since_last = 0   # 重置工具调用计数

            finally:
                # Step 8 (l.353)：释放锁
                self._state.is_extracting = False


# === 演示：模拟长会话中 hook 的触发与防并发行为 ===
async def main():
    hook = SessionMemoryHook()
    post_sampling_hooks = []
    hook.register(post_sampling_hooks)

    # 主流程每次采样完触发 hook 队列
    async def fire_hooks(context):
        for h in post_sampling_hooks:
            await h(context)

    # 会话刚开始，消息太少，不触发
    short_ctx = {
        "query_source": "repl_main_thread",
        "session_memory_enabled": True,
        "messages": [{"role": "user", "content": "hi"}],
    }
    hook._state.tool_calls_since_last = 5   # 假设工具调用数够了
    await fire_hooks(short_ctx)
    assert len(hook._memory_file) == 0, "消息太少不应触发抽取"
    print("[ASSERT-1 PASS] 消息不足，抽取未触发")

    # 消息够长 + 工具调用够多，触发
    long_messages = [{"role": "user", "content": "x" * (MINIMUM_MESSAGE_TOKENS_TO_INIT * 4 + 100)}]
    rich_ctx = {
        "query_source": "repl_main_thread",
        "session_memory_enabled": True,
        "messages": long_messages,
    }
    hook._state.tool_calls_since_last = TOOL_CALLS_BETWEEN_UPDATES
    await fire_hooks(rich_ctx)
    assert len(hook._memory_file) == 1, "条件满足应触发一次抽取"
    print(f"[ASSERT-2 PASS] 条件满足，触发抽取 1 次，记忆文件：{hook._memory_file}")

    # subagent 触发不递归
    sub_ctx = {**rich_ctx, "query_source": "subagent"}
    hook._state.tool_calls_since_last = 100  # 即使阈值超了
    hook._state.last_extraction_tokens = 0
    await fire_hooks(sub_ctx)
    assert len(hook._memory_file) == 1, "subagent 触发不应递归抽取"
    print("[ASSERT-3 PASS] subagent 守门生效，未递归触发")
    print("[ALL PASS] post-sampling hook 闭环：三档阈值 + 防递归 + 并发锁，全路径成立")


if __name__ == "__main__":
    asyncio.run(main())
```

&emsp;&emsp;运行这段代码，我们会看到三个断言依次通过：消息不足不触发、三档阈值全满足时触发一次、subagent 来源被守门拦住不递归。这三条路径覆盖了生产环境里最常出现的三种边界情况。把它迁移进你的 Agent，三个替换点：`run_forked_agent` 里换成你的 LLM 调用（LangGraph 的 `graph.invoke` 或 `anthropic.messages.create`）；`estimate_tokens` 换成真实 tokenizer；`_memory_file` 换成你的持久化存储。`sequential` 语义这里用 `asyncio.Lock` 模拟，生产里如果是多进程 Agent 需要换成文件锁或分布式锁，但单进程 loop 里 `asyncio.Lock` 完全够用。一句话内核：**post-sampling hook + forked subagent + 三档阈值 + 并发锁，这四件套合起来，就是任何长会话 Agent 都需要的记忆抽取基础设施**。


---
