# Interaction Architecture · 24 页交互架构

## Lesson Thesis

**核心命题**：让学员从"知道 Claude Code 多智能体大概是干嘛的"→ "能讲清四个致命问题各自的解法 + 五个反直觉锚点 + 八模式速查 + 四对张力 + 三句话自测"。

**必须可见的机制**（不可视化就无法真正理解）：
1. 13_000 提前量 → 撞死结的机制需要时间轴可视
2. 5 Agent ≈ 1 成本 → 缓存共享需要参数沙盘体感
3. 单 Agent 串行爆炸 vs 多 Agent 隔离不爆 → 并行对比需要沙盘实证
4. lost update 事故 → 时序模拟器才能真正记住"两 worktree 都写 267"

**学员最常见误解 Top 3**：
- "上下文满了再压不就行了" → S002 打碎
- "记忆 = Agent 必须遵守的事实" → S008 打碎
- "5 个 Agent = 5 倍成本 / 7 种 TaskState = 7 种协同模式" → S013 / S017 打碎

**成功判据**：学员看完能在 30 秒内答出三句话自测（autoCompact 13_000 / 记忆免责声明 / Fork ≈1 成本带口径）。

## 逐页交互决策（24 页完整分配）

| page_id | title | teaching_role | interaction_strength | chosen_pattern | four_axis_score | justification | anti_pattern_check |
|---------|-------|--------------|---------------------|----------------|-----------------|---------------|-------------------|
| S001 | 浓缩第 3 节 · 多智能体与上下文工程 | hook | 🟢 | T-COVER | EP:3 MV:1 IC:3 OL:3=10 | 封面静态聚焦 · 三问开场（#1/#2/#4）只需视觉锚定无需交互 | true |
| S002 | 上下文为什么会爆 · 13_000 提前量 | mechanism | 🔴 | Bait & Switch Reveal | EP:3 MV:2 IC:2 OL:3=10 | 反直觉点必须先抛悬念（满了再丢？）再 reveal · 死结动画静态页无法表达 | true |
| S003 | 四层压缩机制全景 | mechanism | 🟡 | Selector + Detail Panel | EP:2 MV:2 IC:3 OL:3=10 | 4 机制并列 · hover/click 查看常量是轻交互最佳场景 · 静态表会信息密度过载 | true |
| S004 | Prompt Cache · 稳定区 vs 动态区 | mechanism | 🔴 | Two-Zone Drag Highlight | EP:3 MV:3 IC:2 OL:3=11 | 分界线拖动看缓存命中变化 · 这种"差一字节就断"的体感非交互不能传 | true |
| S005 | PromptStateSnapshot 检测机制 | example | 🟡 | T-CODE-TRANSLATE | EP:2 MV:1 IC:3 OL:3=9 | 源码 :227 左右对照 · 中度信息密度 · hover 看注释足够 | true |
| S006 | 记忆不是分层数据库 · 打碎直觉 | mechanism | 🔴 | Bait & Switch Reveal | EP:3 MV:2 IC:3 OL:3=11 | 先呈现"想象的分层 DB"图 → 点击"看源码"切换 · 反差是核心教学事件 | true |
| S007 | 10 节模板结构 | mechanism | 🟡 | Selector + Detail Panel | EP:2 MV:2 IC:3 OL:3=10 | 10 节卡片 · click 看每节职责 · 标尺 12000 · 完美轻交互场景 | true |
| S008 | 「记忆是提示不是真理」 | mechanism | 🔴 | Annotation Reveal | EP:3 MV:2 IC:3 OL:3=11 | 源码 prependUserContext 逐字呈现 + 关键句红框渐入 · 配 4 步反直觉问答 | true |
| S009 | 双轨记忆 · SessionMemory vs memdir | comparison | 🟡 | Left/Right Compare | EP:2 MV:2 IC:3 OL:3=10 | 左右对比卡 · hover 看差异 · 反 RAG 反直觉用底部金句静态强调 | true |
| S010 | 单 Agent 串行的物理上限 | mechanism | 🔴 | Bar-Grow Crash | EP:3 MV:3 IC:2 OL:3=11 | 上下文条逐步攀升撞红线 · 必须动态时序才能传"必爆"的体感 | true |
| S011 | 子 Agent 隔离对比沙盘 | mechanism | 🔴🔴 | T-CHAT-FLOW Side-by-Side | EP:3 MV:3 IC:1 OL:2=9 | 单 vs 多 Agent 并行执行 4 子任务 · 父 Agent 上下文实时差异 · 摘要 3-5 词飘字 · 这是本节最核心反直觉的视觉化场景 | true |
| S012 | isolation 字段诚实划界 | example | 🟡 | T-CODE-TRANSLATE | EP:2 MV:1 IC:3 OL:3=9 | 源码三元 external==='ant' 条件编译 · 左右对照 + 注释标"外部仅 worktree" | true |
| S013 | 5 个 Agent ≈ 1 个成本 · 参数沙盘 | mechanism | 🔴🔴 | Parameter Sandbox | EP:3 MV:3 IC:1 OL:2=9 | 拖滑块改 N + hit_ratio 实时看 fork vs 独立成本曲线 · 这条反直觉公式不交互证明就没说服力 | true |
| S014 | CacheSafeParams 五字段 | mechanism | 🟡 | Selector + Detail Panel | EP:2 MV:1 IC:3 OL:3=9 | 5 字段卡 · click 看源码行内注释 + 缓存键 5 要素分组承载图 | true |
| S015 | Coordinator · 编排者不下场 | mechanism | 🔴 | Role Boundary Reveal | EP:3 MV:2 IC:3 OL:3=11 | 中央 Coordinator → reveal orchestrates 关键词 → 系统提示词换一套 · 三条边界浮出（只分活/只收活/不下场）| true |
| S016 | SendMessage 点对点通信 | mechanism | 🟡 | Network Topology | EP:2 MV:2 IC:3 OL:3=10 | 扁平拓扑图 · hover worker 看 ID 寻址 · 对比"层级转发"画灰色弱化 | true |
| S017 | 7 种 TaskState 不是协同模式 | example | 🔴 | Misconception Bust | EP:3 MV:1 IC:3 OL:3=10 | 先抛误解 → reveal 源码 tasks/types.ts 实际是状态类型 · 数字纪律警示 | true |
| S018 | 没有 MAX_CONCURRENT 常量 | summary | 🟢 | Honest Boundary | EP:2 MV:1 IC:3 OL:3=9 | 文本为主 · 强调"没核实就不报数字" · 数字纪律红框 · 不需交互 | true |
| S019 | 三层 routing 实战账单 | example | 🔴 | Bar Comparison Reveal | EP:3 MV:3 IC:2 OL:3=11 | 三组对比柱（51%/40%/11.9%）逐步揭示 · 配金句"点披萨叫直升机" + 数据口径警告 | true |
| S020 | 四问题闭环 · 朴素 vs 三约束端到端 | summary | 🔴🔴 | Side-by-Side Simulator | EP:3 MV:3 IC:1 OL:3=10 | 左 30 行裸奔撞墙 vs 右三约束版全跑完 · 12 step token 曲线对比 · 这是两节课最终答案的视觉化 | true |
| S021 | 八模式速查表 | summary | 🟡 | Sortable Table + Self-Check | EP:2 MV:2 IC:3 OL:3=10 | 8 模式行 · 带"对照自己项目"勾选框即时反馈 · 鼓励挑 ≥1 改造点 | true |
| S022 | Reflection-Critic · 第 9 模式 2026-04 翻牌 | example | 🔴 | Triple Evidence Stack | EP:3 MV:2 IC:3 OL:3=11 | 三重证据叠加（Cognition 2 bug/PR · Anthropic rubric · VERIFICATION_AGENT flag）· 时间线动画必须 | true |
| S023 | 四对张力 · 这把尺 | summary | 🔴 | Tension Balance | EP:3 MV:3 IC:2 OL:3=11 | 脊柱挂四天平 · 上节 2 对 + 本节 2 对（静态/动态 · 集中/分治）高亮 · 强调"这把尺贯穿两节" | true |
| S024 | 三句话自测 + Bitter Lesson | summary | 🔴 | Q&A Flip Card | EP:3 MV:2 IC:3 OL:3=11 | 3 翻卡 click reveal 答案 · 底部金句 model≈CPU/harness≈OS 类比 · 学员自测仪式感 | true |

### Pattern Selection Summary

- **保留模式**：
  - T-COVER（封面）
  - Bait & Switch Reveal（反直觉打破直觉 · S002/S006/S017）
  - Selector + Detail Panel（多并列概念展开 · S003/S007/S014）
  - Two-Zone Drag Highlight（稳定区/动态区分界拖动 · S004）
  - T-CODE-TRANSLATE（源码对照 · S005/S012）
  - Annotation Reveal（关键句渐入 · S008）
  - Left/Right Compare（双轨对比 · S009）
  - Bar-Grow Crash（时序动画撞墙 · S010）
  - T-CHAT-FLOW Side-by-Side（多 Agent 并行沙盘 · S011 🔴🔴）
  - Parameter Sandbox（参数调试 · S013 🔴🔴）
  - Role Boundary Reveal（角色边界揭示 · S015）
  - Network Topology（拓扑图 · S016）
  - Honest Boundary（诚实划界静态文本 · S018）
  - Bar Comparison Reveal（数据柱对比 · S019）
  - Side-by-Side Simulator（端到端对比模拟器 · S020 🔴🔴）
  - Sortable Table + Self-Check（速查表 · S021）
  - Triple Evidence Stack（三重证据 · S022）
  - Tension Balance（张力天平 · S023）
  - Q&A Flip Card（翻卡自测 · S024）

- **拒绝模式**：
  - ❌ 装饰性 GSAP 入场（反 anti-pattern · 每页都搞会审美疲劳）
  - ❌ 11 段 MVP 代码独立成页（违反 brief 硬禁 · 合入对照页或 hover 显示）
  - ❌ 全部页都重交互（违反 IC 经济学 + 学员认知负荷）
  - ❌ 14 张待补图独立成页（图作为页内视觉元素 · 不当主体）

### 🔴🔴 重交互页列表（路由给 interactive-eng）

```json
["S011", "S013", "S020"]
```

### 🔴🔴 失败模式预防清单（每页基于本页 chosen_pattern 推导）

#### S011 子 Agent 隔离对比沙盘（T-CHAT-FLOW Side-by-Side）失败模式（FM）

- **FM-1**：state 切换（idle → serial_running → parallel_running → compared）时 GSAP timeline 残留导致父 Agent 上下文条数值闪烁错位 → 防御：state 切换前 `tl.kill() + .clear()` 显式清理
- **FM-2**：4 个子 Agent 并行 stagger 时间不同步导致视觉对比节奏破坏 → 防御：`stagger: { each: 0.15, from: "start" }` 显式声明 · 不依赖默认值
- **FM-3**：摘要 "3-5 词" 飘字超出视口被截断 / 飘字位置撞到上下文条 → 防御：`overflow: visible + position: absolute + clamp(maxX, minX, x)` 限定飘字轨迹

#### S013 5 个 Agent ≈ 1 个成本参数沙盘（Parameter Sandbox）失败模式（FM）

- **FM-1**：滑块连续拖动 Chart.js 重绘卡顿 → 防御：`debounce(updateChart, 100ms)` + `requestAnimationFrame`
- **FM-2**：hit_ratio = 1.0 边界值时等效独立 Agent 数公式分母变化导致曲线突变 → 防御：边界平滑显示 + 文案"如果没有缓存就退化为线性"
- **FM-3**：N = 1 单 Agent 时公式中 `(N-1) × ratio` 项为 0 看不到 hit 效果 → 防御：N≥2 才显示"节省比率"右侧标签 + N=1 时显示"基线"灰色态

#### S020 朴素 vs 三约束端到端模拟器（Side-by-Side Simulator）失败模式（FM）

- **FM-1**：左右两轨道 requestAnimationFrame 不共享时基导致 6 任务跑完时长不一对比失焦 → 防御：`sharedClock = performance.now()` 共享时基 + 同步 totalDuration
- **FM-2**：朴素版第 4 任务撞墙瞬间数字闪烁太快学员看不清 → 防御：撞墙时 `gsap.pause(800ms)` + 红色脉冲 3 次再继续
- **FM-3**：12 step 序列跑完后 raf 未清导致 cleanup 阶段内存泄漏 → 防御：`return () => { cancelAnimationFrame(rafId); tl.kill(); }` slideHook 标准 cleanup

### motion_level 约束应用

- 当前 motion_level：moderate
- moderate 模式：🔴🔴 重交互 3 页保留 · 🔴 step-reveal 8 页保留 · 不降级
- 已受影响的页面：无（无降级触发）

### 概念覆盖追溯（Phase 1.5 quality-guard 消费）

每页 `chosen_pattern` 都明确 · 每页 `justification` 都不空 · 每页 `anti_pattern_check` 都 boolean · 等 architect 阶段写入 slide_structure.json 时通过 `ia_ref` 反查回本文件锚点。

### 设计哲学回扣（来自主对话 + lesson.md）

- **教学三色严守**：蓝色 (#4a90e2) = 源码事实 / 紫色 (#6a5acd) = 教学归纳 / 粉色 (#ff6b9d) = 数据口径警告
- **反直觉锚点视觉事件化**：5 个核心反直觉（S002/S006/S008/S013/S017/S019/S022 共 7 处）必走 reveal 模式 · 学员"哦原来如此"瞬间通过动画强化
- **数字纪律视觉化**：lesson.md 反复强调"可 grep 复核"的数字（13_000 / 12_000 / 3-5 / 7 / 8000 / 187_000）每次出现配 file:line 引用 + 蓝色字 · 推导数字（51% / 40% / 74.8%）配粉色字 + ⚠️ 口径警告
