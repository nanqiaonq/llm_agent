# 课件需求简报

## 核心目标

把 `Claude Code` 源码课浓缩版第 3 节「多智能体与上下文工程」（1295 行 lesson.md / 9 章 / 11 段 MVP 代码 / 14 张图占位 / 4 个数据表）改造成 24 页可交互 HTML 课件。让学员在 30-45 分钟扫读中**真正记住 5 个反直觉锚点**（13_000 提前量 / 记忆是提示不是真理 / 5 Agent ≈ 1 成本 / RAG 不是必须 / lost update 事故），并能脱口而出三句话自测。

## 受众画像

- **技术背景**：已完成第 1 节学习 · 熟悉五层架构 + QueryLoop + Tool 契约 + 扩展三件套地基
- **语言**：会读 Python（不需懂 TypeScript） · 会调 LLM API
- **使用场景**：开发者电脑大屏 / 会议室投屏自学 + 教练带练（非手机端 · 非移动课件）
- **痛点**：浓缩版信息密度高 · 反直觉锚点多 · 纯 markdown 容易扫读漏点 · 需要 HTML 视觉锚点强化

## 视觉风格倾向

- **方向**：暗色科技风 / "源码深空" 调性（契合 Claude Code 主题）
- **参考锚点**：`hermes-aesthetic-anchor`（PASS 基准 · 黑底暖色金属 + 严谨）/ `weights-anchor`（matrix-green-dark）
- **排斥**：浅色商务风 / 卡通可爱 / 极简性冷淡（不匹配源码深度课内容厚度）

## 交互密度预期

- **🟢 static**：4 页（封面 / 章节衔接 / 纯结论）
- **🟡 mild**：9 页（数据表 hover / 概念卡片切换 / Selector + Detail Panel）
- **🔴 step-reveal**：8 页（反直觉揭秘 + 概念逐步展开 + 推理链揭示）
- **🔴🔴 重交互**：3 页（S011 子 Agent 隔离对比沙盘 / S013 5 Agent ≈ 1 成本参数沙箱 / S020 朴素 vs 三约束端到端模拟器）

设计基线：偏深度演练（教学型）· 反直觉锚点必须独立成页 · 数据点必须有"可 grep 复核"的视觉证据感

## 硬性禁止项

- ❌ 任何 HTML/CSS/JS 数字、教学归纳冒充 Anthropic 官方数字（必带「推导」「讲师评估」口径）
- ❌ 教学命名与源码事实混淆（蓝色=源码事实 / 橙色=教学归纳 / 红色=数据口径警告 三色严格区分）
- ❌ 反直觉锚点直接呈现答案（必先抛悬念 · 等用户点击 → reveal）
- ❌ 每段 MVP 代码独立成页（合并入"机制对照" T-CODE-TRANSLATE）
- ❌ MAX 数字凭空（13_000 / 12_000 / 3_000 / 50_000 / 3-5 词 / 10 节 必精确到 file:line）

## 用户期望感受

「原来这么简单 · 我以为很难」+「终于搞清楚了 · 之前一直没想明白」混合 —— 浓缩版的杀手锏是"反直觉点破窗"，HTML 化要让这种"哦原来如此"的瞬间通过视觉事件强化。

## creativity_level

medium · methodology 必学 / pattern 选用 / independent-artistic 可借鉴

> 理由：本课件需要 8 类 chosen_pattern（Bait & Switch / Two-Zone Highlight / Annotation Reveal / Parameter Sandbox / Selector + Detail Panel / Triple Evidence Stack / Q&A Flip Card / Side-by-Side Simulator）· 单纯 low 档 pattern 库不够 · 但不必偏离 methodology 18 条硬约束 · medium 最匹配。

## source_type

material

> 源材料：`/Users/mac/PycharmProjects/JupyterProject/ClaudeCode/第三节课/claude-code-condensed-lesson2/lesson.md`（1295 行 / 9 章 + 附录三 / 11 MVP 代码 / 14 待补图 / 4 数据表）
> 配套源材料：`appendix_A_cache_break_audit.md` + `appendix_B_autodream_production.md`（选学深水篇 · HTML 24 页不外置 · 课件结尾文字链接到 markdown 文件即可）

## 24 页结构概览（已在主对话深度设计 · 锁定）

| 章节 | 页码 | 内容 |
|---|---|---|
| 第 1 章 | S001 | 封面 · 多智能体与上下文工程 |
| 第 1 章（大纲）| S001b | 今日课程地图 · 3 大约束 + 1 收束 · 4 卡 2x2 + 反直觉锚点横条 |
| 阶段 ① 介绍页 | S001c | 接下来 → ① 工作台 · 上下文不是丢·是分层压缩+缓存重用 |
| 第 2-3 章 · 约束工作台 | S002-S005 | 上下文为什么爆 / 四层压缩 / Prompt Cache / PromptStateSnapshot |
| 阶段 ② 介绍页 | S005b | 接下来 → 记忆·单文件记忆系统 · 一份 markdown 够用 |
| 第 4 章 · 约束记忆 | S006-S009 | 不是分层 DB / 10 节模板 / 记忆是提示不是真理 / 双轨记忆 |
| 阶段 ③ 介绍页 | S009b | 接下来 → ③ 多 Agent · 5 ≈ 1 反直觉 |
| 第 5-7 章 · 多 Agent | S010-S017 | 单 Agent 痛点 / 子 Agent 隔离 / isolation 划界 / 5≈1 成本 / CacheSafeParams / Coordinator / 点对点 / 7 TaskState 不是协同模式 |
| 第 8 章 · 务实约束 | S018-S019 | 没有 MAX 常量 / 三层 routing 账单 |
| 阶段 ④ 介绍页 | S019b | 接下来 → ④ 收束 · 约束本身就是产品力 |
| 第 9 章 · 收尾 | S020-S024 | 四问题闭环 / 八模式 / Reflection-Critic 第 9 模式 / Critic 生命周期动画 / 四对张力 |
| 附录 | S025 | 三句话自测 + Bitter Lesson 哲学收束 |

详细每页内容 / chosen_pattern / EP-MV-IC-OL 四轴评分见主对话设计输出（已锁定 · IA 阶段直接消费）。

## Phase 计划

按 Gate-driven 严格门控：Gate 0 brief → Gate 1 风格三选一 → Gate 2 IA 24 页分配 → Phase 1 architect → **Gate 3 骨架预览（用户最关心 · 真启 HTTP server 看风格+工具栏）** → Phase 3a 4 批 21 页 slide-writer 并行 → Phase 3a.5 逻辑流审查 → Phase 3b 3 重交互页 → Phase 3c + 交付。每个 Gate 真等用户拍板。
