# Phase 3a · 20 页详设计 spec

> slide-writer 按本 spec 写每页 slide html · 4 批并行：
> - 批1 C2-C3 (4 页) S002-S005
> - 批2 C4 (4 页) S006-S009
> - 批3 C5-7 (6 页) S010 / S012 / S014-S017
> - 批4 C8-C9 (6 页) S018-S019 / S021-S024
> - 留 Phase 3b：S011 / S013 / S020 (🔴🔴 重交互)

---

## 通用铁律（所有页严守）

### 1. HTML 结构铁律
- **slide html 文件外层禁止加 `<div class="slide">`** · main.js 会自动包一层 active slide · 双层包导致 opacity:0 看不见
- 直接以 `<div class="page-content">` 或具体功能容器开始
- 不要任何 `<html>` / `<body>` / `<head>` / `<!DOCTYPE>` 文档级标签

### 2. CSS 颜色全用变量
- `var(--primary)` 静谧青 `#5a8a8a` · 主色调
- `var(--secondary)` 黄铜金 `#c4923a` · 辅助
- `var(--accent)` rust 红 `#c44545` · 强调
- `var(--bg-deep)` 暖砂米 `#f4ede0` · 页面背景
- `var(--bg-mid)` 浅砂 `#ecdfca` · 卡片/工具栏背景
- `var(--text-primary)` 深棕黑 `#2a2418` · 正文
- `var(--text-dim)` 砂棕灰 `#5a4d38` · 辅助
- `var(--card-bg)` rgba(196,146,58,0.1)
- `var(--card-border)` rgba(196,146,58,0.3)
- `var(--card-shadow)` 0 10px 40px rgba(90,77,56,0.15)
- 字体 `var(--font-display)` Inter / `var(--font-code)` JetBrains Mono
- 禁纯黑纯白 · 阴影用棕色调 rgba(90,77,56,*)

### 3. 教学三色严格区分
- 🟡 **brass 金 #c4923a** = **源码事实**（13_000 / file:line / 源码引用）
- 🟢 **teal 青 #5a8a8a** = **教学归纳**（约束三连 / 记忆是提示不是真理 / Fork 缓存共享）
- 🔴 **rust 红 #c44545** = **数据口径警告**（推导比率 / 51% / ⚠️ 必带）

### 4. 数字纪律
- 所有可 grep 复核的源码常量：必带 `file:line` 引用 + brass 金字
  例：`AUTOCOMPACT_BUFFER_TOKENS = 13_000`（autoCompact.ts:62）
- 所有推导/估算数字：必带 rust 红 ⚠️ 口径警告框
  例：「依赖定价比率 · 非 Anthropic 官方」

### 5. 反直觉锚点设计
- 必先抛悬念 → 给一个直觉错误答案 → reveal 真相
- 不要直接呈现结论 · 利用"哦原来如此"瞬间

### 6. 字号布局宪法
- `page-title` clamp(2rem, 3.5vw, 2.8rem) bold · 居中 · margin-bottom 3vh
- `page-subtitle` clamp(1rem, 1.5vw, 1.3rem) text-dim · 居中 · margin-bottom 4vh
- 正文 clamp(0.95rem, 1.2vw, 1.1rem) · line-height 1.7
- 卡片 padding clamp(1.2rem, 2vw, 2rem) · border-radius 14px
- `slide` padding 4vh 8vw (main.css 已定 · 不要覆盖)
- 总高度预算 ≤ 85vh（防溢出 · `overflow:hidden` 隐藏后 scrollHeight 不准）

### 7. 视角铁律（来自 lesson.md）
- 「我们」叙述为主 · 「你」对话为辅 · 偶尔「我」心理代入
- 第一人称为主 · 群体视角 · 不要"我为大家列举"等无效铺垫

### 8. Pre-flight 必做（写第一页前）
1. Read `slide_structure.json` 确认本页 layout / chosen_pattern
2. Read `interaction_architecture.md` 找本页 ia_ref
3. Read 源材料 `lesson.md` 对应章节
4. Read 参考页 `slides/S001-cover.html` 学风格
5. Write 写入路径 `slides/{filename}.html`

---

## 批1 · C2-C3 约束工作台（4 页 · S002-S005）

源材料：lesson.md L60-340（第 2-3 章）

### S002 · 上下文为什么会爆·13_000 提前量 🔴 Bait & Switch Reveal
**文件**：`slides/S002-context-budget.html`
**核心**：压缩动作自己也耗上下文 · 永远别等真满才压
**布局**：
- page-title「上下文为什么会爆」+ subtitle「13_000 提前量"压缩自己也要工作空间"」
- 上半：token 进度条横向 · 渐变色（teal→brass→rust）· 触发瞬间 187_000/200_000 红线 + brass 金标 `187_000 = 200_000 - 13_000`
- 中间分两栏：
  - 左卡：「直觉答案」灰色叉
    - "满了再丢最旧的不就行了？"
  - 右卡：「源码真相」brass 金光
    - `AUTOCOMPACT_BUFFER_TOKENS = 13_000` (autoCompact.ts:62)
    - 旁注：压缩动作要喂模型做摘要 · 自己也消耗 token · 等真满才压会陷入 thrash 死循环
- 底部 rust 红框：「BQ 2026-03-10 BigQuery 监控数据 · 1,279 sessions × 50+ 连续失败 · 单 session 最高 3,272 次 · 全球浪费 ~25 万 API/day」(autoCompact.ts:67-69)
- 金句 teal 青：「13_000 不是拍脑袋 · 是 BigQuery 监控反推出来的工业级常量」

### S003 · 四层压缩机制全景 🟡 Selector + Detail Panel
**文件**：`slides/S003-four-layer-compression.html`
**核心**：压缩不是一个动作而是一组分层防御 · 只有 autoCompact 调 LLM
**布局**：
- page-title「四层压缩机制全景」+ subtitle「LLM 调用既贵又慢 · 能不调就别调」
- 4 个卡片横排（点击切换详情）：
  1. autoCompact（调 LLM 兜底）· 13_000 / 3_000 / MAX=3
  2. microCompact（不调）· `[Old tool result content cleared]` 占位
  3. apiMicrocompact（服务端代劳）· 内部不展开
  4. sessionMemoryCompact（不调 · 复用磁盘记忆）· 630 行 / shouldUse(:403) trySession(:514)
- 中心圆：post-compact 恢复预算 · `POST_COMPACT_TOKEN_BUDGET = 50_000` / 5 文件 / 5_000/file (compact.ts:122-124) · brass 金
- 表格：机制 / 策略 / 是否调 LLM / file:line · 「是否调 LLM」列 teal 青加重
- 金句：「Strategy pattern + cost-aware fallback chain · 优先走免 LLM 路径 · 调 LLM 是兜底而不是首选」

### S004 · Prompt Cache·稳定区 vs 动态区 🔴 Two-Zone Highlight
**文件**：`slides/S004-prompt-cache-zones.html`
**核心**：保持稳定区逐字不变 · 账单会自己降下来
**布局**：
- page-title「Prompt Cache · 稳定区 vs 动态区」+ subtitle「前缀必须逐字节相同 · 差一个空格整段缓存全失效」
- 中央：一条横向长条 = 一次请求 · 中间标 `SYSTEM_PROMPT_DYNAMIC_BOUNDARY` (constants/prompts.ts:114-115)
  - 左段（稳定区）teal 青：工具定义 / Skill 静态指令 / 固定规则 / 系统级规则
  - 右段（动态区）rust 红：用户本轮请求 / 工具结果 / 累积对话
- 下方两组对比卡：
  - 稳定区命中 → 命中价（推导 ~10% miss 价）· 标 rust ⚠️ 推导口径
  - 稳定区改一字 → 整段断裂 → 全 miss 价
- 底部 rust 红框：「`cache_read_input_tokens` 突然掉到 0 时 · `promptCacheBreakDetection.ts` 进 debug 清单」(promptCacheBreakDetection.ts:120/125/126)
- 关键 teal 青结论：「优化 Agent 成本只盯"少调几次模型"不够 · 同样次数命中率 30%→80% · 账单直接砍一半（推导 · 不是 Anthropic 官方）」

### S005 · PromptStateSnapshot 检测机制 🟡 T-CODE-TRANSLATE
**文件**：`slides/S005-prompt-state-snapshot.html`
**核心**：debug 高账单时 promptCacheBreakDetection.ts 进你的清单
**布局**：
- page-title「PromptStateSnapshot 检测机制」
- 左右双栏 T-CODE-TRANSLATE：
  - **左（源码 brass 金）**：
    - `services/api/promptCacheBreakDetection.ts` 727 行
    - `MIN_CACHE_MISS_TOKENS = 2_000` (:120)
    - `CACHE_TTL_5MIN_MS` / `CACHE_TTL_1HOUR_MS` (:125/:126)
    - `PromptStateSnapshot` 类型 (:227)
    - `recordPromptState` 函数 (:247)
  - **右（自然语言 teal 青）**：
    - 每次调用前记录"提示词状态快照"
    - 下次对比 cache_control hash
    - hash 变了 = 缓存断裂
    - MIN < 2K 不告警 · 省下也不多
    - 两档 TTL：高频用 5min · 跨空闲用 1h
- 底部金句：「短档够高频连续对话 · 长档跨长间隔会话」

---

## 批2 · C4 约束记忆（4 页 · S006-S009）

源材料：lesson.md L344-557（第 4 章）

### S006 · 记忆不是分层数据库·打碎直觉 🔴 Bait & Switch Reveal
**文件**：`slides/S006-memory-bait-switch.html`
**核心**：长期记忆 = 一份 Markdown 文件 · 不是数据库
**布局**：
- page-title「先打碎一个直觉 · 记忆不是分层数据库」
- 左右对比：
  - **左（灰色叉 · 想象中）**：
    - 画一个"分层 DB"图示：表 users / 表 sessions / 表 memories / 索引层 / 查询层 / 版本管理
    - 标灰字「听起来很专业 · 实际不存在」
  - **右（brass 金光 · 源码真相）**：
    - 一份 markdown 文件图标 + `services/SessionMemory/sessionMemory.ts` 495 行
    - 引用注释逐字 brass 金（L1-5）：
      `Session Memory automatically maintains a markdown file with notes about the current conversation. It runs periodically in the background using a forked subagent to extract key information without interrupting the main conversation flow.`
    - 三个关键设计点标蓝：①markdown 文件 ②自动维护 ③后台 forked subagent
- 底部 teal 青框：「先看 Claude Code 怎么做 · 用一个结构化 Markdown 够不够 · 大多数情况下 · 够」

### S007 · 10 节模板结构 🟡 Selector + Detail Panel
**文件**：`slides/S007-ten-section-template.html`
**核心**：10 节覆盖"做了什么/在哪/犯过错/学到什么"四个维度
**布局**：
- page-title「10 节模板结构」+ subtitle「`MAX_TOTAL_SESSION_MEMORY_TOKENS = 12_000` (prompts.ts:9)」brass 金
- 左侧 10 节竖列卡片（hover/click 看职责）：
  1. Session Title · 2. Current State · 3. Task specification · 4. Files and Functions · 5. Workflow · 6. Errors & Corrections（rust 红高亮）· 7. Codebase and System Documentation · 8. Learnings（rust 红高亮）· 9. Key results · 10. Worklog
  - Errors / Learnings 两节 rust 红强调「失败经验也持久化」
- 右侧标尺：
  - 顶端 `12_000` 上限
  - 中间标 `MAX_SECTION_LENGTH = 2_000` (prompts.ts:8) · 10×2K=20K > 12K → 「节间弹性占用 · 不允许全满」
  - 接近顶端折返箭头：「超限触发 `trySessionMemoryCompaction` (sessionMemoryCompact.ts:514)」
- 底部金句：「用 prompt 让 LLM 自管理输出长度（prompts.ts:67 + :170-191）· 比 if 硬截断不破坏语义」

### S008 · 「记忆是提示不是真理」 🔴 Annotation Reveal
**文件**：`slides/S008-memory-is-hint.html`
**核心**：记忆进上下文 · 但模型有权忽略它
**布局**：
- page-title「记忆是提示 · 不是真理」
- 上方四步反直觉问答（点击逐步揭示）：
  - Q1：记忆 = 数据库？ → 否
  - Q2：记忆 = Agent 必须遵守的事实？ → 否
  - Q3：记忆是什么？ → **一条带免责声明的参考资料**
  - Q4：这意味着什么？ → 任何注入的"背景知识"都该带边界声明
- 中央源码框 brass 金 · `utils/api.ts prependUserContext` 周边：
  ```
  IMPORTANT: this context may or may not be relevant to your tasks.
  You should not respond to this context unless it is highly relevant to your task.
  ```
  - 关键句 `may or may not be relevant` / `highly relevant` 用 rust 红框 + 渐入光
- 底部 teal 青：「『是提示』是工程事实（被注入了上下文）/『不是真理』是应用边界（模型可以根据相关性忽略）· 记忆由 LLM 写入 · 由 LLM 读取 · 中间没有任何强一致性保证」

### S009 · 双轨记忆·SessionMemory vs memdir 🟡 Left/Right Compare
**文件**：`slides/S009-dual-memory.html`
**核心**：业界默认 RAG · Claude Code 跳过 embedding · LLM 自己选
**布局**：
- page-title「双轨记忆 · 业界 RAG vs Claude Code LLM-as-selector」
- 左右两块大卡 · 中间竖虚线分「两套独立子系统 · 互不依赖」
- **左 SessionMemory** teal 青边框：
  - 3 文件 1026 行 / 单 markdown / 10 节固定模板 / 12_000 token 上限 / forked subagent 后台抽取 / **会话内工作笔记**
- **右 memdir** brass 金边框：
  - 8 文件 1736 行 / 多文件多 topic / MEMORY.md 入口索引 / topic_*.md / team/ 共享 / 200 文件上限 / **跨会话事实和偏好**
  - LLM-as-selector：`findRelevantMemories.ts` 141 行 · 一次 Sonnet + JSON schema {selected_memories: string[]} + max_tokens: 256
- 底部金句 rust 红字：**「RAG 是工业默认 · 不是非用不可 · 候选集小（≤200）+ Top-K 小（5）时 · 让 LLM 直接读 manifest 比 embedding 简单得多」**
- 可独立 grep 复核的事实小字：`ls src/memdir/` 8 个 .ts / `grep from.*memdir SessionMemory/*.ts` = 0

---

## 批3 · C5-7 多 Agent（6 页 · S010 / S012 / S014-S017）

源材料：lesson.md L560-975（第 5-7 章）

### S010 · 单 Agent 串行的物理上限 🔴 Bar-Grow Crash
**文件**：`slides/S010-single-agent-crash.html`
**核心**：一个脑子串行做所有事 = 又慢、上下文又必然爆
**布局**：
- page-title「单 Agent 串行的物理上限」+ subtitle「不是 Agent 笨 · 是单线程+单上下文的物理上限」
- 中央：4 个子任务（调研三方案 / 实现一个 / 写测试 / 总结）依次堆叠到一条上下文条
- token 数字逐步攀升：2,000 → 14,000 → 29,000 → 43,000 → 56,000 撞红线 50,000 · 红字「**爆**」+ 闪光
- 下半：标红「**问题根源**：所有事挤在同一条上下文里 → 解法方向：分给多个独立上下文 Agent」
- 转场提示 teal 青：「下一页：子 Agent 隔离 + 极短摘要回传 · 让父 Agent 在结构上就背不到子 Agent 的中间产物」

### S012 · isolation 字段诚实划界 🟡 T-CODE-TRANSLATE
**文件**：`slides/S012-isolation-honest.html`
**核心**：外部公开快照 isolation 只有 worktree · remote 是 Anthropic 内部分支
**布局**：
- page-title「isolation 字段诚实划界」+ subtitle「条件编译三元表达式 · 课件引用枚举值前必看外层 if/三元」
- 左右双栏：
  - **左（源码 brass 金）** `tools/AgentTool/AgentTool.tsx:99`：
    ```
    "external" === 'ant'
      ? z.enum(['worktree', 'remote'])
      : z.enum(['worktree'])
    ```
  - **右（自然语言 teal 青）**：
    - 在你拿到的**外部公开泄露快照**里（`external !== 'ant'`）
    - isolation 实际可选值**只有 `'worktree'` 一个**
    - `'remote'` 是 Anthropic 内部构建（`'ant'` 分支）专属模式
- 下方对比表两列：
  - worktree：临时 git worktree · 隔离**文件系统** · 同机器
  - remote（灰色 · 标"内部专属"）：远程 CCR 环境 · 隔离**整个运行时** · 换机器
- 底部 rust 红警示：「条件编译陷阱 · Opus+Sonnet 共漏 · Codex 第三视角必抓（CC isolation 实战）· 引用枚举前必看外层 if」

### S014 · CacheSafeParams 五字段 🟡 Selector + Detail Panel
**文件**：`slides/S014-cache-safe-params.html`
**核心**：5 字段是 fork 子 Agent 蹭父缓存必须逐字对齐的清单
**布局**：
- page-title「CacheSafeParams 五字段」+ subtitle「fork 子 Agent 想蹭父缓存必须逐字对齐」
- 顶部引用 brass 金（forkedAgent.ts:48-51）：
  ```
  The Anthropic API cache key is composed of:
  system prompt, tools, model, messages (prefix), and thinking config.
  CacheSafeParams carries the first five.
  ```
- 5 字段卡片横列（点击展开 source 注释 + "为什么必须和父一致"）：
  1. `systemPrompt` · System prompt - must match parent for cache hits
  2. `userContext` · User context - prepended to messages, affects cache
  3. `systemContext` · System context - appended to system prompt, affects cache
  4. `toolUseContext` · 一字段承载 tools/model/thinkingConfig 三项
  5. `forkContextMessages` · Parent context messages for prompt cache sharing
- 中心图：缓存键 5 要素 ↔ 5 字段分组承载映射图
  - 关键点：thinking config **不是独立字段** · 派生自 `toolUseContext.options.thinkingConfig`（:51-55）
- 底部金句 teal 青：「别按理论维度切字段 · 按数据实际流向切 · 再逐字段标注它对缓存键的影响」

### S015 · Coordinator·编排者不下场 🔴 Role Boundary Reveal
**文件**：`slides/S015-coordinator-no-execute.html`
**核心**：用提示词工程定义角色边界 · 不是用 if 硬拦截
**布局**：
- page-title「Coordinator · 编排者不下场」+ subtitle「用提示词让它根本不会想去做 · 而不是用代码禁止」
- 上方反直觉 hook 卡：「怎么让 Coordinator 只指挥不下场？」灰色叉「if (isCoordinator) reject(...) ？」
- 中央源码 brass 金（coordinatorMode.ts:116）首句：
  ```
  You are Claude Code, an AI assistant that **orchestrates**
  software engineering tasks across multiple workers.
  ```
  - 「orchestrates」关键词放大 + brass 金光晕
- 下方三条边界卡（reveal 浮出）：
  - ① 只分活（编排者）· ② 只收活（汇总）· ③ 自己不下场（不亲自实现）
- 底部细节框 teal 青：「`CLAUDE_CODE_SIMPLE` 环境变量动态拼"worker 能力清单"（:112-114）· Coordinator 才能准确分活 · 不会把需 skill 的活派给无 skill worker」
- 金句 brass 金：「先想清楚谁当 Coordinator · 给它一套专属系统提示词 · 让"不下场"成为角色本能而不是外部硬拦截」

### S016 · SendMessage 点对点通信 🟡 Network Topology
**文件**：`slides/S016-send-message-p2p.html`
**核心**：扁平拓扑 · 每个 worker 用 task-id 直达 · 不经中间层
**布局**：
- page-title「SendMessage 点对点通信」+ subtitle「寻址即解耦 · 全局地址表压给本来就有全局视野的 Coordinator」
- 上半：扁平拓扑图 · Coordinator 中央（brass 金） + 4 worker（teal 青）围绕 · 4 条线 `to=w0/w1/w2/w3` 直达
- 下半（灰色弱化）：层级转发对比图 · Coordinator → mid → mid → worker 多层中转 · 中间标"链路越深越脆 · 每层可能丢消息/曲解/阻塞"
- 中间一行源码引用 brass 金（coordinatorMode.ts:164）：
  ```
  The <task-id> value is the agent ID — use SendMessage with that ID as `to`
  to continue that worker
  ```
- 旁注：寻址基础 = AgentTool.tsx:94 的 `name` 字段
- 底部金句 teal 青：「Agent 之间用 ID 点对点直达 · 把全局寻址负担集中到那个本来就需要全局视野的编排者身上 · 别去搭多层转发的组织树」

### S017 · 7 TaskState 不是协同模式 🔴 Misconception Bust
**文件**：`slides/S017-7-taskstate-bust.html`
**核心**：7 是后台任务状态类型计数 · 不是协同模式
**布局**：
- page-title「7 TaskState 不是协同模式」
- 上方误解卡片灰色叉：「Claude Code 有 7 种多 Agent 协同模式 ❌」
- 中间过渡："看 `tasks/types.ts` 真相"
- 下方源码 brass 金 · 7 成员竖排：
  - LocalShellTaskState · LocalAgentTaskState · RemoteAgentTaskState · InProcessTeammateTaskState · LocalWorkflowTaskState · MonitorMcpTaskState · DreamTaskState
- 中间加粗 teal 青：「TaskState（任务**状态**） ≠ CollaborationMode（协同**模式**）· 一字之差天壤之别」
- 底部 rust 红框「数字纪律」：「**一个数字真不真**是一回事 · 它**计的是什么口径**是另一回事 · 两者都对了才能讲」

---

## 批4 · C8-C9 务实约束 + 收尾（6 页 · S018 S019 S021-S024）

源材料：lesson.md L976-1260（第 8-9 章）

### S018 · 没有 MAX_CONCURRENT 常量·数字纪律 🟢 Honest Boundary
**文件**：`slides/S018-no-max-constant.html`
**核心**：源码里没这些精确常量 · 是写在系统提示词里的工程指导
**布局**：
- page-title「没有 MAX_CONCURRENT 常量 · 数字纪律」
- 上方误解卡片灰色叉：「`MAX_CONCURRENT_AGENTS = 10`、`TIMEOUT = 5min` 这些常量在哪？❌」
- 中央源码事实 brass 金 · `coordinatorMode.ts:215 Manage concurrency:` 自然语言段落：
  - 只读任务（research）：放开并行（run in parallel freely）
  - 写入密集任务（implementation）：按文件集一次一个（one at a time per set of files）
  - 验证可以和实现在不同文件区域上并行
- 旁注 teal 青：`utils/effort.ts` 模型选择定性说明（不展开精确实现）
- 底部 rust 红框：「**数字纪律** · 没核实到精确常量就**定性表述** · 绝不为了"显得具体"编一个 · 这门课所有可 grep 复核的数字都来自实测 grep」
- 金句 teal 青：「高度依赖场景的约束 · 与其写死所有情况都不最优的常量 · 不如交给有全局视野的角色按原则临场决定」

### S019 · 三层 routing 实战账单·点披萨叫直升机 🔴 Bar Comparison Reveal
**文件**：`slides/S019-three-routing-bills.html`
**核心**：模型分工不是"贵的更稳" · 是"按真实智能需求曲线匹配"
**布局**：
- page-title「三层 routing 实战账单」+ subtitle「按真实智能需求曲线匹配 · 不是越贵越稳」
- 三组对比柱（逐步揭示）：
  1. **Augment Code 三层 routing**：
     - 左柱 `$0.98` 按任务分模型 vs 右柱 `$2.02` 全 Opus
     - 中间 brass 金「**省 51%**」
     - 拆解：Opus 4.6 × 1（架构）· Sonnet 4.6 × 7（实现+测试）· Haiku 4.5 × 12（编辑+review）
  2. **CloudZero Agent Team 配比**：
     - 左柱 1 Opus orchestrator + 4 Sonnet teammate vs 右柱 5 全 Opus
     - 中间 brass 金「**省 40%**」
  3. **Advisor Pattern**（2026 最反直觉）：
     - SWE-bench Multilingual：Sonnet+Opus advisor `74.8%` vs 单跑 Opus `72.1%` 且贵 `11.9%`
     - 中间 brass 金「**便宜 + 高分**」
- 底部金句加粗 teal 青：**「默认每个 agent 都用 Opus · 等于点披萨叫直升机送外卖」**（CloudZero 原句）
- rust 红口径警告框：「51% / 40% / 74.8% / 11.9% / 2.7pp 各家自家博客实测 · 未经第三方独立复现 · 引用必带『依赖任务分布假设』口径 · 学员实操建议先跑 5-10 个对照样本验证」

### S021 · 八模式速查表·对照自己项目 🟡 Sortable Table + Self-Check
**文件**：`slides/S021-eight-patterns.html`
**核心**：拿这 8 个对照自己项目 · 至少挑 1 个改造点
**布局**：
- page-title「八模式速查表」+ subtitle「拿它逐行问自己的项目」
- 8 行交互表格（每行带 ☐ 勾选框 · 勾选后浮出"恭喜你挑了改造点 X"反馈）：
  | # | 模式 | 一句话内核 | 来自 | ☐ |
  | 1 | 提前量压缩 | 压缩动作自己也耗上下文 · 永远别等真满才压 | 第 2 章 | ☐ |
  | 2 | 分层压缩 | 全量/清旧/记忆感知/恢复预算各司其职 | 第 2 章 | ☐ |
  | 3 | 稳定区/动态区分离 | 不变的和变的分开 · 让前者长期命中缓存 | 第 3 章 | ☐ |
  | 4 | 单文件结构化记忆 | 一份固定模板+总量上限的 Markdown · 不上数据库 | 第 4 章 | ☐ |
  | 5 | 记忆带免责声明 | "可能不相关、除非高度相关否则别理" | 第 4 章 | ☐ |
  | 6 | 隔离 + 极短回传 | 独立上下文 + 只回 3-5 词摘要 | 第 5 章 | ☐ |
  | 7 | Fork 蹭缓存 | 子 Agent 复用父缓存前缀 · 成本不随数量线性增长 | 第 6 章 | ☐ |
  | 8 | 编排者不下场 | Coordinator 全局视野 · 只分活/收活/决策 · 不干活 | 第 7 章 | ☐ |
- 底部三条行动建议（约束三连分别对应）：
  - **工作台**：翻你项目调 LLM 那段 · 系统提示词稳定部分是否逐字不变（模式 3）
  - **记忆**：如有长期记忆 · 注入时有无免责声明（模式 5）
  - **多 Agent**：子 Agent 回传是否压到极短 · 有无明确"不下场"的 Coordinator（模式 6、8）

### S022 · Reflection-Critic·第 9 模式 2026-04 翻牌 🔴 Triple Evidence Stack
**文件**：`slides/S022-reflection-critic-9.html`
**核心**：2-agent Generator+Critic 是 2026 年任何严肃产出的最小标配
**布局**：
- page-title「Reflection-Critic · 第 9 模式 2026-04 翻牌」+ subtitle「业界从 ⚠️Medium → ✅High」
- 时间线竖向：
  - 2026 初：⚠️ Medium · 灰色
  - **2026-04-22**：✅ High · brass 金 + 闪光
- 三层证据叠加（点击逐条展开 brass 金 reveal）：
  1. **Cognition Devin Review 自家实战** brass 金：
     - 每个 PR 平均抓 **2 个 bug** · 其中 **58% 是严重 bug**（逻辑错/边界/安全）
     - 反过来支持 multi-agent 的最有力数据 · 来自原本反对方 Cognition
  2. **Anthropic Outcomes 2026-05-03 发布**（Code with Claude 大会期间）：
     - rubric grader 独立 context 评分机制 · 达不到退回重做
  3. **Claude Code 源码 `VERIFICATION_AGENT` feature flag**：
     - 3+ file edits 后自动 spawn read-only adversarial agent
     - verdict: `PASS` / `FAIL` / `PARTIAL`
- 中间总结 teal 青框：「**Reflection-Critic 不是社区 pattern · 是 Anthropic 写进平台的一等公民**」
- 底部金句加粗 brass 金：「以前你写『AI 改完代码人工审』· 现在应该写『AI 改完代码上 critic agent』· **『2-agent Generator+Critic』是 2026 年任何严肃产出的最小标配**」

### S023 · 四对张力·这把尺 🔴 Tension Balance
**文件**：`slides/S023-four-tensions.html`
**核心**：拿这四对张力 · 量任何一个 Agent 系统
**布局**：
- page-title「四对张力 · 这把尺的最终形态」
- 一根贯穿上下的脊柱 · 挂 4 个对称天平（依次浮出）：
  1. ⚖️ **能力 vs 约束**（上节继承 · 灰色）
     - 扩展三件套是油门 · 安全管线是刹车
  2. ⚖️ **信任 vs 约束**（上节延伸 · 灰色）
     - 越想 Agent 自主 · 越要给它套可验证关卡
  3. ⚖️ **静态 vs 动态**（本节归位 · brass 金高亮）
     - 压缩是动态地丢（活的对话）· 记忆是静态地留（死的文件）
  4. ⚖️ **集中 vs 分治**（本节归位 · brass 金高亮）
     - Coordinator 集中编排 · 子 Agent 分治执行
- 脊柱底部金句 rust 红：「能把这四个问题问出来 · 你就不只是"会用某个 Agent 框架" · 而是"能评判任何一个 Agent 系统"」

### S024 · 三句话自测 + Bitter Lesson 哲学收束 🔴 Q&A Flip Card
**文件**：`slides/S024-three-questions-test.html`
**核心**：能答出三句话 · 两节课就真正闭环
**布局**：
- page-title「三句话自测」+ subtitle「30 秒答出 · 两节课就真带走了」
- 3 张翻卡横排（点击翻转看答案）：
  1. **Q1：为什么自动压缩要在上下文还没满时就提前 13_000 token 触发？**
     - 翻：压缩动作本身要喂模型做摘要、要消耗上下文 · 如果等真满才压 · 压缩自己就没空间跑了 · 陷入"想压缩却没空间压缩"死结 · 13_000 是 `autoCompact.ts:62` 写死的可 grep 复核事实 brass 金
  2. **Q2：为什么说「记忆是提示，不是真理」？**
     - 翻：源码 `prependUserContext` 注入时逐字附了「这段内容可能相关也可能不相关 · 除非高度相关否则别理」免责声明 · 记忆确实进了上下文（是提示）· 但模型被明确允许根据相关性忽略它（不是真理）
  3. **Q3：为什么"5 个 Agent ≈ 1 个成本"是反直觉双赢、但引用必带口径？**
     - 翻：fork 子 Agent 通过 `CacheSafeParams` 强制对齐系统提示词前缀 · 命中父 Agent 的 Prompt Cache · 只有第一个付未命中全价 · 其余走命中价 · 但「≈1 成本」是从缓存定价推导的结论 · **不是 Anthropic 官方数字** rust 红 · 引用必带「依赖定价比率」口径
- 底部哲学收束（Bitter Lesson 三铁律 teal 青）：
  - Start Simple：先提供稳健原子工具 · 不要复杂控制流
  - Build to Delete：今天复杂管线 · 明天可能一个提示词搞定 · harness 必须可删除
  - The Harness is the Dataset：竞争优势来自捕获的执行轨迹 · 不是提示词
- 最终类比 brass 金：`model ≈ CPU` / `context window ≈ RAM` / **`harness ≈ OS`** / `agent ≈ application`
- 终极金句 加粗大字 居中：**「约束本身就是产品力」**

---

## 写完后自检（每页单独跑）

- [ ] 文件外层不是 `<div class="slide">` · 而是 `<div class="page-content">` 或具体功能容器
- [ ] 颜色全用 `var(--xxx)` · 仅在不可避免时用 hex 且必须 L-B palette
- [ ] 数据点带 `file:line` 引用 · brass 金字
- [ ] 推导/估算数字带 rust 红 ⚠️ 口径警告
- [ ] 反直觉锚点先抛悬念再 reveal · 不直接给答案
- [ ] 内容总高度 ≤ 85vh · 不溢出
- [ ] 中英文术语首次出现用反引号 / brass 金字 · 提供中文解释
