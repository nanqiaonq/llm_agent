/*
 * interactive.js · slideHooks 容器
 *
 * 重交互页：S003（v3 · 对话流可视化）· S011/S013/S020 待 Phase 3b
 *
 * 填充规则（按 SKILL.md GSAP 安全模板）：
 *   - 禁用 gsap.from() · 必用 gsap.fromTo()
 *   - timeline 必须 paused:true · slide active 后 tl.play()
 *   - hookFn 必须 return function() { ... } cleanup
 *   - cleanup 必须 gsap.killTweensOf() 或 tl.kill()
 *   - 禁止在 hookFn 外绑定事件监听器
 */

window.slideHooks = window.slideHooks || {};

/* ==========================================================================
 * S003 v3 · 对话流可视化 + 4 层压缩各自变形动画
 * ========================================================================== */
window.slideHooks['slides/S003-four-layer-compression.html'] = function () {
  // ============== chat 内容构建 helper ==============
  function msg(kind, text, tok, state) {
    return { type: 'msg', kind: kind, text: text, tok: tok, state: state || 'normal' };
  }
  function memoryCard(sub) {
    return { type: 'memory-card', title: '📕 已写入 session_memory.md', sub: sub };
  }
  function system(text) {
    return { type: 'system', text: text };
  }
  function summary(body) {
    return { type: 'summary', body: body };
  }
  function restored(file, tok) {
    return { type: 'restored', file: file, tok: tok };
  }

  // 14 条核心对话（stage 1 完整状态）
  function baseConvo() {
    return [
      msg('user',        '帮我重构 auth 模块 · 现在 login() 函数太长了',                              500),
      msg('agent',       '我来分析当前结构 · 先读源文件',                                              300),
      msg('tool_call',   'Read("src/auth.ts")',                                                       50),
      msg('tool_result', '[auth.ts · 142 行 · login/logout/refresh 3 函数]',                         3200),
      msg('agent',       'login() 里 token 验证跟 session 创建混了 · 拆出 validateToken()',           400),
      msg('tool_call',   'Edit("src/auth.ts", 拆出 validateToken)',                                   50),
      msg('tool_result', '[diff applied · +15 -8 lines]',                                            500),
      msg('user',        '也帮我加测试 · 特别是失败边界',                                              200),
      msg('agent',       '好 · 我先看现有测试',                                                       200),
      msg('tool_call',   'Read("src/auth.test.ts")',                                                  50),
      msg('tool_result', '[test · 87 行 · 6 用例 · 仅覆盖 happy path]',                              2800),
      msg('agent',       '缺登录失败 / token 过期 / 并发 3 类边界',                                   400),
      msg('tool_call',   'Edit("src/auth.test.ts", 补 3 类边界测试)',                                 50),
      msg('tool_result', '[diff applied · +52 lines · 12 新测试]',                                    800)
    ];
  }

  // stage 2: 同上 但 M04/M07/M11 cleared
  function clearedConvo() {
    var arr = baseConvo();
    [3, 6, 10].forEach(function (i) {
      arr[i] = msg('tool_result', '[Old tool result content cleared]', 50, 'cleared');
    });
    return arr;
  }

  // stage 3: cleared 后 + 4 新 msg + L2 system toast
  function stage3Convo() {
    return clearedConvo().concat([
      msg('user',        '另外把 SDK 升级到 v2',                                                      250),
      msg('agent',       '好 · 我检查依赖',                                                           300),
      msg('tool_call',   'Read("package.json")',                                                      50),
      msg('tool_result', '[deps · 23 项 · 5 个 SDK 需升级]',                                         1500),
      system('⚡ L2 apiMicrocompact · API 边界轻量压缩 · 服务端代劳 · 客户端 0 成本')
    ]);
  }

  // stage 4: 早期 8 条折叠为 memory-card + 剩余 + 新增
  function stage4Convo() {
    return [
      memoryCard('M01-M08 已折叠 · 10 节模板覆盖 · 11.2K · 包含 user 需求 + Read auth + 拆出 validateToken'),
      // 保留 M09-M14 的 cleared 状态摘录
      msg('agent',       '缺登录失败 / token 过期 / 并发 3 类边界',                                   400),
      msg('tool_call',   'Edit("src/auth.test.ts", 补 3 类边界测试)',                                 50),
      msg('tool_result', '[Old tool result content cleared]',                                          50, 'cleared'),
      msg('user',        '另外把 SDK 升级到 v2',                                                      250),
      msg('agent',       '好 · 我检查依赖',                                                           300),
      msg('tool_call',   'Read("package.json")',                                                      50),
      msg('tool_result', '[deps · 23 项 · 5 个 SDK 需升级]',                                         1500),
      system('⚡ L2 apiMicrocompact · 服务端代劳已生效'),
      msg('agent',       '升级 oauth2 / jose / bcrypt 三个核心库',                                    350),
      msg('tool_call',   'Edit("package.json", 升级 3 个核心库)',                                     50),
      msg('tool_result', '[deps updated · oauth2 ^v2 · jose ^v6 · bcrypt ^v5]',                       400),
      msg('agent',       '运行测试看是否有 breaking change',                                          250),
      msg('tool_call',   'Bash("pnpm test")',                                                          50),
      msg('tool_result', '[78 passed · 4 failed · login refresh token / TTL 边界]',                  1200)
    ];
  }

  // stage 5: 同 stage 4 chat · 但 LLM overlay show
  function stage5Convo() {
    return stage4Convo().concat([
      msg('agent',       '4 个失败都跟 jose v6 的 token TTL API 变更有关 · 修补',                     400),
      msg('tool_call',   'Edit("src/auth.ts", 适配 jose v6 TTL API)',                                 50),
      msg('tool_result', '[diff applied · TTL 改用 new payload format]',                              700)
    ]);
  }

  // stage 6: LLM 摘要替代 · 只剩 summary msg
  function stage6Convo() {
    return [
      summary('本会话核心：用户要求重构 <strong>auth 模块</strong> · 已 Read 3 文件（auth.ts / auth.test.ts / package.json）· Patch 4 次（拆 validateToken + 补 3 类边界测试 + 升级 3 SDK + 适配 jose v6 TTL）· 测试 78 通过 · <strong>当前任务：等待用户确认是否继续修复 jose v6 适配的剩余兼容问题</strong>')
    ];
  }

  // stage 7: summary + 3 restored
  function stage7Convo() {
    return [
      summary('本会话核心：用户要求重构 <strong>auth 模块</strong> · 已 Read 3 文件 · Patch 4 次 · 测试 78 通过 · <strong>当前任务：等待用户确认是否继续修复 jose v6 适配的剩余兼容问题</strong>'),
      restored('src/auth.ts',       5000),
      restored('src/auth.test.ts',  5000),
      restored('package.json',      5000)
    ];
  }

  // ============== 7 阶段完整快照 ==============
  var STAGES = [
    { name: '初始 · Agent 启动',                     used:    0, items: [],                  L1:false,L2:false,L3:false,L4:false,pc:false, llm:false },
    { name: '累积 14 message · token → 82K',         used: 82000, items: baseConvo(),         L1:false,L2:false,L3:false,L4:false,pc:false, llm:false },
    { name: 'L1 microCompact · 清旧 tool_result',    used: 73600, items: clearedConvo(),      L1:true, L2:false,L3:false,L4:false,pc:false, llm:false },
    { name: 'L2 apiMicrocompact · 服务端代劳',        used:108000, items: stage3Convo(),       L1:true, L2:true, L3:false,L4:false,pc:false, llm:false },
    { name: 'L3 sessionMemoryCompact · 折叠记忆',     used:150000, items: stage4Convo(),       L1:true, L2:true, L3:true, L4:false,pc:false, llm:false },
    { name: 'L4 autoCompact · 撞墙 · 调 LLM 摘要中',  used:187000, items: stage5Convo(),       L1:true, L2:true, L3:true, L4:true, pc:false, llm:true  },
    { name: 'LLM 摘要完成 · 全替换为浓缩 summary',    used:  8500, items: stage6Convo(),       L1:false,L2:false,L3:false,L4:true, pc:false, llm:false },
    { name: 'post-compact 恢复 · 捞回 3 文件',        used: 23500, items: stage7Convo(),       L1:false,L2:false,L3:false,L4:false,pc:true,  llm:false }
  ];

  // ============== DOM 引用 ==============
  var page = document.querySelector('.s003-page');
  if (!page) { console.warn('[S003] page root not found'); return function(){}; }
  var chatEl    = page.querySelector('#s003-chat');
  var msgCountEl= page.querySelector('#s003-msg-count');
  var fillEl    = page.querySelector('#s003-fill');
  var usedEl    = page.querySelector('#s003-used');
  var stepIndEl = page.querySelector('#s003-step-ind');
  var llmOverlay= page.querySelector('#s003-llm-overlay');
  var l1El = page.querySelector('#s003-l1');
  var l2El = page.querySelector('#s003-l2');
  var l3El = page.querySelector('#s003-l3');
  var l4El = page.querySelector('#s003-l4');
  var pcEl = page.querySelector('#s003-pc');
  var playBtn  = page.querySelector('#s003-play');
  var stepBtn  = page.querySelector('#s003-step');
  var replayBtn= page.querySelector('#s003-replay');
  var speedBtns= page.querySelectorAll('.s003-speed-btn');

  // ============== 状态 ==============
  var currentStep = 0;
  var speed = 1;
  var autoTimer = null;
  var isPlaying = false;
  var totalSteps = STAGES.length - 1; // 0..7

  // ============== 渲染函数 ==============
  var ICONS = {
    user: '👤', agent: '🤖', tool_call: '📞', tool_result: '📄', cleared: '🗑'
  };

  function renderItem(item) {
    if (item.type === 'memory-card') {
      var el = document.createElement('div');
      el.className = 's003-memory-card';
      el.innerHTML = '<div class="title">' + item.title + '</div><div class="sub">' + item.sub + '</div>';
      return el;
    }
    if (item.type === 'system') {
      var el = document.createElement('div');
      el.className = 's003-msg system';
      el.innerHTML = '<div class="bubble">' + item.text + '</div>';
      return el;
    }
    if (item.type === 'summary') {
      var el = document.createElement('div');
      el.className = 's003-summary-msg';
      el.innerHTML = '<div class="lbl">📜 LLM 全量摘要 · 187K → 8.5K</div><div class="body">' + item.body + '</div>';
      return el;
    }
    if (item.type === 'restored') {
      var el = document.createElement('div');
      el.className = 's003-restored';
      el.innerHTML = '<span class="ico">📂</span><span>[restored] <strong>' + item.file + '</strong></span><span class="tok">+' + item.tok.toLocaleString() + ' tok</span>';
      return el;
    }
    // 普通 message
    var el = document.createElement('div');
    var stateCls = item.state === 'cleared' ? ' cleared' : '';
    el.className = 's003-msg ' + item.kind + stateCls;
    var ico = ICONS[item.kind] || '·';
    var tokTxt = item.tok > 0 ? '<span class="tok">+' + item.tok.toLocaleString() + '</span>' : '';
    if (item.state === 'cleared') {
      tokTxt = '<span class="tok">+' + item.tok.toLocaleString() + ' · 清旧</span>';
    }
    el.innerHTML = '<div class="avatar">' + ico + '</div><div class="bubble">' + escapeHtml(item.text) + '</div>' + tokTxt;
    return el;
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function applyStage(idx) {
    var stage = STAGES[idx];
    if (!stage) return;

    // 重建 chat
    if (chatEl) {
      chatEl.innerHTML = '';
      stage.items.forEach(function (item) {
        chatEl.appendChild(renderItem(item));
      });
      // 滚动到底
      setTimeout(function () { chatEl.scrollTop = chatEl.scrollHeight; }, 50);
    }
    // 消息计数
    if (msgCountEl) {
      var cnt = stage.items.filter(function (i) { return i.type === 'msg' || i.type === 'system'; }).length;
      msgCountEl.textContent = cnt + ' messages';
    }
    // token 条
    if (fillEl) {
      var pct = (stage.used / 200000) * 100;
      fillEl.style.width = pct + '%';
    }
    if (usedEl) {
      usedEl.textContent = stage.used.toLocaleString();
      if (stage.used >= 180000) usedEl.classList.add('warn');
      else usedEl.classList.remove('warn');
    }
    // 4 层 + pc
    toggleClass(l1El, 'active', stage.L1);
    toggleClass(l2El, 'active', stage.L2);
    toggleClass(l3El, 'active', stage.L3);
    toggleClass(l4El, 'active', stage.L4);
    toggleClass(pcEl, 'active', stage.pc);
    // LLM overlay
    toggleClass(llmOverlay, 'show', stage.llm);
    // 步骤指示
    if (stepIndEl) {
      stepIndEl.textContent = '阶段 ' + idx + ' / ' + totalSteps + ' · ' + stage.name;
    }
  }

  function toggleClass(el, cls, on) {
    if (!el) return;
    if (on) el.classList.add(cls);
    else el.classList.remove(cls);
  }

  // ============== 控制函数 ==============
  function nextStep() {
    if (currentStep >= totalSteps) return;
    currentStep++;
    applyStage(currentStep);
  }

  function resetAll() {
    stopAuto();
    currentStep = 0;
    applyStage(0);
  }

  function startAuto() {
    if (isPlaying) return;
    stopAuto();
    isPlaying = true;
    if (playBtn) { playBtn.textContent = '⏸ 暂停'; playBtn.classList.remove('primary'); }
    if (currentStep >= totalSteps) resetAll();
    // 各阶段停顿时间（毫秒）· stage 1 重 / stage 6 重（LLM 调用）
    var pauseMs = function (idx) {
      if (idx === 1) return 4000 / speed; // 累积阶段慢一些
      if (idx === 5) return 4500 / speed; // LLM overlay 停留
      return 2800 / speed;
    };
    function tick() {
      if (!isPlaying) return;
      if (currentStep >= totalSteps) { stopAuto(); return; }
      currentStep++;
      applyStage(currentStep);
      autoTimer = setTimeout(tick, pauseMs(currentStep));
    }
    autoTimer = setTimeout(tick, pauseMs(currentStep + 1));
  }

  function stopAuto() {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
    isPlaying = false;
    if (playBtn) { playBtn.textContent = '▶ 自动播放'; playBtn.classList.add('primary'); }
  }

  function togglePlay() {
    if (isPlaying) stopAuto();
    else startAuto();
  }

  function setSpeed(s) {
    speed = s;
    speedBtns.forEach(function (b) {
      if (parseFloat(b.getAttribute('data-speed')) === s) b.classList.add('active');
      else b.classList.remove('active');
    });
    if (isPlaying) { stopAuto(); startAuto(); }
  }

  // ============== 事件绑定 ==============
  if (playBtn)   playBtn.addEventListener('click', togglePlay);
  if (stepBtn)   stepBtn.addEventListener('click', function () { stopAuto(); nextStep(); });
  if (replayBtn) replayBtn.addEventListener('click', resetAll);
  var speedHandlers = [];
  speedBtns.forEach(function (b) {
    var h = function () { setSpeed(parseFloat(b.getAttribute('data-speed'))); };
    b.addEventListener('click', h);
    speedHandlers.push({ el: b, fn: h });
  });

  // 初始化 · 应用阶段 0
  applyStage(0);

  // ============== Cleanup ==============
  return function cleanup() {
    stopAuto();
    if (playBtn)   playBtn.removeEventListener('click', togglePlay);
    if (stepBtn)   stepBtn.removeEventListener('click', nextStep);
    if (replayBtn) replayBtn.removeEventListener('click', resetAll);
    speedHandlers.forEach(function (s) { s.el.removeEventListener('click', s.fn); });
    if (window.gsap) {
      window.gsap.killTweensOf('.s003-page, .s003-msg, .s003-fill');
    }
  };
};

/* ==========================================================================
 * S008 v2 · 记忆是提示不是真理 · prependUserContext 注入流水线
 * ========================================================================== */
window.slideHooks['slides/S008-memory-is-hint.html'] = function () {
  var page = document.querySelector('.s008-page');
  if (!page) return function(){};

  // 用户输入模板（按场景）
  var USER_MSGS = {
    relevant:   '帮我看下这个登录流程',
    irrelevant: '帮我加一个数组排序算法'
  };

  // 模型推理（按场景 × 是否有免责声明）
  var REASONINGS = {
    'relevant-with': [
      { ico:'①', cls:'', text:'解析 system-reminder 包裹的 memory · 这是「参考」非「指令」' },
      { ico:'②', cls:'good', text:'相关性判断：memory 提到 auth 重构用 JWT · 当前任务问"登录流程" · <strong>高度相关</strong>' },
      { ico:'③', cls:'good', text:'采纳 memory 作为上下文参考 · 回答时复用「JWT + 24h TTL」背景' }
    ],
    'relevant-without': [
      { ico:'①', cls:'', text:'解析 memory · 无边界声明 · 默认按"硬规则"处理' },
      { ico:'②', cls:'', text:'读取 memory：auth 用 JWT · TTL 24h' },
      { ico:'③', cls:'good', text:'恰好相关 · 误打误撞产出合理回答（这次运气好）' }
    ],
    'irrelevant-with': [
      { ico:'①', cls:'', text:'解析 system-reminder 包裹的 memory · 这是「参考」非「指令」' },
      { ico:'②', cls:'good', text:'相关性判断：memory 提到 auth/JWT · 当前任务问"排序算法" · <strong>不相关</strong>' },
      { ico:'③', cls:'good', text:'按免责声明指示 <strong>忽略 memory</strong> · 直接产出排序算法答案 · 不被陈旧上下文污染' }
    ],
    'irrelevant-without': [
      { ico:'①', cls:'bad', text:'解析 memory · 无边界声明 · 模型默认当"硬规则"' },
      { ico:'②', cls:'bad', text:'读取 memory：auth 用 JWT · TTL 24h' },
      { ico:'③', cls:'bad', text:'强行关联："我之前重构过 auth 用 JWT · 所以排序算法也应该用类似的 ..." → <strong>跑偏</strong>' }
    ]
  };
  var VERDICTS = {
    'relevant-with':    { cls:'adopt',  text:'✓ 采纳 · 记忆相关 → 作参考' },
    'relevant-without': { cls:'adopt',  text:'✓ 偶然采纳 · 这次运气好' },
    'irrelevant-with':  { cls:'ignore', text:'⊘ 忽略 · 记忆不相关 → 按免责声明指示不响应' },
    'irrelevant-without':{ cls:'bad',   text:'✗ 跑偏 · 把陈旧 memory 当硬规则照搬' }
  };

  // 管道 7 阶段（lines = 显示哪些行）
  var STAGES = [
    { name:'初始 · 等待启动',                lines: [{c:'placeholder', t:'// 等待启动 · 点击 ▶ 或 ⏭'}], srcFlow:[], arrow:false, reasonShow:false },
    { name:'步骤 1 · Memory 流入管道',        lines: [
        {c:'placeholder', t:'/* 组装 messages[0].content */'},
        {c:'tag', t:'&lt;system-reminder&gt;'},
        {c:'memory', t:'# Session Memory'},
        {c:'memory', t:'最近重构过 auth 模块 · 用了 JWT 方案 · TTL 24h'}
      ], srcFlow:['memory'], arrow:false, reasonShow:false },
    { name:'步骤 2 · DISCLAIMER 流入',        lines: [
        {c:'placeholder', t:'/* 组装 messages[0].content */'},
        {c:'tag', t:'&lt;system-reminder&gt;'},
        {c:'memory', t:'# Session Memory'},
        {c:'memory', t:'最近重构过 auth 模块 · 用了 JWT 方案 · TTL 24h'},
        {c:'memory', t:''},
        {c:'disclaimer', t:'IMPORTANT: this context may or may not be relevant'},
        {c:'disclaimer', t:'to your tasks. You should not respond unless highly relevant.'}
      ], srcFlow:['disclaimer'], arrow:false, reasonShow:false },
    { name:'步骤 3 · system-reminder 包裹完成', lines: [
        {c:'tag', t:'&lt;system-reminder&gt;'},
        {c:'memory', t:'# Session Memory · 最近重构过 auth · JWT · TTL 24h'},
        {c:'disclaimer', t:'⚠ IMPORTANT: may or may not be relevant · highly relevant 才理'},
        {c:'tag', t:'&lt;/system-reminder&gt;'}
      ], srcFlow:[], arrow:false, reasonShow:false },
    { name:'步骤 4 · User Msg 拼接',          lines: [
        {c:'tag', t:'&lt;system-reminder&gt;'},
        {c:'memory', t:'# Session Memory · 最近重构过 auth · JWT · TTL 24h'},
        {c:'disclaimer', t:'⚠ IMPORTANT: may or may not be relevant · highly relevant 才理'},
        {c:'tag', t:'&lt;/system-reminder&gt;'},
        {c:'memory', t:''},
        {c:'user', t:'__USER_MSG__'}
      ], srcFlow:['user'], arrow:false, reasonShow:false },
    { name:'步骤 5 · 组装完成 · 发送给 Claude', lines: [
        {c:'tag', t:'&lt;system-reminder&gt;'},
        {c:'memory', t:'# Session Memory · 最近重构过 auth · JWT · TTL 24h'},
        {c:'disclaimer', t:'⚠ IMPORTANT: may or may not be relevant · highly relevant 才理'},
        {c:'tag', t:'&lt;/system-reminder&gt;'},
        {c:'memory', t:''},
        {c:'user', t:'__USER_MSG__'}
      ], srcFlow:[], arrow:true, reasonShow:false },
    { name:'步骤 6 · 模型推理 + 裁决',         lines: 'KEEP', srcFlow:[], arrow:false, reasonShow:true }
  ];

  // DOM
  var pipeEl    = page.querySelector('#s008-pipe');
  var arrowEl   = page.querySelector('#s008-arrow');
  var stepIndEl = page.querySelector('#s008-step-ind');
  var srcMemEl  = page.querySelector('#s008-src-memory');
  var srcDisEl  = page.querySelector('#s008-src-disclaimer');
  var srcUserEl = page.querySelector('#s008-src-user');
  var userMsgEl = page.querySelector('#s008-user-msg');
  var reasonEl  = page.querySelector('#s008-reasoning');
  var verdictEl = page.querySelector('#s008-verdict');
  var verdictTxtEl = page.querySelector('#s008-verdict-text');
  var tabRelevant   = page.querySelector('#s008-tab-relevant');
  var tabIrrelevant = page.querySelector('#s008-tab-irrelevant');
  var noDiscBtn = page.querySelector('#s008-no-disclaimer');
  var playBtn   = page.querySelector('#s008-play');
  var stepBtn   = page.querySelector('#s008-step');
  var replayBtn = page.querySelector('#s008-replay');

  var currentStep = 0;
  var scenario = 'relevant';     // 'relevant' / 'irrelevant'
  var hideDisclaimer = false;
  var autoTimer = null;
  var isPlaying = false;
  var totalSteps = STAGES.length - 1;
  var lastLines = null;

  function applyStage(idx) {
    var stage = STAGES[idx];
    if (!stage) return;
    // pipe lines
    var lines = stage.lines === 'KEEP' ? lastLines : stage.lines;
    lastLines = lines;
    if (pipeEl && lines) {
      pipeEl.innerHTML = '';
      lines.forEach(function (ln) {
        if (hideDisclaimer && ln.c === 'disclaimer') return;
        var d = document.createElement('div');
        d.className = 's008-pipe-line ' + ln.c + ' visible';
        var t = ln.t;
        if (t.indexOf('__USER_MSG__') >= 0) t = USER_MSGS[scenario];
        d.innerHTML = t;
        pipeEl.appendChild(d);
      });
    }
    // 源卡片 flowing 状态
    [srcMemEl, srcDisEl, srcUserEl].forEach(function (el) { if (el) { el.classList.remove('flowing','danger'); } });
    if (stage.srcFlow.indexOf('memory') >= 0 && srcMemEl) srcMemEl.classList.add('flowing');
    if (stage.srcFlow.indexOf('disclaimer') >= 0 && srcDisEl) srcDisEl.classList.add('flowing','danger');
    if (stage.srcFlow.indexOf('user') >= 0 && srcUserEl) srcUserEl.classList.add('flowing');
    // arrow
    if (arrowEl) { if (stage.arrow) arrowEl.classList.add('sending'); else arrowEl.classList.remove('sending'); }
    // 步骤指示
    if (stepIndEl) stepIndEl.textContent = '阶段 ' + idx + ' / ' + totalSteps + ' · ' + stage.name;
    // user msg 文本同步
    if (userMsgEl) userMsgEl.textContent = USER_MSGS[scenario];
    // 推理 + verdict
    if (stage.reasonShow) renderReasoning();
    else if (reasonEl) {
      reasonEl.innerHTML = '<div class="step"><span class="ico">…</span><span class="body">等待消息组装完成</span></div>';
      if (verdictEl) verdictEl.classList.remove('show');
    }
  }

  function renderReasoning() {
    if (!reasonEl) return;
    var key = scenario + (hideDisclaimer ? '-without' : '-with');
    var steps = REASONINGS[key];
    var v = VERDICTS[key];
    reasonEl.innerHTML = '';
    steps.forEach(function (s, i) {
      setTimeout(function () {
        var d = document.createElement('div');
        d.className = 'step ' + (s.cls || '');
        d.innerHTML = '<span class="ico">' + s.ico + '</span><span class="body">' + s.text + '</span>';
        reasonEl.appendChild(d);
      }, i * 600);
    });
    setTimeout(function () {
      if (verdictEl) {
        verdictEl.className = 's008-verdict show ' + v.cls;
        if (verdictTxtEl) verdictTxtEl.innerHTML = v.text;
      }
    }, steps.length * 600 + 200);
  }

  function nextStep() { if (currentStep < totalSteps) { currentStep++; applyStage(currentStep); } }
  function resetAll() { stopAuto(); currentStep = 0; applyStage(0); }
  function startAuto() {
    if (isPlaying) return;
    stopAuto();
    isPlaying = true;
    if (playBtn) { playBtn.textContent = '⏸ 暂停'; playBtn.classList.remove('primary'); }
    if (currentStep >= totalSteps) resetAll();
    function tick() {
      if (!isPlaying) return;
      if (currentStep >= totalSteps) { stopAuto(); return; }
      currentStep++;
      applyStage(currentStep);
      var delay = currentStep === 6 ? 3500 : 2200;
      autoTimer = setTimeout(tick, delay);
    }
    autoTimer = setTimeout(tick, 1800);
  }
  function stopAuto() {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
    isPlaying = false;
    if (playBtn) { playBtn.textContent = '▶ 自动播放'; playBtn.classList.add('primary'); }
  }
  function togglePlay() { if (isPlaying) stopAuto(); else startAuto(); }

  function setScenario(scn) {
    scenario = scn;
    if (tabRelevant)   tabRelevant.classList.toggle('active', scn === 'relevant');
    if (tabIrrelevant) tabIrrelevant.classList.toggle('active', scn === 'irrelevant');
    applyStage(currentStep);
  }
  function toggleNoDisc() {
    hideDisclaimer = !hideDisclaimer;
    if (noDiscBtn) noDiscBtn.classList.toggle('active', hideDisclaimer);
    applyStage(currentStep);
  }

  // 事件
  if (playBtn)   playBtn.addEventListener('click', togglePlay);
  if (stepBtn)   stepBtn.addEventListener('click', function(){ stopAuto(); nextStep(); });
  if (replayBtn) replayBtn.addEventListener('click', resetAll);
  if (tabRelevant)   tabRelevant.addEventListener('click', function(){ setScenario('relevant'); });
  if (tabIrrelevant) tabIrrelevant.addEventListener('click', function(){ setScenario('irrelevant'); });
  if (noDiscBtn) noDiscBtn.addEventListener('click', toggleNoDisc);

  applyStage(0);

  return function cleanup() {
    stopAuto();
    if (playBtn)   playBtn.removeEventListener('click', togglePlay);
    if (stepBtn)   stepBtn.removeEventListener('click', nextStep);
    if (replayBtn) replayBtn.removeEventListener('click', resetAll);
    if (tabRelevant)   tabRelevant.removeEventListener('click', function(){ setScenario('relevant'); });
    if (tabIrrelevant) tabIrrelevant.removeEventListener('click', function(){ setScenario('irrelevant'); });
    if (noDiscBtn) noDiscBtn.removeEventListener('click', toggleNoDisc);
    if (window.gsap) window.gsap.killTweensOf('.s008-page *');
  };
};

/* ==========================================================================
 * S010 v2 · 单 Agent 串行 vs 多 Agent 隔离 · 双轨对比沙盘
 * ========================================================================== */
window.slideHooks['slides/S010-single-agent-crash.html'] = function () {
  var page = document.querySelector('.s010-page');
  if (!page) return function(){};

  // 4 个子任务（serial 真堆 / isolated 只回摘要）
  var TASKS = [
    { id:'A', name:'Task1 调研三方案', serialTok: 12000, internalTok: 14000, summary: 'Found 3 candidate libs' },
    { id:'B', name:'Task2 实现',       serialTok: 15000, internalTok: 17000, summary: 'Implementing auth module' },
    { id:'C', name:'Task3 测试',       serialTok: 14000, internalTok: 16000, summary: 'Writing 12 unit tests' },
    { id:'D', name:'Task4 总结',       serialTok: 13000, internalTok: 15000, summary: 'Drafting summary report' }
  ];
  var CTX_LIMIT = 50000;
  var BASE = 2000;
  var SUMMARY_TOK = 30; // 每条摘要 ~30 tok

  // 6 阶段
  function buildStages() {
    var sCtx = BASE;
    var iCtx = BASE;
    var stages = [{
      name:'初始 · 同 4 个子任务即将开始',
      sCtx: BASE, sHistory: [], sCrashed: false,
      iCtx: BASE, iHistory: [], activeSub: -1, doneSubs: []
    }];
    TASKS.forEach(function (task, idx) {
      sCtx += task.serialTok;
      iCtx += SUMMARY_TOK;
      var crashed = sCtx > CTX_LIMIT;
      stages.push({
        name: '任务 ' + (idx+1) + ' · ' + task.name,
        sCtx: sCtx,
        sHistory: TASKS.slice(0, idx+1).map(function (t, i) {
          var thisCrash = (BASE + TASKS.slice(0, i+1).reduce(function(a,b){return a+b.serialTok;}, 0)) > CTX_LIMIT;
          return { name: t.name, tok: t.serialTok, crash: thisCrash };
        }),
        sCrashed: crashed,
        iCtx: iCtx,
        iHistory: TASKS.slice(0, idx+1).map(function (t) { return { name: '摘要 · ' + t.summary, tok: SUMMARY_TOK }; }),
        activeSub: idx,
        doneSubs: TASKS.slice(0, idx+1).map(function (_, i) { return i; })
      });
    });
    stages.push({
      name: '结论 · 串行撞墙 / 隔离安然',
      sCtx: sCtx, sHistory: stages[stages.length-1].sHistory, sCrashed: true,
      iCtx: iCtx, iHistory: stages[stages.length-1].iHistory, activeSub: -1, doneSubs: [0,1,2,3]
    });
    return stages;
  }
  var STAGES = buildStages();

  // DOM
  var sFill = page.querySelector('#s010-s-fill');
  var sNow  = page.querySelector('#s010-s-now');
  var sHistory = page.querySelector('#s010-s-history');
  var sStatus  = page.querySelector('#s010-s-status');
  var sTrack   = page.querySelector('#s010-serial');
  var iFill = page.querySelector('#s010-i-fill');
  var iNow  = page.querySelector('#s010-i-now');
  var iHistory = page.querySelector('#s010-i-history');
  var iStatus  = page.querySelector('#s010-i-status');
  var subEls = page.querySelectorAll('.s010-sub');
  var stepIndEl = page.querySelector('#s010-step-ind');
  var lineSerial = page.querySelector('#s010-line-serial');
  var lineIso    = page.querySelector('#s010-line-iso');
  var crashMark  = page.querySelector('#s010-crash-mark');
  var playBtn   = page.querySelector('#s010-play');
  var stepBtn   = page.querySelector('#s010-step');
  var replayBtn = page.querySelector('#s010-replay');
  var speedBtns = page.querySelectorAll('.s010-speed-btn');

  var currentStep = 0;
  var speed = 1;
  var autoTimer = null;
  var isPlaying = false;
  var totalSteps = STAGES.length - 1;

  function pct(v) { return Math.min(100, (v / CTX_LIMIT) * 100); }

  function chartPath(values) {
    // values: array of ctx (按 stage 增长) · 转 SVG path
    // viewBox 800 x 80 · 50K → y=12, 2K → y=76
    var step = 800 / Math.max(1, totalSteps);
    var pts = ['M0 76'];
    values.forEach(function (v, i) {
      var x = (i+1) * step;
      // y 反向：v=2000 → 76 · v=50000 → 12
      var y = 76 - ((v - BASE) / (CTX_LIMIT - BASE)) * 64;
      if (y < 8) y = 8;
      pts.push('L' + x.toFixed(1) + ' ' + y.toFixed(1));
    });
    return pts.join(' ');
  }

  function applyStage(idx) {
    var stage = STAGES[idx];
    if (!stage) return;

    // serial 轨
    if (sFill) sFill.style.width = pct(stage.sCtx) + '%';
    if (sNow)  { sNow.textContent = stage.sCtx.toLocaleString(); sNow.classList.toggle('warn', stage.sCtx > 40000); }
    if (sTrack) sTrack.classList.toggle('crashed', stage.sCrashed);
    if (sHistory) {
      sHistory.innerHTML = '';
      stage.sHistory.forEach(function (h) {
        var d = document.createElement('div');
        d.className = 's010-history-item' + (h.crash ? ' crash' : '');
        d.innerHTML = '<span class="item-title">' + h.name + (h.crash ? ' 💥' : '') + '</span><span class="item-tok">+' + (h.tok/1000).toFixed(1) + 'K</span>';
        sHistory.appendChild(d);
      });
    }
    if (sStatus) {
      sStatus.textContent = stage.sCrashed
        ? '💥 上下文爆 · 撞 50K 红线 · 任务质量崩盘'
        : '已完成 ' + stage.sHistory.length + ' / 4 · ctx ' + stage.sCtx.toLocaleString();
    }

    // isolated 轨
    if (iFill) iFill.style.width = pct(stage.iCtx) + '%';
    if (iNow)  iNow.textContent = stage.iCtx.toLocaleString();
    if (iHistory) {
      iHistory.innerHTML = '';
      stage.iHistory.forEach(function (h) {
        var d = document.createElement('div');
        d.className = 's010-history-item';
        d.innerHTML = '<span class="item-title">' + h.name + '</span><span class="item-tok">+' + h.tok + ' tok</span>';
        iHistory.appendChild(d);
      });
    }
    if (iStatus) iStatus.textContent = '已完成 ' + stage.iHistory.length + ' / 4 · 父 ctx 仅 ' + stage.iCtx.toLocaleString() + '（基线 + ' + (stage.iCtx - BASE) + '）';

    // sub agent 状态
    subEls.forEach(function (el, i) {
      el.classList.toggle('active', i === stage.activeSub);
      el.classList.toggle('done', stage.doneSubs.indexOf(i) >= 0 && i !== stage.activeSub);
    });

    // SVG 折线（含已发生 stage 的数据）
    var sVals = [], iVals = [];
    for (var k = 1; k <= idx; k++) {
      sVals.push(STAGES[k].sCtx);
      iVals.push(STAGES[k].iCtx);
    }
    if (lineSerial) lineSerial.setAttribute('d', chartPath(sVals));
    if (lineIso)    lineIso.setAttribute('d', chartPath(iVals));
    // 撞墙标记
    if (crashMark) {
      if (stage.sCrashed) {
        var crashIdx = -1;
        STAGES.forEach(function (s, i2) { if (s.sCrashed && crashIdx === -1) crashIdx = i2; });
        if (crashIdx >= 0 && crashIdx <= idx) {
          var step = 800 / totalSteps;
          crashMark.setAttribute('cx', (crashIdx * step).toFixed(1));
          crashMark.setAttribute('cy', '12');
          crashMark.setAttribute('opacity', '1');
        }
      } else {
        crashMark.setAttribute('opacity', '0');
      }
    }

    if (stepIndEl) stepIndEl.textContent = '阶段 ' + idx + ' / ' + totalSteps + ' · ' + stage.name;
  }

  function nextStep() { if (currentStep < totalSteps) { currentStep++; applyStage(currentStep); } }
  function resetAll() { stopAuto(); currentStep = 0; applyStage(0); }
  function startAuto() {
    if (isPlaying) return;
    stopAuto();
    isPlaying = true;
    if (playBtn) { playBtn.textContent = '⏸ 暂停'; playBtn.classList.remove('primary'); }
    if (currentStep >= totalSteps) resetAll();
    var pauseMs = function () { return 2400 / speed; };
    function tick() {
      if (!isPlaying) return;
      if (currentStep >= totalSteps) { stopAuto(); return; }
      currentStep++;
      applyStage(currentStep);
      autoTimer = setTimeout(tick, pauseMs());
    }
    autoTimer = setTimeout(tick, pauseMs());
  }
  function stopAuto() {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
    isPlaying = false;
    if (playBtn) { playBtn.textContent = '▶ 自动播放'; playBtn.classList.add('primary'); }
  }
  function togglePlay() { if (isPlaying) stopAuto(); else startAuto(); }
  function setSpeed(s) {
    speed = s;
    speedBtns.forEach(function (b) {
      b.classList.toggle('active', parseFloat(b.getAttribute('data-speed')) === s);
    });
    if (isPlaying) { stopAuto(); startAuto(); }
  }

  if (playBtn)   playBtn.addEventListener('click', togglePlay);
  if (stepBtn)   stepBtn.addEventListener('click', function(){ stopAuto(); nextStep(); });
  if (replayBtn) replayBtn.addEventListener('click', resetAll);
  var speedHandlers = [];
  speedBtns.forEach(function (b) {
    var h = function () { setSpeed(parseFloat(b.getAttribute('data-speed'))); };
    b.addEventListener('click', h);
    speedHandlers.push({ el: b, fn: h });
  });

  applyStage(0);

  return function cleanup() {
    stopAuto();
    if (playBtn)   playBtn.removeEventListener('click', togglePlay);
    if (stepBtn)   stepBtn.removeEventListener('click', nextStep);
    if (replayBtn) replayBtn.removeEventListener('click', resetAll);
    speedHandlers.forEach(function (s) { s.el.removeEventListener('click', s.fn); });
    if (window.gsap) window.gsap.killTweensOf('.s010-page *');
  };
};

/* ==========================================================================
 * S011 v2 · 子 Agent 内部细节 · 14K → 3-5 词压缩魔法
 * ========================================================================== */
window.slideHooks['slides/S011-subagent-isolation-sim.html'] = function () {
  var page = document.querySelector('.s011-page');
  if (!page) return function(){};

  var ACTIONS = [
    { ico:'📞', t:'Read("src/user.ts")', tok:3200, type:'tool' },
    { ico:'📞', t:'Read("src/auth.ts")', tok:2800, type:'tool' },
    { ico:'📞', t:'Edit("src/user.ts", refactor login)', tok:500, type:'tool' },
    { ico:'📞', t:'Bash("npm test")', tok:4100, type:'tool' },
    { ico:'📞', t:'Read("test/user.test.ts")', tok:1600, type:'tool' },
    { ico:'📞', t:'Edit("src/user.ts", fix lint)', tok:2000, type:'tool' }
  ];

  // 9 阶段：0 初始 / 1-5 累积 5 动作 / 6 父询问 / 7 LLM 输出(Good 或 Bad) / 8 摘要回父
  var BASE = 2000;
  function buildStages(mode) {
    var stages = [{
      name:'初始 · 父 dispatch 子 Agent',
      subCtx: BASE, subActions: [],
      parentCtx: 2000, parentHistory: [],
      parentQ: false, llmOut: null, constraints: ['idle','idle','idle','idle','idle'], verdict: null
    }];
    var subCtx = BASE;
    for (var i = 0; i < 5; i++) {
      subCtx += ACTIONS[i].tok;
      stages.push({
        name: '动作 ' + (i+1) + ' · ' + ACTIONS[i].t.slice(0, 28),
        subCtx: subCtx,
        subActions: ACTIONS.slice(0, i+1),
        parentCtx: 2000, parentHistory: [],
        parentQ: false, llmOut: null, constraints: ['idle','idle','idle','idle','idle'], verdict: null
      });
    }
    // 阶段 6: 父来询问
    stages.push({
      name:'父 Agent 询问 "你做什么了?"',
      subCtx: subCtx, subActions: ACTIONS.slice(0, 5),
      parentCtx: 2000, parentHistory: [],
      parentQ: true, llmOut: null, constraints: ['active','active','active','active','active'], verdict: null
    });
    if (mode === 'bad') {
      // 阶段 7: Bad LLM 输出
      stages.push({
        name:'LLM 第 1 次输出 · ❌ Bad 示例',
        subCtx: subCtx, subActions: ACTIONS.slice(0, 5),
        parentCtx: 2000, parentHistory: [],
        parentQ: true,
        llmOut: { text: '"Analyzed the branch diff"', cls: 'bad', note: '4 词但过去时 + 提 branch' },
        constraints: ['pass','fail','fail','pass','fail'],
        verdict: { cls:'fail', text:'❌ 校验失败 · 重写' }
      });
      // 阶段 8: LLM 重写 Good
      stages.push({
        name:'LLM 重写 · ✓ Good · 摘要飞回父',
        subCtx: subCtx, subActions: ACTIONS.slice(0, 5),
        parentCtx: 2030, parentHistory: [{ lbl:'子 Agent 摘要', text:'"Refactoring user.ts login"', tok:30 }],
        parentQ: false,
        llmOut: { text: '"Refactoring user.ts login"', cls: 'good', note: '4 词 + 现在分词 + 点文件名' },
        constraints: ['pass','pass','pass','pass','pass'],
        verdict: { cls:'pass', text:'✓ 5 项全过 · 摘要回父 · +30 tok' }
      });
    } else {
      // Good 模式：直接通过
      stages.push({
        name:'LLM 输出 · ✓ Good 示例',
        subCtx: subCtx, subActions: ACTIONS.slice(0, 5),
        parentCtx: 2000, parentHistory: [],
        parentQ: true,
        llmOut: { text: '"Refactoring user.ts login"', cls: 'good', note: '4 词 + 现在分词 + 点文件名' },
        constraints: ['pass','pass','pass','pass','pass'],
        verdict: { cls:'pass', text:'✓ 5 项全过' }
      });
      stages.push({
        name:'摘要飞回父 Agent · 14K 留在子窗口',
        subCtx: subCtx, subActions: ACTIONS.slice(0, 5),
        parentCtx: 2030, parentHistory: [{ lbl:'子 Agent 摘要', text:'"Refactoring user.ts login"', tok:30 }],
        parentQ: false,
        llmOut: { text: '"Refactoring user.ts login"', cls: 'good', note: '飞回父 · 14K 留子窗口' },
        constraints: ['pass','pass','pass','pass','pass'],
        verdict: { cls:'pass', text:'✓ 完成 · 父 ctx +30 · 隔离生效' }
      });
    }
    return stages;
  }

  var mode = 'good';
  var STAGES = buildStages(mode);
  var currentStep = 0;
  var autoTimer = null;
  var isPlaying = false;
  var totalSteps;

  // DOM
  var pFill = page.querySelector('#s011-p-fill');
  var pNow  = page.querySelector('#s011-p-now');
  var pHistEl = page.querySelector('#s011-p-history');
  var pNote   = page.querySelector('#s011-p-note');
  var sFill = page.querySelector('#s011-s-fill');
  var sNow  = page.querySelector('#s011-s-now');
  var sActions = page.querySelector('#s011-actions');
  var sNote = page.querySelector('#s011-s-note');
  var stepIndEl = page.querySelector('#s011-step-ind');
  var cEls = [
    page.querySelector('#s011-c1'),
    page.querySelector('#s011-c2'),
    page.querySelector('#s011-c3'),
    page.querySelector('#s011-c4'),
    page.querySelector('#s011-c5')
  ];
  var llmLineEl = page.querySelector('#s011-llm-line');
  var verdictEl = page.querySelector('#s011-verdict');
  var playBtn   = page.querySelector('#s011-play');
  var stepBtn   = page.querySelector('#s011-step');
  var replayBtn = page.querySelector('#s011-replay');
  var modeGoodBtn = page.querySelector('#s011-mode-good');
  var modeBadBtn  = page.querySelector('#s011-mode-bad');

  function applyStage(idx) {
    var stage = STAGES[idx];
    if (!stage) return;

    // 父
    if (pFill) pFill.style.width = (stage.parentCtx / 50000 * 100) + '%';
    if (pNow) { pNow.textContent = stage.parentCtx.toLocaleString(); if (stage.parentHistory.length > 0) pNow.classList.add('up'); }
    if (pHistEl) {
      if (stage.parentHistory.length === 0) {
        pHistEl.innerHTML = '<div class="empty">等待子 Agent 返回摘要 ...</div>';
      } else {
        pHistEl.innerHTML = '';
        stage.parentHistory.forEach(function (h) {
          var d = document.createElement('div');
          d.className = 'summary-item';
          d.innerHTML = '<span class="lbl">' + h.lbl + '</span><span class="body">' + h.text + '</span><span class="tok">+' + h.tok + ' tok</span>';
          pHistEl.appendChild(d);
        });
      }
    }
    if (pNote) pNote.classList.toggle('show', stage.parentHistory.length > 0);

    // 子
    if (sFill) sFill.style.width = (stage.subCtx / 50000 * 100) + '%';
    if (sNow) sNow.textContent = stage.subCtx.toLocaleString();
    if (sActions) {
      sActions.innerHTML = '';
      stage.subActions.forEach(function (a) {
        var d = document.createElement('div');
        d.className = 's011-action-line';
        d.style.opacity = '1';
        d.innerHTML = '<span class="ico">' + a.ico + '</span>' + a.t + '<span class="tok">+' + a.tok.toLocaleString() + '</span>';
        sActions.appendChild(d);
      });
      if (stage.parentQ) {
        var q = document.createElement('div');
        q.className = 's011-action-line parent-q';
        q.style.opacity = '1';
        q.innerHTML = '👨‍💼 父 Agent: "你做什么了？"';
        sActions.appendChild(q);
      }
      if (stage.llmOut) {
        var o = document.createElement('div');
        o.className = 's011-action-line summary-out';
        o.style.opacity = '1';
        o.innerHTML = '🛠 子 Agent 摘要: ' + stage.llmOut.text;
        sActions.appendChild(o);
      }
      sActions.scrollTop = sActions.scrollHeight;
    }
    if (sNote) sNote.classList.toggle('show', stage.subActions.length >= 3);

    // 右栏 5 约束
    cEls.forEach(function (el, i) {
      if (!el) return;
      el.classList.remove('active','pass','fail');
      var st = stage.constraints[i];
      if (st === 'active') el.classList.add('active');
      else if (st === 'pass') { el.classList.add('pass'); el.querySelector('.icon').textContent = '✓'; }
      else if (st === 'fail') { el.classList.add('fail'); el.querySelector('.icon').textContent = '✗'; }
      else el.querySelector('.icon').textContent = '○';
    });

    // LLM 输出
    if (llmLineEl) {
      if (stage.llmOut) {
        llmLineEl.className = 'out-line ' + stage.llmOut.cls;
        llmLineEl.innerHTML = stage.llmOut.text + '<div style="font-size:0.62rem;color:rgba(232,222,200,0.55);margin-top:4px">' + stage.llmOut.note + '</div>';
      } else {
        llmLineEl.className = 'out-line empty';
        llmLineEl.textContent = '等待触发摘要生成 ...';
      }
    }

    // verdict
    if (verdictEl) {
      if (stage.verdict) {
        verdictEl.className = 's011-verdict show ' + stage.verdict.cls;
        verdictEl.textContent = stage.verdict.text;
      } else {
        verdictEl.className = 's011-verdict';
        verdictEl.textContent = '待校验';
      }
    }

    if (stepIndEl) stepIndEl.textContent = '阶段 ' + idx + ' / ' + totalSteps + ' · ' + stage.name;
  }

  function nextStep() { if (currentStep < totalSteps) { currentStep++; applyStage(currentStep); } }
  function resetAll() { stopAuto(); currentStep = 0; applyStage(0); }
  function startAuto() {
    if (isPlaying) return; stopAuto();
    isPlaying = true;
    if (playBtn) { playBtn.textContent = '⏸ 暂停'; playBtn.classList.remove('primary'); }
    if (currentStep >= totalSteps) resetAll();
    function tick() {
      if (!isPlaying) return;
      if (currentStep >= totalSteps) { stopAuto(); return; }
      currentStep++;
      applyStage(currentStep);
      autoTimer = setTimeout(tick, currentStep === 6 ? 2500 : 1800);
    }
    autoTimer = setTimeout(tick, 1800);
  }
  function stopAuto() {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
    isPlaying = false;
    if (playBtn) { playBtn.textContent = '▶ 自动播放'; playBtn.classList.add('primary'); }
  }
  function togglePlay() { if (isPlaying) stopAuto(); else startAuto(); }
  function setMode(m) {
    mode = m;
    STAGES = buildStages(m);
    totalSteps = STAGES.length - 1;
    if (modeGoodBtn) modeGoodBtn.classList.toggle('active', m === 'good');
    if (modeBadBtn)  modeBadBtn.classList.toggle('active', m === 'bad');
    resetAll();
  }
  totalSteps = STAGES.length - 1;

  if (playBtn)   playBtn.addEventListener('click', togglePlay);
  if (stepBtn)   stepBtn.addEventListener('click', function(){ stopAuto(); nextStep(); });
  if (replayBtn) replayBtn.addEventListener('click', resetAll);
  if (modeGoodBtn) modeGoodBtn.addEventListener('click', function(){ setMode('good'); });
  if (modeBadBtn)  modeBadBtn.addEventListener('click', function(){ setMode('bad'); });

  applyStage(0);

  return function cleanup() {
    stopAuto();
    if (playBtn)   playBtn.removeEventListener('click', togglePlay);
    if (stepBtn)   stepBtn.removeEventListener('click', nextStep);
    if (replayBtn) replayBtn.removeEventListener('click', resetAll);
    if (modeGoodBtn) modeGoodBtn.removeEventListener('click', function(){ setMode('good'); });
    if (modeBadBtn)  modeBadBtn.removeEventListener('click', function(){ setMode('bad'); });
    if (window.gsap) window.gsap.killTweensOf('.s011-page *');
  };
};

/* ==========================================================================
 * S013 · Fork 缓存参数沙盘 · N + hit_ratio 双滑块
 * ========================================================================== */
window.slideHooks['slides/S013-fork-cache-sandbox.html'] = function () {
  var page = document.querySelector('.s013-page');
  if (!page) return function(){};

  var PER_AGENT_TOK = 8; // 8K
  var MISS_PRICE = 1.0;  // 归一化 $1/K

  // DOM
  var nSlider = page.querySelector('#s013-n-slider');
  var rSlider = page.querySelector('#s013-r-slider');
  var nVal = page.querySelector('#s013-n-val');
  var rVal = page.querySelector('#s013-r-val');
  var indepVal = page.querySelector('#s013-indep-val');
  var forkVal  = page.querySelector('#s013-fork-val');
  var indepFill = page.querySelector('#s013-indep-fill');
  var forkFill  = page.querySelector('#s013-fork-fill');
  var savingsEl = page.querySelector('#s013-savings');
  var savedMoneyEl = page.querySelector('#s013-saved-money');
  var equivEl = page.querySelector('#s013-equiv');
  var explainPctEl = page.querySelector('#s013-explain-pct');
  var explainEquivEl = page.querySelector('#s013-explain-equiv');
  var lineIndep = page.querySelector('#s013-line-indep');
  var lineFork  = page.querySelector('#s013-line-fork');
  var cursor    = page.querySelector('#s013-line-cursor');
  var cursorLabel = page.querySelector('#s013-cursor-label');
  var presetBtns = page.querySelectorAll('.s013-preset-btn');
  var demoBtn = page.querySelector('#s013-demo');
  var resetBtn = page.querySelector('#s013-reset');

  var demoTimer = null;

  function compute(N, r) {
    var indep = N * PER_AGENT_TOK * MISS_PRICE;
    var fork  = PER_AGENT_TOK * MISS_PRICE + (N - 1) * PER_AGENT_TOK * MISS_PRICE * r;
    var savings = indep > 0 ? (indep - fork) / indep : 0;
    var equiv = fork / (PER_AGENT_TOK * MISS_PRICE);
    return { indep: indep, fork: fork, savings: savings, equiv: equiv };
  }

  // 曲线计算：N=1→20
  function curvePath(r, kind) {
    // x: 0..800 映射 N=1..20 · y: 100..0 映射 $0..$160
    var pts = [];
    for (var n = 1; n <= 20; n++) {
      var c = compute(n, r);
      var v = kind === 'indep' ? c.indep : c.fork;
      var x = ((n - 1) / 19) * 800;
      var y = 100 - (Math.min(v, 160) / 160) * 100;
      pts.push((n === 1 ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1));
    }
    return pts.join(' ');
  }

  function update() {
    var N = parseInt(nSlider.value);
    var r = parseFloat(rSlider.value);
    if (nVal) nVal.textContent = N;
    if (rVal) rVal.textContent = r.toFixed(2);

    var c = compute(N, r);

    if (indepVal) indepVal.textContent = '$' + c.indep.toFixed(2);
    if (forkVal)  forkVal.textContent  = '$' + c.fork.toFixed(2);
    // bar 视觉 (max = indep · fork 相对)
    var maxV = Math.max(c.indep, c.fork);
    if (indepFill) indepFill.style.width = (c.indep / maxV * 100) + '%';
    if (forkFill)  forkFill.style.width  = (c.fork / maxV * 100) + '%';

    var pctTxt = (c.savings * 100).toFixed(0) + '%';
    if (savingsEl) {
      savingsEl.textContent = c.savings >= 0 ? '-' + pctTxt : '+' + Math.abs(c.savings * 100).toFixed(0) + '%';
      savingsEl.className = 'val ' + (c.savings > 0.3 ? 'good' : (c.savings < 0.05 ? 'bad' : ''));
    }
    if (savedMoneyEl) savedMoneyEl.textContent = '$' + (c.indep - c.fork).toFixed(2);
    if (equivEl) equivEl.textContent = c.equiv.toFixed(1);
    if (explainPctEl) explainPctEl.textContent = pctTxt;
    if (explainEquivEl) explainEquivEl.textContent = c.equiv.toFixed(1);

    // 曲线
    if (lineIndep) lineIndep.setAttribute('d', curvePath(r, 'indep'));
    if (lineFork)  lineFork.setAttribute('d', curvePath(r, 'fork'));
    // 当前 N 黄线
    var cx = ((N - 1) / 19 * 800).toFixed(1);
    if (cursor) { cursor.setAttribute('x1', cx); cursor.setAttribute('x2', cx); }
    if (cursorLabel) { cursorLabel.setAttribute('x', cx); cursorLabel.textContent = 'N=' + N; }

    // 预设按钮 active 状态
    presetBtns.forEach(function (b) {
      b.classList.toggle('active', Math.abs(parseFloat(b.getAttribute('data-r')) - r) < 0.01);
    });
  }

  function nSliderInput()  { update(); }
  function rSliderInput()  { update(); }
  function clickPreset(e)  {
    var r = parseFloat(e.currentTarget.getAttribute('data-r'));
    rSlider.value = r;
    update();
  }
  function clickDemo() {
    if (demoTimer) { clearInterval(demoTimer); demoTimer = null; demoBtn.textContent = '▶ 演示 N=1→20 动画'; return; }
    var n = 1;
    nSlider.value = 1; update();
    demoBtn.textContent = '⏸ 停止演示';
    demoTimer = setInterval(function () {
      n++;
      if (n > 20) { clearInterval(demoTimer); demoTimer = null; demoBtn.textContent = '▶ 演示 N=1→20 动画'; return; }
      nSlider.value = n;
      update();
    }, 350);
  }
  function clickReset() {
    if (demoTimer) { clearInterval(demoTimer); demoTimer = null; demoBtn.textContent = '▶ 演示 N=1→20 动画'; }
    nSlider.value = 5;
    rSlider.value = 0.1;
    update();
  }

  if (nSlider) nSlider.addEventListener('input', nSliderInput);
  if (rSlider) rSlider.addEventListener('input', rSliderInput);
  presetBtns.forEach(function (b) { b.addEventListener('click', clickPreset); });
  if (demoBtn) demoBtn.addEventListener('click', clickDemo);
  if (resetBtn) resetBtn.addEventListener('click', clickReset);

  update();

  return function cleanup() {
    if (demoTimer) { clearInterval(demoTimer); demoTimer = null; }
    if (nSlider) nSlider.removeEventListener('input', nSliderInput);
    if (rSlider) rSlider.removeEventListener('input', rSliderInput);
    presetBtns.forEach(function (b) { b.removeEventListener('click', clickPreset); });
    if (demoBtn) demoBtn.removeEventListener('click', clickDemo);
    if (resetBtn) resetBtn.removeEventListener('click', clickReset);
  };
};

/* ==========================================================================
 * S020 · 跨章总结双轨 · 朴素 vs 三约束 · 6 任务
 * ========================================================================== */
window.slideHooks['slides/S020-closure-simulator.html'] = function () {
  var page = document.querySelector('.s020-page');
  if (!page) return function(){};

  var BASE = 2000;
  var LIMIT = 50000;

  // 6 任务剧本
  var TASKS = [
    { id:1, name:'Task1 调研三方案',  nTok: 8000, gSummary:'Researched 3 libs',     gExtra: null,             gNet: 30 },
    { id:2, name:'Task2 实现 auth',   nTok: 9000, gSummary:'Implementing auth',     gExtra: 'L1 清旧',          gNet: -3000 + 30 },
    { id:3, name:'Task3 测试 12 用例',nTok:11000, gSummary:'Writing 12 tests',      gExtra: '📕 写入 session_memory.md', gNet: 30 },
    { id:4, name:'Task4 重构 utils',  nTok:10000, gSummary:'Refactoring utils.ts',  gExtra: 'L3 复用记忆 -2K',   gNet: -2000 + 30 },
    { id:5, name:'Task5 部署 docker', nTok:12000, gSummary:'Deploying to docker',   gExtra: null,             gNet: 30 },
    { id:6, name:'Task6 总结 report', nTok: 9000, gSummary:'Drafting summary',      gExtra: 'post-compact +15K 恢复', gNet: 15000 + 30 }
  ];

  // 状态快照（含 8 阶段）
  function buildStages() {
    var nCtx = BASE, gCtx = BASE;
    var nHist = [], gHist = [];
    var stages = [{
      name:'初始 · 同样 6 任务即将开始',
      nCtx: BASE, nHist: [], nCrashed: false,
      gCtx: BASE, gHist: []
    }];
    TASKS.forEach(function (task, i) {
      // naive：堆 nTok
      nCtx += task.nTok;
      var nCrashed = nCtx > LIMIT;
      nHist = nHist.concat([{ name: task.name, tok: task.nTok, crash: nCrashed, cutoff: false }]);
      // 如果撞墙后再来任务 · 显示 cutoff
      if (nCrashed && i + 1 < TASKS.length) {
        // 后续任务直接 cutoff（不增加）
      }
      // guarded：每任务一行子 Agent 摘要 + 可选介入行
      var gAdd = [{ name:'子 Agent 摘要 · "' + task.gSummary + '"', tok:30, kind:'summary' }];
      if (task.gExtra) gAdd.push({ name: task.gExtra, tok: task.gNet - 30, kind: task.gExtra.indexOf('📕') >= 0 ? 'memory' : 'compress' });
      gCtx += task.gNet;
      gCtx = Math.max(BASE, gCtx);
      gHist = gHist.concat(gAdd);

      stages.push({
        name:'任务 ' + (i+1) + ' · ' + task.name,
        nCtx: Math.min(nCtx, LIMIT + 6000), // 防爆出可视范围
        nHist: nHist.slice(),
        nCrashed: nCrashed,
        gCtx: gCtx,
        gHist: gHist.slice()
      });
    });
    // 阶段 7：结论
    stages.push({
      name:'结论 · 朴素崩盘 / 三约束装齐胜出',
      nCtx: stages[stages.length-1].nCtx,
      nHist: stages[stages.length-1].nHist.concat([{ name:'☠ 任务被截断 · 上下文已爆', tok:0, cutoff:true }]),
      nCrashed: true,
      gCtx: stages[stages.length-1].gCtx,
      gHist: stages[stages.length-1].gHist
    });
    return stages;
  }
  var STAGES = buildStages();
  var totalSteps = STAGES.length - 1;

  // DOM
  var nFill = page.querySelector('#s020-n-fill');
  var nNow  = page.querySelector('#s020-n-now');
  var nHistEl = page.querySelector('#s020-n-history');
  var nStatus = page.querySelector('#s020-n-status');
  var nTrack  = page.querySelector('#s020-naive');
  var gFill = page.querySelector('#s020-g-fill');
  var gNow  = page.querySelector('#s020-g-now');
  var gHistEl = page.querySelector('#s020-g-history');
  var gStatus = page.querySelector('#s020-g-status');
  var stepIndEl = page.querySelector('#s020-step-ind');
  var lineNaive = page.querySelector('#s020-line-naive');
  var lineGuarded = page.querySelector('#s020-line-guarded');
  var crashMark = page.querySelector('#s020-crash-mark');
  var cnclN = page.querySelector('#s020-cncl-naive');
  var cnclG = page.querySelector('#s020-cncl-guarded');
  var nDoneEl = page.querySelector('#s020-n-done');
  var gDoneEl = page.querySelector('#s020-g-done');
  var gFinalEl = page.querySelector('#s020-g-final');
  var playBtn = page.querySelector('#s020-play');
  var stepBtn = page.querySelector('#s020-step');
  var replayBtn = page.querySelector('#s020-replay');
  var speedBtns = page.querySelectorAll('.s020-speed-btn');

  var currentStep = 0;
  var speed = 1;
  var autoTimer = null;
  var isPlaying = false;

  function pct(v) { return Math.min(110, (v / LIMIT) * 100); }

  function chartPath(values) {
    if (values.length === 0) return 'M0 86';
    var step = 800 / 7;
    var pts = ['M0 86'];
    values.forEach(function (v, i) {
      var x = (i + 1) * step;
      var y = 86 - ((v - BASE) / (LIMIT - BASE)) * 74;
      if (y < 8) y = 8;
      pts.push('L' + x.toFixed(1) + ' ' + y.toFixed(1));
    });
    return pts.join(' ');
  }

  function applyStage(idx) {
    var stage = STAGES[idx];
    if (!stage) return;

    // naive
    if (nFill) nFill.style.width = pct(stage.nCtx) + '%';
    if (nNow) { nNow.textContent = stage.nCtx.toLocaleString(); nNow.classList.toggle('warn', stage.nCtx > 40000); }
    if (nTrack) nTrack.classList.toggle('crashed', stage.nCrashed);
    if (nHistEl) {
      nHistEl.innerHTML = '';
      stage.nHist.forEach(function (h) {
        var d = document.createElement('div');
        d.className = 's020-history-item' + (h.crash ? ' crash' : '') + (h.cutoff ? ' cutoff' : '');
        var ico = h.crash ? ' 💥' : (h.cutoff ? '' : '');
        d.innerHTML = '<span class="item-name">' + h.name + ico + '</span><span class="item-tok">' + (h.cutoff ? '☠ 截断' : '+' + (h.tok/1000).toFixed(1) + 'K') + '</span>';
        nHistEl.appendChild(d);
      });
      nHistEl.scrollTop = nHistEl.scrollHeight;
    }
    if (nStatus) {
      var nDone = stage.nHist.filter(function(h){return !h.cutoff;}).length - (stage.nCrashed ? 1 : 0);
      if (nDone < 0) nDone = stage.nHist.filter(function(h){return !h.cutoff;}).length;
      nStatus.textContent = stage.nCrashed
        ? '💥 上下文爆 · 撞 50K 红线 · 后续任务被截断'
        : '已完成 ' + stage.nHist.length + ' / 6 · ctx ' + stage.nCtx.toLocaleString();
    }

    // guarded
    if (gFill) gFill.style.width = pct(stage.gCtx) + '%';
    if (gNow)  gNow.textContent = stage.gCtx.toLocaleString();
    if (gHistEl) {
      gHistEl.innerHTML = '';
      stage.gHist.forEach(function (h) {
        var d = document.createElement('div');
        var cls = 's020-history-item';
        if (h.kind === 'compress') cls += ' compress';
        else if (h.kind === 'memory') cls += ' memory';
        d.className = cls;
        var tokTxt = h.tok > 0 ? '+' + h.tok + ' tok' : (h.tok < 0 ? h.tok + ' tok' : '0');
        d.innerHTML = '<span class="item-name">' + h.name + '</span><span class="item-tok">' + tokTxt + '</span>';
        gHistEl.appendChild(d);
      });
      gHistEl.scrollTop = gHistEl.scrollHeight;
    }
    if (gStatus) {
      var gDoneN = Math.floor(stage.gHist.length / (stage.gHist.length > 0 ? Math.max(1, Math.ceil(stage.gHist.length / 6)) : 1));
      var gTaskDone = Math.min(6, idx);
      gStatus.textContent = '已完成 ' + gTaskDone + ' / 6 · ctx ' + stage.gCtx.toLocaleString() + '（远低 50K）';
    }

    // 曲线
    var nVals = [], gVals = [];
    for (var k = 1; k <= idx; k++) {
      nVals.push(Math.min(STAGES[k].nCtx, LIMIT + 4000));
      gVals.push(STAGES[k].gCtx);
    }
    if (lineNaive) lineNaive.setAttribute('d', chartPath(nVals));
    if (lineGuarded) lineGuarded.setAttribute('d', chartPath(gVals));

    // 撞墙标记
    if (crashMark) {
      if (stage.nCrashed) {
        var crashIdx = -1;
        for (var i2 = 1; i2 <= idx; i2++) { if (STAGES[i2].nCrashed && crashIdx === -1) crashIdx = i2; }
        if (crashIdx >= 0) {
          var step = 800 / 7;
          crashMark.setAttribute('cx', (crashIdx * step).toFixed(1));
          crashMark.setAttribute('cy', '12');
          crashMark.setAttribute('opacity', '1');
        }
      } else {
        crashMark.setAttribute('opacity', '0');
      }
    }

    // 结论卡
    if (idx >= totalSteps) {
      if (cnclN) cnclN.classList.add('show');
      if (cnclG) cnclG.classList.add('show');
      if (nDoneEl) nDoneEl.textContent = '3';
      if (gDoneEl) gDoneEl.textContent = '6';
      if (gFinalEl) gFinalEl.textContent = stage.gCtx.toLocaleString();
    } else {
      if (cnclN) cnclN.classList.remove('show');
      if (cnclG) cnclG.classList.remove('show');
    }

    if (stepIndEl) stepIndEl.textContent = '阶段 ' + idx + ' / ' + totalSteps + ' · ' + stage.name;
  }

  function nextStep() { if (currentStep < totalSteps) { currentStep++; applyStage(currentStep); } }
  function resetAll() { stopAuto(); currentStep = 0; applyStage(0); }
  function startAuto() {
    if (isPlaying) return; stopAuto();
    isPlaying = true;
    if (playBtn) { playBtn.textContent = '⏸ 暂停'; playBtn.classList.remove('primary'); }
    if (currentStep >= totalSteps) resetAll();
    var pauseMs = function () { return 2400 / speed; };
    function tick() {
      if (!isPlaying) return;
      if (currentStep >= totalSteps) { stopAuto(); return; }
      currentStep++;
      applyStage(currentStep);
      autoTimer = setTimeout(tick, pauseMs());
    }
    autoTimer = setTimeout(tick, pauseMs());
  }
  function stopAuto() {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
    isPlaying = false;
    if (playBtn) { playBtn.textContent = '▶ 自动播放'; playBtn.classList.add('primary'); }
  }
  function togglePlay() { if (isPlaying) stopAuto(); else startAuto(); }
  function setSpeed(s) {
    speed = s;
    speedBtns.forEach(function (b) { b.classList.toggle('active', parseFloat(b.getAttribute('data-speed')) === s); });
    if (isPlaying) { stopAuto(); startAuto(); }
  }

  if (playBtn)   playBtn.addEventListener('click', togglePlay);
  if (stepBtn)   stepBtn.addEventListener('click', function(){ stopAuto(); nextStep(); });
  if (replayBtn) replayBtn.addEventListener('click', resetAll);
  var speedHandlers = [];
  speedBtns.forEach(function (b) {
    var h = function () { setSpeed(parseFloat(b.getAttribute('data-speed'))); };
    b.addEventListener('click', h);
    speedHandlers.push({ el: b, fn: h });
  });

  applyStage(0);

  return function cleanup() {
    stopAuto();
    if (playBtn)   playBtn.removeEventListener('click', togglePlay);
    if (stepBtn)   stepBtn.removeEventListener('click', nextStep);
    if (replayBtn) replayBtn.removeEventListener('click', resetAll);
    speedHandlers.forEach(function (s) { s.el.removeEventListener('click', s.fn); });
    if (window.gsap) window.gsap.killTweensOf('.s020-page *');
  };
};

// =====================================
// S023 · Critic 临时召唤生命周期动画
// =====================================
window.slideHooks['slides/S023-critic-lifecycle.html'] = function () {
  var page = document.querySelector('.s023-page');
  if (!page) return;
  var gsap = window.gsap;
  if (!gsap) return;

  var gen = page.querySelector('#s023-gen');
  var files = [page.querySelector('#s023-file-1'), page.querySelector('#s023-file-2'), page.querySelector('#s023-file-3')];
  var trigger = page.querySelector('#s023-trigger');
  var critic = page.querySelector('#s023-critic');
  var criticBadge = page.querySelector('#s023-critic-badge');
  var criticSpinner = page.querySelector('#s023-critic-spinner');
  var verdictPass = page.querySelector('#s023-v-pass');
  var verdictFail = page.querySelector('#s023-v-fail');
  var verdictPartial = page.querySelector('#s023-v-partial');
  var dots = page.querySelectorAll('#s023-dots .s023-dot');
  var stepInd = page.querySelector('#s023-step-ind');
  var playBtn = page.querySelector('#s023-play');
  var pauseBtn = page.querySelector('#s023-pause');
  var stepBtn = page.querySelector('#s023-step');

  var tl = null;
  var currentStageIdx = 0;
  var stageEnds = [1.5, 3, 4, 5.5, 7, 8.5, 10];
  var stageNames = [
    'Generator 写代码',
    '产出文件 1+2',
    '产出文件 3 · 触发',
    'Critic 召唤',
    'Critic review',
    'Verdict 出 PASS',
    'Critic 消失'
  ];

  function setStage(i) {
    currentStageIdx = i;
    if (!dots) return;
    dots.forEach(function (d, idx) { d.classList.toggle('active', idx <= i); });
    var cards = page.querySelectorAll('.s023-stage-card');
    if (cards) cards.forEach(function (c, idx) { c.classList.toggle('active', idx === i); });
    if (stepInd) stepInd.textContent = 'stage ' + (i + 1) + '/7 · ' + stageNames[i];
  }

  function stepNext() {
    if (!tl) return;
    if (currentStageIdx >= 6) {
      // 末尾 · 回到 stage 1 起点
      buildAndPlay();
      tl.pause(0);
      setStage(0);
      if (pauseBtn) pauseBtn.textContent = '▶ 继续';
      return;
    }
    var targetTime = stageEnds[currentStageIdx + 1] - 0.05;
    tl.tweenTo(targetTime, {
      onComplete: function () { tl.pause(); }
    });
    if (pauseBtn) pauseBtn.textContent = '▶ 继续';
  }

  function resetState() {
    gsap.set(gen, { boxShadow: 'none' });
    files.forEach(function (f) { if (f) gsap.set(f, { opacity: 0, scale: 0.5, y: 6 }); });
    if (trigger) gsap.set(trigger, { opacity: 0, y: 5 });
    if (critic) gsap.set(critic, { opacity: 0, scale: 0 });
    if (criticBadge) gsap.set(criticBadge, { opacity: 0, scale: 1 });
    if (criticSpinner) gsap.set(criticSpinner, { opacity: 0, rotation: 0 });
    [verdictPass, verdictFail, verdictPartial].forEach(function (v) {
      if (v) gsap.set(v, { opacity: 0.25, scale: 1 });
    });
    setStage(0);
  }

  function buildTimeline() {
    resetState();
    var t = gsap.timeline({
      onComplete: function () {
        setTimeout(function () {
          if (t && !t.paused() && page.isConnected) {
            buildAndPlay();
          }
        }, 1200);
      }
    });

    // Stage 1: Generator active glow (0 - 1.5s)
    t.call(function () { setStage(0); })
     .to(gen, { boxShadow: '0 0 26px rgba(90,138,138,0.55)', duration: 0.6 }, 0);

    // Stage 2: 产出文件 1+2 出现 (1.5 - 3s)
    t.call(function () { setStage(1); }, null, 1.5);
    if (files[0]) t.to(files[0], { opacity: 1, scale: 1, y: 0, duration: 0.4 }, 1.5);
    if (files[1]) t.to(files[1], { opacity: 1, scale: 1, y: 0, duration: 0.4 }, 2.2);

    // Stage 3: 产出文件 3 + trigger 触发 (3 - 4s)
    t.call(function () { setStage(2); }, null, 3);
    if (files[2]) t.to(files[2], { opacity: 1, scale: 1, y: 0, duration: 0.4 }, 3);
    if (trigger) t.fromTo(trigger, { opacity: 0, y: 5 }, { opacity: 1, y: 0, duration: 0.5 }, 3.4);

    // Stage 4: Critic 召唤 (4 - 5.5s)
    t.call(function () { setStage(3); }, null, 4);
    if (critic) t.to(critic, { opacity: 1, scale: 1, duration: 0.8, ease: 'back.out(1.7)' }, 4);
    if (criticBadge) t.to(criticBadge, { opacity: 1, scale: 1.15, yoyo: true, repeat: 1, duration: 0.4 }, 4.6);

    // Stage 5: Critic review spinner (5.5 - 7s)
    t.call(function () { setStage(4); }, null, 5.5);
    if (criticSpinner) {
      t.to(criticSpinner, { opacity: 1, duration: 0.2 }, 5.5);
      t.to(criticSpinner, { rotation: 720, duration: 1.4, ease: 'none' }, 5.5);
    }

    // Stage 6: Verdict PASS 脉冲 (7 - 8.5s)
    t.call(function () { setStage(5); }, null, 7);
    if (verdictPass) t.to(verdictPass, { opacity: 1, scale: 1.15, yoyo: true, repeat: 3, duration: 0.3 }, 7);
    if (criticSpinner) t.to(criticSpinner, { opacity: 0, duration: 0.3 }, 7.5);

    // Stage 7: Critic 消失 (8.5 - 10s)
    t.call(function () { setStage(6); }, null, 8.5);
    if (critic) t.to(critic, { opacity: 0, scale: 0, duration: 1, ease: 'power2.in' }, 8.5);
    if (verdictPass) t.to(verdictPass, { opacity: 1, scale: 1, duration: 0.4 }, 9);

    return t;
  }

  function buildAndPlay() {
    if (tl) tl.kill();
    tl = buildTimeline();
    if (pauseBtn) pauseBtn.textContent = '⏸ 暂停';
  }

  function togglePause() {
    if (!tl) return;
    if (tl.paused()) {
      tl.play();
      if (pauseBtn) pauseBtn.textContent = '⏸ 暂停';
    } else {
      tl.pause();
      if (pauseBtn) pauseBtn.textContent = '▶ 继续';
    }
  }

  if (playBtn) playBtn.addEventListener('click', buildAndPlay);
  if (pauseBtn) pauseBtn.addEventListener('click', togglePause);
  if (stepBtn) stepBtn.addEventListener('click', stepNext);

  buildAndPlay();

  return function cleanup() {
    if (tl) tl.kill();
    tl = null;
    if (window.gsap) window.gsap.killTweensOf('.s023-page *');
  };
};
