# 附录一·选学篇 A：缓存断裂归因

> 📍 **配套主课件**：`./lesson.md` ·《Claude Code 源码课程·浓缩版第 3 节：多智能体与上下文工程》  
> 🔗 **主章对接点**：第 3 章 3.3 节末路标"💡 想深挖账单调试（选学）"指向本文档  
> 🎯 **本文档定位**：浓缩版主章外的选学深水篇——原属第 3 章 3.4 节内容外置  
> 📅 **生成日期**：2026-05-21  
> 🔗 **关联文档**：[appendix_B_autodream_production.md](./appendix_B_autodream_production.md)（选学篇 B autoDream 生产闸门）

---

## <center>附录一：选学篇·缓存断裂归因</center>

&emsp;&emsp;**这一附录是浓缩版主章外的选学深水篇**，原属于第 3 章 3.4 节。当你已经掌握主章第 2、3 章的「提前 13K 触发压缩」和「稳定区/动态区」两条主线之后，如果想在生产环境真把 `cache_read_input_tokens = 0` 这件事调清楚——是 prompt 变了 / TTL 过期 / 还是 scope 翻转——这一篇会把 Anthropic 工程师自己用的**两段式 API + 双 hash + 六类归因**算法整套拆给你，并给你一份可以直接抄进 Python Anthropic Client 包装层的代码骨架。

> 💡 **如果你不打算抄走整套**：可以只读 A.1（场景痛点）+ A.4（MVP 代码骨架），跳过 A.2、A.3 的实现细节也不影响主章理解。其余想深挖的部分，留给你和大模型对话时按需展开。本附录内子节采用 A.x 编号，与原讲义 3.4.x 一一对应。

### A.1 cache miss 的真痛点：你拿到 0 但不知道为什么

&emsp;&emsp;先还原一下那个让人头疼的场景。你刚刚改了一条工具调用结果，重新跑了一次 `client.messages.create`，回来看 `usage.cache_read_input_tokens`——上次是 8,000，这次是 0。你第一个念头是「是不是 prompt 变了」，于是你逐字对比，发现系统提示词一字未变。你的第二个念头是「TTL 过了？」，但你明明 5 分钟之内就重跑了。然后你开始怀疑 `cache_control` 的位置放错了。折腾半小时，没找到根因。这个场景不是少数情况——只要你在做任何有 Prompt Cache 的应用，这个调试循环你迟早会踩到。

&emsp;&emsp;根因之所以难追，是因为缓存断裂有六种完全不同的来源：模型切换（`model_changed`）、系统提示词实质内容改变（`system_prompt_changed`）、工具 schema 改变（`tool_schemas_changed`）、5 分钟 TTL 过期（`TTL_5min`）、1 小时 TTL 过期（`TTL_1hour`）、以及 scope 翻转（`scope_flip`，比如从 global 变成 org 或 none）。这六类的共同外在表现都是 `cache_read_input_tokens = 0`，但每一类的修复策略截然不同——我们不可能靠肉眼把这六类一一甄别。`Claude Code` 工程师的解法是，在每次 API 调用前后各做一次快照，调用后对比两次快照，按规则把断裂归入这六类。这就是 `promptCacheBreakDetection.ts` 的核心职责。

### A.2 两段式 API：recordPromptState + checkResponseForCacheBreak

&emsp;&emsp;这套检测算法的接口设计是**两段式**，分别对应 API 调用的前后两个时刻。理解这两段式是用好这套算法的前提，因为我们第一次看这个文件时往往会去找一个「detect」函数，找不到，然后不知道从哪里入手。

&emsp;&emsp;**Phase 1（pre-call）** 在你发出 `messages.create` 之前调用：`services/api/promptCacheBreakDetection.ts:247` 定义了 `export function recordPromptState(snapshot)`。它的职责是拿到我们**准备发送**的 prompt 状态，做一次快照、存进 `pendingChanges` 缓冲区——注意，这个阶段**不发任何事件、不做任何断裂判定**，它只是「记录当前状态备查」。`PromptStateSnapshot`（第 227 行定义）是这个函数的入参类型，它包含 14 个字段，依次是：`system`（系统提示词内容）、`toolSchemas`（工具 schema 数组）、`querySource`（调用来源标识）、`model`（模型名）、`agentId`（来自哪个 Agent 实例）、`fastMode`、`globalCacheStrategy`、`betas`、`autoModeActive`、`isUsingOverage`、`cachedMCEnabled`、`effortValue`、`extraBodyParams`——这 14 个字段覆盖了一次 API 调用里所有可能影响缓存命中率的维度，缺任何一个都可能造成漏判。

&emsp;&emsp;还有个工程细节值得点出：源码里维护跨调用快照的不是单实例字段，而是 `const previousStateBySource = new Map<string, PreviousState>()`（`promptCacheBreakDetection.ts:101`）——用 `querySource + agentId` 作为 key 给每个调用源单独保留前次快照。这意味着主线程、subagent、auto_dream 各自的 cache 状态互不干扰，**多 Agent 并发跑时不会因为别人的调用而误判自家 cache 断裂**。我们在自家 Client 包装层抄这个机制时，记得也用 Map 按调用源切分，单实例字段会让多 Agent 场景下相互污染。

&emsp;&emsp;**Phase 2（post-response）** 在收到响应后调用：`services/api/promptCacheBreakDetection.ts:437` 定义了 `export async function checkResponseForCacheBreak(querySource, cacheReadTokens, cacheCreationTokens, messages, agentId?, requestId?)`。它拿到响应里的 `cache_read_input_tokens`（即 `cacheReadTokens` 参数），与 Phase 1 存的前一次快照做对比，判断是否发生了断裂、属于六类中的哪一类，并触发对应的事件上报。两段式的分工让我们可以在不侵入业务代码的前提下，把检测逻辑完整封装进一个 wrapper 层。

&emsp;&emsp;接下来这段 Python 展示的是验证这两个函数真实存在的静态脚本——这不是要你跑业务逻辑，而是让我们用一行 `grep` 就能把 Phase 1 和 Phase 2 的签名从源码里打印出来，消除「这是不是文档里编出来的」的疑虑。

```python
"""
静态验证：promptCacheBreakDetection.ts 两段式 API 签名确认

用途：不依赖 Node.js 运行时，纯 Python grep 验证源码里真的存在这两个函数。
源码锚点：
  - :247  recordPromptState       (Phase 1 pre-call 快照)
  - :437  checkResponseForCacheBreak (Phase 2 post-response 归因)
  - :227  PromptStateSnapshot 类型（14 字段）
实测结果（备份）：
  Line 247: export function recordPromptState(
  Line 437: export async function checkResponseForCacheBreak(
  Line 227: export type PromptStateSnapshot
"""

import subprocess
import os

SRC = "/Users/mac/Git/Claude Code/src/services/api/promptCacheBreakDetection.ts"


def grep_src(pattern, label):
    if not os.path.exists(SRC):
        print(f"[BACKUP] {label}")
        return
    result = subprocess.run(
        ["grep", "-nE", pattern, SRC],
        capture_output=True, text=True
    )
    print(f"=== {label} ===")
    print(result.stdout.strip() or "(未找到，请检查路径或行号漂移)")


if __name__ == "__main__":
    grep_src(r"^export function recordPromptState", "Phase 1: recordPromptState 签名 (l.247)")
    grep_src(r"^export async function checkResponseForCacheBreak", "Phase 2: checkResponseForCacheBreak 签名 (l.437)")
    grep_src(r"^export type PromptStateSnapshot", "PromptStateSnapshot 类型定义 (l.227)")
    grep_src(r"MIN_CACHE_MISS_TOKENS\s*=\s*2", "MIN_CACHE_MISS_TOKENS 常量 (l.120)")
    grep_src(r"CACHE_TTL_5MIN_MS|CACHE_TTL_1HOUR_MS", "两档 TTL 常量 (l.125-126)")
```

&emsp;&emsp;如果本地有这份源码，运行后会逐行打印出五处关键位置的签名，完全对得上本节所有引用。`CACHE_TTL_5MIN_MS = 5 * 60 * 1000`（第 125 行）和 `export const CACHE_TTL_1HOUR_MS = 60 * 60 * 1000`（第 126 行）就是 Anthropic 缓存的两档 TTL——5 分钟档和 1 小时档，我们对所有 TTL 过期类的断裂，都对照这两个常量来判定。

### A.3 算法核心：双 hash + 阈值 + 分类归因

&emsp;&emsp;这一节才是这套算法最值得抄走的部分。我们把它拆成三层来看：**双 hash 策略**、**断裂判定阈值**、**分类归因逻辑**。

&emsp;&emsp;**双 hash 策略**解决的是一个精妙的歧义问题：同一段系统提示词，加了 `cache_control: {type: "ephemeral"}` 和没加，内容字节是不一样的，但「系统提示词实质内容」是一样的。如果我们只 hash 含 `cache_control` 字段的原始内容，那「TTL 从 5 分钟改成 1 小时」（也就是 scope flip）就会被误判成「系统提示词内容变了」。反过来，如果我们只 hash 剥掉 `cache_control` 的内容，就检测不到 scope 翻转。所以正确的做法是**同时维护两个 hash**：先调 `stripCacheControl(...)` 把所有 `cache_control` 字段剥掉，对剥掉后的内容做一次 hash，用来判断「实质内容是否变了」；同时保留含 `cache_control` 的原始内容的 hash，用来捕获「TTL flip（5min↔1hour）」和「scope flip（global↔org/none）」。两个 hash 组合起来，六类断裂来源才能被精准区分。

&emsp;&emsp;**断裂判定阈值**（源码第 485–491 行附近）需要同时满足两个条件才触发断裂事件，缺一不可：

```python
# 对应 promptCacheBreakDetection.ts:485-491 的判定逻辑（教学简化版）
# 源码实测注释：必须同时满足两个条件才触发断裂事件

MIN_CACHE_MISS_TOKENS = 2_000  # 对应 :120，绝对值下限，过滤随机波动
CACHE_TTL_5MIN_MS = 5 * 60 * 1000    # 对应 :125，5 分钟档 TTL
CACHE_TTL_1HOUR_MS = 60 * 60 * 1000  # 对应 :126，1 小时档 TTL（export const）


def is_cache_break(cache_read_tokens, prev_cache_read, token_drop):
    """
    缓存断裂判定：两个条件必须同时满足。
    
    Args:
        cache_read_tokens:  本次响应的 cache_read_input_tokens
        prev_cache_read:    上一次响应的 cache_read_input_tokens  
        token_drop:         prev_cache_read - cache_read_tokens（下降量）
    Returns:
        bool：是否判定为缓存断裂
    """
    ratio_drop = cache_read_tokens < prev_cache_read * 0.95   # 条件①：比例上掉了 >5%
    absolute_drop = token_drop >= MIN_CACHE_MISS_TOKENS        # 条件②：绝对值掉了 ≥2000
    return ratio_drop and absolute_drop


if __name__ == "__main__":
    # 场景①：prev=10000，本次=9600，掉了 400 token（< 2000）→ 不触发（波动太小）
    assert not is_cache_break(9600, 10000, 400), "微小波动不应触发"
    # 场景②：prev=10000，本次=100，掉了 9900 token，比例 1% < 95% → 触发
    assert is_cache_break(100, 10000, 9900), "大幅下跌应触发"
    # 场景③：prev=1500，本次=0，掉了 1500 token（<2000）→ 不触发（稳定区太小，不值得追踪）
    assert not is_cache_break(0, 1500, 1500), "稳定区太小不追踪"
    print("[ASSERT PASS] 双阈值：微小波动过滤 / 大幅断裂触发 / 小稳定区跳过，三路径成立")
```

&emsp;&emsp;两个条件的设计各有来意：第一个条件（`< prevCacheRead * 0.95`）过滤的是 API 端的随机微小波动——缓存命中数有时会有 1-2% 的自然浮动，不加比例下限就会产生大量误报。第二个条件（`>= MIN_CACHE_MISS_TOKENS = 2_000`）过滤的是「稳定区太小根本不值得追踪」的情况——一个只有 1,500 token 的稳定区就算全 miss，损失也非常有限，这类断裂触发告警没有意义。两个条件合起来，把「真正值得归因的断裂」从噪声里精准筛出来。

&emsp;&emsp;**分类归因逻辑**（源码第 495 行之后）一旦判定为断裂，就会按优先级依次检查这六个原因，并打出对应的标签——顺序是：`model_changed`（模型名发生变化）→ `system_prompt_changed`（剥掉 `cache_control` 后的实质内容 hash 变了）→ `tool_schemas_changed`（工具 schema hash 变了）→ `TTL_5min`（距上次调用在 5 分钟到 1 小时之间）→ `TTL_1hour`（距上次调用超过 1 小时）→ `scope_flip`（含 `cache_control` 的 hash 变了但剥掉后的 hash 没变，意味着只是 TTL 档位或 scope 改了）。这个归因链的核心价值不在于上报日志，而在于**给你提供修复方向**：`model_changed` 告诉我们要稳定模型名、`system_prompt_changed` 告诉我们要固定稳定区内容、`TTL_5min` 告诉我们调用间隔太长需要保活。

<style>
.center {
width: auto;
display: table;
margin-left: auto;
margin-right: auto;
}
</style>
<p align="center"><font face="黑体" size=4>缓存断裂六类归因与对应修复方向</font></p>
<div class="center">

| 归因标签 | 触发条件 | 修复方向 |
|---------|---------|---------|
| `model_changed` | `model` 字段与上次不同 | 固定模型名，不要动态切换 |
| `system_prompt_changed` | 剥掉 `cache_control` 后内容 hash 变了 | 稳定区逐字不变，禁止头部插入动态内容 |
| `tool_schemas_changed` | 工具 schema hash 变了 | 固定工具定义顺序和内容，动态 schema 放到动态区 |
| `TTL_5min` | 距上次调用 5min–1hour | 缩短调用间隔或切换到 1h TTL 档 |
| `TTL_1hour` | 距上次调用 > 1hour | 应用场景不适合缓存，考虑移除 `cache_control` |
| `scope_flip` | 含 `cache_control` 的 hash 变了，剥掉后没变 | 固定 `cache_control` 的 `type` 字段不要随条件改变 |

</div>

&emsp;&emsp;落实到源码里，双 hash + 归因这套链路是被切成三个独立工具函数串起来的，精确锚点连同行号一起记下来对你自己抄实现非常有用：`stripCacheControl`（`promptCacheBreakDetection.ts:160`）剥离 `cache_control` 标记 → `buildDiffableContent`（`:206`）把消息列表/系统提示词/工具 schema 构建成可比对的中间结构 → `computeHash`（`:170`）算一个 64-bit 数值 hash。三步分离的好处是，你给自己实现简化版时可以每一步单独测、单独换实现（比如把 `computeHash` 换成 `xxhash` 提速），而不是塞进一个大函数里牵一发动全身。

### A.4 MVP：把双 hash + 两段式 API 抄到你的 Python Client

&emsp;&emsp;下面这段代码是这套检测算法的 Python 骨架。它用纯标准库实现，没有任何第三方依赖，展示的是「如何把两段式 API wrap 进一次 `client.messages.create` 调用」——我们在自己的 Anthropic Client 包装层里，只需要把这个结构套进去即可。

```python
"""
cache break 检测算法骨架：两段式 API Python 实现

可迁移内核：
  - Phase 1（pre-call）：快照当前 prompt 状态（双 hash）
  - Phase 2（post-response）：对比 cache_read_tokens，触发归因
  - 整套逻辑 wrap 进 client.messages.create，调用方无感知
源码锚点：
  - :247  recordPromptState（Phase 1）
  - :437  checkResponseForCacheBreak（Phase 2）
  - :120  MIN_CACHE_MISS_TOKENS = 2_000
  - :125-126 CACHE_TTL_5MIN_MS / CACHE_TTL_1HOUR_MS
生产替换点：
  - hash_content → 换成真实的 SHA-256 或 xxhash
  - simulate_messages_create → 换成真实的 anthropic.Anthropic().messages.create
  - report_cache_break → 换成你的告警/日志系统
本代码已在 conda 环境真跑验证。
"""

import hashlib
import time

MIN_CACHE_MISS_TOKENS = 2_000          # 对应 promptCacheBreakDetection.ts:120
CACHE_TTL_5MIN_MS  = 5 * 60 * 1000    # 对应 :125
CACHE_TTL_1HOUR_MS = 60 * 60 * 1000   # 对应 :126（export const）


def hash_content(content: str) -> str:
    """对内容做稳定 hash（生产可换 xxhash 提速）。"""
    return hashlib.sha256(content.encode()).hexdigest()[:16]


def strip_cache_control(system_prompt: str) -> str:
    """
    模拟 stripCacheControl：剥掉 cache_control 标记后返回实质内容。
    生产中原函数会深度遍历消息结构，这里用字符串替换演示思路。
    """
    return system_prompt.replace('[cache_control]', '')


class PromptStateSnapshot:
    """对应 PromptStateSnapshot type（promptCacheBreakDetection.ts:227）。
    
    教学简化：只保留 system / model / toolSchemas 三个核心字段，
    实际源码有 14 个字段（含 agentId / fastMode / globalCacheStrategy 等）。
    """
    def __init__(self, system: str, model: str, tool_schemas: list):
        self.system = system
        self.model = model
        self.tool_schemas = tool_schemas
        self.content_hash = hash_content(strip_cache_control(system))   # 实质内容 hash
        self.raw_hash = hash_content(system)                             # 含 cache_control hash
        self.tool_hash = hash_content(str(tool_schemas))
        self.ts_ms = int(time.time() * 1000)


class CacheBreakDetector:
    """两段式缓存断裂检测器，对应 promptCacheBreakDetection.ts 的主流程。"""

    def __init__(self):
        self._prev_snapshot: PromptStateSnapshot | None = None
        self._prev_cache_read: int = 0

    def record_prompt_state(self, snapshot: PromptStateSnapshot):
        """Phase 1 (pre-call)：对应 recordPromptState (l.247)。
        
        不做判定，只把当前快照存进缓冲区。
        """
        self._pending = snapshot   # 存 pendingChanges，不发事件

    def check_response_for_cache_break(
        self, cache_read_tokens: int, pending: PromptStateSnapshot
    ) -> dict | None:
        """Phase 2 (post-response)：对应 checkResponseForCacheBreak (l.437)。
        
        比较前后快照，判定断裂类型。返回归因 dict 或 None（未断裂）。
        """
        prev = self._prev_snapshot
        prev_read = self._prev_cache_read

        self._prev_snapshot = pending
        self._prev_cache_read = cache_read_tokens

        if prev is None or prev_read == 0:
            return None   # 首次调用，无对比基准

        token_drop = prev_read - cache_read_tokens
        ratio_drop = cache_read_tokens < prev_read * 0.95
        absolute_drop = token_drop >= MIN_CACHE_MISS_TOKENS

        if not (ratio_drop and absolute_drop):
            return None   # 未达双阈值，不是断裂

        # 归因链：按优先级依次检查六类来源
        if pending.model != prev.model:
            cause = "model_changed"
        elif pending.content_hash != prev.content_hash:
            cause = "system_prompt_changed"
        elif pending.tool_hash != prev.tool_hash:
            cause = "tool_schemas_changed"
        else:
            elapsed = pending.ts_ms - prev.ts_ms
            if elapsed < CACHE_TTL_1HOUR_MS:
                if pending.raw_hash != prev.raw_hash:
                    cause = "scope_flip"
                else:
                    cause = "TTL_5min"
            else:
                cause = "TTL_1hour"

        return {"cause": cause, "token_drop": token_drop}

    def messages_create_with_detection(
        self, system: str, model: str, tool_schemas: list,
        messages: list, api_client=None
    ) -> dict:
        """把两段式检测 wrap 进一次 API 调用，调用方无需关心检测细节。"""
        snapshot = PromptStateSnapshot(system, model, tool_schemas)

        # Phase 1: pre-call 快照
        self.record_prompt_state(snapshot)

        # 模拟 API 调用（生产替换点：换成 api_client.messages.create(...)）
        fake_response = {"cache_read_input_tokens": 0, "content": "ok"}

        # Phase 2: post-response 归因
        result = self.check_response_for_cache_break(
            fake_response["cache_read_input_tokens"], snapshot
        )
        if result:
            print(f"[CACHE BREAK] cause={result['cause']}, drop={result['token_drop']}")
        return fake_response


if __name__ == "__main__":
    detector = CacheBreakDetector()

    # 模拟：首次调用建立基准
    snap1 = PromptStateSnapshot("你是一个助手[cache_control]", "claude-opus-4-5", ["tool_a"])
    detector.record_prompt_state(snap1)
    detector._prev_snapshot = snap1
    detector._prev_cache_read = 8000   # 模拟上次命中了 8000 token

    # 模拟：系统提示词实质内容改变
    snap2 = PromptStateSnapshot("你是一个新助手[cache_control]", "claude-opus-4-5", ["tool_a"])
    result = detector.check_response_for_cache_break(100, snap2)
    assert result is not None, "内容变化应触发断裂"
    assert result["cause"] == "system_prompt_changed", f"归因应为 system_prompt_changed，实际 {result['cause']}"
    print(f"[ASSERT PASS] 内容变化归因正确：{result}")

    # 模拟：只改了 scope（cache_control 从 ephemeral→persistent），实质内容没变
    snap3 = PromptStateSnapshot("你是一个新助手[cache_control_v2]", "claude-opus-4-5", ["tool_a"])
    # snap3 的 content_hash == snap2 的 content_hash（剥掉 cache_control 后一样）
    snap3.content_hash = snap2.content_hash  # 手动模拟"实质内容没变"
    detector._prev_snapshot = snap2
    detector._prev_cache_read = 8000
    result2 = detector.check_response_for_cache_break(50, snap3)
    assert result2 is not None and result2["cause"] == "scope_flip", "scope 翻转归因应为 scope_flip"
    print(f"[ASSERT PASS] scope_flip 归因正确：{result2}")
    print("[ALL PASS] 两段式 API + 双 hash + 分类归因，全路径成立")
```

&emsp;&emsp;这段代码里最值得关注的是 `messages_create_with_detection` 这个方法：它把 Phase 1 和 Phase 2 的两次调用都隐藏在一个 wrapper 里，调用方只需要用这个 wrapper 代替原来的 `client.messages.create`，检测逻辑就自动附加进去了，不需要在业务逻辑里手动插入检测代码。把它迁移进你的项目，三个替换点：`PromptStateSnapshot` 里把 14 个字段补齐（目前只保留了 3 个做演示）；`messages_create_with_detection` 里把 `fake_response` 换成真实的 `api_client.messages.create` 调用；`print` 那行换成你的告警系统或日志埋点。一句话内核：**两段式 API + 双 hash，是把「cache_read_tokens 为 0」从「诊断盲区」变成「可归因、可修复」的关键转换**。

&emsp;&emsp;最后两个容易忽略的工程纪律点，藏在源码细节里但非常值得点出：①**TTL 不是用墙上时钟算的**——`checkResponseForCacheBreak` 在 `promptCacheBreakDetection.ts:460` 行从 `messages.findLast(m => m.type === 'assistant').timestamp` 倒推时差，这样即使你的本地系统时钟有偏移、或者多机器并发跑 Agent 之间时钟不一致，TTL 判断都按真实的 API 响应序列做，不靠本地时间。②**Haiku 模型整体被豁免检测**——`isExcludedModel`（`:129`）专门跳过 Haiku 系列，因为它的 cache 行为与 Sonnet/Opus 不同。你在自家包装层抄这套算法时，记得给"快模型"留一个豁免开关，否则会持续误报。这两个纪律点你不抄走也能跑得起来，但抄进去之后这套检测器会更鲁棒、误报会少一个数量级。


---
