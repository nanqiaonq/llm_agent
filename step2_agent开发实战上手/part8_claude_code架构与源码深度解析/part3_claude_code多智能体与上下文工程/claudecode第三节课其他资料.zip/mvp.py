"""
Claude Code Context Compression MVP — LangChain 1.2.0 create_agent + middleware
Source: /Users/mac/Git/Claude Code/src/services/compact/

Core mapping:
  microcompact   → @before_model: clean stale tool_results from messages
  SessionMemory  → @before_model: inject SM into messages
  autoCompact    → @before_model: token-threshold compact (LLM summary)
  ⚡ All three are AgentMiddleware subclasses registered in create_agent(middleware=[...])

Uses DeepSeek API via langchain_openai.ChatOpenAI.
"""
import os, re, json, time, math
from pathlib import Path
from typing import Any

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

# ★ LangChain 1.2.0 create_agent + middleware
from langchain.agents import create_agent
from langchain.agents.middleware import (
    AgentMiddleware, AgentState, before_model, ToolCallLimitMiddleware,
)
from langgraph.runtime import Runtime

# ── Config ────────────────────────────────────────────────────────────
os.environ.setdefault("DEEPSEEK_API_KEY", "sk-d513cfff202f4740ba887e87f745014d")
print(f"[config] DEEPSEEK_API_KEY={'***' if os.environ['DEEPSEEK_API_KEY'] else 'MISSING'}")

def _mk_llm(temp=0.3, max_tok=4096):
    return ChatOpenAI(
        model="deepseek-chat",
        openai_api_key=os.environ["DEEPSEEK_API_KEY"],
        openai_api_base="https://api.deepseek.com",
        temperature=temp, max_tokens=max_tok,
    )

llm = _mk_llm()
SM_DIR = Path("/tmp/mvp-sm")
SM_DIR.mkdir(exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════
# 1. TokenEstimator
# ═══════════════════════════════════════════════════════════════════════
def count_tokens(text: str) -> int:
    return max(1, math.ceil(len(text) / 4))

# ═══════════════════════════════════════════════════════════════════════
# 2. format_compact_summary — strip <analysis>, keep <summary>
# ═══════════════════════════════════════════════════════════════════════
def format_compact_summary(text: str) -> str:
    result = re.sub(r"<analysis>[\s\S]*?</analysis>", "", text)
    m = re.search(r"<summary>([\s\S]*?)</summary>", result)
    if m:
        result = result.replace(m.group(0), f"Summary:\n{m.group(1).strip()}")
    return re.sub(r"\n\n+", "\n\n", result).strip()

# ═══════════════════════════════════════════════════════════════════════
# 3. MicroCompactMiddleware — @before_model: clean old tool_results
#    对应源码: microCompact.ts
# ═══════════════════════════════════════════════════════════════════════
MICRO_TOOLS = {"Read", "Bash", "Grep", "Glob", "WebSearch", "WebFetch", "Edit", "Write"}
CLEARED = "[Old tool result content cleared]"

class MicroCompactMiddleware(AgentMiddleware):
    """
    每次 model 调用前, 检查对话中的 tool_result,
    如果距离上次 tool 调用超过 gap_threshold_s, 清理 keep_recent 以外的老结果。
    """
    def __init__(self, gap_s: float = 30.0, keep: int = 3):
        super().__init__()
        self.gap_s = gap_s
        self.keep = keep
        self._ts: dict[str, float] = {}

    def before_model(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        messages = state.get("messages", [])
        now = time.time()

        compactable_ids: list[str] = []
        for msg in messages:
            if not isinstance(msg, AIMessage):
                continue
            content = msg.content
            if not isinstance(content, list):
                continue
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    tid = block.get("id", "")
                    if block.get("name", "") in MICRO_TOOLS:
                        compactable_ids.append(tid)
                        self._ts[tid] = now

        last_ts = max(self._ts.values(), default=0)
        gap = now - last_ts
        if gap < self.gap_s or not compactable_ids:
            return None

        keep_set = set(compactable_ids[-self.keep:])
        clear_set = set(compactable_ids[:-self.keep]) if len(compactable_ids) > self.keep else set()
        if not clear_set:
            return None

        new_messages = []
        cleared = 0
        for msg in messages:
            if not isinstance(msg, HumanMessage):
                new_messages.append(msg)
                continue
            content = msg.content
            if not isinstance(content, list):
                new_messages.append(msg)
                continue
            changed = False
            new_content = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    if block.get("tool_use_id", "") in clear_set:
                        new_content.append({**block, "content": CLEARED})
                        cleared += 1; changed = True
                    else:
                        new_content.append(block)
                else:
                    new_content.append(block)
            new_messages.append(HumanMessage(content=new_content) if changed else msg)

        if cleared:
            print(f"  [MicroCompact] gap={gap:.0f}s, cleared {cleared} results, kept {len(keep_set)}")
        return {"messages": new_messages} if cleared else None

# ═══════════════════════════════════════════════════════════════════════
# 4. SessionMemoryMiddleware — @before_model: inject SM into context
#    对应源码: sessionMemoryCompact.ts
# ═══════════════════════════════════════════════════════════════════════
SM_TEMPLATE = """# Session Title\n_A short 5-10 word title._\n\n# Current State\n_What is being worked on?_"""

class SessionMemoryStore:
    path: Path = SM_DIR / "session-memory.md"
    def init(self):
        if not self.path.exists():
            self.path.write_text(SM_TEMPLATE.strip())
        return self
    def read(self) -> str | None:
        return self.path.read_text() if self.path.exists() else None
    def is_empty(self) -> bool:
        raw = self.read()
        return not raw or raw.strip() == SM_TEMPLATE.strip()
    def write(self, content: str):
        self.path.write_text(content)

class SessionMemoryMiddleware(AgentMiddleware):
    """将 Session Memory 注入到对话上下文中 (system message 前缀)."""
    def __init__(self, sm: SessionMemoryStore):
        super().__init__()
        self.sm = sm

    def before_model(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        self.sm.init()
        if self.sm.is_empty():
            return None
        sm_text = self.sm.read() or ""
        if not sm_text.strip():
            return None

        messages = list(state.get("messages", []))
        # 找到第一条 human message, 在其前注入 SM 作为 context
        for i, msg in enumerate(messages):
            if isinstance(msg, HumanMessage):
                prefix = f"[Session Memory Context]\n{sm_text}\n\n--- current conversation ---\n"
                content = msg.content
                if isinstance(content, str):
                    messages[i] = HumanMessage(content=prefix + content)
                elif isinstance(content, list):
                    messages[i] = HumanMessage(content=[{"type": "text", "text": prefix}] + content)
                print(f"  [SessionMemory] injected {len(sm_text)} chars into context")
                break

        return {"messages": messages}

# ═══════════════════════════════════════════════════════════════════════
# 5. CompactTriggerMiddleware — @before_model: threshold-triggered LLM compact
#    对应源码: autoCompact.ts autoCompactIfNeeded() + compact.ts compactConversation()
# ═══════════════════════════════════════════════════════════════════════
COMPACT_PROMPT = """CRITICAL: Respond with TEXT ONLY. Do NOT call any tools.

Summarize the conversation in detail. Wrap analysis in <analysis> tags, then write <summary>.

<summary> must include 9 sections:
1. Primary Request  2. Key Concepts  3. Files & Code  4. Errors & Fixes
5. Problem Solving  6. User Messages  7. Pending Tasks  8. Current Work
9. Optional Next Step

Format: <analysis>...</analysis><summary>...</summary>"""

class CompactTriggerMiddleware(AgentMiddleware):
    """
    Token threshold gate: 当 token 超过 threshold 时, 用一个独立 LLM 调用
    生成对话摘要并压缩消息历史。
    """
    def __init__(self, context_window: int = 32000, buffer: int = 3000):
        super().__init__()
        self.threshold = context_window - buffer

    def before_model(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        messages = state.get("messages", [])
        total = sum(count_tokens(json.dumps(m.content, default=str, ensure_ascii=False))
                    for m in messages)
        print(f"  [CompactTrigger] tokens≈{total} threshold={self.threshold}")

        if total < self.threshold:
            return None

        print(f"  [CompactTrigger] OVER → calling compact LLM...")
        conv = self._serialize(messages)
        compact_llm = _mk_llm()
        raw = compact_llm.invoke([HumanMessage(content=COMPACT_PROMPT + "\n\n=== CONVERSATION ===\n" + conv)])
        raw_text = raw.content if hasattr(raw, "content") else str(raw)
        summary = format_compact_summary(raw_text)

        # 保留最后 3 条 human message, 其余替换为 compact summary
        user_idxs = [i for i, m in enumerate(messages) if isinstance(m, HumanMessage)]
        keep_n = min(3, len(user_idxs))
        keep_from = user_idxs[-keep_n] if keep_n > 0 else len(messages)
        kept = messages[keep_from:]

        new_msgs = [SystemMessage(content="--- COMPACT BOUNDARY ---\n" + summary)] + list(kept)
        print(f"  [CompactTrigger] done: {len(messages)}→{len(new_msgs)} msgs, {len(summary)} chars summary")
        return {"messages": new_msgs}

    @staticmethod
    def _serialize(messages) -> str:
        lines = []
        for m in messages:
            role = type(m).__name__.replace("Message", "")
            content = m.content
            if isinstance(content, list):
                texts = [b.get("text","") for b in content if isinstance(b, dict) and b.get("type")=="text"]
                content = " ".join(texts)
            lines.append(f"[{role}]: {content}")
        return "\n".join(lines)

# ═══════════════════════════════════════════════════════════════════════
# 6. Tools
# ═══════════════════════════════════════════════════════════════════════
def read_file(path: str) -> str:
    """Read the contents of a file at the given absolute path."""
    try: return Path(path).read_text()
    except Exception as e: return f"Error: {e}"

def write_file(path: str, content: str) -> str:
    """Write content to a file at the given absolute path, creating parent directories as needed."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(content)
    return f"Written: {path}"

def run_bash(cmd: str) -> str:
    """Execute a bash command and return its output (simulated in this demo)."""
    return f"[simulated] {cmd} → ok"

# ═══════════════════════════════════════════════════════════════════════
# 7. Build agent
# ═══════════════════════════════════════════════════════════════════════
def build_agent(context_window: int = 32000, compact_buffer: int = 3000):
    sm = SessionMemoryStore().init()
    if sm.is_empty():
        sm.write("""# Session Title\n_Building FastAPI web app_\n\n# Current State\nWriting auth endpoints.\n\n# Task specification\nFastAPI + SQLite + JWT login.\n\n# Files and Functions\n- main.py: app entrypoint\n- auth.py: login/register/refresh\n- models.py: User model\n\n# Key results\nRegister/login working.\n""")

    return create_agent(
        model=llm,
        tools=[read_file, write_file, run_bash],
        system_prompt="You are a helpful coding assistant. Use tools when needed.",
        middleware=[
            SessionMemoryMiddleware(sm),        # ① 注入预生成记忆
            MicroCompactMiddleware(gap_s=0.0, keep=3),  # ② 清理旧工具结果
            CompactTriggerMiddleware(           # ③ 阈值触发 LLM 压缩
                context_window=context_window,
                buffer=compact_buffer,
            ),
        ],
    )

# ═══════════════════════════════════════════════════════════════════════
# 8. Demo
# ═══════════════════════════════════════════════════════════════════════
def main():
    print("=" * 60)
    print("Claude Code Context Compression MVP")
    print("LangChain 1.2.0 create_agent + AgentMiddleware")
    print("=" * 60)

    # 场景 1: 低阈值 → 触发压缩
    print("\n--- Scenario 1: Low context window (500) → compact triggers ---")
    agent1 = build_agent(context_window=500, compact_buffer=100)
    result1 = agent1.invoke({
        "messages": [HumanMessage(content="帮我在 /tmp/demo 创建 FastAPI + SQLite web 应用, 需要用户注册和登录功能。")]
    })
    final_msgs = result1.get("messages", [])
    print(f"\n  Final messages: {len(final_msgs)}")
    # 检查是否有 compact boundary
    has_boundary = any(
        isinstance(m, SystemMessage) and "COMPACT BOUNDARY" in str(m.content)
        for m in final_msgs
    )
    print(f"  Has compact boundary: {has_boundary}")
    if has_boundary:
        print(f"  ✅ Compact triggered and applied")
    else:
        print(f"  ℹ️  Compact middleware ran but may not have triggered (check threshold)")

    # 场景 2: 高阈值 → 不触发压缩
    print(f"\n--- Scenario 2: High context window (32k) → skip compact ---")
    agent2 = build_agent(context_window=32000, compact_buffer=3000)
    result2 = agent2.invoke({
        "messages": [HumanMessage(content="列出当前目录 /tmp 的文件。")]
    })

    print(f"\n✅ create_agent + middleware pipeline complete")
    return True

if __name__ == "__main__":
    ok = main()
    print(f"\nexit={'OK' if ok else 'WARN'}")
