# Claude Code 源码架构入门 · HTML 课件

> 一份 20 页交互式 HTML 课件，从「30 行朴素 Agent」到「51 万行工业级 Claude Code」，拆解 QueryLoop 调用循环、Tool 协议、扩展接入（Skill/MCP/Hook/Plugin/SystemPrompt）与安全约束。所有源码引用经 Claude Code v2.1.88 真实仓库验证。

## 启动方式

课件用 `fetch()` 加载各 slide HTML 片段，**必须通过 HTTP 服务器访问**（`file://` 协议下 CORS 会阻止 fetch）。

```bash
cd claude-code-source-arch-intro
python3 -m http.server 8000
# 然后浏览器打开 http://localhost:8000/index.html
```

或用任何静态服务器：

```bash
npx serve .          # Node.js
php -S localhost:8000  # PHP
```

推荐浏览器：Chrome / Safari / Edge（任意现代浏览器，支持 ES6 + CSS clamp）。视口建议 1920×1080 或更大。

## 课件结构（20 页 / 6 章节）

| 章 | 页 | 标题 |
|---|---|---|
| **C00 钩子与全景** | S001 | 从 QueryLoop 到安全管线（封面）|
| | S002 | 源码快照：Claude Code v2.1.88 |
| **C01 心智模型与朴素 Agent** | S003 | 1.6% vs 98.4%：工业级 Agent 的重心 |
| | S004 | 30 行朴素 Agent：能跑，但不敢用 |
| **C02 工业级运行时** | S005 | 为什么 51 万行 Claude Code 源码值得读 |
| | S006 | Claude Code 全局架构图 |
| | S007 | 入口 main.tsx：并行预取把 420ms 压到 135ms |
| **C03 循环内部** | S008 | QueryLoop 全景：一次对话如何转圈 |
| | S008b | QueryLoop 可靠性：不只看 stop_reason |
| | S009 | Tool 契约：40+ 工具为什么能统一调用 |
| | S010 | Tool 执行链：从 tool_use 到 tool_result |
| **C04 扩展接入** | S011 | Skill：知识的渐进式披露 |
| | S012 | MCP：外部能力如何变成标准 Tool |
| | S013 | 扩展三件套：know / do / intercept |
| | S014 | Plugin：三件套的打包清单 |
| | S015 | System Prompt：能力碎片如何组装成上下文 |
| **C05 安全约束与闭环** | S016 | 安全总览：能力越强，越需要约束 |
| | S017 | Bash 四层安全管线：逐层收紧，不是替代 |
| | S018 | 权限、沙箱、断路器：最终执行权怎么裁决 |
| | S019 | 第二节闭环：我们解决了哪一个生产问题 |

## 交互说明

### 全局导航

| 操作 | 行为 |
|---|---|
| `→` / `Space` / 鼠标滚轮下滚 | 下一页 |
| `←` / 鼠标滚轮上滚 | 上一页 |
| `M` 或 toolbar 「目录」 | 打开左侧目录抽屉 |
| `T` 或 toolbar 「钢笔」 | 切换钢笔批注模式 |
| `D` 或 toolbar 「画板」 | 切换画板模式 |
| `C` 或 toolbar 「颜色」 | 切换批注颜色 |
| `F` 或 toolbar 「全屏」 | 切换全屏 |

URL 哈希同步当前页：`#3` 表示第 4 页（0-based）。

### 每页交互（按页索引）

**重交互页（点击/拖动 state machine）**：

- **S004**：3 列联动（代码↔节点↔风险）+ 3 按钮（运行一轮 / 单步 / 重置）
- **S005**：8 层叠加（逐层叠加 / 重置 + 点击已激活胶囊切换详情）
- **S006**：5 panel 双向 hover 联动 + 4 秒重播入场动画
- **S007**：串行 420ms vs 并行 135ms 真实时序 bar 动画 + 重播
- **S008**：6 step state machine + 3 按钮 + 任意跳转
- **S008b**：4 案例点击切换（朴素 vs Claude Code 双判断对比）
- **S009**：12 卡片双轨切换（左 6 工具 / 中 6 字段）
- **S010**：7 step 点击切换详情
- **S011**：点击 Skill 卡直接加载 SKILL.md body + Token bar 同步跳变
- **S012**：3 source × 4 transport 双向联动
- **S013**：3 场景 ↔ 3 能力卡同步高亮 + 其他 dim
- **S014**：左 manifest 4 字段 ↔ 右 4 Registry 双向联动
- **S015**：5 step state machine + 自动播放（每 1200ms）+ 重置
- **S016**：4 数字 count-up 入场 + 重播
- **S017**：4 闸门可点击 + 同步左 4 层卡 + 右详情切换
- **S018**：3 卡（权限 / 沙箱 / 断路器）点击切换详情
- **S019**：4 问题状态盘点击切换详情

## 技术架构

### 文件树

```
claude-code-source-arch-intro/
├── README.md              # 本文件
├── index.html             # SPA 入口
├── css/
│   └── main.css           # 全局样式 + 设计 token（深海翡翠 P01）
├── js/
│   ├── main.js            # SPA 调度（slideFiles 数组 / 章节 / slideHook 机制）
│   └── interactive.js     # 通用交互工具
└── slides/                # 20 个 slide 片段
    ├── S001-hook-scale.html
    ├── ...
    └── S019-closure.html
```

### SPA 加载机制

`js/main.js` 启动时 `fetch()` 所有 `slides/*.html` 并注入到 `<div id="slide-container">`，每页执行内嵌 `<script>` 注册 `window.__slideHooks['<sid>']` 钩子，切页时调用对应 hook（含 cleanup 闭包防跨页定时器泄漏）。

slide ID 从文件名正则提取（`/\/(S[0-9a-z]+)-/`），支持 `S001` / `S008b` 等字母后缀变体。

### 设计 token

所有视觉用 `var(--*)` token，零 `#hex` 硬编码 / 零 `rgba()`：

| token | 含义 |
|---|---|
| `--primary` | 青色（主色 · 入口/工具/默认强调）|
| `--accent` | 橙色（数字 / hl / 焦点态边框）|
| `--accent-amber-strong` | 黄色（callout 警示 / 强调边框）|
| `--state-success` / `--state-danger` | 绿/红（语义状态）|
| `--card-bg` / `--card-border` / `--bg-deep` / `--bg-surface` | 容器背景与边框 |
| `--text-primary` / `--text-body` / `--text-dim` / `--text-subtle` | 文字四级灰度 |
| `--font-display` / `--font-mono` / `--font-body` | 字体三套 |
| `--glow-primary` | 焦点态光晕 |

### 居中铁律

`.slide` 基类左 7rem padding（避让左侧 fixed toolbar），右 4rem padding。各页 `.sXXX-slide` 用 `padding-right: 7rem !important` 覆盖让左右对称，配合 `max-width: min(1700px, calc(100vw - 14rem))`，内容相对 viewport 几何中心居中。

## 源码事实

所有源码引用基于 **Claude Code v2.1.88** 真实仓库验证，关键锚点：

| 概念 | 源码位置 |
|---|---|
| QueryLoop 主循环 | `src/query.ts` / `src/QueryEngine.ts` |
| `stop_reason === 'tool_use' is unreliable` 注释 | `src/query.ts:554` / `src/utils/messages.ts:834` |
| isToolUseRequestMessage（结构化判断） | `src/utils/messages.ts:829-836` |
| Tool 协议接口 | `src/Tool.ts` |
| 6 工具 name 常量 | `src/tools/FileReadTool/` / `BashTool/` / `GrepTool/` / `FileEditTool/` / `MCPTool/` / `SkillTool/` |
| MCP 命名前缀 `mcp__<server>__<tool>` | `src/services/mcp/utils.ts:40` |
| 5 层权限优先级 SETTING_SOURCES | `src/utils/settings/constants.ts` |
| 行为评估 deny > ask > allow | `src/types/permissions.ts` |
| LLM 分类器三证据 | `src/utils/permissions/yoloClassifier.ts:31/33/784/871/1145/1346` |
| 断路器 DENIAL_LIMITS | `src/utils/permissions/denialTracking.ts:12` |
| Bash 安全管线 2592 行 / 23 检查 / 18 ZSH | `src/tools/BashTool/bashSecurity.ts` |

## 课件特性

- **0 后端依赖**：纯前端，HTTP 服务器即可
- **响应式**：clamp() 字号 + grid + flex，1280px 起向上自适应
- **0 控制台错误 / 0 页面错误**：所有页 Playwright 真鼠标交互验证通过
- **真实时序动画**：S007 左右 bar 动画严格按 420ms / 135ms 1:1 还原
- **真实源码引用**：所有数字 / 字段 / 函数名经源码 grep 验证

## 故障排查

| 现象 | 原因 | 解决 |
|---|---|---|
| 白屏 / slide 不加载 | `file://` 协议下 fetch 被 CORS 拦截 | 启动 HTTP 服务器（见上）|
| 数字动画不滚动 | 浏览器禁用了 RAF | 检查浏览器版本（Chrome ≥90）|
| 钢笔/画板无响应 | toolbar 按钮 onclick 异常 | 打开 DevTools 看 console |
| 标题偏右 24px | `.sXXX-slide` 未覆盖 padding-right | 检查该页是否声明 `padding-right: 7rem !important` |

## 许可与致谢

本课件为教学用途，源码引用遵循 Claude Code 开源协议。
