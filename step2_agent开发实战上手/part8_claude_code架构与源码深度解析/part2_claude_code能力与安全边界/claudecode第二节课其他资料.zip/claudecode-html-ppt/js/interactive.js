/* ============================================================
   交互引擎 · 🔴🔴 S004 / S011 hookFn（interactive-eng 内联）
   §三.9 GSAP 安全模板：fromTo / paused:true / return cleanup 闭包
   FM 防御 1:1 标注 // ←FM{n}，对应 interaction_architecture.md §🔴🔴 失败模式预防清单
   ============================================================ */
(function () {
  'use strict';
  window.__slideHooks = window.__slideHooks || {};

  /* ===================================================================
     S004 · QueryLoop 调用循环全景（环形时序动画 · 单步/自动播放）
     FM-1: 自动播放定时器跨 slide 未清理 → cleanup 中清 interval + killTweensOf
     FM-2: "结果回注→再进入" 第二圈未重置 → 每圈起点显式 reset 所有节点
     FM-3: 单步连点越界 → step 索引 clamp 到 [0, len]
     =================================================================== */
  window.__slideHooks['S004'] = function (slideEl) {
    if (!slideEl) return;
    var stage = slideEl.querySelector('#s004-stage');
    var nodeGroups = Array.prototype.slice.call(slideEl.querySelectorAll('.s004-node-g'))
      .sort(function (a, b) { return +a.getAttribute('data-node') - +b.getAttribute('data-node'); });
    var labels = slideEl.querySelectorAll('.s004-node-label');
    var btnStep = slideEl.querySelector('#s004-step');
    var btnPlay = slideEl.querySelector('#s004-play');
    var btnReset = slideEl.querySelector('#s004-reset');
    var cT = slideEl.querySelector('#s004-c-t');
    var cS = slideEl.querySelector('#s004-c-s');
    var cRound = slideEl.querySelector('#s004-c-round');
    var capN = slideEl.querySelector('#s004-cap-n');
    var capR = slideEl.querySelector('#s004-cap-r');

    var NODES = [
      { t: '① 用户输入', s: '你敲下一句话回车' },
      { t: '② 预处理', s: 'normalize / prepend / autoCompact / ToolSearch' },
      { t: '③ API 流式响应', s: '消息发往模型端，流式接收' },
      { t: '④ tool_use + 权限闸', s: '若需工具：过统一管道 + deny→allow→mode→HITL' },
      { t: '⑤ 工具执行', s: '权限通过后真正执行工具' },
      { t: '⑥ 结果回注', s: '工具结果拼回上下文 → 再进入一圈' }
    ];
    var LEN = NODES.length;
    var step = 0;     // 0 = 未开始；1..LEN = 已点亮到第 N 个
    var round = 1;
    var playing = false;
    var timer = null; // ←FM1 自动播放定时器句柄，cleanup 必清

    function resetVisual() {
      // ←FM2 每圈/重置：显式清空所有节点 class，防第二圈高亮叠加
      nodeGroups.forEach(function (g) { g.classList.remove('active'); });
      labels.forEach(function (l) { l.classList.remove('active'); });
    }

    function render() {
      resetVisual();
      for (var i = 0; i < step && i < LEN; i++) {
        nodeGroups[i].classList.add('active');
        if (labels[i]) labels[i].classList.add('active');
      }
      var idx = Math.min(Math.max(step - 1, 0), LEN - 1); // ←FM3 索引 clamp 防越界
      if (step === 0) {
        cT.textContent = '点「下一步 / 自动播放」开始';
        cS.textContent = '看一次对话如何走完一圈';
        cRound.textContent = '';
      } else {
        cT.textContent = NODES[idx].t;
        cS.textContent = NODES[idx].s;
        cRound.textContent = (step >= LEN) ? '⑥ 结果回注 ↩ 第 ' + round + ' 圈完成，可继续下一圈' : '第 ' + round + ' 圈进行中';
      }
      capN.textContent = Math.min(step, LEN);
      capR.textContent = round;
      btnReset.disabled = (step === 0 && round === 1);
      btnStep.textContent = (step >= LEN) ? '下一圈 ↻' : '下一步 ▸';
    }

    function advance() {
      if (step < LEN) {
        step++;                       // ←FM3 只在 < LEN 时自增
      } else {
        // 完成一圈 → 结果回注 → 再进入：round+1，step 归零重播（FM-2 显式 reset）
        round++;
        step = 1;
        resetVisual();                // ←FM2 进入新圈前强制 reset
      }
      render();
    }

    function onStep() {
      if (playing) return; // 播放中禁手动，避免双驱动竞态
      advance();
    }
    function onReset() {
      stopPlay();
      step = 0; round = 1;
      render();
    }
    function startPlay() {
      if (playing) return;
      playing = true;
      btnPlay.textContent = '暂停 ⏸';
      btnStep.disabled = true;
      if (step >= LEN) { step = 0; round = round; } // 从头播
      timer = setInterval(function () {
        advance();
        if (step >= LEN && round >= 2) { /* 已演示回注循环至少 2 圈，停在第 2 圈末 */ stopPlay(); }
      }, 1100);
    }
    function stopPlay() {
      playing = false;
      if (timer) { clearInterval(timer); timer = null; } // ←FM1 清定时器
      btnPlay.textContent = '自动播放 ▶';
      btnStep.disabled = false;
    }
    function onPlay() { if (playing) stopPlay(); else startPlay(); }

    btnStep.addEventListener('click', onStep);
    btnPlay.addEventListener('click', onPlay);
    btnReset.addEventListener('click', onReset);

    // 进场：GSAP fromTo（§三.9 禁 gsap.from）
    if (window.gsap) {
      gsap.killTweensOf(stage);
      gsap.fromTo(stage, { opacity: 0, scale: 0.94 }, { opacity: 1, scale: 1, duration: 0.6, ease: 'power2.out' });
    }
    render();

    // ←FM1 cleanup：清定时器 + killTweensOf + 解绑，防跨 slide 改已卸载 DOM
    return function cleanup() {
      stopPlay();
      if (window.gsap) gsap.killTweensOf(stage);
      btnStep.removeEventListener('click', onStep);
      btnPlay.removeEventListener('click', onPlay);
      btnReset.removeEventListener('click', onReset);
    };
  };

  /* ===================================================================
     S011 · 15 设计模式选择器 + 详情 + 内置 mini 循环缩略图回指
     FM-1: 快速连点详情竞态 → currentId 守卫，渲染前比对 id
     FM-2: 回指引用 S004 DOM 报错 → mini 循环图自带在 S011 内，不跨 slide querySelector
     FM-3: 初始无选中空白无引导 → 默认选中第 1 组第 1 项并渲染
     =================================================================== */
  var LOOP_NODES = ['输入', '预处理', 'API流式', 'tool_use', '工具执行', '结果回注'];

  var PATTERNS = [
    { g: '输入与上下文', items: [
      { id: 'P1', name: 'Pipeline 管道', node: 1, body: '把预处理拆成 normalize→prepend→compact→toolsearch 的<b>固定有序流水线</b>，每步单一职责。', why: '让"整理输入"这个复杂动作可组合、可单测、可在循环里稳定复现。' },
      { id: 'P2', name: 'Lazy Compaction 惰性压缩', node: 1, body: '只在历史 token 超阈值时才触发 autoCompact，平时<b>零开销</b>。', why: '循环每圈都过预处理，惰性触发避免给高频路径加固定成本。' },
      { id: 'P3', name: 'Context Injection 上下文注入', node: 1, body: 'prependUserContext 把项目信息<b>声明式拼到消息头部</b>，而非散落各处。', why: '让"模型知道自己在哪个项目"这件事有单一可控注入点。' }
    ]},
    { g: 'API 流式段', items: [
      { id: 'P4', name: 'Streaming 流式处理', node: 2, body: '不等模型整段返回，<b>边收边处理</b> tool_use 信号。', why: '循环要尽早识别"该调工具了"，流式让响应延迟最小化。' },
      { id: 'P5', name: 'State Machine 状态机', node: 2, body: '一圈循环的"输入/等待/工具/回注"用<b>显式状态机</b>驱动而非散乱标志位。', why: '"结果回注→再进入"这种环形流程，状态机才不会乱。' },
      { id: 'P6', name: 'Backpressure 背压', node: 2, body: '流式消费速度跟不上时<b>反向限流</b>，不无限堆积。', why: '保护循环不被超长响应拖垮，稳定性优先。' }
    ]},
    { g: 'tool_use 与权限', items: [
      { id: 'P7', name: 'Unified Registry 统一注册表', node: 3, body: '内置/MCP/Skill 工具<b>登记进同一张表</b>，对循环表现一致。', why: 'S006 的"42 不是 42 个独立功能"正源于此——一个收敛入口。' },
      { id: 'P8', name: 'Fully-Qualified Name 完全限定名', node: 3, body: 'MCP tool 加 <b>mcp__server__tool</b> 前缀消除命名冲突。', why: '让外部工具无歧义地复用同一条 tool_use 管道。' },
      { id: 'P9', name: 'Defense in Depth 纵深防御', node: 3, body: '权限是 <b>deny→allow→mode→HITL</b> 四级闸而非单 if。', why: '能力越开放越需要分层收敛，最后一道永远交还给人。' },
      { id: 'P10', name: 'Human-in-the-Loop', node: 3, body: '前三级无定论时<b>把决定权弹回给人</b>。', why: '自动化与安全的张力，靠人工兜底这个节点平衡。' }
    ]},
    { g: '执行与回注', items: [
      { id: 'P11', name: 'Sandbox Isolation 沙箱隔离', node: 4, body: '工具执行限制在受控环境，副作用<b>不外溢</b>。', why: '执行节点是循环里最危险的一步，隔离是底线。' },
      { id: 'P12', name: 'Result Feedback 结果回注', node: 5, body: '工具结果<b>结构化拼回上下文</b>，触发下一圈。', why: '这正是"循环"之所以是循环的关键一步。' },
      { id: 'P13', name: 'Idempotent Retry 幂等重试', node: 4, body: '可重试工具设计成<b>多次执行结果一致</b>。', why: '回注循环可能重入，幂等保证重试不产生脏数据。' }
    ]},
    { g: '跨循环协调', items: [
      { id: 'P14', name: 'Fork/Sub-loop 子循环派生', node: 5, body: 'Agent/Skill fork 出<b>隔离的子调用循环</b>，跑完回注主循环。', why: '主循环高效与子任务隔离的张力，靠派生子循环平衡。' },
      { id: 'P15', name: 'Coordinator 主从协调', node: 5, body: 'coordinator <b>派生→等待→回收</b>子循环结果。', why: '让"一圈套一圈"有统一的协调者，不失控。' }
    ]}
  ];

  window.__slideHooks['S011'] = function (slideEl) {
    if (!slideEl) return;
    var listEl = slideEl.querySelector('#s011-list');
    var detailEl = slideEl.querySelector('#s011-detail');
    var currentId = null; // ←FM1 竞态守卫

    // 渲染左侧分组列表（FM-3：保证有内容、有 hover 态）
    var lh = '';
    PATTERNS.forEach(function (grp) {
      lh += '<div class="s011-group-h">' + grp.g + '</div>';
      grp.items.forEach(function (it) {
        lh += '<div class="s011-item" data-id="' + it.id + '">' +
          '<span class="it-id">' + it.id + '</span>' +
          '<span class="it-name">' + it.name + '</span></div>';
      });
    });
    listEl.innerHTML = lh;

    var flat = [];
    PATTERNS.forEach(function (g) { g.items.forEach(function (i) { flat.push(i); }); });

    function findItem(id) {
      for (var i = 0; i < flat.length; i++) if (flat[i].id === id) return flat[i];
      return null;
    }

    function renderDetail(id) {
      currentId = id;                 // ←FM1 先占位
      var it = findItem(id);
      if (!it) return;
      // ←FM1 异步竞态守卫：渲染前确认 currentId 仍是本次 id（同步渲染此处天然安全，仍保留守卫语义）
      if (currentId !== id) return;
      // ←FM2 mini 循环图在 S011 内自带渲染，不 querySelector S004 的 DOM
      var miniHtml = '';
      LOOP_NODES.forEach(function (n, idx) {
        miniHtml += '<span class="s011-mini-node' + (idx === it.node ? ' hl' : '') + '">' + n + '</span>';
        if (idx < LOOP_NODES.length - 1) miniHtml += '<span class="s011-mini-arr">▸</span>';
      });
      detailEl.innerHTML =
        '<div class="s011-d-head"><span class="s011-d-name">' + it.name + '</span>' +
        '<span class="s011-d-tag">' + it.id + ' · 作用于「' + LOOP_NODES[it.node] + '」节点</span></div>' +
        '<div class="s011-d-body">' + it.body + '</div>' +
        '<div class="s011-d-why">' + it.why + '</div>' +
        '<div class="s011-mini">' +
        '<div class="s011-mini-cap">在调用循环中的位置 —— <b>' + LOOP_NODES[it.node] + '</b> 节点高亮：</div>' +
        '<div class="s011-mini-loop">' + miniHtml + '</div></div>';
      listEl.querySelectorAll('.s011-item').forEach(function (el) {
        el.classList.toggle('active', el.getAttribute('data-id') === id);
      });
    }

    function onListClick(e) {
      var item = e.target.closest('.s011-item');
      if (!item) return;
      // ←FM1 每次选择前同步清面板再渲染，避免快速连点残留
      detailEl.innerHTML = '';
      renderDetail(item.getAttribute('data-id'));
    }
    listEl.addEventListener('click', onListClick);

    // ←FM3 初始默认选中第 1 组第 1 项并渲染详情（防空白无引导）
    renderDetail(flat[0].id);

    if (window.gsap) {
      gsap.killTweensOf(detailEl);
      gsap.fromTo(detailEl, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.5, ease: 'power2.out' });
    }

    return function cleanup() {
      if (window.gsap) gsap.killTweensOf(detailEl);
      listEl.removeEventListener('click', onListClick);
    };
  };
})();
