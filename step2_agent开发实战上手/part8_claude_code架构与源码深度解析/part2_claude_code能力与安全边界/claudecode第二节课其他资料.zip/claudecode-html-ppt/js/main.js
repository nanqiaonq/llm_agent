/* ============================================================
   Claude Code 源码架构入门 · 骨架运行时
   回引 REF_golden_patterns.md §一：
   §一.1 画笔拖尾 (FADE_MS 时间衰减 + quadraticCurveTo + _hexToRgba)
   §一.2 画板 (D 键开启 / 再按 D 或 Esc 清后退)
   §一.3 颜色选择器 (4 色 / currentDrawColor 共享 / 点外关闭)
   §一.4 目录分组 (从 slide_structure chapters 渲染分组+缩进子项+当前页高亮)
   §一.5 工具栏五件套 (M/T/D/颜色/F · 每按钮有 onclick)
   §三.9 slideHook 机制 (return cleanup 闭包，供 interactive.js S004/S011)
   ============================================================ */

(function () {
  'use strict';

  /* ---- 章节/页面元数据（由 builder 从 slide_structure.json 内联，目录分组铁律 §一.4）---- */
  var CHAPTERS = [
    { id: 'C00', title: '钩子与全景', slides: ['S001', 'S002'] },
    { id: 'C01', title: '心智模型与朴素 Agent', slides: ['S003', 'S004'] },
    { id: 'C02', title: '工业级运行时：架构 + 性能', slides: ['S005', 'S006', 'S007'] },
    { id: 'C03', title: '循环内部：全景 + 可靠 + Tool', slides: ['S008', 'S008b', 'S009', 'S010'] },
    { id: 'C04', title: '扩展接入：Skill / MCP / Hook / Plugin / SystemPrompt', slides: ['S011', 'S012', 'S013', 'S014', 'S015'] }
  ];
  var SLIDE_FILES = [
    'slides/S001-hook-scale.html',
    'slides/S002-nine-layer-overview.html',
    'slides/S003-entry-main-tsx.html',
    'slides/S004-queryloop-core.html',
    'slides/S005-preprocess-detail.html',
    'slides/S006-tool-pipeline.html',
    'slides/S007-permission-gate.html',
    'slides/S008-mcp-bridge.html',
    'slides/S008b-reliability.html',
    'slides/S009-skill-command.html',
    'slides/S010-agent-subloop.html',
    'slides/S011-design-patterns-selector.html',
    'slides/S012-summary-methodology.html',
    'slides/S013-extension-trinity.html',
    'slides/S014-plugin-manifest.html',
    'slides/S015-system-prompt.html',
    'slides/S016-safety-overview.html',
    'slides/S017-bash-pipeline.html',
    'slides/S018-permission-sandbox-breaker.html',
    'slides/S019-closure.html'
  ];
  var SLIDE_TITLES = [
    '从 QueryLoop 到安全管线（封面）',
    '源码快照：Claude Code v2.1.88',
    '1.6% vs 98.4%：工业级 Agent 的重心',
    '30 行朴素 Agent：能跑，但不敢用',
    '为什么 51 万行 Claude Code 源码值得读',
    'Claude Code 全局架构图',
    '入口 main.tsx：并行预取把 420ms 压到 135ms',
    'QueryLoop 全景：一次对话如何转圈',
    'QueryLoop 可靠性：不只看 stop_reason',
    'Tool 契约：40+ 工具为什么能统一调用',
    'Tool 执行链：从 tool_use 到 tool_result',
    'Skill：知识的渐进式披露',
    'MCP：外部能力如何变成标准 Tool',
    '扩展三件套：know / do / intercept',
    'Plugin：三件套的打包清单',
    'System Prompt：能力碎片如何组装成上下文',
    '安全总览：能力越强，越需要约束',
    'Bash 四层安全管线：逐层收紧，不是替代',
    '权限、沙箱、断路器：最终执行权怎么裁决',
    '第二节闭环：我们解决了哪一个生产问题'
  ];

  var current = 0;
  var total = SLIDE_FILES.length;
  var slideEls = [];
  var currentCleanup = null; // §三.9 当前页 cleanup 闭包

  /* ====== Slide 注入/切换 ====== */
  var container = document.getElementById('slide-container');

  function loadSlides() {
    var loaded = 0;
    SLIDE_FILES.forEach(function (path, idx) {
      fetch(path)
        .then(function (r) { return r.ok ? r.text() : '<div class="slide"><h1 style="color:#ff7b72">缺页 ' + path + '</h1></div>'; })
        .then(function (html) {
          var wrap = document.createElement('div');
          wrap.innerHTML = html;
          // slide 内容根节点：取第一个 .slide，没有就包一层
          var el = wrap.querySelector('.slide');
          if (!el) {
            el = document.createElement('div');
            el.className = 'slide';
            el.innerHTML = html;
          }
          el.setAttribute('data-idx', idx);
          el.id = 'slide-' + idx;
          slideEls[idx] = { el: el, raw: wrap };
          loaded++;
          if (loaded === total) finalizeSlides();
        })
        .catch(function () {
          var el = document.createElement('div');
          el.className = 'slide';
          el.innerHTML = '<h1 style="color:#ff7b72">加载失败 ' + path + '</h1>';
          el.id = 'slide-' + idx;
          slideEls[idx] = { el: el, raw: null };
          loaded++;
          if (loaded === total) finalizeSlides();
        });
    });
  }

  function finalizeSlides() {
    for (var i = 0; i < total; i++) {
      if (slideEls[i]) {
        // 将 slide 内 <style> 提到 head（保证作用域生效）
        var raw = slideEls[i].raw;
        if (raw) {
          var styles = raw.querySelectorAll('style');
          styles.forEach(function (s) { document.head.appendChild(s); });
          // 将 slide 内 <script> 收集，激活时再执行
          var scripts = raw.querySelectorAll('script');
          slideEls[i].scripts = Array.prototype.slice.call(scripts);
        }
        container.appendChild(slideEls[i].el);
      }
    }
    buildMenu();
    var hash = parseInt((location.hash || '').replace('#', ''), 10);
    goTo(isNaN(hash) ? 0 : Math.min(Math.max(hash, 0), total - 1), true);
  }

  function runSlideScripts(idx) {
    var entry = slideEls[idx];
    if (!entry || !entry.scripts || entry._scriptsRun) return;
    entry.scripts.forEach(function (oldS) {
      var s = document.createElement('script');
      if (oldS.src) { s.src = oldS.src; } else { s.textContent = oldS.textContent; }
      document.body.appendChild(s);
    });
    entry._scriptsRun = true;
  }

  /* §三.9 slideHook 机制：interactive.js 注册 window.__slideHooks[slideId] = fn
     fn 返回 cleanup 闭包；切页时调用上一页 cleanup（GSAP killTweensOf / clearInterval） */
  window.__slideHooks = window.__slideHooks || {};

  function goTo(idx, instant) {
    if (idx < 0 || idx >= total) return;
    // ── 切页前：执行上一页 cleanup（§三.9 / S004 FM-1 防跨页定时器）──
    if (typeof currentCleanup === 'function') {
      try { currentCleanup(); } catch (e) { console.warn('[cleanup]', e); }
      currentCleanup = null;
    }
    slideEls.forEach(function (s, i) {
      if (s && s.el) s.el.classList.toggle('active', i === idx);
    });
    current = idx;
    location.hash = idx;
    updateProgress();
    updateMenuCurrent();
    runSlideScripts(idx);
    // ── 切页后：执行本页 slideHook，保存 cleanup ──
    // 从文件名解析 sid，支持 S001 / S008b / S012 等字母后缀变体
    var sidMatch = SLIDE_FILES[idx] && SLIDE_FILES[idx].match(/\/(S[0-9a-z]+)-/);
    var sid = sidMatch ? sidMatch[1] : 'S' + String(idx + 1).padStart(3, '0');
    setTimeout(function () {
      var hook = window.__slideHooks[sid];
      if (typeof hook === 'function') {
        try {
          var ret = hook(slideEls[idx] && slideEls[idx].el);
          if (typeof ret === 'function') currentCleanup = ret;
        } catch (e) { console.warn('[slideHook ' + sid + ']', e); }
      }
    }, instant ? 0 : 80);
  }

  function updateProgress() {
    var pb = document.getElementById('progress-bar');
    if (pb) pb.style.width = ((current + 1) / total * 100) + '%';
    var pi = document.getElementById('page-indicator');
    if (pi) pi.innerHTML = '<span class="cur">' + (current + 1) + '</span> / ' + total;
  }

  /* ====== §一.4 目录分组（chapter 分组 + 缩进子项 + 当前页高亮）====== */
  function buildMenu() {
    var panel = document.getElementById('menu-list');
    if (!panel) return;
    var html = '';
    var globalIdx = 0;
    CHAPTERS.forEach(function (ch) {
      // 分组标题（蓝色粗体 · 不可点击）§一.4 规则2/5
      html += '<div class="menu-chapter">' + ch.title + '</div>';
      ch.slides.forEach(function (sid) {
        var idx = parseInt(sid.replace('S', ''), 10) - 1;
        // 缩进子项（序号 + 标题 · 可点击）§一.4 规则3/5
        html += '<div class="menu-item" data-idx="' + idx + '">' +
          '<span class="mi-num">' + String(idx + 1).padStart(2, '0') + '</span>' +
          '<span class="mi-title">' + (SLIDE_TITLES[idx] || sid) + '</span></div>';
        globalIdx++;
      });
    });
    panel.innerHTML = html;
    panel.querySelectorAll('.menu-item').forEach(function (item) {
      item.addEventListener('click', function () {
        goTo(parseInt(item.getAttribute('data-idx'), 10));
        closeMenu();
      });
    });
  }
  function updateMenuCurrent() {
    var items = document.querySelectorAll('#menu-list .menu-item');
    items.forEach(function (it) {
      it.classList.toggle('current', parseInt(it.getAttribute('data-idx'), 10) === current);
    });
  }
  function openMenu() { document.getElementById('menu-overlay').classList.add('show'); }
  function closeMenu() { document.getElementById('menu-overlay').classList.remove('show'); }

  /* ====== §一.1 画笔拖尾（FADE_MS 时间衰减 + quadraticCurveTo + _hexToRgba）====== */
  var FADE_MS = 1200;
  var penCanvas = document.getElementById('pen-canvas');
  var penCtx = penCanvas.getContext('2d');
  var penEnabled = false;
  var penTrails = [];
  var penDrawing = false;
  var lastPt = null;
  var currentDrawColor = '#ef4444'; // §一.3 共享变量

  function resizeCanvases() {
    [penCanvas, document.getElementById('board-canvas')].forEach(function (c) {
      c.width = window.innerWidth;
      c.height = window.innerHeight;
    });
  }
  resizeCanvases();
  window.addEventListener('resize', resizeCanvases);

  function _hexToRgba(hex, a) {
    var h = hex.replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var r = parseInt(h.substr(0, 2), 16),
        g = parseInt(h.substr(2, 2), 16),
        b = parseInt(h.substr(4, 2), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  function penDown(e) {
    if (!penEnabled) return;
    penDrawing = true;
    lastPt = { x: e.clientX, y: e.clientY };
  }
  function penMove(e) {
    if (!penEnabled || !penDrawing) return;
    var p = { x: e.clientX, y: e.clientY };
    penTrails.push({ a: lastPt, b: p, t: performance.now(), color: currentDrawColor });
    lastPt = p;
  }
  function penUp() { penDrawing = false; lastPt = null; }

  function animatePenTrail() {
    penCtx.clearRect(0, 0, penCanvas.width, penCanvas.height);
    var now = performance.now();
    penTrails = penTrails.filter(function (s) { return now - s.t < FADE_MS; });
    penTrails.forEach(function (s) {
      var age = (now - s.t) / FADE_MS;
      var alpha = 1 - age; // §一.1 时间衰减
      penCtx.strokeStyle = _hexToRgba(s.color, alpha);
      penCtx.lineWidth = 3;
      penCtx.lineCap = 'round';
      penCtx.beginPath();
      penCtx.moveTo(s.a.x, s.a.y);
      var mx = (s.a.x + s.b.x) / 2, my = (s.a.y + s.b.y) / 2;
      penCtx.quadraticCurveTo(s.a.x, s.a.y, mx, my); // §一.1 平滑曲线
      penCtx.lineTo(s.b.x, s.b.y);
      penCtx.stroke();
    });
    requestAnimationFrame(animatePenTrail);
  }
  requestAnimationFrame(animatePenTrail);

  /* ====== §一.2 画板（D 键开启 / 笔迹永久保留 / 再按 D 或 Esc 清后退）====== */
  var boardCanvas = document.getElementById('board-canvas');
  var boardCtx = boardCanvas.getContext('2d');
  var boardEnabled = false;
  var boardDrawing = false;
  var boardLast = null;

  function clearDrawBoard() { boardCtx.clearRect(0, 0, boardCanvas.width, boardCanvas.height); }
  function boardDown(e) { if (!boardEnabled) return; boardDrawing = true; boardLast = { x: e.clientX, y: e.clientY }; }
  function boardMove(e) {
    if (!boardEnabled || !boardDrawing) return;
    boardCtx.strokeStyle = currentDrawColor;
    boardCtx.lineWidth = 3;
    boardCtx.lineCap = 'round';
    boardCtx.beginPath();
    boardCtx.moveTo(boardLast.x, boardLast.y);
    boardCtx.lineTo(e.clientX, e.clientY);
    boardCtx.stroke();
    boardLast = { x: e.clientX, y: e.clientY };
  }
  function boardUp() { boardDrawing = false; boardLast = null; }

  document.addEventListener('mousedown', function (e) { penDown(e); boardDown(e); });
  document.addEventListener('mousemove', function (e) { penMove(e); boardMove(e); });
  document.addEventListener('mouseup', function () { penUp(); boardUp(); });

  /* ====== §一.5 工具栏五件套（每按钮有 onclick）====== */
  function toggleMenu() {
    var ov = document.getElementById('menu-overlay');
    if (ov.classList.contains('show')) closeMenu(); else openMenu();
  }
  function togglePen() {
    penEnabled = !penEnabled;
    if (penEnabled && boardEnabled) toggleBoard(); // 互斥
    document.getElementById('btn-pen').classList.toggle('active', penEnabled);
    penCanvas.style.pointerEvents = 'none'; // 拖尾用全局监听不拦点击
    showHint(penEnabled ? 'pen' : null);
  }
  function toggleBoard() {
    if (boardEnabled) {
      // §一.2 清后退：先 clearDrawBoard 再关闭
      clearDrawBoard();
      boardEnabled = false;
      document.body.classList.remove('draw-mode');
      showHint(null);
    } else {
      boardEnabled = true;
      if (penEnabled) togglePen();
      document.body.classList.add('draw-mode');
      showHint('board');
    }
    document.getElementById('btn-board').classList.toggle('active', boardEnabled);
  }
  function toggleColorPicker() {
    document.getElementById('color-picker').classList.toggle('show');
  }
  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      (document.documentElement.requestFullscreen || function () {}).call(document.documentElement);
    } else if (document.exitFullscreen) {
      document.exitFullscreen();
    }
    document.getElementById('btn-fs').classList.toggle('active');
  }

  function showHint(mode) {
    var h = document.getElementById('keyboard-hint');
    if (!mode) { h.classList.remove('show'); return; }
    if (mode === 'pen') h.innerHTML = '钢笔模式 · 按住拖动绘制 · <span class="k">T</span> 关闭';
    if (mode === 'board') h.innerHTML = '画板模式 · 拖动绘制（永久保留）· <span class="k">D</span>/<span class="k">Esc</span> 清除并退出';
    h.classList.add('show');
  }

  /* ====== §一.3 颜色选择器（点外关闭 + 选中白圈）====== */
  function selectColor(hex, dotEl) {
    currentDrawColor = hex;
    document.querySelectorAll('.color-dot').forEach(function (d) { d.classList.remove('selected'); });
    if (dotEl) dotEl.classList.add('selected');
  }
  document.addEventListener('click', function (e) {
    var cp = document.getElementById('color-picker');
    var cb = document.getElementById('btn-color');
    if (cp.classList.contains('show') && !cp.contains(e.target) && !cb.contains(e.target)) {
      cp.classList.remove('show');
    }
  });

  /* ====== 键盘导航 + 工具快捷键 ====== */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') { e.preventDefault(); goTo(current + 1); }
    else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); goTo(current - 1); }
    else if (e.key === 'Home') goTo(0);
    else if (e.key === 'End') goTo(total - 1);
    else if (e.key === 'm' || e.key === 'M') toggleMenu();
    else if (e.key === 't' || e.key === 'T') togglePen();
    else if (e.key === 'd' || e.key === 'D') toggleBoard();
    else if (e.key === 'f' || e.key === 'F') toggleFullscreen();
    else if (e.key === 'Escape') {
      if (document.getElementById('menu-overlay').classList.contains('show')) closeMenu();
      else if (boardEnabled) toggleBoard();
      else if (penEnabled) togglePen();
    }
  });

  // 暴露给 index.html onclick（§一.5 工具栏按钮 onclick 硬约束 + 事故 I3）
  window.CC = {
    toggleMenu: toggleMenu,
    togglePen: togglePen,
    toggleBoard: toggleBoard,
    toggleColorPicker: toggleColorPicker,
    toggleFullscreen: toggleFullscreen,
    selectColor: selectColor,
    closeMenu: closeMenu,
    goTo: goTo
  };

  document.addEventListener('DOMContentLoaded', loadSlides);
  if (document.readyState !== 'loading') loadSlides();
})();
